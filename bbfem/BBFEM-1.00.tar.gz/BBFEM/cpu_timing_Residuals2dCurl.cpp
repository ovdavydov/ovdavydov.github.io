#include <stdio.h>
#include <math.h>
#include <time.h>
#include <iostream>


#ifdef MEX_stroud_bary2d
#include <mex.h>
#endif

#ifdef MEX_stroud_bary2dw
#include <mex.h>
#endif


#ifdef MEX_stiff
#include <mex.h>
#endif

#include "bbfem.h"
#include "bbfem2dCurl.h"


#ifndef MAX
#define MAX(a,b) ( (a) > (b) ? (a) : (b) )
#endif



// example of stiffness matrix coefficients
double 
A0 (double v[2])
{
	return 2.0 - sin(v[0]*v[1]);
}

// mass matrix coefficient example
void
Kappa0 (double v[2], double matC[2][2])
{
//   matC[0][0] = 1;
//   matC[0][1] = 0;
//   matC[1][0] = 0;
//   matC[1][1] = 1;
	
	// non-standard coefficient example
  matC[0][0] =  10.0 + v[0];
  matC[0][1] =  v[1] * v[0] * v[0];
  matC[1][0] =  v[1] * v[0] * v[0];
  matC[1][1] =  2.0 - sin(v[0]*v[1]);	
}

// load vector coefficient example
void 
F0( double v[2], double vectF[2] )
{
	vectF[0] = sin(v[0]*v[1]);
	vectF[1] = 1 - v[0]*v[1];
}



///////////// cpu timing for residual computation //////////////////////

// WARNING: only used with n>1
#ifdef PRECOMP
double
time_residual_Comp( int n, int q, double v1[2], double v2[2], double v3[2], 
										double **binomialMat, int nbIter, double average[4])	
#else
double
time_residual_Comp( int n, int q, double v1[2], double v2[2], double v3[2], 
										int nbIter, double average[4])							
#endif
{
	double cpu_time[4]={0,0,0,0};
	
	#ifdef PRECOMP
	double **precomp;	
	double **matValNodes; 
	#else
	double **BmomentInter;
	#endif
	double **Bmoment;
  double **quadraWN;
	double **cBar;
	
	// initialize number of quadrature pointers, and integers needed for indexing Bmoment entries
  int nDash = n ;
  #ifdef PRECOMP
	int mp = MAX (nDash, q-1);  // "precomp" size
  #endif
	int nb_Array = 1;  //scalar-valued coefficients
	int len_Quadra = q + 1;     // space required for storing Jacobi nodes of order q is q, but indexing starts at 1
  quadraWN = create_quadraWN2d(len_Quadra);	
		
	// initialize auxilliary arrays		
	int lenMoments = len_Moments2d(nDash,q);
  Bmoment = create_Bmoment(lenMoments, nb_Array);
	
	#ifdef PRECOMP
	precomp = create_precomp2d(mp+1);	// store precomputed arrays
	int len_matValNodes = q * q ;      // space required for 2D array with dimension q
  matValNodes = create_matValNodes2d(len_matValNodes);
	#else
	BmomentInter = create_Bmoment(lenMoments, nb_Array);
	#endif
	assign_quadra2d(q, quadraWN);	 // initialize quadrature weights and nodes
	
	cBar = create_cBar(n);
	
	int lenRes = dim_nonGradCurl(n);
	double *resVect = new double [lenRes];
	
	
	double *random_Coeff = new double [ n*(n+1)/2 ]; // random_Coeff is endowed with lexicographical order
	
	double **Coeff_p,  **Coeff_pInter; 	
	int M_p = MAX(n-1,q-1);
	int lenCoeff_p = (M_p+1) * (M_p + 1); // Coeff_p and Coeff_pInter are used with position2d2( . , M_p) order
	Coeff_p = create_Coeff( lenCoeff_p, nb_Array );
	Coeff_pInter = create_Coeff( lenCoeff_p, nb_Array );
	
	double **Coeff_u, **Coeff_uInter;
	int M_u = MAX(n-1,q-1);
	int lenCoeff_u= (M_u+1) * (M_u + 1); //Coeff_p and Coeff_pInter are used with position2d2( . , M_u) order
	Coeff_u = create_Coeff( lenCoeff_u, nb_Array );
	Coeff_uInter = create_Coeff( lenCoeff_u, nb_Array );
	
	
	average[0] = average[1] = average[2] = average[3]=0; 
	for (int i=0; i < nbIter; i++)
	{
		#ifdef PRECOMP
		residual_Compute(random_Coeff, Coeff_p, Coeff_pInter, Coeff_u,
										 Coeff_uInter, lenCoeff_p, lenCoeff_u, n, q, 
										 v1, v2, v3, cpu_time,
										 binomialMat, precomp, mp, Bmoment, resVect, 
										 matValNodes, quadraWN, cBar);
		#else
		residual_Compute(random_Coeff, Coeff_p, Coeff_pInter, Coeff_u,
										 Coeff_uInter, lenCoeff_p, lenCoeff_u, n, q, 
										 v1, v2, v3, cpu_time, Bmoment, BmomentInter, 
										 resVect, quadraWN, cBar);
		#endif
		
		
		average[0] += cpu_time[0];
		average[1] += cpu_time[1];
		average[2] += cpu_time[2];
		average[3] += cpu_time[3];
	}
	
	average[0] /= nbIter; // function evaluations at Stroud nodes
	average[1] /= nbIter; // B-moment computations constitutive equation
	average[2] /= nbIter; // B-moment computations conservative equation
	average[3] /= nbIter; // total
	
	
	
	delete_Coeff(Coeff_u); delete_Coeff(Coeff_uInter);
	delete_Coeff(Coeff_p); delete_Coeff(Coeff_pInter);
	
	delete random_Coeff;
	delete_cBar(cBar);
	#ifdef PRECOMP
  delete_precomp(precomp);
	delete_matValNodes(matValNodes);
	#else
	delete_Bmoment(BmomentInter);
  #endif
  
  delete_Bmoment(Bmoment);	
  delete_quadraWN(quadraWN);
	
	delete resVect;
	
	return average[3]; // total cpu timing
}


// WARNING: only used with n>1
void
printTime_residual_Comp( int n0, int n1, double v1[2], double v2[2], double v3[2], int nbIter)	
{
	#ifdef PRECOMP
	int len_binomial = 300;
	double **binomialMat;
  binomialMat = create_BinomialMat(len_binomial); //allocate memory to binomial coefficients
  computeBinomials(binomialMat, len_binomial);  //compute binomials
	#endif
	
	double average[4] = {0,0,0,0};
	
	#ifdef LOG
	int step;	
	step=MAX((int)(n0/1.5),1);
  for (int n=n0; n<=n1; n += step, step=MAX((int)(n/1.5),1))
  {
		int q = n+1;
		#ifdef PRECOMP
		time_residual_Comp( n, q, v1, v2, v3, binomialMat, nbIter, average);
		#else
		time_residual_Comp( n, q, v1, v2, v3, nbIter, average);
		#endif
		fprintf(stderr," n= %d, eval cpu = %e, Res. constit. = %e, Res. conserv. = %e, total cpu = %e\n", n, average[0], average[1], average[2], average[3] );
  }
  #else
  std::cout << "[";
  for (int n=n0; n< n1; n++ )
  {
		int q = n+1;
		#ifdef PRECOMP
		time_residual_Comp( n, q, v1, v2, v3, binomialMat, nbIter, average);
		#else
		time_residual_Comp( n, q, v1, v2, v3, nbIter, average);
		#endif
		std::cout << average[3] << ",";
  }
  int q = n1+1;
	#ifdef PRECOMP
	time_residual_Comp( n1, q, v1, v2, v3, binomialMat, nbIter, average);
	#else
	time_residual_Comp( n1, q, v1, v2, v3, nbIter, average);
	#endif
  std::cout << average[3] << "]\n";  
	
  #endif // end not LOG
  
  #ifdef PRECOMP
  delete_BinomialMat (binomialMat, len_binomial);  
	#endif
}



int main()
{
// 	// vertices (standard triangle)
// 	double v1[2] = { 0, 0 };
//   double v2[2] = { 1, 0 };
//   double v3[2] = { 0, 1 };
	
	//vertices (particular triangle)
	double v1[2] = { 1.2  , 3.4 }; 
	double v2[2] = { -1.5 , 2. };
	double v3[2] = { 0.1  , -1. };	
  
  int n0, n1, nbIter;

  std::cout<<"Enter a value for the number of iterations:";
  std::cin>>nbIter;
 
  
  std::cout<<"Enter a value for n0 (n0>1):";
  std::cin>>n0;
  
  std::cout<<"Enter a value for n1:";
  std::cin>>n1;
  
	printTime_residual_Comp( n0, n1, v1, v2, v3, nbIter);	
}



#include <stdio.h>
#include <math.h>
#include <time.h>
#include <iostream>


#ifdef MEX_stroud_bary2d
#include <mex.h>
#endif

#ifdef MEX_stroud_bary2dw
#include <mex.h>
#endif


#ifdef MEX_stiff
#include <mex.h>
#endif

#include "bbfem.h"
#include "bbfem2dCurl.h"


#ifndef MAX
#define MAX(a,b) ( (a) > (b) ? (a) : (b) )
#endif


// example of stiffness matrix coefficients
double 
A0 (double v[2])
{
	return 2.0 - sin(v[0]*v[1]);
}

// mass matrix coefficient example
void
Kappa0 (double v[2], double matC[2][2])
{
//   matC[0][0] = 1;
//   matC[0][1] = 0;
//   matC[1][0] = 0;
//   matC[1][1] = 1;
	
	// non-standard coefficient example
  matC[0][0] =  10.0 + v[0];
  matC[0][1] =  v[1] * v[0] * v[0];
  matC[1][0] =  v[1] * v[0] * v[0];
  matC[1][1] =  2.0 - sin(v[0]*v[1]);	
}

// load vector coefficient example
void 
F0( double v[2], double vectF[2] )
{
	vectF[0] = 2 - sin(v[0]*v[1]);
	vectF[1] = 1 - v[0]*v[1];
}


double 
timeMass2dCurl( int n, int q, double v1[2], double v2[2], double v3[2],
											 double **binomialMat, double normalMat[][2],
											 int nbIter, double average[2] )
{
	
	void (*Kappa)(double[2], double[2][2]) = Kappa0;
	double cputime[2]={0,0};
	
	double **massMat;
	int len_Mass = dimCurl(n);
  massMat = create_Mat(len_Mass);
	
	
	#ifdef PRECOMP
	double **precomp;	
	#endif
	double **matValNodes; // now also used with non-PRECOMP
	
	double **BmomentInter; // needed with LowerMoment
	
	double **Bmoment, **Bmomentab;
  double **quadraWN;
	
	double **cRing; // store cRing coefficients
	
	// initialize number of quadrature pointers, and integers needed for indexing Bmoment entries
  int nDash = 2*n ;  // highest Bmoment order required for mass matrix
  #ifdef PRECOMP
	int mp = MAX (nDash, q-1);  // "precomp" size
  #endif
	int nb_Array = 3;  //matrix-valued coefficients
	int len_Quadra = q + 1;     // space required for storing Jacobi nodes of order q is q, but indexing starts at 1
  quadraWN = create_quadraWN2d(len_Quadra);	
	
	// initialize auxilliary arrays		
	
	int lenMoments = len_Moments2d(nDash,q);
  Bmoment = create_Bmoment(lenMoments, nb_Array);
  Bmomentab = create_Bmoment(lenMoments, 6); // multiply normals to Bmoments and store into Bmomentab
	
	if (n>1)
	{
		cRing = create_cRing(n);
		CRing(n, normalMat, cRing); // store CRing coefficients into cRing 
	}
	
	#ifdef PRECOMP
	precomp = create_precomp2d(mp+1);	// store precomputed arrays
	#endif
	int len_matValNodes = q * q ;      // space required for 2D array with dimension q
  matValNodes = create_matValNodes2d(len_matValNodes);
	
	BmomentInter = create_Bmoment(lenMoments, nb_Array); // needed by LowerMoment
	
	
	assign_quadra2d(q, quadraWN);	 // initialize quadrature weights and nodes
	
	 // storing values of Kappa at Stroud nodes into matValNodes  
	#ifdef PRECOMP
	data_at_Nodes_Stiff2d (Kappa, matValNodes, q, quadraWN, v1, v2, v3);
  #else
	init_BmomentC_Stiff2d (Kappa, q, v1, v2, v3, matValNodes, quadraWN);
	#endif
	
  average[0] = average[1] = 0.;
  for (int k=0; k<nbIter; k++)
  {
		#ifdef PRECOMP 
		Mass2d_Curl(n, q, v1, v2, v3, binomialMat, normalMat, precomp, mp, Bmoment, BmomentInter, Bmomentab, massMat, matValNodes, quadraWN, cRing, cputime);
		#else
		Mass2d_Curl(n, q, v1, v2, v3, binomialMat, normalMat, Bmoment, 
								BmomentInter, Bmomentab, massMat, matValNodes, quadraWN, cRing, cputime);
		#endif
		
		average[0] += cputime[0]; // total CPU time
		average[1] += cputime[1]; // CPU time involving gradients
  }
  
  average[0] /= nbIter;
  average[1] /= nbIter;
  
  
	#ifdef PRECOMP
	delete_pointers_Curl(precomp, Bmoment, BmomentInter, matValNodes,quadraWN);
	delete_Bmoment(Bmomentab);
	#else
	delete_pointers_Curl(Bmoment, BmomentInter, matValNodes, quadraWN);
	delete_Bmoment(Bmomentab);
	#endif
	
	if (n>1)
		delete_cRing(cRing);
	
	delete_Mat(massMat);
	
  return average[0];  
}


void 
printTimeMass2dCurl( void (*Kappa)(double[2], double[2][2]), int n0, 
														int n1, double v1[2], double v2[2], double v3[2], 
														int nbIter )
{
	
	int len_binomial = 300;
	double **binomialMat;
  binomialMat = create_BinomialMat(len_binomial); //allocate memory to binomial coefficients
  computeBinomials(binomialMat, len_binomial);  //compute binomials

  double normalMat[3][2] = { {0, 0}, {0, 0}, {0, 0} };  // store normals to the edges	
	normals2d(v1,v2,v3,normalMat);
    
  double cputime[2];
  
  std::cout<<"\n";

	#ifdef LOG
	int step;
  step=MAX((int)(n0/1.5),1);
  for (int n=n0; n<=n1; n += step, step=MAX((int)(n/1.5),1))
  {
		int q = n+1;
		timeMass2dCurl( n, q, v1, v2, v3, binomialMat, normalMat, nbIter, cputime);
		fprintf(stderr," n= %d, total cpu = %e, non-grad cpu = %e, grad cpu = %e \n", n, cputime[0], cputime[0]-cputime[1], cputime[1] );
  }
  
  #else
  
  std::cout << "[";
  for (int n=n0; n< n1; n++ )
  {
		int q = n+1;
		timeMass2dCurl( n, q, v1, v2, v3, binomialMat, normalMat, nbIter, cputime);
		std::cout << cputime[0] << ",";
  }
  int q = n1+1;
  timeMass2dCurl( n1, q, v1, v2, v3, binomialMat, normalMat, nbIter, cputime);
  std::cout << cputime[0] << "]\n";
  
  #endif
  
  delete_BinomialMat (binomialMat, len_binomial);
}



double 
timeStiff2dCurl( int n, int q, double v1[2], double v2[2], double v3[2],
											 double **binomialMat, int nbIter, double average[3] )
{
	
	double (*A)(double[2]) = A0;
	
	double **stiffMat;
	int len_Stiff;
	if (n>1)
		len_Stiff = ( n*(n+1) )/2 + 3;
	else
		len_Stiff = 3;
  stiffMat = create_Mat(len_Stiff); // only non-gradient entries of stiffness matrix
	
	double cputime[3]={0,0,0};
	
	#ifdef PRECOMP
	double **precomp;	
	#endif
	double **matValNodes;
	double **BmomentInter; // needed with LowerMoment
	
	double **Bmoment;
	double **cBar;
  double **quadraWN;
	
	// initialize number of quadrature pointers, and integers needed for indexing Bmoment entries
  int nDash = 2*n-2 ;  // highest Bmoment order required for stiffness matrix
  #ifdef PRECOMP
	int mp = MAX (nDash, q-1);  // "precomp" size
  #endif
	int nb_Array = 1;  //scalar-valued coefficients
	int len_Quadra = q + 1;  // space required for storing Jacobi nodes of order q is q, but indexing starts at 1
  quadraWN = create_quadraWN2d(len_Quadra);	
	
	// initialize auxilliary arrays		
	int lenMoments = len_Moments2d(nDash,q);
  Bmoment = create_Bmoment(lenMoments, nb_Array);
	
	#ifdef PRECOMP
	precomp = create_precomp2d(mp+1);	// store precomputed arrays
	#endif
	int len_matValNodes = q * q ;      // space required for 2D array with dimension q
  matValNodes = create_matValNodes2d(len_matValNodes);
	
	BmomentInter = create_Bmoment(lenMoments, nb_Array); // needed by LowerMoment
	
	assign_quadra2d(q, quadraWN);	 // initialize quadrature weights and nodes
	
	 // storing values of A at Stroud nodes into matValNodes  
	#ifdef PRECOMP
	data_at_Nodes_Mass2d (A, matValNodes, q, quadraWN, v1, v2, v3);
	#else
	init_BmomentC_Mass2d ( A, q, v1, v2, v3, matValNodes, quadraWN );
	#endif
  
  if (n>1)
	{
		cBar = create_cBar(n);
		CBar(n, v1, v2, v3, cBar);
	}
  
  average[0] = average[1]=average[2]=0.;
  for (int k=0; k<nbIter; k++)
  {
		#ifdef PRECOMP
		Stiff2d_Curl( n, q, v1, v2, v3, binomialMat, precomp, mp, Bmoment,  BmomentInter, cBar, stiffMat, matValNodes, quadraWN, cputime);
		#else
		Stiff2d_Curl( n, q, v1, v2, v3, binomialMat, Bmoment, BmomentInter, cBar, stiffMat, matValNodes, quadraWN, cputime);
		#endif

		average[0] += cputime[0];
		average[1] += cputime[1];
		average[2] += cputime[2];
  }
  
  average[0] /= nbIter;
  average[1] /= nbIter;
  average[2] /= nbIter;

  if (n>1)
		delete_cBar(cBar);
	
	#ifdef PRECOMP
	delete_pointers_Curl(precomp, Bmoment, BmomentInter, matValNodes,quadraWN);
	#else
	delete_pointers_Curl(Bmoment, BmomentInter, matValNodes, quadraWN);
	#endif
	
	delete_Mat(stiffMat);
  
  return average[0]+average[1]+average[2];
  
}

void 
printTimeStiff2dCurl( double (*A)(double[2]), int n0, int n1, double v1[2], 
											double v2[2], double v3[2], int nbIter )
{
	
	int len_binomial = 300;
	double **binomialMat;
  binomialMat = create_BinomialMat(len_binomial); //allocate memory to binomial coefficients
  computeBinomials(binomialMat, len_binomial);  //compute binomials
	
  double cputime[3];
  
  std::cout<<"\n";

	#ifdef LOG
	int step;
  step=MAX((int)(n0/1.5),1);
  for (int n=n0; n<=n1; n += step, step=MAX((int)(n/1.5),1))
  {
		int q = n+1;
		timeStiff2dCurl(n, q, v1, v2, v3, binomialMat, nbIter, cputime);
		fprintf(stderr," n= %d, stiff cpu = %e, sigma/sigma cpu = %e, sigma/W cpu = %e \n", n, cputime[0], cputime[1], cputime[2] );
  }
  
  #else
  double timing;
  std::cout << "[";
  for (int n=n0; n< n1; n++ )
  {
		int q = n+1;
		timing = timeStiff2dCurl(n, q, v1, v2, v3, binomialMat, nbIter, cputime);
		std::cout << timing << ",";
  }
  int q = n1+1;
  timing = timeStiff2dCurl(n1, q, v1, v2, v3, binomialMat, nbIter, cputime);
  std::cout << timing << "]\n";
  
  #endif
  
  delete_BinomialMat (binomialMat, len_binomial);  
}


double 
timeLoadCurl( int n, int q, double v1[2], double v2[2], double v3[2],
							double **binomialMat, double normalMat[][2],
							int nbIter, double average[3] )
{
  void (*F)(double[2], double [2] ) = F0;
	double cputime[3]={0,0,0};
	
	double *loadVect;
	int len_Load = dimCurl(n);
  loadVect = new double [len_Load];
	
	
	#ifdef PRECOMP
	double **precomp;	
	#endif
	double **matValNodes;
	double **BmomentInter; // needed with LowerMoment
	
	double **Bmoment;
  double **quadraWN;
	
	double **cRing; // store cRing coefficients
  
	// initialize number of quadrature pointers, and integers needed for indexing Bmoment entries
  int nDash =  n ;  // highest Bmoment order required for load vector
  #ifdef PRECOMP
	int mp = MAX (nDash, q-1);  // "precomp" size
  #endif
	int nb_Array = 2;  //vector-valued coefficients
	int len_Quadra = q + 1;     // space required for storing Jacobi nodes of order q is q, but indexing starts at 1
  quadraWN = create_quadraWN2d(len_Quadra);	
	
	// initialize auxilliary arrays		
	
	int lenMoments = len_Moments2d(nDash,q);
  Bmoment = create_Bmoment(lenMoments, nb_Array);
	
	if (n>1)
	{
		cRing = create_cRing(n);
		CRing(n, normalMat,cRing); 	// stores CRing coefficients into cRing
	}
		
	#ifdef PRECOMP
	precomp = create_precomp2d(mp+1);	// store precomputed arrays
	#endif
	int len_matValNodes = q * q ;      // space required for 2D array with dimension q
  matValNodes = create_matValNodes2d(len_matValNodes);
	
	BmomentInter = create_Bmoment(lenMoments, nb_Array); // needed by LowerMoment
	
	assign_quadra2d(q, quadraWN);	 // initialize quadrature weights and nodes
	
	// storing values of F at Stroud nodes into matValNodes
	#ifdef PRECOMP
  data_at_Nodes_Convec2d (F, matValNodes, q, quadraWN, v1, v2, v3); 
  #else
  init_BmomentC_Convec2d ( F, q, v1, v2, v3, matValNodes, quadraWN );
  #endif
	
  average[0] = average[1] = average[2] = 0;
  for (int k=0; k<nbIter; k++)
  {
		#ifdef PRECOMP
		Load2d_Curl(n, q, v1, v2, v3, binomialMat, normalMat, precomp, mp, Bmoment, BmomentInter, loadVect, matValNodes, quadraWN, cRing, cputime);
		#else
		Load2d_Curl(n, q, v1, v2, v3, binomialMat, normalMat, Bmoment, BmomentInter, loadVect, matValNodes, quadraWN, cRing, cputime);
		#endif
		
		cputime[0] += cputime[0]; 
		cputime[1] += cputime[1]; // cpu time involving grads... 
		cputime[2] += cputime[2]; // cpu time involving B-moments... 
  }
  
  cputime[0] /= nbIter;
  cputime[1] /= nbIter;
  cputime[2] /= nbIter;
	
	#ifdef PRECOMP
	delete_pointers_Curl(precomp, Bmoment, BmomentInter, matValNodes,quadraWN);
	#else
	delete_pointers_Curl(Bmoment, BmomentInter, matValNodes, quadraWN);
	#endif
	
	if (n>1)
		delete_cRing(cRing);
	
	delete loadVect;
 
  return cputime[0] ;
   
}

void 
printTimeLoadCurl( void (*F)(double[2], double[2]), int n0, int n1, double v1[2], double v2[2], double v3[2], int nbIter )
{
	int len_binomial = 300;
	double **binomialMat;
  binomialMat = create_BinomialMat(len_binomial); //allocate memory to binomial coefficients
  computeBinomials(binomialMat, len_binomial);  //compute binomials

  double normalMat[3][2] = { {0, 0}, {0, 0}, {0, 0} };  // store normals to the edges	
	normals2d(v1,v2,v3,normalMat);
	
  double cputime[3];
	
	std::cout<<"\n";
 
	#ifdef LOG
  int step; 	
  step=MAX((int)(n0/1.5),1);
  for (int n=n0; n<=n1; n += step, step=MAX((int)(n/1.5),1))
  {
		int q = n+1;
		timeLoadCurl( n, q, v1, v2, v3, binomialMat, normalMat, nbIter, cputime);
		fprintf(stderr," n= %d, total cpu = %e, non-grad cpu = %e , grad cpu = %e, B-moment = %e\n", n, cputime[0], cputime[0]-cputime[1], cputime[1], cputime[2] );
  }
  
  #else
  std::cout << "[";
  for (int n=n0; n< n1; n++ )
  {
		int q = n+1;
		timeLoadCurl( n, q, v1, v2, v3, binomialMat, normalMat, nbIter, cputime);
		std::cout << cputime[0] << ",";
  }
  int q = n1+1;
  timeLoadCurl( n1, q, v1, v2, v3, binomialMat, normalMat, nbIter, cputime);
  std::cout << cputime[0] << "]\n";
  
  #endif
  
  delete_BinomialMat (binomialMat, len_binomial);  
}







/////////////////////////// mains /////////////////////////////////////////

#ifdef MASS_LOW
int main ()
{
  int n;

// 	// vertices (standard triangle)
//   double v1[2] = { 0, 0 };
//   double v2[2] = { 1, 0 };
//   double v3[2] = { 0, 1 };
	
	//vertices (particular triangle)
	double v1[2] = { 1.2  , 3.4 }; 
	double v2[2] = { -1.5 , 2. };
	double v3[2] = { 0.1  , -1. };
    
  std::cout<<"Enter a value for n:";
  std::cin>>n;
	
	void (*Kappa) (double[2], double[2][2]) = Kappa0; // change here to your routine for mass matrix coefficients
	
	int functval = 0; //default: using a routine (Kappa) for mass matrix coefficients
	
	int len_binomial = 2*n+2;
	double **binomialMat = create_BinomialMat(len_binomial); //allocate memory to binomial coefficients
	
	double cputime[2]={0,0}; // passed as argument to Mass2d_Curl
	
	double normalMat[3][2] = { {0, 0}, {0, 0}, {0, 0} };  // store normals to the edges	
	normals2d(v1,v2,v3,normalMat);
	
	double **massMat;  // store mass matrix entries
  int len_Mass = dimCurl(n); // allocate memory to massMat
  massMat = create_Mat(len_Mass);
	
	
	#ifdef PRECOMP
	double **precomp;	
	#endif
	double **matValNodes; // now also used with non-PRECOMP
	
	double **BmomentInter; // needed with LowerMoment
	
	double **Bmoment, **Bmomentab;
  double **quadraWN;
	
	double **cRing; // store cRing coefficients
	
	
	#ifdef FUNCT_VAL
	functval = 1; //using the values stored in Cval for mass matrix coefficients
	double *Cval; // store coefficients values at Stroud nodes
	double *B; // store barycentric coordinates of Stroud nodes
	#endif
	
	// initialize number of quadrature pointers, and integers needed for indexing Bmoment entries
	int q = n+1; 
  int nDash = 2*n ;  // highest Bmoment order required for mass matrix
  #ifdef PRECOMP
	int mp = MAX (nDash, q-1);  // "precomp" size
  #endif
	int nb_Array = 3;  //matrix-valued coefficients
	int len_Quadra = q + 1;     // space required for storing Jacobi nodes of order q is q, but indexing starts at 1
  quadraWN = create_quadraWN2d(len_Quadra);	
	
	
	int lenMoments = len_Moments2d(nDash,q);
  Bmoment = create_Bmoment(lenMoments, nb_Array);
  Bmomentab = create_Bmoment(lenMoments, 6); // multiply normals to Bmoments and store into Bmomentab
	
	
	// initialize auxilliary arrays		
	
	computeBinomials(binomialMat, len_binomial);  //compute binomials
	
	#ifdef FUNCT_VAL
	B = new double [q*q*3];
	stroud_nodes_bary2d (q, B);
	
	//allocates memory for Cval
  int LEN = q * q ;  // space required for 2D array with dimension q	
	Cval = new double[LEN * nb_Array];    //Cval entries are stored in LINEAR memory, and used directly
	
	matrix_values_at_Stroud2d(q, Cval, B, Kappa, v1, v2, v3 ); // store the values of Kappa at the Stroud nodes into Cval
	#endif
	
	
	
	if (n>1)
	{
		cRing = create_cRing(n);
		CRing(n, normalMat,cRing); 	// stores CRing coefficients into cRing
	}
	
	#ifdef PRECOMP
	precomp = create_precomp2d(mp+1);	// store precomputed arrays
	#endif
	int len_matValNodes = q * q ;      // space required for 2D array with dimension q
  matValNodes = create_matValNodes2d(len_matValNodes);
	
	BmomentInter = create_Bmoment(lenMoments, nb_Array); // needed by LowerMoment
		
	
	//assign values to auxilliary arrays for computing matrix-valued B-moments
	assign_quadra2d(q, quadraWN);	 // initialize quadrature weights and nodes
	
	if (functval==1) // read values stored in Cval
	{
		#ifdef PRECOMP
		data_at_Nodes_Cval2d (matValNodes, q, Cval, nb_Array);
		#else
		init_Bmoment2d_Cval (Cval, q, v1, v2, v3, matValNodes, nb_Array);
		#endif
	}
	else // compute values of Kappa at Stroud nodes
	{
		#ifdef PRECOMP
		data_at_Nodes_Stiff2d (Kappa, matValNodes, q, quadraWN, v1, v2, v3); 
		#else
		init_BmomentC_Stiff2d ( Kappa, q, v1, v2, v3, matValNodes, quadraWN );
		#endif
	}
		
	// compute mass matrix:
	#ifdef PRECOMP 
	Mass2d_Curl(n, q, v1, v2, v3, binomialMat, normalMat, precomp, mp, Bmoment, BmomentInter, Bmomentab, massMat, matValNodes, quadraWN, cRing, cputime);
	#else
	Mass2d_Curl(n, q, v1, v2, v3, binomialMat, normalMat, Bmoment, 
							BmomentInter, Bmomentab, massMat, matValNodes, quadraWN, cRing, cputime);
	#endif
	
	
	#ifdef PRECOMP
	delete_pointers_Curl(precomp, Bmoment, BmomentInter, matValNodes,quadraWN);
	delete_Bmoment(Bmomentab);
	#else
	delete_pointers_Curl(Bmoment, BmomentInter, matValNodes, quadraWN);
	delete_Bmoment(Bmomentab);
	#endif
	
	if (n>1)
		delete_cRing(cRing);
	
	delete_BinomialMat (binomialMat, len_binomial);
	
	#ifdef FUNCT_VAL
	delete Cval;
	delete B;
	#endif
	
	// Insert your code here to make use of massMat. It will be destroyed in the next line!		 
	
	delete_Mat(massMat);
  
	
	#ifdef CHECK
	std::cout<<"Mass matrix entries stored into array massMat of dimension "<<len_Mass<<"\n";
  #endif
	
}

#elif STIFF_LOW
int main()
{
	int n;

// 	// vertices (standard triangle)
//   double v1[2] = { 0, 0 };
//   double v2[2] = { 1, 0 };
//   double v3[2] = { 0, 1 };
	
	//vertices (particular triangle)
	double v1[2] = { 1.2  , 3.4 }; 
	double v2[2] = { -1.5 , 2. };
	double v3[2] = { 0.1  , -1. };
	
    
  std::cout<<"Enter a value for n:";
  std::cin>>n;
	
	double (*A) (double[2]) = A0; // change here to your routine for stiffness matrix coefficients
	
	int functval = 0; //default: using a routine (Kappa) for mass matrix coefficients
	
	int len_binomial = 2*n+2;
	double **binomialMat = create_BinomialMat(len_binomial); //allocate memory to binomial coefficients
	
	double cputime[3]={0,0,0}; // passed as argument to Stiff2d_Curl
	
	double **stiffMat;  // store non-zero stiffness matrix entries
  int len_Stiff = dim_nonGradCurl(n); // allocate memory to stiffMat
  stiffMat = create_Mat(len_Stiff);
	
	#ifdef PRECOMP
	double **precomp;	
	#endif
	double **matValNodes; // now also used by non-PRECOMP...
	
	double **BmomentInter; // needed with LowerMoment
	
	double **Bmoment;
  double **quadraWN;
	
	double **cBar; // store cBar coefficients
	
	#ifdef FUNCT_VAL
	functval = 1; //using the values stored in Cval for mass matrix coefficients
	double *Cval; // store coefficients values at Stroud nodes
	double *B; // store barycentric coordinates of Stroud nodes
	#endif
	
	// initialize number of quadrature pointers, and integers needed for indexing Bmoment entries
	int q = n+1; 
  int nDash = 2*n ;  // highest Bmoment order required for mass matrix
  #ifdef PRECOMP
	int mp = MAX (nDash, q-1);  // "precomp" size
  #endif
	int nb_Array = 1;  //scalar-valued coefficients
	int len_Quadra = q + 1;     // space required for storing Jacobi nodes of order q is q, but indexing starts at 1
  quadraWN = create_quadraWN2d(len_Quadra);	
	
	// initialize auxilliary arrays		
	
	int lenMoments = len_Moments2d(nDash,q);
  Bmoment = create_Bmoment(lenMoments, nb_Array);
	
	computeBinomials(binomialMat, len_binomial);  //compute binomials
	
	#ifdef FUNCT_VAL
	B = new double [q*q*3];
	stroud_nodes_bary2d (q, B);
	
	//allocates memory to Cval
  int LEN = q * q ;  // space required for 2D array with dimension q	
	Cval = new double[LEN * nb_Array];    //Cval entries are stored in LINEAR memory, and used directly
	
	scalar_values_at_Stroud2d(q, Cval, B, A, v1, v2, v3 ); // store the values of A at the Stroud nodes into Cval
	#endif
	
	if (n>1)
	{
		cBar = create_cBar(n);
		CBar(n, v1, v2, v3, cBar);
	}
	
	#ifdef PRECOMP
	precomp = create_precomp2d(mp+1);	// store precomputed arrays
	#endif
	int len_matValNodes = q * q ;      // space required for 2D array with dimension q
  matValNodes = create_matValNodes2d(len_matValNodes);
	
	BmomentInter = create_Bmoment(lenMoments, nb_Array); // needed by LowerMoment
		
	
	//assign values to auxilliary arrays for computing matrix-valued B-moments
	assign_quadra2d(q, quadraWN);	 // initialize quadrature weights and nodes
	
	if (functval==1) // read values stored in Cval
	{
		#ifdef PRECOMP
		data_at_Nodes_Cval2d (matValNodes, q, Cval, nb_Array); 
		#else
		init_Bmoment2d_Cval (Cval, q, v1, v2, v3, matValNodes, nb_Array);
		#endif
	}
	else // storing values of A at Stroud nodes into matValNodes
	{
		#ifdef PRECOMP
		data_at_Nodes_Mass2d (A, matValNodes, q, quadraWN, v1, v2, v3); 
		#else
		init_BmomentC_Mass2d ( A, q, v1, v2, v3, matValNodes, quadraWN );
		#endif
	}
	// compute stiffness matrix:
	#ifdef PRECOMP
	Stiff2d_Curl( n, q, v1, v2, v3, binomialMat, precomp, mp, Bmoment,  BmomentInter, cBar, stiffMat, matValNodes, quadraWN, cputime);
	#else
	Stiff2d_Curl( n, q, v1, v2, v3, binomialMat, Bmoment, BmomentInter, cBar, stiffMat, matValNodes, quadraWN, cputime);
	#endif
	
	
	#ifdef PRECOMP
	delete_pointers_Curl(precomp, Bmoment, BmomentInter, matValNodes,quadraWN);
	#else
	delete_pointers_Curl(Bmoment, BmomentInter, matValNodes, quadraWN);
	#endif
	
	delete_BinomialMat (binomialMat, len_binomial);	
		
	
	if (n>1)
		delete_cBar(cBar);
	
	#ifdef FUNCT_VAL
	delete Cval;
	delete B;
	#endif
	
	// Insert your code here to make use of stiffMat. It will be destroyed in the next line!		 
	
	delete_Mat(stiffMat);
  
	
	#ifdef CHECK
	std::cout<<"Stiffness matrix entries stored into array massMat of dimension "<<len_Stiff<<"\n";
  #endif
	
	
}

#elif LOAD_LOW
int main()
{
	
	int n;

// 	// vertices (standard triangle)
//   double v1[2] = { 0, 0 };
//   double v2[2] = { 1, 0 };
//   double v3[2] = { 0, 1 };
	
	
	//vertices (particular triangle)
	double v1[2] = { 1.2  , 3.4 }; 
	double v2[2] = { -1.5 , 2. };
	double v3[2] = { 0.1  , -1. };
	
    
  std::cout<<"Enter a value for n:";
  std::cin>>n;
	
	void (*F)( double v[2], double vectF[2]) = F0; // change here to your routine for load vector coefficients
	
	int functval = 0; //default: using a routine (F) for load vector coefficients
	
	int len_binomial = 2*n+2;
	double **binomialMat = create_BinomialMat(len_binomial); //allocate memory to binomial coefficients
	
	double cputime[3]={0,0,0}; // passed as argument to Load2d_Curl
	
	double normalMat[3][2] = { {0, 0}, {0, 0}, {0, 0} };  // store normals to the edges	
	normals2d(v1,v2,v3,normalMat);
	
	double *loadVect;  // store load vector entries
  int len_Load = dimCurl(n); // allocate memory to load vector
	loadVect = new double[len_Load];
	
	#ifdef PRECOMP
	double **precomp;	
	#endif
	double **matValNodes; // now also used by non-PRECOMP...
	
	double **BmomentInter; // needed with LowerMoment
	
	double **Bmoment, **Bmomentab;
  double **quadraWN;
	
	double **cRing; // store cRing coefficients
	
	
	#ifdef FUNCT_VAL
	functval = 1; //using the values stored in Cval for mass matrix coefficients
	double *Cval; // store coefficients values at Stroud nodes
	double *B; // store barycentric coordinates of Stroud nodes
	#endif
	
	// initialize number of quadrature pointers, and integers needed for indexing Bmoment entries
	int q = n+1; 
  int nDash = 2*n ;  // highest Bmoment order required for load vector
  #ifdef PRECOMP
	int mp = MAX (nDash, q-1);  // "precomp" size
  #endif
	int nb_Array = 2;  //vector-valued coefficients
	int len_Quadra = q + 1;     // space required for storing Jacobi nodes of order q is q, but indexing starts at 1
  quadraWN = create_quadraWN2d(len_Quadra);	
	
	
	int lenMoments = len_Moments2d(nDash,q);
  Bmoment = create_Bmoment(lenMoments, nb_Array);
  Bmomentab = create_Bmoment(lenMoments, 6); // multiply normals to Bmoments and store into Bmomentab
	
	
	// initialize auxilliary arrays		
	
	computeBinomials(binomialMat, len_binomial);  //compute binomials
	
	
	#ifdef FUNCT_VAL
	B = new double [q*q*3];
	stroud_nodes_bary2d (q, B);
	
	//allocates memory for Cval
  int LEN = q * q ;  // space required for 2D array with dimension q	
	Cval = new double[LEN * nb_Array];    //Cval entries are stored in LINEAR memory, and used directly
	
	vector_values_at_Stroud2d(q, Cval, B, F, v1, v2, v3 ); // store the values of F at the Stroud nodes into Cval
	#endif	
	
	if (n>1)
	{
		cRing = create_cRing(n);
		CRing(n, normalMat,cRing); 	// stores CRing coefficients into cRing
	}
	
	#ifdef PRECOMP
	precomp = create_precomp2d(mp+1);	// store precomputed arrays
	#endif
	int len_matValNodes = q * q ;      // space required for 2D array with dimension q
  matValNodes = create_matValNodes2d(len_matValNodes);
	
	BmomentInter = create_Bmoment(lenMoments, nb_Array); // needed by LowerMoment
		
	
	//assign values to auxilliary arrays for computing matrix-valued B-moments
	assign_quadra2d(q, quadraWN);	 // initialize quadrature weights and nodes
	
	if (functval==1) // read values stored in Cval
	{
		#ifdef PRECOMP
		data_at_Nodes_Cval2d (matValNodes, q, Cval, nb_Array);
		#else
		init_Bmoment2d_Cval (Cval, q, v1, v2, v3, matValNodes, nb_Array);
		#endif
	}
	else // compute values of F at Stroud nodes
	{
		#ifdef PRECOMP
		data_at_Nodes_Convec2d (F, matValNodes, q, quadraWN, v1, v2, v3); 
		#else
		init_BmomentC_Convec2d ( F, q, v1, v2, v3, matValNodes, quadraWN );
		#endif
	}
	// compute load vector:
	#ifdef PRECOMP
	Load2d_Curl(n, q, v1, v2, v3, binomialMat, normalMat, precomp, mp, Bmoment, BmomentInter, loadVect, matValNodes, quadraWN, cRing, cputime);
	#else
	Load2d_Curl(n, q, v1, v2, v3, binomialMat, normalMat, Bmoment, BmomentInter, loadVect, matValNodes, quadraWN, cRing, cputime);
	#endif
	
	
	#ifdef PRECOMP
	delete_pointers_Curl(precomp, Bmoment, BmomentInter, matValNodes,quadraWN);
	#else
	delete_pointers_Curl(Bmoment, BmomentInter, matValNodes, quadraWN);
	#endif
	
	if (n>1)
		delete_cRing(cRing);
	
	delete_BinomialMat (binomialMat, len_binomial);
	
	#ifdef FUNCT_VAL
	delete Cval;
	delete B;
	#endif
	
	
	// Insert your code here to make use of loadVect. It will be destroyed in the next line!		 
	
	
	delete loadVect;
	
	
	#ifdef CHECK
	std::cout<<"Load vector entries stored into loadVect of length "<<len_Load<<"\n";
	#endif

}
  
#else // cpu timing purposes
  
int main()
{
// 	// vertices (standard triangle)
// 	double v1[2] = { 0, 0 };
//   double v2[2] = { 1, 0 };
//   double v3[2] = { 0, 1 };
	
	//vertices (particular triangle)
	double v1[2] = { 1.2  , 3.4 }; 
	double v2[2] = { -1.5 , 2. };
	double v3[2] = { 0.1  , -1. };	
  
  int n0, n1, nbIter;

  std::cout<<"Enter a value for the number of iterations:";
  std::cin>>nbIter;
 
  
  std::cout<<"Enter a value for n0:";
  std::cin>>n0;
  
  std::cout<<"Enter a value for n1:";
  std::cin>>n1;
  
  #ifdef TIMEMASS
  printTimeMass2dCurl( Kappa0, n0, n1, v1, v2, v3, nbIter );
  
  #elif TIMELOAD
  printTimeLoadCurl( F0, n0, n1, v1, v2, v3, nbIter );
	  
  #elif TIMESTIFF
  printTimeStiff2dCurl( A0, n0, n1, v1, v2, v3, nbIter );
	#endif

}

#endif // end not low-level routines

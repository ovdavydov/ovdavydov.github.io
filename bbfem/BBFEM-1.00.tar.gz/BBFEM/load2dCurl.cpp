#include <stdio.h>
#include <math.h>
#include <time.h>
#include <iostream>


#include "bbfem.h"
#include "bbfem2dCurl.h"

// example of load vector coefficient
void 
F0( double v[2], double vectF[2] )
{	
	vectF[0] = 2 - sin(v[0]*v[1]);
	vectF[1] = 1 - v[0]*v[1];
}


int main()
{
// 	   //vertices (standard triangle)
//     double v1[2] = { 0, 0 };
//     double v2[2] = { 1, 0 };
//     double v3[2] = { 0, 1 };
  
  //vertices (particular triangle)
  double v1[2] = { 1.2  , 3.4 }; 
  double v2[2] = { -1.5 , 2. };
  double v3[2] = { 0.1  , -1. };

  int n; // degree of the Bernstein polynomial basis
  std::cout<<"Enter a value for the polynomial order n:";
  std::cin>>n;
	
	double *Cval; // store array of coefficients values at Stroud quadrature nodes
	
	int functval = 0; //default: using a routine (Kappa) for mass matrix coefficients
	
	void (*F) (double[2], double[2]) = F0; // change here to your routine for load vector coefficients
	
	#ifdef FUNCT_VAL
	functval = 1;  //using the values stored in Cval for load vector coefficients
	int q = n+1;
	int nb_Array = 2; // the load vector is associated with vector-valued data
	
	double *B; // store barycentric coordinates of Stroud nodes
	B = new double [q*q*3];
	stroud_nodes_bary2d (q, B);
	
	int LEN = q * q ;  // space required for 2D array with dimension q x q
  Cval = new double[LEN * nb_Array];    //Cval entries are stored in LINEAR memory, and used directly

	// storing your data in Cval
	vector_values_at_Stroud2d(q, Cval, B, F, v1, v2, v3 ); 
	#endif
	
	double *loadVect;  // store load vector entries
  int len_Load = dimCurl(n); // allocate memory to stiffMat
  loadVect = new double [len_Load];
	
	get_load2dCurl(loadVect, n, F, Cval, v1, v2, v3, functval); // compute load vector
		
	// free allocated memory
	#ifdef FUNCT_VAL
	delete Cval;
	delete B;
	#endif
	
	// Insert your code here to make use of loadVect. It will be destroyed in the next line!
	
	delete loadVect;
	
}
//  This file is part of BBFEM.
//  
//   Authors: Mark Ainsworth
// 				    Division of Applied Mathematics
// 				    Brown University
// 				    182 George Street
// 				    Providence, RI 02912
// 				    e-mail: Mark_Ainsworth@Brown.edu
//
//            Gaelle Andriamaro
// 	  			  University of Strathclyde
// 	  			  Department of Mathematics and Statistics
//           	26 Richmond Street
// 	  			  Glasgow G1 1XH
// 	  			  Scotland, UK
// 	          e-mail: gaelle.andriamaro@strath.ac.uk
//  
//            Oleg Davydov
// 	  			  University of Strathclyde
// 	  			  Department of Mathematics and Statistics
//           	26 Richmond Street
// 	  			  Glasgow G1 1XH
// 	  			  Scotland, UK
// 	  			  e-mail: oleg.davydov@strath.ac.uk
// 
// 
//   Copyright (C) 2013 Mark Ainsworth, Gaelle Andriamaro and Oleg Davydov
// 
// 
// This package is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2, or (at your option)
// any later version.
// 
// This package is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this package; see the file COPYING.  If not, write to
// the Free Software Foundation, 59 Temple Place - Suite 330,
// Boston, MA 02111-1307, USA.  

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <iostream>

#include "bbfem.h"

#ifdef GAUJAC
//declaration from GaussJacobi.cpp
void gaujac(double *x, double *w, int n, float alf, float bet);
#include "GaussJacobi.cpp"
#else
#include "JacobiGaussNodes.h"
#endif


#ifndef MAX
#define MAX(a,b) ( (a) > (b) ? (a) : (b) )
#endif

//// routines which are common to 2D and 3D computations ///////////////////////////////

// allocates memory to binomialMat array which stores binomial coefficients
double **
create_BinomialMat(int len_binomialMat)
{
  double **binomialMat = new double *[len_binomialMat];
  for (int i=0; i<len_binomialMat; i++)
	binomialMat[i]= new double [len_binomialMat];
  
  return binomialMat;
}

// free memory allocated to binomialMat
void
delete_BinomialMat(double **binomialMat, int len_binomialMat)
{
  for (int i=0; i<len_binomialMat; i++)
		delete binomialMat[i];
  delete binomialMat;
}

// compute binomial coefficients
// computed binomial coefficients stored into binomialMat array
void computeBinomials(double **binomialMat, int len_binomialMat)
{
  for (int i=0; i<len_binomialMat; i++)
  {
		for (int j=0; j<len_binomialMat; j++)
		{
			binomialMat[i][j]=0;
		}
  }
  for (int i=0; i<len_binomialMat; i++)
	binomialMat[i][0] +=1;

  for (int j=1; j<len_binomialMat; j++) 
		binomialMat[0][j] +=1;

  for (int k=1; k<len_binomialMat; k++)
  {
	for (int l=1; l<len_binomialMat; l++)
		{
			binomialMat[k][l] += binomialMat[k][l-1] + binomialMat[k-1][l];	
		}
  }
}


// allocate memory for B-moments
// nb_Array determines whether B-moments are associated with scalar-, vector- or matrix-valued coefficients
double **
create_Bmoment( int lenMoments, int nb_Array )
{
  double **Bmoment = new double *[lenMoments];
  double *Bmoment_array = new double[nb_Array * lenMoments];
 
  double *p1 = Bmoment_array;

  for (int i = 0; i < lenMoments; p1 += nb_Array, i++)
      Bmoment[i] = p1;

  return Bmoment;
}

// free memory allocated to B-moments
void
delete_Bmoment(double **Bmoment)
{
  delete Bmoment[0];
  delete Bmoment;
}

// allocate memory to square matrix of dimension len_Mat3d
double **
create_Mat(int len_Mat3d)
{
  double **Mat = new double *[len_Mat3d];
  double *Mat_array = new double [len_Mat3d * len_Mat3d];

  double *p = Mat_array;
  for (int i=0; i<len_Mat3d; p += len_Mat3d, i++)
	Mat[i] = p;
  
  return Mat;
}

void delete_Mat(double **Mat)
{
  delete Mat[0];
  delete Mat;
}



// routine for freeing dynamically allocated memory
// this is used for both the convective and the stiffness matrices
// used for computing elemental quantities associated with variable data

// quadraWN used to store Gauss-Jacobi quadrature weights and nodes
// Bmoment used to store B-moments associated with mass matrix coefficients
#ifdef PRECOMP
// precomp used to store precomputed arrays needed in computation of B-moments associated with mass matrix coefficients
// matValNodes used to store coefficients values at the quadrature nodes
void
delete_pointers_Bmom(double **precomp, double **matValNodes, double **quadraWN)
#else
// BmomentInter used to store intermediate values needed in computation of B-moments associated with mass matrix coefficients
void
delete_pointers_Bmom(double **BmomentInter, double **quadraWN)
#endif

{
	#ifdef PRECOMP
  delete_precomp(precomp);
  #endif
  
  #ifdef PRECOMP
  delete_matValNodes(matValNodes);
	#else
	delete_Bmoment(BmomentInter);
  #endif

  delete_quadraWN(quadraWN);
   
  
}


// quadraWN used to store Gauss-Jacobi quadrature weights and nodes
// Bmoment used to store B-moments
#ifdef PRECOMP
// precomp used to store precomputed arrays needed in B-moments' computation 
// matValNodes used to store coefficients values at the quadrature nodes
void
delete_pointers_Mass(double **precomp, double **Bmoment,
										 double **matValNodes, double **quadraWN)
#else
// BmomentInter used to store intermediate values needed in B-moments' computation
void
delete_pointers_Mass(double **Bmoment, double **BmomentInter, 
										 double **quadraWN)
#endif
{
	#ifdef PRECOMP
  delete_precomp(precomp);
  #endif
  
  delete_Bmoment(Bmoment);	
 
  #ifdef PRECOMP
  delete_matValNodes(matValNodes);
	#else
	delete_Bmoment(BmomentInter);
  #endif

  delete_quadraWN(quadraWN);  
  
}

// quadraWN used to store Gauss-Jacobi quadrature weights and nodes
// Bmoment used to store B-moments associated with convective matrix coefficients
// Bmomentab used to store inner products of vector-valued B-moments with normals to the element's edges
#ifdef PRECOMP
// precomp used to store precomputed arrays needed in computation of B-moments associated with convective matrix coefficients
// matValNodes used to store coefficients values at the quadrature nodes
void
delete_pointers(double **precomp, double **Bmoment, double **Bmomentab, double **matValNodes, double **quadraWN)
#else
// BmomentInter used to store intermediate values needed in computation of B-moments associated with convective matrix coefficients
void
delete_pointers(double **Bmoment, double **BmomentInter, 
											 double **Bmomentab, double **quadraWN)
#endif
{
	#ifdef PRECOMP
  delete_precomp(precomp);
  #endif
  
  delete_Bmoment(Bmoment);
	
  delete_Bmoment(Bmomentab);
  
  #ifdef PRECOMP
  delete_matValNodes(matValNodes);
	#else
	delete_Bmoment(BmomentInter);
  #endif
	
  delete_quadraWN(quadraWN);    
  
}


#ifdef PRECOMP


// initializes matValNodes, used for B-moments computation
// nb_Array allows to handle scalar-, vector- or matrix-valued coefficients
// WARNING: the Stroud nodes corresponding to PRECOMP are different
// from those used with NO PRECOMP
// q is the number of quadrature points
// Cval contains the coefficients values at the quadrature nodes
void
data_at_Nodes_Cval2d (double **matValNodes, int q, double *Cval, int nb_Array)    
{
  int index_ij = 0;
  double *val = Cval;


	for (int i = 0; i < q; i++)
    {

			for (int j = 0; j < q; j++)
        {
          for (int ell = 0; ell < nb_Array; ell++)
            matValNodes[index_ij][ell] = *val++;

          index_ij++;
        }
    }
}

//need to create four different copies of data_at_Nodes_*,
// so that compiler does not complain about global arrays legendre and jacobi
// this depends on q (number of quadrature nodes), thus (arbitrary) position2d2( . , q) is used
// f is a scalar-valued function which produces the B-moments coefficients
// matValNodes contains coefficient values at the quadrature nodes
// q^2 is the number of quadrature points
// quadraWN contains Gauss-Jacobi quadrature weights and nodes
// v1, v2, v3 are the element's vertices
void
data_at_Nodes_Bmom2d (double (*f) (double[2]), double **matValNodes, int q,
							 double **quadraWN,
							 double v1[2], double v2[2], double v3[2])
{
	// add parameters legendre_w and jacobi_w so that use of "JacobiGaussNodes.h" is optional
	#ifdef GAUJAC
	double *legendre_x = quadraWN[1]; // legendre_x is pointer which points to the address quadraWN[1]
	double *jacobi_x = quadraWN[3]; 
	#endif
	

  double B1, B2, B3;


	for (int i = 0; i < q; i++)
    {
			for (int j = 0; j < q; j++)
        {

					
					#ifdef GAUJAC
					B3 = (1 - jacobi_x[i+1]) * (1 - legendre_x[j+1]) / 4; // indices start at 1 with GAUJAC
          B1 = (1 + jacobi_x[i+1]) / 2;
          B2 = (1 - jacobi_x[i+1]) * (1 + legendre_x[j+1]) / 4;
					#else
					B3 = (1 - jacobi[1][q - 2][i]) * (1 - legendre[1][q - 2][j]) / 4; 
          B1 = (1 + jacobi[1][q - 2][i]) / 2;
          B2 = (1 - jacobi[1][q - 2][i]) * (1 + legendre[1][q - 2][j]) / 4;
					#endif

          double x_ij[2] = { B1 * v1[0] + B2 * v2[0] + B3 * v3[0],
            B1 * v1[1] + B2 * v2[1] + B3 * v3[1]
          };

          double functVal = (*f) (x_ij);

					int index_ij = position2d2 (i, j, q-1);

					// cannot use nb_Array, since STIFF uses matC, and MASS and BMOM use functVal
          matValNodes[index_ij][0] = functVal;

        }
    }
    
}


// f is a scalar-valued function which produces the B-moments coefficients
// matValNodes contains coefficient values at the quadrature nodes
// q^2 is the number of quadrature points
// quadraWN contains Gauss-Jacobi quadrature weights and nodes
// v1, v2, v3 are the element's vertices
void
data_at_Nodes_Mass2d (double (*f) (double[2]), double **matValNodes, int q,
							 double **quadraWN,
							 double v1[2], double v2[2], double v3[2])
{
	
	#ifdef GAUJAC
	double *legendre_x = quadraWN[1]; // legendre_x is pointer which points to the address quadraWN[1]
	double *jacobi_x = quadraWN[3];
	#endif

  double B1, B2, B3;


	for (int i = 0; i < q; i++)
    {
			for (int j = 0; j < q; j++)
        {

					
					#ifdef GAUJAC
					B3 = (1 - jacobi_x[i+1]) * (1 - legendre_x[j+1]) / 4; // indices start at 1 with GAUJAC
          B1 = (1 + jacobi_x[i+1]) / 2;
          B2 = (1 - jacobi_x[i+1]) * (1 + legendre_x[j+1]) / 4;
					#else
					B3 = (1 - jacobi[1][q - 2][i]) * (1 - legendre[1][q - 2][j]) / 4; 
          B1 = (1 + jacobi[1][q - 2][i]) / 2;
          B2 = (1 - jacobi[1][q - 2][i]) * (1 + legendre[1][q - 2][j]) / 4;
					#endif

          double x_ij[2] = { B1 * v1[0] + B2 * v2[0] + B3 * v3[0],
            B1 * v1[1] + B2 * v2[1] + B3 * v3[1]
          };


          double functVal = (*f) (x_ij);
					int index_ij = position2d2 (i, j, q-1);

          matValNodes[index_ij][0] = functVal;
        }
    }
    

}


// b is a vector-valued function which produces the convective matrix coefficients
// matValNodes contains coefficient values at the quadrature nodes
// q^2 is the number of quadrature points
// quadraWN contains Gauss-Jacobi quadrature weights and nodes
// v1, v2, v3 are the element's vertices
void
data_at_Nodes_Convec2d ( void (*b) (double[2], double[2]), double **matValNodes, int q,
							 double **quadraWN,
							 double v1[2], double v2[2], double v3[2])
{
	
	// add parameters legendre_w and jacobi_w so that use of "JacobiGaussNodes.h" is optional
	#ifdef GAUJAC
	double *legendre_x = quadraWN[1]; // legendre_x is pointer which points to the address quadraWN[1]
	double *jacobi_x = quadraWN[3];
	#endif

  double B1, B2, B3;

  double vect[2];            // store intermediate values

	for (int i = 0; i < q; i++)
    {
			for (int j = 0; j < q; j++)
        {

					
					#ifdef GAUJAC
					B3 = (1 - jacobi_x[i+1]) * (1 - legendre_x[j+1]) / 4; // indices start at 1 with GAUJAC
          B1 = (1 + jacobi_x[i+1]) / 2;
          B2 = (1 - jacobi_x[i+1]) * (1 + legendre_x[j+1]) / 4;
					#else
					B3 = (1 - jacobi[1][q - 2][i]) * (1 - legendre[1][q - 2][j]) / 4;
          B1 = (1 + jacobi[1][q - 2][i]) / 2;
          B2 = (1 - jacobi[1][q - 2][i]) * (1 + legendre[1][q - 2][j]) / 4;
					#endif

          double x_ij[2] = { B1 * v1[0] + B2 * v2[0] + B3 * v3[0],
            B1 * v1[1] + B2 * v2[1] + B3 * v3[1]
          };


					(*b) (x_ij, vect); // evaluate b at x_ij
							int index_ij = position2d2 (i, j, q-1);

					matValNodes[index_ij][0] = vect[0];
					matValNodes[index_ij][1] = vect[1];

        }
    }
    

}


// C is a (symmetric) matrix-valued function which produces the stiffness matrix coefficients
// matValNodes contains coefficient values at the quadrature nodes
// q^2 is the number of quadrature points
// quadraWN contains Gauss-Jacobi quadrature weights and nodes
// v1, v2, v3 are the element's vertices
void
data_at_Nodes_Stiff2d (void (*C) (double[2], double[2][2]), double **matValNodes, int q,
										 double **quadraWN,
										 double v1[2], double v2[2], double v3[2])
{
	
	// add parameters legendre_w and jacobi_w so that use of "JacobiGaussNodes.h" is optional
	#ifdef GAUJAC
	double *legendre_x = quadraWN[1]; // legendre_x is pointer which points to the address quadraWN[1]
	double *jacobi_x = quadraWN[3];
	#endif

  double B1, B2, B3;

  double matC[2][2];            // store intermediate values

	for (int i = 0; i < q; i++)
    {
			for (int j = 0; j < q; j++)
        {

					
					#ifdef GAUJAC
					B3 = (1 - jacobi_x[i+1]) * (1 - legendre_x[j+1]) / 4; // indices start at 1 with GAUJAC
          B1 = (1 + jacobi_x[i+1]) / 2;
          B2 = (1 - jacobi_x[i+1]) * (1 + legendre_x[j+1]) / 4;
					#else
					B3 = (1 - jacobi[1][q - 2][i]) * (1 - legendre[1][q - 2][j]) / 4; 
          B1 = (1 + jacobi[1][q - 2][i]) / 2;
          B2 = (1 - jacobi[1][q - 2][i]) * (1 + legendre[1][q - 2][j]) / 4;
					#endif

          double x_ij[2] = { B1 * v1[0] + B2 * v2[0] + B3 * v3[0],
            B1 * v1[1] + B2 * v2[1] + B3 * v3[1]
          };



          (*C) (x_ij, matC);   // evaluate C at x_ij 
					
					int index_ij = position2d2 (i, j, q-1);


          matValNodes[index_ij][0] = matC[0][0];
          matValNodes[index_ij][1] = matC[0][1];        // matC is symmetric
          matValNodes[index_ij][2] = matC[1][1];
        }
    }
    

}


void delete_precomp(double **precomp)
{
  delete precomp[0];
  delete precomp;
}
#endif // end PRECOMP

//freeing the memory allocated to the arrays of quadrature knots and weights used by 'gaussJacobiUnit'
void
delete_quadraWN (double **quadraWN)
{
  delete quadraWN[0];
  delete quadraWN;
}

//////////////////////////////////////////////////////////////////////////// 3D routines /////////////////////////////////


#ifdef PRECOMP

// allocates memory to matValNodes
// matValNodes is used to store coefficients values at the quadrature nodes
double **
create_matValNodes3d(int len_matValNodes)
{
  double **matValNodes = new double *[len_matValNodes];
  double *matValNodes_array = new double[len_matValNodes * 6];  // by default: with Stiff, needs 6 independent entries

  double *p_matVal = matValNodes_array;
  for (int i = 0; i < len_matValNodes; i++, p_matVal += 6)
    matValNodes[i] = p_matVal;
  
  return matValNodes;
}



// computes Bmoment vector entries into Bmoment array
// matValNodes initialized by means of data_at_Nodes_* or data_at_Nodes_Cval3d routines
// parameter q stands for the number of quadrature points in each direction
// precomp contains precomputed arrays used in the B-moments computation
// binomialMat contains binomial coefficients
// nb_Array determines the length of the Bmoment (whether the output is associated with a scalar-, vector- or matrix-valued function)
double
Bmoment3d (int n, int q, int nb_Array, double v1[3], double v2[3], double v3[3], double v4[3], 
		  double **binomialMat, double **precomp, double **Bmoment, double **matValNodes)      
{
	

  int mm = ( (n+3)*(n+2)*(n+1) )/6;

  double Const = Volume3d(v1,v2,v3,v4)* 3./32;
  
	int mp = MAX(n,q-1); // mp+1 = size allocated to precomp

  clock_t t0, t1;
  double cpu_time_used;

  t0=clock();


  // initialize all the entries of Bmoment since they are modified at each function call !!
  for (int mu = 0; mu < mm; mu++)
  {
	for (int ell=0; ell< nb_Array; ell++)
	  Bmoment[mu][ell] = 0.0;
								
  }


	double H[nb_Array][q], L[nb_Array];

	for (int mu0=0; mu0<=n; mu0++)
  {	
	for (int k=0; k< q; k++)
	{
		for (int j=0; j< q; j++)
	  {
		for (int ell=0; ell<nb_Array; ell++)
		  H[ell][j]=0;
				
		for (int i=0; i< q; i++)
		{

			int index_ijk = position3d2(i,j,k,q-1);

			double Const = precomp[3*(mp+1) + mu0][i] * precomp[4*(mp+1) + mu0][i];

			for (int ell=0; ell<nb_Array; ell++)
			  H[ell][j] +=  Const * matValNodes[index_ijk][ell];

			
		 } 
	  }
		
		for (int mu1=0; mu1<=n-mu0; mu1++)
	  {
		for (int ell=0; ell< nb_Array; ell++)
		  L[ell] = 0;
		
		for (int j=0; j< q; j++)
		{  
			double precomp6mu0mu1= precomp[5*(mp+1)+ n-mu0-mu1][j];		  
		  double precomp3mu1=  precomp[2*(mp+1) + mu1][j];
		  
		  for (int ell=0; ell<nb_Array; ell++)
				L[ell] += precomp6mu0mu1 * precomp3mu1 * H[ell][j] ;
			
		}
		for (int mu3=0; mu3<=n-mu0-mu1; mu3++)
		{
			int mu2=n-mu3-mu0-mu1; int iMu=position3d(mu1,mu2,mu3);	
			
			double Const_mu = precomp[mu3][k] * precomp[(mp+1) + mu2][k] * binomialMat[mu3+mu0+mu1][mu2] * binomialMat[mu3+mu0][mu1] * binomialMat[mu3][mu0] * Const ;
										
			for (int ell=0; ell< nb_Array; ell++)
			  Bmoment[iMu][ell] += L[ell] * Const_mu;

		}
	  }  
	} 
			
  }
		
  t1=clock();

  
  #ifdef CHECK // check output
  std::cout<<"Bmoments entries (PRECOMP method):\n";
  for (int mu1=n; mu1>=0; mu1--)		
  {
	for (int mu2=n-mu1; mu2>=0; mu2--)
	{
	  int mu4=0;
	  for (int mu3=n-mu1-mu2; mu3>=0; mu3--, mu4++)
	  {
		int iMu = position3d(mu2,mu3,mu4);
		std::cout<<"Bmoment"<<"["<<mu1<<" "<<mu2<<" "<<mu3<<" "<<n-mu1-mu2-mu3<<"]: ";
		
		for (int ell = 0; ell < nb_Array; ell++)
					std::cout<<std::scientific<<Bmoment[iMu][ell]<<"\t";
		
		std::cout<<"\n";
		
	  }
	}
  }
  std::cout<<"\n";
  #endif

  cpu_time_used=((double)(t1-t0))/CLOCKS_PER_SEC;

  return cpu_time_used;


}


// initialize precomp entries
// n stands for the B-moment order
// q^3 quadrature points are used
// quadraWN contains Gauss-Jacobi quadrature weights and nodes
void
init_precomp3d(double **precomp, int n, int q, int mp, double **quadraWN)
{
	
	#ifdef GAUJAC
	double *legendre_x = quadraWN[5]; // legendre_x is pointer which points to the address quadraWN[1]
  double *legendre_w = quadraWN[4];
	
	double *jacobi_x = quadraWN[3];
	double *jacobi_w = quadraWN[2];	
	
	double *jacobi2_x = quadraWN[1];
	double *jacobi2_w = quadraWN[0];
	#endif
	
	for (int mu1=0; mu1< n+1; mu1++)
  {
		for (int j=0; j< q; j++)
		{
			
			#ifdef GAUJAC
			
			precomp[mu1][j] = sqrt( legendre_w[j+1] ) * pow( ( 1-legendre_x[j+1] )/2, mu1); // indices start at 1 with GAUJAC
			precomp[(mp+1) + mu1][j]= sqrt( legendre_w[j+1] ) * pow( (1+legendre_x[j+1])/2 , mu1);
			
			precomp[2*(mp+1) + mu1][j] = sqrt( jacobi_w[j+1] ) * pow ( (1+jacobi_x[j+1])/2 , mu1);
			
			precomp[3*(mp+1) + mu1][j] = sqrt( jacobi2_w[j+1] ) * pow ( (1-jacobi2_x[j+1])/2, n-mu1);

			precomp[4*(mp+1) + mu1][j] = sqrt( jacobi2_w[j+1] ) * pow ( (1+jacobi2_x[j+1])/2, mu1);
			
			precomp[5*(mp+1) + mu1][j] = sqrt(jacobi_w[j+1]) * pow( (1- jacobi_x[j+1])/2, mu1 );
			
			#else


			precomp[mu1][j] = sqrt( legendre[0][q-2][j] ) * pow( ( 1-legendre[1][q-2][j] )/2, mu1);
			precomp[(mp+1) + mu1][j]= sqrt( legendre[0][q-2][j] ) * pow( (1+legendre[1][q-2][j])/2 , mu1);
			precomp[2*(mp+1) + mu1][j] = sqrt( jacobi[0][q-2][j] ) * pow ( (1+jacobi[1][q-2][j])/2 , mu1);

			precomp[3*(mp+1) + mu1][j] = sqrt( jacobi2[0][q-2][j] ) * pow ( (1-jacobi2[1][q-2][j])/2, n-mu1);

			precomp[4*(mp+1) + mu1][j] = sqrt( jacobi2[0][q-2][j] ) * pow ( (1+jacobi2[1][q-2][j])/2, mu1);
			 			
			precomp[5*(mp+1) + mu1][j] = sqrt(jacobi[0][q-2][j]) * pow( (1- jacobi[1][q-2][j])/2, mu1 ); // thus need precomp[5*(mp+1) + n-mu1-mu2][j]
			
			#endif
	  
		}
  
	}
	
}

// allocate memory to precomp array
double **
create_precomp3d(int len_precomp)
{
  double **precomp = new double *[6 * len_precomp];
  double *precomp_array = new double [6 * len_precomp * len_precomp];
  
  double *p = precomp_array;
  for (int i=0; i< 6 * len_precomp; p += len_precomp, i++)
	precomp[i] = p;
  
  return precomp;
}



// initializes matValNodes, used for B-moments computation
// nb_Array allows to handle scalar-, vector- or matrix-valued coefficients
// WARNING: the Stroud nodes corresponding to PRECOMP are different
// from those used with NO PRECOMP
// q^3 is the number of quadrature points
// Cval contains the coefficients values at the quadrature nodes
void
data_at_Nodes_Cval3d(double **matValNodes, int q, double *Cval, int nb_Array)
{
	int index_ijk = 0;
  double *val = Cval;

	for (int i = 0; i < q; i++)
	{
		for (int j = 0; j < q; j++)
		{
			for (int k=0; k< q; k++)
			{
				for (int ell = 0; ell < nb_Array; ell++)
					matValNodes[index_ijk][ell] = *val++;

				index_ijk++;
			}
		}
	}
}



//need to create four different copies of data_at_Nodes_*,
// so that compiler does not complain about global arrays legendre and jacobi
// this depends on q (number of quadrature nodes), thus (arbitrary) index( . , q) is used
// f is a scalar-valued function which produces the B-moments coefficients
// matValNodes contains coefficient values at the quadrature nodes
// q^3 is the number of quadrature points
// quadraWN contains Gauss-Jacobi quadrature weights and nodes
// v1, v2, v3, v4 are the element's vertices 			
void
data_at_Nodes_Bmom3d ( double (*f) (double[3]), 
										 double **matValNodes, int q, double **quadraWN,
										 							double v1[3], double v2[3], double v3[3], double v4[3] ) 
{ 

	#ifdef GAUJAC
	double *legendre_x = quadraWN[5]; // legendre_x is pointer which points to the address quadraWN[1]
	double *jacobi_x = quadraWN[3];
	double *jacobi2_x = quadraWN[1];
	#endif
	
  double B1, B2, B3, B4;

	for (int i=0; i< q; i++)
  {
		for (int j=0; j< q; j++)
		{
			for (int k=0; k< q; k++)
			{
	
			#ifdef GAUJAC
			
			B4= (1-jacobi2_x[i+1]) * (1-jacobi_x[j+1]) * (1-legendre_x[k+1]) / 8; // indices start at 1 with GAUJAC
			B1= (1+jacobi2_x[i+1])/2;
			B2= (1-jacobi2_x[i+1]) * (1+jacobi_x[j+1]) / 4;
			B3= (1-jacobi2_x[i+1]) * ( 1-jacobi_x[j+1]) * (1+legendre_x[k+1]) / 8;
			
			#else

			B4= (1-jacobi2[1][q-2][i]) * (1-jacobi[1][q-2][j]) * (1-legendre[1][q-2][k]) / 8; 
			B1= (1+jacobi2[1][q-2][i])/2;
			B2= (1-jacobi2[1][q-2][i]) * (1+jacobi[1][q-2][j]) / 4;
			B3= (1-jacobi2[1][q-2][i]) * ( 1-jacobi[1][q-2][j]) * (1+legendre[1][q-2][k]) / 8;
			
			#endif
			
			double x_ijk[3] = { B1*v1[0] + B2*v2[0] + B3*v3[0] + B4*v4[0] , B1*v1[1]+ B2*v2[1] + B3*v3[1] + B4*v4[1] , B1*v1[2] + B2*v2[2] + B3*v3[2] + B4*v4[2]  };
			
			
			double functVal = (*f)(x_ijk);
			
			int index_ijk = position3d2(i,j,k,q-1);
			
			matValNodes[index_ijk][0] = functVal;
					
			}
		}
  } 

}


//pre-computes values of f at the quadrature nodes corresponding to degree q = q(n)
//q^3 is the number of quadrature points in each direction
// this depends on q (number of quadrature nodes), thus (arbitrary) index( . , q) is used
// f is a scalar-valued function which produces the B-moments coefficients
// matValNodes contains coefficient values at the quadrature nodes
// q^3 is the number of quadrature points
// quadraWN contains Gauss-Jacobi quadrature weights and nodes
// v1, v2, v3, v4 are the element's vertices 	
void
data_at_Nodes_Mass3d ( double (*f) (double[3]),
										 double **matValNodes, int q, double **quadraWN,
										 double v1[3], double v2[3], double v3[3], double v4[3] )
{
	
	#ifdef GAUJAC
	double *legendre_x = quadraWN[5]; // legendre_x is pointer which points to the address quadraWN[1]
	double *jacobi_x = quadraWN[3];
	double *jacobi2_x = quadraWN[1];
	#endif


  double B1, B2, B3, B4;

	for (int i=0; i< q; i++)
  {
		for (int j=0; j< q; j++)
		{
			for (int k=0; k< q; k++)
			{
	
			#ifdef GAUJAC
			
			B4= (1-jacobi2_x[i+1]) * (1-jacobi_x[j+1]) * (1-legendre_x[k+1]) / 8; // indices start at 1 with GAUJAC
			B1= (1+jacobi2_x[i+1])/2;
			B2= (1-jacobi2_x[i+1]) * (1+jacobi_x[j+1]) / 4;
			B3= (1-jacobi2_x[i+1]) * ( 1-jacobi_x[j+1]) * (1+legendre_x[k+1]) / 8;
			
			#else

			B4= (1-jacobi2[1][q-2][i]) * (1-jacobi[1][q-2][j]) * (1-legendre[1][q-2][k]) / 8;
			B1= (1+jacobi2[1][q-2][i])/2;
			B2= (1-jacobi2[1][q-2][i]) * (1+jacobi[1][q-2][j]) / 4;
			B3= (1-jacobi2[1][q-2][i]) * ( 1-jacobi[1][q-2][j]) * (1+legendre[1][q-2][k]) / 8;
			
			#endif
			
			double x_ijk[3] = { B1*v1[0] + B2*v2[0] + B3*v3[0] + B4*v4[0] , B1*v1[1]+ B2*v2[1] + B3*v3[1] + B4*v4[1] , B1*v1[2] + B2*v2[2] + B3*v3[2] + B4*v4[2]  };
			
			
			double functVal = (*f)(x_ijk);

			int index_ijk = position3d2(i,j,k,q-1);
	
			matValNodes[index_ijk][0] = functVal;
							
			}
		}
  } 

}

//pre-computes values of b at the quadrature nodes corresponding to degree q = q(n)
//q^3 is the number of quadrature points in each direction
// this depends on q (number of quadrature nodes), thus (arbitrary) index( . , q) is used
// b is a vector-valued function which produces the B-moments coefficients
// matValNodes contains coefficient values at the quadrature nodes
// q^3 is the number of quadrature points
// quadraWN contains Gauss-Jacobi quadrature weights and nodes
// v1, v2, v3, v4 are the element's vertices 
void
data_at_Nodes_Convec3d ( void (*b) (double[3], double[3]), 
											 double **matValNodes, int q, double **quadraWN,
											 double v1[3], double v2[3], double v3[3], double v4[3] ) 
{ 
	
	#ifdef GAUJAC
	double *legendre_x = quadraWN[5]; // legendre_x is pointer which points to the address quadraWN[1]
	double *jacobi_x = quadraWN[3];
	double *jacobi2_x = quadraWN[1];
	#endif
	
  double vect[3]; // store intermediate results


  double B1, B2, B3, B4;

	for (int i=0; i< q; i++)
  {
		for (int j=0; j< q; j++)
		{
			for (int k=0; k< q; k++)
			{
	
			#ifdef GAUJAC
			
			B4= (1-jacobi2_x[i+1]) * (1-jacobi_x[j+1]) * (1-legendre_x[k+1]) / 8; // indices start at 1 with GAUJAC
			B1= (1+jacobi2_x[i+1])/2;
			B2= (1-jacobi2_x[i+1]) * (1+jacobi_x[j+1]) / 4;
			B3= (1-jacobi2_x[i+1]) * ( 1-jacobi_x[j+1]) * (1+legendre_x[k+1]) / 8;
			
			#else

			B4= (1-jacobi2[1][q-2][i]) * (1-jacobi[1][q-2][j]) * (1-legendre[1][q-2][k]) / 8; 
			B1= (1+jacobi2[1][q-2][i])/2;
			B2= (1-jacobi2[1][q-2][i]) * (1+jacobi[1][q-2][j]) / 4;
			B3= (1-jacobi2[1][q-2][i]) * ( 1-jacobi[1][q-2][j]) * (1+legendre[1][q-2][k]) / 8;
			
			#endif
			
			double x_ijk[3] = { B1*v1[0] + B2*v2[0] + B3*v3[0] + B4*v4[0] , B1*v1[1]+ B2*v2[1] + B3*v3[1] + B4*v4[1] , B1*v1[2] + B2*v2[2] + B3*v3[2] + B4*v4[2]  };
			
			
			(*b)(x_ijk, vect);
			
			int index_ijk = position3d2(i,j,k,q-1);
			
			matValNodes[index_ijk][0] = vect[0];
			matValNodes[index_ijk][1] = vect[1];
			matValNodes[index_ijk][2] = vect[2];
					
				
			}
		}
  } 

}

//pre-computes values of A at the quadrature nodes corresponding to degree q = q(n)
//q^3 is the number of quadrature points in each direction
// this depends on q (number of quadrature nodes), thus (arbitrary) index( . , q) is used
// A is a (symmetric) matrix-valued function which produces the B-moments coefficients
// matValNodes contains coefficient values at the quadrature nodes
// q^3 is the number of quadrature points
// quadraWN contains Gauss-Jacobi quadrature weights and nodes
// v1, v2, v3, v4 are the element's vertices 
void
data_at_Nodes_Stiff3d ( void (*A)(double[3],double[3][3]), 
											double **matValNodes, int q, double **quadraWN, 
											double v1[3], double v2[3], double v3[3], 
											double v4[3] ) 
{ 
	
	#ifdef GAUJAC
	double *legendre_x = quadraWN[5]; // legendre_x is pointer which points to the address quadraWN[1]
	double *jacobi_x = quadraWN[3];
	double *jacobi2_x = quadraWN[1];
	#endif
	
  double matC[3][3]; // store intermediate results


  double B1, B2, B3, B4;

	for (int i=0; i< q; i++)
  {
		for (int j=0; j< q; j++)
		{
			for (int k=0; k< q; k++)
			{
	
			#ifdef GAUJAC
			
			B4= (1-jacobi2_x[i+1]) * (1-jacobi_x[j+1]) * (1-legendre_x[k+1]) / 8; // indices start at 1 with GAUJAC
			B1= (1+jacobi2_x[i+1])/2;
			B2= (1-jacobi2_x[i+1]) * (1+jacobi_x[j+1]) / 4;
			B3= (1-jacobi2_x[i+1]) * ( 1-jacobi_x[j+1]) * (1+legendre_x[k+1]) / 8;
			
			#else

			B4= (1-jacobi2[1][q-2][i]) * (1-jacobi[1][q-2][j]) * (1-legendre[1][q-2][k]) / 8; 
			B1= (1+jacobi2[1][q-2][i])/2;
			B2= (1-jacobi2[1][q-2][i]) * (1+jacobi[1][q-2][j]) / 4;
			B3= (1-jacobi2[1][q-2][i]) * ( 1-jacobi[1][q-2][j]) * (1+legendre[1][q-2][k]) / 8;
			
			#endif
			
			double x_ijk[3] = { B1*v1[0] + B2*v2[0] + B3*v3[0] + B4*v4[0] , B1*v1[1]+ B2*v2[1] + B3*v3[1] + B4*v4[1] , B1*v1[2] + B2*v2[2] + B3*v3[2] + B4*v4[2]  };
			
			
			(*A)(x_ijk,matC); // evaluate A at x_ijk and store result into matC
			
			int index_ijk = position3d2(i,j,k,q-1);
		
			matValNodes[index_ijk][0]= matC[0][0];
			matValNodes[index_ijk][1]= matC[0][1];
			matValNodes[index_ijk][2]= matC[0][2];
			matValNodes[index_ijk][3]= matC[1][1]; 
			matValNodes[index_ijk][4]= matC[1][2];
			matValNodes[index_ijk][5]= matC[2][2];		
				
			}
		}
  } 

}


#else // non-PRECOMP

// create four versions of init_BmomentC_*

//initialize BmomentC by the values of the function f at the quadrature points of order q
//f given as function in Cartesian coordinates, realised with (double)(*f) (double [3])
// q^3 is the number of quadrature points
// v1, v2, v3, v4 are the element's vertices
// computed B-moments are stored into Bmoment array
// quadraWN contains Gauss-Jacobi quadrature weights and nodes
void
init_BmomentC_Bmom3d ( double (*f) (double [3]), int q, 
										 double v1[3], double v2[3], double v3[3], double v4[3], 
										 double **BmomentInter, double **quadraWN)
{
	
  double scalingConst = 6 * Volume3d(v1, v2, v3, v4); // Jacobian of Duffy transformation
  
  
  double b1,b2,b3,b4;
	

  double *pI;
  int index_ijk=0;

	for (int i=0; i< q; i++)
  {
		b1= quadraWN[1][i+1];

		index_ijk = i * q * q ;

		for (int j=0; j< q; j++)
		{
			index_ijk += j * q;
		
			b2= quadraWN[3][j+1]*(1-b1);
			
			for (int k=0; k< q; k++)
			{
				index_ijk += k;
				
				#ifdef OLDS
				int index_ijk = position3d2(i,j,k,q-1);
				#endif

				b3= quadraWN[5][k+1]*(1-b1-b2); b4= 1-b1-b2-b3;
				
				double v[3];
				bary2cart3d(b1,b2,b3,b4,v1,v2,v3,v4,v);
				
			
				double functVal = (*f)(v);
				
				pI = BmomentInter[index_ijk];
				

				BmomentInter[index_ijk][0] = scalingConst * functVal; 
				
				index_ijk -= k;
				
			}
			index_ijk -= j * q ;
		}
  }
  
	
}


//initialize BmomentC by the values of the function f at the quadrature points of order q
//f given as function in Cartesian coordinates, realised with (double)(*f) (double [3])
// q^3 is the number of quadrature points
// v1, v2, v3, v4 are the element's vertices
// computed B-moments are stored into Bmoment array
// quadraWN contains Gauss-Jacobi quadrature weights and nodes
void
init_BmomentC_Mass3d ( double (*f) (double [3]), int q, 
										 double v1[3], double v2[3], double v3[3], double v4[3], 
										 double **BmomentInter, double **quadraWN)
{
	
  double scalingConst = 6 * Volume3d(v1, v2, v3, v4); // Jacobian of Duffy transformation
  
  
  double b1,b2,b3,b4;
	

  double *pI;
  int index_ijk=0;

	for (int i=0; i< q; i++)
  {
		b1= quadraWN[1][i+1];

		index_ijk = i * q * q ;

		for (int j=0; j< q; j++)
		{
			index_ijk += j * q;
		
			b2= quadraWN[3][j+1]*(1-b1);
			
			for (int k=0; k< q; k++)
			{
				index_ijk += k;
				
				#ifdef OLDS
				int index_ijk = position3d2(i,j,k,q-1);
				#endif

				b3= quadraWN[5][k+1]*(1-b1-b2); b4= 1-b1-b2-b3;
				
				double v[3];
				bary2cart3d(b1,b2,b3,b4,v1,v2,v3,v4,v);
				

				double functVal = (*f)(v);
				
				pI = BmomentInter[index_ijk];
				

				BmomentInter[index_ijk][0] = scalingConst * functVal;
			
				index_ijk -= k;
				
			}
			index_ijk -= j * q ;
		}
  }
  
	
}

//initialize BmomentC by the values of the vector-valued function b at the quadrature points of order q
//b given as function in Cartesian coordinates, realised with (void)(*b) (double [3], double[3])
// q^3 is the number of quadrature points
// v1, v2, v3, v4 are the element's vertices
// computed B-moments are stored into Bmoment array
// quadraWN contains Gauss-Jacobi quadrature weights and nodes
void
init_BmomentC_Convec3d ( void (*b)(double[3],double[3]), int q, 
											 double v1[3], double v2[3], double v3[3], double v4[3], 
											 double **BmomentInter, double **quadraWN)
{
	
  double scalingConst = 6 * Volume3d(v1, v2, v3, v4); // Jacobian of Duffy transformation
  
  
  double b1,b2,b3,b4;
	
  double vect[3];            // store intermediate (function) values


  double *pI;
  int index_ijk=0;

	for (int i=0; i< q; i++)
  {
		b1= quadraWN[1][i+1];

		index_ijk = i * q * q ;

		for (int j=0; j< q; j++)
		{
			index_ijk += j * q;
		
			b2= quadraWN[3][j+1]*(1-b1);
			
			for (int k=0; k< q; k++)
			{
				index_ijk += k;
				
				#ifdef OLDS
				int index_ijk = position3d2(i,j,k,q-1);
				#endif

				b3= quadraWN[5][k+1]*(1-b1-b2); b4= 1-b1-b2-b3;
				
				double v[3];
				bary2cart3d(b1,b2,b3,b4,v1,v2,v3,v4,v);
				
				(*b)(v, vect); // puts b(v) into vect
			
				pI = BmomentInter[index_ijk];
				
				
				BmomentInter[index_ijk][0] = scalingConst * vect[0];
				BmomentInter[index_ijk][1] = scalingConst * vect[1];
				BmomentInter[index_ijk][2] = scalingConst * vect[2];
				
				index_ijk -= k;
				
			}
			index_ijk -= j * q ;
		}
  }
  
	
}

//initialize BmomentC by the values of the matrix-valued function A at the quadrature points of order q
//b given as function in Cartesian coordinates, realised with (void)(*A) (double [3], double[3][3])
// q^3 is the number of quadrature points
// v1, v2, v3, v4 are the element's vertices
// computed B-moments are stored into Bmoment array
// quadraWN contains Gauss-Jacobi quadrature weights and nodes
void
init_BmomentC_Stiff3d ( void (*A) (double[3], double[3][3]), int q, 
											double v1[3], double v2[3], double v3[3], double v4[3], 
											double **BmomentInter, double **quadraWN)
{
	
  double scalingConst = 6 * Volume3d(v1, v2, v3, v4); // Jacobian of Duffy transformation
  
  
  double b1,b2,b3,b4;
	
  double matC[3][3];            // store intermediate (function) values


  double *pI;
  int index_ijk=0;

	for (int i=0; i< q; i++)
  {
		b1= quadraWN[1][i+1];

		index_ijk = i * q * q ;

		for (int j=0; j< q; j++)
		{
			index_ijk += j * q;
		
			b2= quadraWN[3][j+1]*(1-b1);
			
			for (int k=0; k< q; k++)
			{
				index_ijk += k;
				
				#ifdef OLDS
				int index_ijk = position3d2(i,j,k,q-1);
				#endif

				b3= quadraWN[5][k+1]*(1-b1-b2); b4= 1-b1-b2-b3;
				
				double v[3];
				bary2cart3d(b1,b2,b3,b4,v1,v2,v3,v4,v);
				

				(*A)(v,matC); // puts A(v) into matC
				
				pI = BmomentInter[index_ijk];
				

				
				BmomentInter[index_ijk][0] = scalingConst * matC[0][0];
				BmomentInter[index_ijk][1] = scalingConst * matC[0][1];
				BmomentInter[index_ijk][2] = scalingConst * matC[0][2];
				BmomentInter[index_ijk][3] = scalingConst * matC[1][1];
				BmomentInter[index_ijk][4] = scalingConst * matC[1][2];
				BmomentInter[index_ijk][5] = scalingConst * matC[2][2];	
					
				
				index_ijk -= k;
				
			}
			index_ijk -= j * q ;
		}
  }
  
	
}




//initialize BmomentC by the coefficients values at the q-Stroud nodes ;
//the matrix, vector or scalar coefficients values are stored in Cval array: 
// matrix A: 6 values C[0][0], C[0][1], C[0][2], C[1][1], C[1][2], C[2][2] (since C is symmetric)
// vector b: 3 values b[0], b[1], b[2]
// function f: 1 value f
// for each quadrature point, altogether 4*(q+1)^3 values;
// the order of points the same as in 'stroud_bary' 
// include extra parameter nb_Array (in order to allow various kinds of data (scalar,vector,or matrix-valued)
// WARNING: Cval needs to have the CORRECT size
// q^3 is the number of quadrature points
void
init_Bmoment3d_Cval (double *Cval, int q,double v1[3], double v2[3], double v3[3], double v4[3],
									 double **BmomentInter, int nb_Array) 
                                                                                
{
  
  double scalingConst = 6 * Volume3d(v1, v2, v3, v4); // Jacobian of Duffy transformation
  
  int index_ijk = 0;
  double *val = Cval;

	for (int i = 0; i < q; i++)
	{
		for (int j = 0; j < q; j++)
		{
			for (int k=0; k < q; k++)
			{
				for (int ell = 0; ell < nb_Array; ell++)
					BmomentInter[index_ijk][ell] = scalingConst * (*val++);

				index_ijk++;
			}
		}
	}

}


//compute B-moments of order n using q-point Stroud quadrature rule
// q^3 is the number of quadrature points
// nb_Array determines the type of data with which the Bmoments are associated
// computed B-moments stored into Bmoment array
// quadraWN contains Gauss-Jacobi quadrature weights and nodes
double
Bmoment3d_Index( int n, int q, int nb_Array, double **Bmoment, double **BmomentInter,double **quadraWN )
{
  
	int m = MAX(n,q-1); // m is used for indexing

  int Len=(m+1)*(m+1)*(m+1);

  clock_t t0, t1;
  double cpu_time_used;


  t0=clock();


  for (int iMu=0; iMu<Len; iMu++)
  {
	for (int ell=0; ell< nb_Array; ell++)
	  Bmoment[iMu][ell]=0;
  }	


  	
  double xi, wgt, s, r, B;

  //convert first index
	
	for (int i=0; i< q; i++)
  {
		xi= quadraWN[1][i+1]; wgt= quadraWN[0][i+1];
		
		s=1-xi; r=xi/(1-xi);
		
		B= wgt * pow(s,n);

		int index_ijk = i * q * q; // init_BmomentC uses position3d2( . , q-1)
		for (int mu1=0; mu1<=n; mu1++)
		{
			int index_mu1jk = mu1*(m+1)*(m+1);
			for (int j=0; j< q; j++)
			{		
				index_mu1jk += j*(m+1);
				index_ijk += j* q ;
				for (int k=0; k< q; k++)
				{
					#ifdef OLDS				
					int index_mu1jk= position3d2(mu1,j,k,m);
					#endif				

					index_mu1jk += k;
					index_ijk += k;//index_ijk= position3d2(i,j,k,q-1);
				  
					for (int ell=0; ell< nb_Array; ell++)
					  Bmoment[index_mu1jk][ell] += B * BmomentInter[index_ijk][ell];
						
					index_ijk -= k;
					index_mu1jk -= k;
		  
				}
				index_mu1jk -= j*(m+1);
				index_ijk -= j* q;
			}
			B *= r*(n-mu1)/(1+mu1);
		}
	}
	  
	
  for (int iMu=0; iMu<Len; iMu++)
  {
	for (int ell=0; ell<nb_Array; ell++)
	  BmomentInter[iMu][ell]=0;
  }	


  // convert second index

	for (int j=0; j< q; j++)
  {
	xi= quadraWN[3][j+1]; wgt= quadraWN[2][j+1];

	s= 1-xi; r= xi/(1-xi);

	int index_mu1jk = j*(m+1);
	for (int mu1=0; mu1<=n; mu1++)
	{
	  int index_mu1mu2k = mu1*(m+1)*(m+1);
	  B= wgt * pow(s,n-mu1);

	  index_mu1jk += mu1*(m+1)*(m+1);
	  for (int mu2=0; mu2<=n-mu1; mu2++)
	  {
		index_mu1mu2k += mu2 * (m+1);
		for (int k=0; k< q; k++)
		{
			
		  index_mu1mu2k += k;
		  #ifdef OLDS
		  int index_mu1mu2k = position3d2(mu1,mu2,k,m);
		  #endif
	  
		  index_mu1jk += k; //index_mu1jk= position3d2(mu1,j,k,m);
	  
		  for (int ell=0; ell<nb_Array;ell++)
			BmomentInter[index_mu1mu2k][ell] += B * Bmoment[index_mu1jk][ell];
	  
		  index_mu1jk -= k;
		  index_mu1mu2k -= k;
				
		}
		B *= r*(n-mu1-mu2)/(1+mu2);
		index_mu1mu2k -= mu2 * (m+1);
	  }
	  index_mu1jk -= mu1*(m+1)*(m+1);
	}
  }

	
  for (int iMu=0; iMu<Len; iMu++)
  {
	for (int ell=0; ell< nb_Array; ell++)
	  Bmoment[iMu][ell]=0;
  }	


  // convert third index

	for (int k=0; k< q; k++)	
  {
	xi=quadraWN[5][k+1]; wgt= quadraWN[4][k+1];

	s=1-xi; r=xi/(1-xi);

	int index_mu1mu2k = k;
	for (int mu1=0; mu1<=n; mu1++)
	{
	  int index_mu1mu2mu3 = mu1*(m+1)*(m+1);
	  index_mu1mu2k += mu1*(m+1)*(m+1);
	  
	  for (int mu2=0; mu2<=n-mu1; mu2++)
	  {
		index_mu1mu2mu3 += mu2*(m+1);
		index_mu1mu2k += mu2*(m+1);
		
		B = wgt*pow(s,n-mu1-mu2);

		for (int mu3=0; mu3<=n-mu1-mu2; mu3++)
		{
		  index_mu1mu2mu3 += mu3;
		  
		  #ifdef OLDS				  
		  int index_mu1mu2mu3 = position3d2(mu1,mu2,mu3,m);
		  #endif

		  for (int ell=0; ell< nb_Array;ell++)
			Bmoment[index_mu1mu2mu3][ell] += B * BmomentInter[index_mu1mu2k][ell];
		  
		  
		  B *= r*(n-mu1-mu2-mu3) / (1+mu3);	
		  
		  index_mu1mu2mu3 -= mu3;
		}
		index_mu1mu2k -= mu2*(m+1);
		index_mu1mu2mu3 -= mu2*(m+1);
	  }
	  index_mu1mu2k -= mu1*(m+1)*(m+1);
	}
  }		
	
  
  t1=clock();
	  
  #ifdef CHECK // check output
  std::cout.precision(6);
  std::cout<<"\nBmoments entries:\n";
  for (int mu1=n; mu1>=0; mu1--)
  {
		for (int mu2=n-mu1; mu2>=0; mu2--)
		{
			for (int mu3=n-mu1-mu2; mu3>=0; mu3--)
			{
				int index_mu1mu2mu3 = position3d2(mu1,mu2,mu3,m);
				
				std::cout<<"Bmoment"<<"["<<mu1<<" "<<mu2<<" "<<mu3<<" "<<n-mu1-mu2-mu3<<"]: ";
				for (int ell = 0; ell < nb_Array; ell++)
					std::cout<<std::scientific<<Bmoment[index_mu1mu2mu3 ][ell]<<"\t";
				
				std::cout<<"\n";
			}
		}
  }
  std::cout<<"\n";
  #endif
	  
  cpu_time_used=((double)(t1-t0))/CLOCKS_PER_SEC;

  return cpu_time_used;
}


#endif // end not PRECOMP

// map to obtain Gauss-Jacobi rule on unit interval
// q is the number of quadrature points
void
gaussJacobiUnit2D(int q, double **quadraWN )
{
  
	#ifdef GAUJAC
	
	#else
	if (q>80)
	{
		std::cout<<"The polynomial order is too large. Activate GAUJAC option.\n";
		exit (EXIT_FAILURE);
	}
	#endif
	
	
  double *x = quadraWN[1]; // x is pointer which points to the address quadraWN[1], thus the effective MODIFICATION of quadraWN[1] entries
  double *w = quadraWN[0];
	
	
	#ifdef GAUJAC
	gaujac (x, w, q, 1, 0);   // stores nodes and weights of Gauss-Jacobi rule on [-1;1] into x and w
	#endif

	for (int k = 1; k <= q ; k++) // indices start at 1 with GAUJAC
    {
			#ifdef GAUJAC
		  x[k] += 1.0; x[k] *= 0.5;             // (1 + x[k]) * 0.5;
			#else
			x[k] = ( 1.0 + jacobi[1][q-2][k-1] ) * 0.5;
			#endif
		}

	for (int k = 1; k <= q ; k++) // indices start at 1 with GAUJAC
	{
		#ifdef GAUJAC
    w[k] *= 0.25;                         // w[k] * 0.25;    // w[k] / 2^(2+1-i), i=1
		#else
		w[k] = jacobi[0][q-2][k-1] * 0.25;
		#endif
	}

  x = quadraWN[3];
  w = quadraWN[2];

	
	#ifdef GAUJAC
	gaujac (x, w, q , 0, 0);
	#endif

	for (int k = 1; k <= q ; k++) // indices start at 1 with GAUJAC
    {
			#ifdef GAUJAC
      x[k] += 1.0; x[k] *= 0.5;               //x[k] = (1 + x[k]) * 0.5;
			#else
			x[k] = ( 1.0 + legendre[1][q-2][k-1] ) * 0.5;
			#endif
			
		}

	for (int k = 1; k <= q ; k++) // indices start at 1 with GAUJAC
	{
		#ifdef GAUJAC
    w[k] *= 0.5;                            //w[k] = w[k] * 0.5;   // w[k] / 2^(2+1-i), i=2
    #else
    w[k] = legendre[0][q-2][k-1] * 0.5;
		#endif
	}
	
}

// map to obtain Gauss-Jacobi rule on unit interval
// q is the number of quadrature points
void
gaussJacobiUnit3D(int q, double **quadraWN )
{
  
  double *x=quadraWN[1];
	double *w=quadraWN[0];

	#ifdef GAUJAC
	gaujac(x, w, q, 2, 0); // stores nodes and weights of Gauss-Jacobi rule on [-1;1] into x and w
	#endif
  

	for (int k=1; k<= q; k++) // indices start at 1 with GAUJAC
  {
	#ifdef GAUJAC	
	x[k] += 1;  x[k] *= 0.5;//quadraWN[1][k] =  (1+x[k]) * 0.5;
	w[k] *= 1./8.; //quadraWN[0][k] = w[k] / 8.
	#else
	x[k] = (1.0 + jacobi2[1][q-2][k-1] ) * 0.5;
	w[k] = jacobi2[0][q-2][k-1] / 8.;
	#endif
  }

  x = quadraWN[3];
  w = quadraWN[2];
	
	#ifdef GAUJAC
	gaujac(x, w, q, 1, 0);
	#endif
  

	for (int k=1; k<=q; k++) // indices start at 1 with GAUJAC
  {
		#ifdef GAUJAC
		x[k] += 1; x[k] *= 0.5; //quadraWN2[1][k] =  (1+x[k]) * 0.5;
		w[k] *= 0.25; //quadraWN2[0][k] =  (w[k]) / 4.
		#else
		x[k] = (1. + jacobi[1][q-2][k-1] ) * 0.5;
		w[k] = jacobi[0][q-2][k-1] * 0.25;
		#endif
  }
  
	  

  x = quadraWN[5];
  w = quadraWN[4];
	
	#ifdef GAUJAC
	gaujac(x, w, q, 0, 0);
	#endif
  
	for (int k=1; k<=q; k++) // indices start at 1 with GAUJAC
  {
		#ifdef GAUJAC
		x[k] += 1; x[k] *= 0.5;		//quadraWN3[1][k] =  (1+x[k]) * 0.5;
		w[k] *= 0.5;	//quadraWN3[0][k] =  (w[k]) * 0.5 
		#else
		x[k] = (1. + legendre[1][q-2][k-1]) * 0.5;
		w[k] = legendre[0][q-2][k-1] * 0.5;
		#endif
  }
	
}

// computes Bmoments of order n into Bmoment array
// Bmoments associated with constant coefficients equal to 1
void
Bmoment3d_const (int n, double v1[3], double v2[3], double v3[3], double v4[3], double **binomialMat, double **Bmoment)
{
	int mm = ( (n + 3) * (n + 2) * (n + 1)) / 6;
	
	double Const =  Volume3d (v1, v2, v3, v4) / binomialMat[n][3];
	
	for (int mu = 0; mu < mm; mu++)
	{
		Bmoment[mu][0] = Const;
	}
	
	#ifdef CHECK       // check output
	std::cout.precision(6);
  std::cout << "\nBmoments entries (constant data):\n";
  int iMu = 0;            

  for (int mu1 = n; mu1 >= 0; mu1--)
    {
      for (int mu2 = n - mu1; mu2 >= 0; mu2--)
        {
					for (int mu3 = n-mu1-mu2; mu3 >=0; mu3--, iMu++)
					{
						std::cout<<"Bmoment"<<"["<<mu1<<","<<mu2<<","<<mu3<<","<<n-mu1-mu2-mu3<<"]: ";
						std::cout << std::scientific <<Bmoment[iMu][0] << "\n";
					}
				}
    }
  std::cout << "\n";
	#endif
}


// when non-PRECOMP is used, the Bmoment entries are stored
// using position3d2
int 
position3d2(int i, int j, int k, int n) // index (i,j,k) on the cube {0,...,n}^3
{
  return i*(n+1)*(n+1)+ j*(n+1) + k; 
}

int 
position3d(int eta1, int eta2, int eta3)
{
  return ( (eta1+eta2+eta3)*(eta1+eta2+eta3+1)*(eta1+eta2+eta3+2) )/6 + ( (eta2+eta3)*(eta2+eta3+1) )/2 + eta3 ;
}

// compute dimension of the elemental matrices
int 
len_Mat3d(int n)
{
	return ((n+1)*(n+2)*(n+3))/6;
}



// computes lexicographical position3d of eta+xi >> DANGEROUS, since another routine with same name
int 
position3d2(int eta1, int eta2, int eta3, int xi1, int xi2, int xi3)
{
  return position3d(eta1+xi1,eta2+xi2,eta3+xi3);
}

int 
position3d_sum(int eta123, int xi123)
{
  return ( (eta123 + xi123) * (eta123 + xi123 +1) * (eta123+xi123+2) )/6;
}

int 
position3d_sum2(int eta23, int xi23)
{
  return ( (eta23 + xi23) * (eta23 + xi23 +1)  ) / 2;
}



//initialisation of the arrays of quadrature knots and weights used by 'gaussJacobiUnit'
double **
create_quadraWN3d (int len_quadra)
{
  double **quadraWN = new double *[6];
  double *quadraWN_array = new double[6 * len_quadra];
	

  double *p_quadra = quadraWN_array;
  for (int i = 0; i < 6; p_quadra += len_quadra, i++)
    {
      quadraWN[i] = p_quadra;
    }
  return quadraWN;

}



//Computes barycentric coordinates of triangle Stroud quadrature points for BB moments of degree m; 
//The array B contains barycentric coordinates in 4-tuples: b1,b2,b3,b4, b1,b2,b3,b4, ... 
//which corresponds to a matlab matrix with four rows (each for a bary. coordinate);
// There are q^3 points, hence the allocated size of B must be at least 4*q^3
void
stroud_nodes_bary3d (int q, double *B)
{
	double **quadraWN;
	
	int len_Quadra = q+1;  // space required for storing Jacobi nodes of order q is q, BUT indexing starts at 1
	quadraWN = create_quadraWN3d(len_Quadra);
	
	assign_quadra3d(q, quadraWN );  // initialize quadrature weights and nodes
	
	#ifdef PRECOMP
	#ifdef GAUJAC
	double *legendre_x = quadraWN[5]; // legendre_x is pointer which points to the address quadraWN[5]	
	double *jacobi_x = quadraWN[3];
	double *jacobi2_x = quadraWN[1];
	#endif
	#endif
	
	double b1, b2, b3, b4;
	double *b = B;
	
	#ifdef PRECOMP
	
	for (int i=0; i< q; i++)
  {
		for (int j=0; j< q; j++)
		{
			for (int k=0; k< q; k++)
			{

				#ifdef GAUJAC
				
				b1= (1+jacobi2_x[i+1])/2; // indices start at 1 with GAUJAC
				b2= (1-jacobi2_x[i+1]) * (1+jacobi_x[j+1]) / 4;
				b3= (1-jacobi2_x[i+1]) * ( 1-jacobi_x[j+1]) * (1+legendre_x[k+1]) / 8;
				b4= (1-jacobi2_x[i+1]) * (1-jacobi_x[j+1]) * (1-legendre_x[k+1]) / 8; 
				
				#else

				b1= (1+jacobi2[1][q-2][i])/2;
				b2= (1-jacobi2[1][q-2][i]) * (1+jacobi[1][q-2][j]) / 4;
				b3= (1-jacobi2[1][q-2][i]) * ( 1-jacobi[1][q-2][j]) * (1+legendre[1][q-2][k]) / 8;
				b4= (1-jacobi2[1][q-2][i]) * (1-jacobi[1][q-2][j]) * (1-legendre[1][q-2][k]) / 8;
				
				#endif
				
				*b++ = b1;
				*b++ = b2;
				*b++ = b3;
				*b++ = b4;
				

			}		  
	  }
	}
	
	#else // non-PRECOMP
	
	for (int i=0; i < q; i++)
	{
		
		b1 = quadraWN[1][i+1];
		
		for (int j=0; j < q; j++)
		{
			b2 = quadraWN[3][j+1] * (1-b1);
			
			for (int k=0; k < q; k++)
			{
				b3 = quadraWN[5][k+1] * (1-quadraWN[3][j+1]) * (1-b1);
				b4 = 1 - b1- b2- b3;
				
				*b++ = b1;
				*b++ = b2;
				*b++ = b3;
				*b++ = b4;					
			
			}
		
		}
	}
	
	#endif // end not PRECOMP
	
	
	delete_quadraWN(quadraWN);
		
}


// routine which stores function values at Stroud nodes
// Stroud nodes' barycentric coordinates produced by stroud_bary
// barycentric coordinates stored in array B
// size of B is at least 4*q^3
// function values stored into Cval
// f is a scalar-valued function
void
scalar_values_at_Stroud3d(int q, double *Cval, double *B, double (*f)(double[3]),
												double v1[3], double v2[3], double v3[3], double v4[3] )
{
	
	double *bary = B;
	
	double b1, b2, b3, b4;
	double v[3];
	
	for (int i=0; i<q; i++)
	{
		for (int j=0; j<q; j++)
		{
			for (int k=0; k<q; k++)
			{
				
				b1 = *bary++;
				b2 = *bary++;
				b3 = *bary++;
				b4 = *bary++;
				
				bary2cart3d (b1, b2, b3, b4, v1, v2, v3, v4, v); // v is a Stroud node in Cartesian coordinates
				
				*Cval++ = (*f)(v);
				
			}
		}
	}
}

// routine which stores function values at Stroud nodes
// Stroud nodes' barycentric coordinates produced by stroud_bary
// barycentric coordinates stored in array B
// size of B is at least 4*q^3
// function values stored into Cval
// b is a vector-valued function
void
vector_values_at_Stroud3d(int q, double *Cval, double *B, void (*b) (double[3], double[3]),
												double v1[3], double v2[3], double v3[3], double v4[3] )
{
	
	double *Cvalpnt = Cval;
	double *bary = B;
	
	double b1, b2, b3, b4;
	double v[3];
	
	for (int i=0; i<q; i++)
	{
		for (int j=0; j<q; j++)
		{
			
			for (int k=0; k<q; k++)
			{
			
				b1 = *bary++;
				b2 = *bary++;
				b3 = *bary++;
				b4 = *bary++;
				
				bary2cart3d (b1, b2, b3, b4, v1, v2, v3, v4, v); // v is a Stroud node in Cartesian coordinates
				
				double vect[3];
				(*b)(v,vect);
				
				*Cvalpnt++ =  vect[0];
				*Cvalpnt++ =  vect[1];
				*Cvalpnt++ =  vect[2];
			}
			
		}
	}

}


// routine which stores function values at Stroud nodes
// Stroud nodes' barycentric coordinates produced by stroud_bary
// barycentric coordinates stored in array B
// size of B is at least 4*q^3
// function values stored into Cval
// A is a matrix-valued function
void
matrix_values_at_Stroud3d(int q, double *Cval, double *B, void (*A) (double[3], double[3][3]),
												double v1[3], double v2[3], double v3[3], double v4[3] )
{
	
	double *Cvalpnt = Cval;
	double *bary = B;
	
	double b1, b2, b3, b4;
	double v[3];
	
	for (int i=0; i<q; i++)
	{
		for (int j=0; j<q; j++)
		{
			for (int k=0; k<q; k++)
			{
				b1 = *bary++;
				b2 = *bary++;
				b3 = *bary++;
				b4 = *bary++;
				
				bary2cart3d (b1, b2, b3, b4, v1, v2, v3, v4, v); // v is a Stroud node in Cartesian coordinates
				
				double mat[3][3];
				(*A)(v,mat); // mat = A(v)
		
				*Cvalpnt++ =  mat[0][0];
				*Cvalpnt++ =  mat[0][1];
				*Cvalpnt++ =  mat[0][2];
				*Cvalpnt++ =  mat[1][1];
				*Cvalpnt++ =  mat[1][2];
				*Cvalpnt++ =  mat[2][2]; // A is symmetric
			}
		}
	}

}


// store cross-product of w1 and w2 into Cross
void crossProd(double w1[3], double w2[3], double Cross[3])
{
  Cross[0]=w1[1]*w2[2]-w1[2]*w2[1];
  Cross[1]=w1[2]*w2[0]-w1[0]*w2[2];
  Cross[2]=w1[0]*w2[1]-w1[1]*w1[0];
}

// store weighted cross-product of w1 and w2 into Cross
void crossProd2(double w1[3], double w2[3], double Cross[3]) 
{
  double *p=&Cross[0];
  *p = (w1[1]*w2[2]-w1[2]*w2[1])*0.5;
  p++;
  *p = (w1[2]*w2[0]-w1[0]*w2[2])*0.5;
  p++;
  *p = (w1[0]*w2[1]-w1[1]*w1[0])*0.5;
}

// store v-w into Sub
void subtract( double v[3], double w[3], double Sub[3])
{
for (int i=0; i<3; i++)
	Sub[i] = v[i]-w[i];
}

// compute intermediate quantity Res (needed in computation of normals to the element's edges)
void inter( double u[3], double v[3], double w[3], double Res[3] )
{
	double Sub1[3], Sub2[3];	//intermediate results
	subtract(u,w,Sub1);
	subtract(v,w,Sub2);
	crossProd2(Sub1,Sub2,Res); // cross product divided by 2: norm of cross product is twice the area of face (triangle)
}


// compute normals to the edges of tetrahedron <v1,v2,v3,v4>
void
normals3d(double v1[3], double v2[3], double v3[3], double v4[3], double normalMat[4][3]) 
{
  double Res1[3], Res2[3], Res3[3], Res4[3];	//intermediate results

  inter(v3,v4,v2,Res1);
  inter(v4,v1,v3,Res2);
  inter(v1,v2,v4,Res3);
  inter(v2,v3,v1,Res4);

  normalMat[0][0]=Res1[0]; normalMat[0][1]=Res1[1]; normalMat[0][2]=Res1[2];
  normalMat[1][0]=-Res2[0]; normalMat[1][1]=-Res2[1]; normalMat[1][2]=-Res2[2];
  normalMat[2][0]=Res3[0]; normalMat[2][1]=Res3[1]; normalMat[2][2]= Res3[2];
  normalMat[3][0]=-Res4[0]; normalMat[3][1]=-Res4[1]; normalMat[3][2]=-Res4[2];
}

// compute scalar product of w1 and w2
double scalarProd3d(double w1[3],double w2[3])
{
  double Sum=0;
  for (int i=0; i<3; i++)
	  Sum+= w1[i]*w2[i];
  return Sum;
}

// compute area of tetrahedron <v1,v2,v3,v4>
double
Volume3d(double v1[3], double v2[3], double v3[3], double v4[3]) // computes area of tetrahedral < v1,v2,v3,v4 >
{
  
  double Cross[3];
  
  double w1[3] = { v1[0]-v4[0] , v1[1]-v4[1] , v1[2]-v4[2] };
  double w2[3] = { v2[0]-v4[0] , v2[1]-v4[1] , v2[2]-v4[2] };
  double w3[3] = { v3[0]-v4[0] , v3[1]-v4[1] , v3[2]-v4[2] };

  crossProd(w2,w3,Cross);
  double t= scalarProd3d(w1,Cross);
  if (t<0.0)
	  t*=-1;
  return t/6;
}


// compute inner products of normals to the edges of tetrahedron <v1,v2,v3,v4>
void scalarMatrix3d(double scalarMat[][4],double v1[3], double v2[3], double v3[3], double v4[3] , double normalMat[][3])	
{
	
	for (int i=0; i<4; i++)
  {
		for (int j=0; j<4; j++)
			scalarMat[i][j]=0;
  }
	
	normals3d(v1, v2, v3, v4, normalMat) ;
	  

  for (int alfa0=0; alfa0<=1; alfa0++)
  {
		for (int alfa1=0; alfa1<=1-alfa0; alfa1++)
		{
			for (int alfa2=0; alfa2<=1-alfa0-alfa1; alfa2++)
			{
				int alfa3=1-alfa0-alfa1-alfa2; int iAlfa=position3d(alfa1,alfa2,alfa3);
				double vAlfa[3] ={ normalMat[iAlfa][0], normalMat[iAlfa][1], normalMat[iAlfa][2] };
				for (int beta0=0; beta0<=1; beta0++)
				{
					for (int beta1=0; beta1<=1-beta0; beta1++)
					{
						for (int beta2=0; beta2<=1-beta0-beta1; beta2++)
						{
							int beta3=1-beta0-beta1-beta2; int iBeta=position3d(beta1,beta2,beta3);
							double vBeta[3]={ normalMat[iBeta][0], normalMat[iBeta][1], normalMat[iBeta][2] };
						
							scalarMat[iAlfa][iBeta] += scalarProd3d(vAlfa,vBeta);
						}
					}
				}
			}
		}
  } 

}

// compute weighted inner products of normals to the edges of tetrahedron <v1,v2,v3,v4>
// needed in computations of stiffness matrix with constant coefficients
void scalarMatrix3d_Coeff(double scalarMat[][4],double v1[3], double v2[3], double v3[3], double v4[3] , double normalMat[][3],
													double Coeff[6] )	
{
	
  normals3d(v1, v2, v3, v4, normalMat) ;
	  

  for (int i=0; i<4; i++)
  {
	for (int j=0; j<4; j++)
	  scalarMat[i][j]=0;
  }
  
  double Mat[3][3];

	Mat[0][0] = Coeff[0]; // Mat is used to build the symmetric coefficient matrix
	Mat[0][1] = Mat[1][0] = Coeff[1];
	Mat[0][2] = Mat[2][0] = Coeff[2];
	Mat[1][1] = Coeff[3];
	Mat[1][2] = Mat[2][1] = Coeff[4];
	Mat[2][2] = Coeff[5];
	

	for (int beta0=0; beta0<=1; beta0++)
	{
		for (int beta1=0; beta1<=1-beta0; beta1++)
		{
			for (int beta2=0; beta2<=1-beta0-beta1; beta2++)
			{				
				int beta3=1-beta0-beta1-beta2; int iBeta=position3d(beta1,beta2,beta3);
				double vBeta[3]={ normalMat[iBeta][0], normalMat[iBeta][1], normalMat[iBeta][2] };
				
				double matVectMult[3];
				matVectMult[0] = Mat[0][0] * vBeta[0] + Mat[0][1] * vBeta[1] + Mat[0][2] * vBeta[2];
				matVectMult[1] = Mat[1][0] * vBeta[0] + Mat[1][1] * vBeta[1] + Mat[1][2] * vBeta[2];
				matVectMult[2] = Mat[2][0] * vBeta[0] + Mat[2][1] * vBeta[1] + Mat[2][2] * vBeta[2];
				
				for (int alfa0=0; alfa0<=1; alfa0++)
				{
					for (int alfa1=0; alfa1<=1-alfa0; alfa1++)
					{
						for (int alfa2=0; alfa2<=1-alfa0-alfa1; alfa2++)
						{
							int alfa3=1-alfa0-alfa1-alfa2; int iAlfa=position3d(alfa1,alfa2,alfa3);
							double vAlfa[3] ={ normalMat[iAlfa][0], normalMat[iAlfa][1], normalMat[iAlfa][2] };							
						
							scalarMat[iAlfa][iBeta] += scalarProd3d(vAlfa, matVectMult);
						}
					}
				}
			}
		}
  } 		

}


// compute weighted inner products of vectCoeff with normals to the element's edges
// needed in computation of convective matrix with constant coefficients
// vectCoeff[2] contains the entries of the constant coefficient vector associated with the convective matrix
void
innerProd_Coeff3d (double normalMat[][3], double innerProdMat[4], double vectCoeff[3])
{

  for (int i = 0; i < 4; i++)
		innerProdMat[i] = 0;
	
	innerProdMat[0] = vectCoeff[0] * normalMat[0][0] + vectCoeff[1] * normalMat[0][1] + vectCoeff[2] * normalMat[0][2]; //alpha=[1,0,0,0]
	innerProdMat[1] = vectCoeff[0] * normalMat[1][0] + vectCoeff[1] * normalMat[1][1] + vectCoeff[2] * normalMat[1][2]; //alpha=[0,1,0,0]
	innerProdMat[2] = vectCoeff[0] * normalMat[2][0] + vectCoeff[1] * normalMat[2][1] + vectCoeff[2] * normalMat[2][2]; //alpha=[0,0,1,0]
	innerProdMat[3] = vectCoeff[0] * normalMat[3][0] + vectCoeff[1] * normalMat[3][1] + vectCoeff[2] * normalMat[3][2]; //alpha=[0,0,0,1]
			 
}


// initialize pointers for the quadrature weights and nodes
void
assign_quadra3d(int q, double **quadraWN )
{
	#ifdef GAUJAC
	
	#else
	
	if (q>80)
	{
		std::cout<<"\nThe polynomial order is too large. Activate GAUJAC option.\n";
		exit (EXIT_FAILURE);
	}
	#endif
	
	
	#ifdef PRECOMP
	#ifdef GAUJAC
	
	double *legendre_x, *legendre_w;
	double *jacobi_x, *jacobi_w;
	double *jacobi2_x, *jacobi2_w;
	
	legendre_x = quadraWN[5]; // legendre_x points to the address quadraWN[1], thus the effective MODIFICATION of quadraWN[1] entries
  legendre_w = quadraWN[4];   
	gaujac (legendre_x, legendre_w, q, 0, 0);   // stores nodes and weights of Gauss-Jacobi rule on [-1;1] into x and w
				
	jacobi_x = quadraWN[3];
	jacobi_w = quadraWN[2];
	gaujac(jacobi_x, jacobi_w, q, 1, 0);
	
	jacobi2_x = quadraWN[1];
	jacobi2_w = quadraWN[0];
	gaujac(jacobi2_x, jacobi2_w, q, 2, 0); // so that match same definition as non-PRECOMP
	
	#endif // end GAUJAC
	
	#else // not PRECOMP
  gaussJacobiUnit3D (q, quadraWN); // macro GAUJAC already implemented in gaussJacobiUnit
  #endif
  
}


// returns size of Bmoment vector
// depending on whether or not PRECOMP is used
// with non-PRECOMP, more memory is required,
// since entries are indexed as domain points of the cube (as opposed to the tetrahedron)
int
len_Moments3d(int n, int q)
{
	int mm, lenMoments;
  
  #ifdef PRECOMP
  mm = n;   // for PRECOMP, lenMoments required is always determined by Bmoment order (and NOT quadrature rule used)
			// because indexing INDEPENDENT of MAX(n,q)
  lenMoments = ( (mm+3) * (mm+2) * (mm+1)) / 6;
  #else
  mm = MAX (n, q-1);  // mm will be used for indexing
  lenMoments = (mm + 1) * (mm + 1) * (mm + 1);
  #endif
  
  return lenMoments;
}



// compute mass matrix of order n with constant coefficients equal to 1
// v1, v2, v3, v4 are the element's vertices
// binomialMat contains binomial coefficients
// computed mass matrix entries are stored into massMat array
double 
Mass3d_const (int n, double v1[3], double v2[3], double v3[3], double v4[3], double **binomialMat, double **massMat)
{

	
  int Len=((n+1)*(n+2)*(n+3) )/6;

  for (int i=0; i<Len; i++)
  {
  for (int j=0; j<Len; j++)
	memset(&massMat[i][j],  '\0', sizeof massMat[i][j]);
  }

  clock_t t0, t1;
  double cpu_time_used;

  t0=clock();
  
  double Const= Volume3d(v1,v2,v3,v4) / binomialMat[n][n] / binomialMat[2*n][3];
  
  

  int iMu=0;
  for (int mu0=n; mu0>=0; mu0--)
  {
	for (int mu1=n-mu0; mu1>=0; mu1--)
	{
	  int mu3=0;
	  for (int mu2=n-mu0-mu1; mu2>=0; mu2--, mu3++, iMu++)
	  {
		
		int iEta=0;
		for (int eta0=n; eta0>=0; eta0--)
		{
		  
		  for (int eta1 = n-eta0 ; eta1>=0; eta1--)
		  {
					
				int eta3=0;
				for (int eta2=n-eta0-eta1; eta2>=0; eta2--, eta3++, iEta++)
				{
			  
					double w = binomialMat[eta0][mu0] * binomialMat[eta1][mu1]*binomialMat[eta2][mu2]*binomialMat[eta3][mu3]*Const; // faster than factorization of binomials
			  
			  
					massMat[iMu][iEta] = w;
				
				}
		  }
		}
	  }
	}
  } 
	  
  #ifdef CHECK									// check output
  std::cout<<"Mass matrix entries:\n";
  for (int mu0=n; mu0>=0; mu0--)
  {
	for (int mu1=n-mu0; mu1>=0; mu1--)
	{
	  for (int mu2=n-mu0-mu1; mu2>=0; mu2--)
	  {
		int mu3=n-mu0-mu1-mu2; int iMu=position3d(mu1,mu2,mu3);
		for (int eta0=n; eta0>=0; eta0--)
		{
		  for (int eta1=n-eta0; eta1>=0; eta1--)
		  {
			for (int eta2=n-eta0-eta1; eta2>=0; eta2--)
			{
			  int eta3=n-eta0-eta1-eta2; int iEta=position3d(eta1,eta2,eta3);
			  printf("%.04e\t",massMat[iMu][iEta]);
			}
		  }
		}
		std::cout<<"\n";
	  }	
	}
  }
  #endif
	  	  
  t1=clock();
  cpu_time_used=((double) (t1-t0))/ CLOCKS_PER_SEC;
  return cpu_time_used;
  
}


// high-level routine for computing mass matrix of order n with constant coefficients
// v1, v2, v3, v4 are the element's vertices
// computed mass matrix entries are stored into massMat array
void
get_mass3d_const(double **massMat, int n, double v1[3], double v2[3],
							 double v3[3], double v4[3])							 
{
	
	double **binomialMat;
  int len_binomialMat=2*n+3;
  binomialMat = create_BinomialMat(len_binomialMat);
	
  
  computeBinomials(binomialMat, len_binomialMat);
	
	Mass3d_const (n, v1, v2, v3, v4, binomialMat, massMat); // compute mass matrix
	
	
	//free allocated memory
  delete_BinomialMat (binomialMat, len_binomialMat);
	
	
	#ifdef CHECK
	int len_Mass = len_Mat3d(n); // dimension of the elemental mass matrix
	std::cout<<"Mass matrix entries stored into array massMat of dimension "<<len_Mass<<"\n";
	#endif
	
}



// compute mass matrix of order n with variable coefficients
// q^3 is the number of quadrature points
// v1, v2, v3, v4 are the element's vertices
// binomialMat stores binomial coefficients
// Bmoment contains B-moments associated with mass matrix coefficients
// quadraWN contains Gauss-Jacobi quadrature weights and nodes
// computed mass matrix stored into massMat array
#ifdef PRECOMP
// precomp contains precomputed arrays
// matValNodes contains coefficients values at the quadrature nodes
double 
Mass3d (int n, int q, double v1[3], double v2[3], double v3[3], double v4[3], double **binomialMat, double **precomp, double **Bmoment,
      double **massMat, double **matValNodes, double **quadraWN)
#else
// BmomentInter contains intermediate values required for the B-moments' computation
double 
Mass3d (int n, int q, double v1[3], double v2[3], double v3[3], double v4[3], double **binomialMat, double **Bmoment, double **BmomentInter,
      double **massMat, double **quadraWN)
#endif
{

	
  int Len=((n+1)*(n+2)*(n+3) )/6;

  for (int i=0; i<Len; i++)
  {
  for (int j=0; j<Len; j++)
	memset(&massMat[i][j],  '\0', sizeof massMat[i][j]);
  }

  clock_t t0, t1;
  double cpu_time_used;

  t0=clock();
  
  double Const= Volume3d(v1,v2,v3,v4) / binomialMat[n][n] / binomialMat[2*n][3];
  
  
  Const = 1./ binomialMat[n][n];  
  int nb_Array=1; // Mass needs Bmoments associated with scalar valued function  
  
  
  #ifdef PRECOMP  
  Bmoment3d (2*n, q, nb_Array, v1, v2, v3, v4, binomialMat, precomp, Bmoment, matValNodes);  
  #else // not PRECOMP
  Bmoment3d_Index(2*n, q, nb_Array, Bmoment, BmomentInter, quadraWN);
	//WARNING: since q might be arbitrarily chosen, careful about indexing with non-PRECOMP:
	int M = MAX(2*n,q-1); // M is used for indexing  
  #endif


  int iMu=0;
  for (int mu0=n; mu0>=0; mu0--)
  {
	for (int mu1=n-mu0; mu1>=0; mu1--)
	{
	  int mu3=0;
	  for (int mu2=n-mu0-mu1; mu2>=0; mu2--, mu3++, iMu++)
	  {
		
		int iEta=0;
		for (int eta0=n; eta0>=0; eta0--)
		{
		  
		  #ifdef PRECOMP
		  int iMuEta0 = position3d_sum(n-mu0, n-eta0); // n-mu0 = mu1+mu2+mu3, n-eta0 = eta1+eta2+eta3
		  #else
		  int iMuEta0 = (mu0 + eta0) * (M+1) * (M+1);     // the Bmoments are indexed w.r.t index2(. , 2n)
		  #endif
		  for (int eta1 = n-eta0 ; eta1>=0; eta1--)
		  {
				
				#ifdef PRECOMP
				int iMuEta1 = iMuEta0 + position3d_sum2 (n-mu0-mu1, n-eta0-eta1);
				#else
				int iMuEta1 = iMuEta0 + (mu1+eta1) * (M+1);
				#endif
				
				int eta3=0;
				for (int eta2=n-eta0-eta1; eta2>=0; eta2--, eta3++, iEta++)
				{
						
					double w = binomialMat[eta0][mu0] * binomialMat[eta1][mu1]*binomialMat[eta2][mu2]*binomialMat[eta3][mu3]*Const; // faster than factorization of binomials
					
					int iMuEta;
					
					#ifdef PRECOMP
					iMuEta = iMuEta1 + mu3 + eta3;
					#else
					iMuEta = iMuEta1 + mu2 + eta2;
					#endif
				
					massMat[iMu][iEta] = w * Bmoment[iMuEta][0];
								
				}
		  }
		}
	  }
	}
  } 
	  
  #ifdef CHECK									// check output
  std::cout<<"Mass matrix entries:\n";
  for (int mu0=n; mu0>=0; mu0--)
  {
	for (int mu1=n-mu0; mu1>=0; mu1--)
	{
	  for (int mu2=n-mu0-mu1; mu2>=0; mu2--)
	  {
		int mu3=n-mu0-mu1-mu2; int iMu=position3d(mu1,mu2,mu3);
		for (int eta0=n; eta0>=0; eta0--)
		{
		  for (int eta1=n-eta0; eta1>=0; eta1--)
		  {
			for (int eta2=n-eta0-eta1; eta2>=0; eta2--)
			{
			  int eta3=n-eta0-eta1-eta2; int iEta=position3d(eta1,eta2,eta3);
			  printf("%.04e\t",massMat[iMu][iEta]);
			}
		  }
		}
		std::cout<<"\n";
	  }	
	}
  }
  #endif
	  	  
  t1=clock();
  cpu_time_used=((double) (t1-t0))/ CLOCKS_PER_SEC;
  return cpu_time_used;
  
}


//Stiffness matrix of order n with constant coefficients
//The entries in the rows and columns of the stiffness are indexed using lexicographical order
// v1, v2, v3, v4 are the element's vertices
// binomialMat stores binomial coefficients
// scalarMat contains weighted inner products of normals to the element's edges
// cputime contains cpu timings
// computed stiffness matrix stored into stiffMat array
// Coeff stores the upper triangular entries of the (symmetric) coefficient associated
// with the stiffness matrix
double
Stiff3d_const (int n, double v1[3], double v2[3], double v3[3], double v4[3], double **stiffMat,
						 double **binomialMat, double scalarMat[][4], double normalMat[][3],
						 double cpu_time[5], double Coeff[6])
{
	
  
  int Len= ( (n+3)*(n+2)*(n+1) ) / 6;



  for (int i=0; i<Len; i++)
  {
		for (int j=0; j<Len; j++)
		{
			stiffMat[i][j] = 0.;
		}
  }


  clock_t t0, t1, t1Bis, t2, t3;


  t0=clock();

	
  double Const= n*n / 9. / Volume3d(v1,v2,v3,v4) / binomialMat[n-1][n-1] / binomialMat[2*n-2][3] ; 

  double scalarMat_scaled[4][4];
	  
  for (int i=0; i<4; i++)
  {
	for (int j=0; j<4; j++)
	  scalarMat_scaled[i][j] = scalarMat[i][j] * Const;
  }
	

  t1=clock();

  t1Bis=clock();

  cpu_time[0]= ( (double)(t1Bis-t1) )/CLOCKS_PER_SEC;	


  t2=clock();

  cpu_time[1] = ( (double)(t2-t1Bis) ) /CLOCKS_PER_SEC;



  int p = n-1;

  int iMu=0, iMu1=1, iMu2=2, iMu3=3;
  for (int mu0=p; mu0>=0; mu0--, iMu1 +=p-mu0+1, iMu2++, iMu3++)
  {
	int mu2PlusMu3=0;
	for (int mu1=p-mu0; mu1>=0; mu1--, mu2PlusMu3++, iMu2++, iMu3++ )
	{
	  int mu3=0;
	  for (int mu2=p-mu0-mu1; mu2>=0; mu2--, mu3++, iMu++, iMu1++, iMu2++, iMu3++)
	  {

		int iEta=0, iEta1=1, iEta2=2, iEta3=3;			
		for (int eta0=p; eta0>=0; eta0--, iEta1 += p-eta0+1, iEta2++, iEta3++)
		{

		  double v = binomialMat[mu0][eta0] ;
		  int eta2PlusEta3 = 0 ;
		  for (int eta1 = p-eta0 ; eta1>=0; eta1--, eta2PlusEta3++, iEta2++, iEta3++)
		  {

			v *= binomialMat[mu1][eta1];
			int eta3=0;
			for (int eta2=p-eta0-eta1; eta2>=0; eta2--, eta3++, iEta++, iEta1++, iEta2++, iEta3++)
			{

			  double w = v * binomialMat[mu2][eta2] * binomialMat[mu3][eta3];	//double w = binomialMat[mu0][eta0] * binomialMat[mu1][eta1] * binomialMat[mu2][eta2] * binomialMat[mu3][eta3];


			  stiffMat[iMu][iEta]   += w * scalarMat_scaled[0][0]; //alfa=[1,0,0,0], beta=[1,0,0,0]
			  stiffMat[iMu][iEta1]  += w * scalarMat_scaled[0][1]; //beta=[0,1,0,0]
			  stiffMat[iMu][iEta2]  += w * scalarMat_scaled[0][2]; //beta=[0,0,1,0]
			  stiffMat[iMu][iEta3]  += w * scalarMat_scaled[0][3]; //beta=[0,0,0,1]

									  
			  stiffMat[iMu1][iEta]  += w * scalarMat_scaled[1][0]; //alfa=[0,1,0,0], beta=[1,0,0,0]
			  stiffMat[iMu1][iEta1] += w * scalarMat_scaled[1][1]; //beta=[0,1,0,0] 
			  stiffMat[iMu1][iEta2] += w * scalarMat_scaled[1][2]; //beta=[0,0,1,0]
			  stiffMat[iMu1][iEta3] += w * scalarMat_scaled[1][3]; //beta=[0,0,1,0]

								  
			  stiffMat[iMu2][iEta]  += w * scalarMat_scaled[2][0]; //alfa=[0,0,1,0], beta=[1,0,0,0]
			  stiffMat[iMu2][iEta1] += w * scalarMat_scaled[2][1]; //beta=[0,1,0,0]
			  stiffMat[iMu2][iEta2] += w * scalarMat_scaled[2][2]; //beta=[0,0,1,0]
			  stiffMat[iMu2][iEta3] += w * scalarMat_scaled[2][3]; //beta=[0,0,0,1]

			  
			  stiffMat[iMu3][iEta]  += w * scalarMat_scaled[3][0]; //alfa=[0,0,0,1], beta=[1,0,0,0]
			  stiffMat[iMu3][iEta1] += w * scalarMat_scaled[3][1]; //beta=[0,1,0,0]
			  stiffMat[iMu3][iEta2] += w * scalarMat_scaled[3][2]; //beta=[0,0,1,0]
			  stiffMat[iMu3][iEta3] += w * scalarMat_scaled[3][3]; //beta=[0,0,0,1]
						  
			}
			v /= binomialMat[mu1][eta1];	
		  }
		}
	  }
	}
  }


  t3=clock();


  cpu_time[2]=((double) (t3-t2) )	/ CLOCKS_PER_SEC ;

					  
  #ifdef CHECK							// check output
  std::cout<<"\nStiffness matrix entries:\n";
  for (int mu0=n; mu0>=0; mu0--)
  {
		for (int mu1=n-mu0; mu1>=0; mu1--)
		{
			for (int mu2=n-mu0-mu1; mu2>=0; mu2--)
			{
				int mu3=n-mu0-mu1-mu2; int iMu=position3d(mu1,mu2,mu3);
				for (int eta0=n; eta0>=0; eta0--)
				{
					for (int eta1=n-eta0; eta1>=0; eta1--)
					{
						for (int eta2=n-eta0-eta1; eta2>=0; eta2--)
						{
							int eta3=n-eta0-eta1-eta2; int iEta=position3d(eta1,eta2,eta3);
							printf("%.02e\t",stiffMat[iMu][iEta]);
						}
					}
				}
				std::cout<<"\n";
			}	  
		}
  } 

  #endif	

  cpu_time[3] = ((double)(t3-t0))/CLOCKS_PER_SEC;

  return cpu_time[3];	//return cpu_time_used;

}

// high-level routine for stiffness matrix of order n with constant coefficients
// computed stiffness matrix stored into stiffMat array
// v1, v2, v3, v4 are the element's vertices
// Coeff contains the upper-triangular entries of the (symmetric) matrix-valued
// coefficient associated with the stiffness matrix
void
get_stiffness3d_const (double **stiffMat, int n, double v1[3], double v2[3], double v3[3], double v4[3],
								 double Coeff[6])
{
	double **binomialMat; // store binomial coefficients  
  double cpu_time[5]; // needed, since passed as argument in Stiff  
  double normalMat[4][3] = { {0, 0, 0}, {0, 0, 0}, {0, 0, 0}, {0, 0, 0} };  // store normals to the edges
  double scalarMat[4][4];       // passed as argument in Stiff 
	
	int len_binomial = 2*n+3;
	binomialMat = create_BinomialMat(len_binomial);
	
	// initialize auxilliary arrays
	computeBinomials(binomialMat, len_binomial); //compute binomials
	normals3d (v1, v2, v3, v4, normalMat);
	scalarMatrix3d_Coeff (scalarMat, v1, v2, v3, v4, normalMat, Coeff);
	
	Stiff3d_const (n, v1, v2, v3, v4, stiffMat, binomialMat, scalarMat,
							 normalMat, cpu_time, Coeff);
	
	delete_BinomialMat (binomialMat, len_binomial);
	
	
	#ifdef CHECK
	int len_Stiff = len_Mat3d(n); // dimension of the elemental stiffness matrix
	std::cout<<"Stiffness matrix entries stored into array stiffMat of dimension "<<len_Stiff<<"\n";
	#endif	
	
	
}


// compute convective matrix of order n associated with constant coefficients equal to vectCoeff
// v1, v2, v3, v4 are the element's vertices
// binomialMat stores binomial coefficients
// normalMat contains normals to the edges of <v1,v2,v3,v4>
// innerProdMat contains inner products of vectCoeff with normals
// computed convective matrix stored into convecMat array
// vectCoeff stores the constant vector-valued coefficients associated with the convective matrix
double
Convec3d_const (int n, double v1[3], double v2[3], double v3[3], double v4[3], double **binomialMat, double normalMat[][3], 
							double innerProdMat[4], double **convecMat, double vectCoeff[3] )
{
  int Len= ( (n+3)*(n+2)*(n+1) ) / 6;



  for (int i=0; i<Len; i++)
  {
		for (int j=0; j<Len; j++)
		{
			convecMat[i][j] = 0.;
		}
  }
  
  clock_t t0, t1;
	
	t0 = clock();
	
	double Const = -n / 3. / binomialMat[n-1][n]/binomialMat[2*n-1][3]; // scaling constant used with constant coefficients
		
	// scale the normals (factor out "Const")
	double innerProdMat_scaled[4];
  for (int i = 0; i<4; i++)
		innerProdMat_scaled[i] = innerProdMat[i] * Const;

		
	int p = n-1;

  int iMu=0, iMu1=1, iMu2=2, iMu3=3;
  for (int mu0=p; mu0>=0; mu0--, iMu1 +=p-mu0+1, iMu2++, iMu3++)
  {
		int mu2PlusMu3=0;
		for (int mu1=p-mu0; mu1>=0; mu1--, mu2PlusMu3++, iMu2++, iMu3++ )
		{
			int mu3=0;
			for (int mu2=p-mu0-mu1; mu2>=0; mu2--, mu3++, iMu++, iMu1++, iMu2++, iMu3++)
			{

				int iEta=0, iEta1=1, iEta2=2, iEta3=3;			
				for (int eta0=n; eta0>=0; eta0--, iEta1 += n-eta0+1, iEta2++, iEta3++)
				{
					
					double v = binomialMat[mu0][eta0] ;
					int eta2PlusEta3 = 0 ;
					for (int eta1 = n-eta0 ; eta1>=0; eta1--, eta2PlusEta3++, iEta2++, iEta3++)
					{
						v *= binomialMat[mu1][eta1];
						int eta3=0;
						for (int eta2=n-eta0-eta1; eta2>=0; eta2--, eta3++, iEta++, iEta1++, iEta2++, iEta3++)
						{

							double w = v * binomialMat[mu2][eta2] * binomialMat[mu3][eta3];	

							convecMat[iMu] [iEta]  += w * innerProdMat_scaled[0]; //alpha=[1,0,0,0]
							convecMat[iMu1][iEta]  += w * innerProdMat_scaled[1]; //alpha=[0,1,0,0]
							convecMat[iMu2][iEta]  += w * innerProdMat_scaled[2]; //alpha=[0,0,1,0]
							convecMat[iMu3][iEta]  += w * innerProdMat_scaled[3]; //alpha=[0,0,0,1]
										
						}
						v /= binomialMat[mu1][eta1];	
					}
				}
			}
		}
  }
  
  t1 = clock();
  
					  
  #ifdef CHECK							// check output
  std::cout<<"\nConvective matrix entries:\n";
  for (int mu0=n; mu0>=0; mu0--)
  {
		for (int mu1=n-mu0; mu1>=0; mu1--)
		{
			for (int mu2=n-mu0-mu1; mu2>=0; mu2--)
			{
			int mu3=n-mu0-mu1-mu2; int iMu=position3d(mu1,mu2,mu3);
			for (int eta0=n; eta0>=0; eta0--)
			{
				for (int eta1=n-eta0; eta1>=0; eta1--)
				{
				for (int eta2=n-eta0-eta1; eta2>=0; eta2--)
				{
					int eta3=n-eta0-eta1-eta2; int iEta=position3d(eta1,eta2,eta3);
					printf("%.04e\t",convecMat[iMu][iEta]);
				}
				}
			}
			std::cout<<"\n";
			}	  
		}
  } 

  #endif	

  double cpu_time_used = ((double)(t1-t0))/CLOCKS_PER_SEC;

  return cpu_time_used;
	
	
}

// high-level routine for convective matrix of order n associated with constant coefficients
// computed convective matrix stored into convecMat array
// v1, v2, v3, v4 are the element's vertices
// vectCoeff contains the constant vector-valued coefficients associated with the convective matrix
void
get_convec3d_const (double **convecMat, int n, double v1[3], double v2[3],
									double v3[3], double v4[3], double vectCoeff[3])
{
	double **binomialMat; // store binomial coefficients  
  double normalMat[4][3] = { {0, 0, 0}, {0, 0, 0}, {0, 0 , 0}, {0, 0 , 0} };  // store normals to the edges
  
  int len_binomial = 2*n+3;
	binomialMat = create_BinomialMat(len_binomial);
	
	// initialize auxilliary arrays
	computeBinomials(binomialMat, len_binomial); //compute binomials
	normals3d (v1, v2, v3, v4, normalMat); // compute normals to the edges
	
	double innerProdMat[4];
	innerProd_Coeff3d (normalMat, innerProdMat, vectCoeff);
	
	Convec3d_const (n, v1, v2, v3, v4, binomialMat, normalMat, innerProdMat, convecMat, vectCoeff); // compute convective matrix
	
	
	
	//free allocated memory
	delete_BinomialMat (binomialMat, len_binomial);
	
	#ifdef CHECK
	int lenConvec = len_Mat3d(n); // dimension of the convective matrix
	std::cout<<"Convective matrix entries stored into array convecMat of dimension "<< lenConvec <<"\n";
	#endif
	
	
}


//convert barycentric coordinates (b1,b2,b3,b4) of a point w.r.t. vertices v1,v2,v3,v4 into Cartesian coordinates v
void 
bary2cart3d(double b1, double b2, double b3, double b4, double v1[3], double v2[3], double v3[3], double v4[3], double v[3])
{
  v[0]= b1*v1[0] + b2*v2[0] + b3*v3[0]+b4*v4[0];
  v[1]= b1*v1[1] + b2*v2[1] + b3*v3[1]+b4*v4[1];
  v[2]= b1*v1[2] + b2*v2[2] + b3*v3[2]+b4*v4[2];
}



// create two versions of transform_BmomentC, so that
// Convec, Stiff require no precompiler (of type CONVEC,....)

// computes inner product of vector-valued B-moments with normals
// n is the order of the finite element
// q is the number of quadrature points used in each direction
// Bmoment contains B-moments associated with vector-valued coefficients
// normalMat stores normals
// computed inner product are stored into Bmomentab array
void
transform_BmomentC_Convec3d(int n, int q, double **Bmoment, double **Bmomentab, double normalMat[4][3])
{

  int m, mm; // m is the Bmoment order, mm is used for indexing
 
  m = 2*n-1; 
  
  #ifdef PRECOMP
  mm = ((m+3)*(m+2)*(m+1))/6;
  #else
	int m_index = MAX(m, q-1);
  mm = (m_index+1)*(m_index+1)*(m_index+1);
  
  #endif

  for (int mu = 0; mu < mm; mu++)
  {
	
	double Vec[3];
	Vec[0] = Bmoment[mu][0]; // Vec is used to store Bmoment[mu] entries
	Vec[1] = Bmoment[mu][1];
	Vec[2] = Bmoment[mu][2];
	
	Bmomentab[mu][0] = normalMat[0][0] * Vec[0] + normalMat[0][1] * Vec[1] + normalMat[0][2] * Vec[2];  //beta=[1,0,0,0]
	Bmomentab[mu][1] = normalMat[1][0] * Vec[0] + normalMat[1][1] * Vec[1] + normalMat[1][2] * Vec[2]; // beta=[0,1,0,0]
	Bmomentab[mu][2] = normalMat[2][0] * Vec[0] + normalMat[2][1] * Vec[1] + normalMat[2][2] * Vec[2]; // beta=[0,0,1,0]
	Bmomentab[mu][3] = normalMat[3][0] * Vec[0] + normalMat[3][1] * Vec[1] + normalMat[3][2] * Vec[2]; // beta=[0,0,0,1]
	
  }
	
}


// routine used to pre-multiply normals with the Bmoments
// pre-multiply matrix-valued B-moments with normals
// n is the order of the finite element
// q is the number of quadrature points used in each direction
// Bmoment contains B-moments associated with matrix-valued coefficients
// normalMat stores normals
// computed inner product are stored into Bmomentab array
void
transform_BmomentC_Stiff3d (int n, int q, double **Bmoment, double **Bmomentab, 
													double normalMat[4][3])
{

  int m, mm; // m is the Bmoment order, mm is used for indexing
  
  m = 2*n-2; // stiffness matrix
  
  
  #ifdef PRECOMP
  mm = ((m+3)*(m+2)*(m+1))/6;
  #else
	int m_index = MAX(m, q-1);
  mm = (m_index+1)*(m_index+1)*(m_index+1);
  
  #endif

  for (int mu = 0; mu < mm; mu++)
  {

	double Mat[3][3];
	Mat[0][0] = Bmoment[mu][0];	
	Mat[0][1] = Mat[1][0] = Bmoment[mu][1];	
	Mat[0][2] = Mat[2][0] = Bmoment[mu][2];
	Mat[1][1] = Bmoment[mu][3];	
	Mat[1][2] = Mat[2][1] = Bmoment[mu][4];
	Mat[2][2] = Bmoment[mu][5];

	double matVectMult[3];

	matVectMult[0] = Mat[0][0]*normalMat[0][0] + Mat[0][1]*normalMat[0][1] + Mat[0][2]*normalMat[0][2];	
	matVectMult[1] = Mat[1][0]*normalMat[0][0] + Mat[1][1]*normalMat[0][1] + Mat[1][2]*normalMat[0][2];
	matVectMult[2] = Mat[2][0]*normalMat[0][0] + Mat[2][1]*normalMat[0][1] + Mat[2][2]*normalMat[0][2];


	Bmomentab[mu][0] = normalMat[0][0]*matVectMult[0] + normalMat[0][1]*matVectMult[1] + normalMat[0][2]*matVectMult[2]; //alfa=[1,0,0,0], beta=[1,0,0,0]
	Bmomentab[mu][1] = normalMat[1][0]*matVectMult[0] + normalMat[1][1]*matVectMult[1] + normalMat[1][2]*matVectMult[2]; //alfa=[0,1,0,0], beta=[1,0,0,0]
	Bmomentab[mu][2] = normalMat[2][0]*matVectMult[0] + normalMat[2][1]*matVectMult[1] + normalMat[2][2]*matVectMult[2]; //alfa=[0,0,1,0], beta=[1,0,0,0]
	Bmomentab[mu][3] = normalMat[3][0]*matVectMult[0] + normalMat[3][1]*matVectMult[1] + normalMat[3][2]*matVectMult[2]; //alfa=[0,0,0,1], beta=[1,0,0,0]
	
	
	matVectMult[0] = Mat[0][0]*normalMat[1][0] + Mat[0][1]*normalMat[1][1] + Mat[0][2]*normalMat[1][2];	
	matVectMult[1] = Mat[1][0]*normalMat[1][0] + Mat[1][1]*normalMat[1][1] + Mat[1][2]*normalMat[1][2];
	matVectMult[2] = Mat[2][0]*normalMat[1][0] + Mat[2][1]*normalMat[1][1] + Mat[2][2]*normalMat[1][2];


	//Bmomentab[mu][1] = normalMat[0][0]*matVectMult[0] + normalMat[0][1]*matVectMult[1] + normalMat[0][2]*matVectMult[2]; //alfa=[1,0,0,0], beta=[0,1,0,0]
	Bmomentab[mu][4] = normalMat[1][0]*matVectMult[0] + normalMat[1][1]*matVectMult[1] + normalMat[1][2]*matVectMult[2]; //alfa=[0,1,0,0], beta=[0,1,0,0]
	Bmomentab[mu][5] = normalMat[2][0]*matVectMult[0] + normalMat[2][1]*matVectMult[1] + normalMat[2][2]*matVectMult[2]; //alfa=[0,0,1,0], beta=[0,1,0,0]
	Bmomentab[mu][6] = normalMat[3][0]*matVectMult[0] + normalMat[3][1]*matVectMult[1] + normalMat[3][2]*matVectMult[2]; //alfa=[0,0,0,1], beta=[0,1,0,0]


	matVectMult[0] = Mat[0][0]*normalMat[2][0] + Mat[0][1]*normalMat[2][1] + Mat[0][2]*normalMat[2][2];	
	matVectMult[1] = Mat[1][0]*normalMat[2][0] + Mat[1][1]*normalMat[2][1] + Mat[1][2]*normalMat[2][2];
	matVectMult[2] = Mat[2][0]*normalMat[2][0] + Mat[2][1]*normalMat[2][1] + Mat[2][2]*normalMat[2][2];

	
	//Bmomentab[mu][2] = normalMat[0][0]*matVectMult[0] + normalMat[0][1]*matVectMult[1] + normalMat[0][2]*matVectMult[2]; //alfa=[1,0,0,0], beta=[0,0,1,0]
	//Bmomentab[mu][5] = normalMat[1][0]*matVectMult[0] + normalMat[1][1]*matVectMult[1] + normalMat[1][2]*matVectMult[2]; //alfa=[0,1,0,0], beta=[0,0,1,0]
	Bmomentab[mu][7] = normalMat[2][0]*matVectMult[0] + normalMat[2][1]*matVectMult[1] + normalMat[2][2]*matVectMult[2]; //alfa=[0,0,1,0], beta=[0,0,1,0]
	Bmomentab[mu][8] = normalMat[3][0]*matVectMult[0] + normalMat[3][1]*matVectMult[1] + normalMat[3][2]*matVectMult[2]; //alfa=[0,0,0,1], beta=[0,0,1,0]

	
	matVectMult[0] = Mat[0][0]*normalMat[3][0] + Mat[0][1]*normalMat[3][1] + Mat[0][2]*normalMat[3][2];	
	matVectMult[1] = Mat[1][0]*normalMat[3][0] + Mat[1][1]*normalMat[3][1] + Mat[1][2]*normalMat[3][2];
	matVectMult[2] = Mat[2][0]*normalMat[3][0] + Mat[2][1]*normalMat[3][1] + Mat[2][2]*normalMat[3][2];

	//Bmomentab[mu][3] = normalMat[0][0]*matVectMult[0] + normalMat[0][1]*matVectMult[1] + normalMat[0][2]*matVectMult[2]; //alfa=[1,0,0,0], beta=[0,0,0,1]
	//Bmomentab[mu][6] = normalMat[1][0]*matVectMult[0] + normalMat[1][1]*matVectMult[1] + normalMat[1][2]*matVectMult[2]; //alfa=[0,1,0,0], beta=[0,0,0,1]
	//Bmomentab[mu][8] = normalMat[2][0]*matVectMult[0] + normalMat[2][1]*matVectMult[1] + normalMat[2][2]*matVectMult[2]; //alfa=[0,0,1,0], beta=[0,0,0,1]
	Bmomentab[mu][9] = normalMat[3][0]*matVectMult[0] + normalMat[3][1]*matVectMult[1] + normalMat[3][2]*matVectMult[2]; //alfa=[0,0,0,1], beta=[0,0,0,1]
	
  }
	
}


// Convective matrix of order n associated with variable coefficients
// q^3 is the number of quadrature points
// v1, v2, v3, v4 are the element's vertices
// binomialMat stores binomial coefficients
// normalMat stores normals to the edges of <v1,v2,v3,v4>
// Bmoment array contains B-moments associated with convective matrix coefficients
// Bmomentab contains contains inner products of convective matrix coefficients with normals
// computed convective matrix stored into convecMat array
// quadraWN contains Gauss-Jacobi quadrature weights and nodes
#ifdef PRECOMP
// matValNodes stores coefficients values at the quadrature points
double
Convec3d (int n, int q, double v1[3], double v2[3], double v3[3], double v4[3], double **binomialMat, double normalMat[][3], 
		double **precomp, double **Bmoment, double **Bmomentab, double **convecMat, double **matValNodes, double **quadraWN)
#else
// BmomentInter contains intermediate values required in the B-moments computation
double
Convec3d (int n, int q, double v1[3], double v2[3], double v3[3], double v4[3], double **binomialMat, double normalMat[][3], 
		double **Bmoment, double **BmomentInter, double **Bmomentab, double **convecMat, double **quadraWN)
#endif
{
  int Len= ( (n+3)*(n+2)*(n+1) ) / 6;



  for (int i=0; i<Len; i++)
  {
		for (int j=0; j<Len; j++)
		{
			convecMat[i][j] = 0.;
		}
  }
  
  clock_t t0, t1;
	
	t0 = clock();
	
	
	double Const = -n / 3./ Volume3d(v1,v2,v3,v4) / binomialMat[n-1][n]; // scaling constant used for variable coefficient
	
	int nb_Array = 3; // Convec needs Bmoments associated with 3D vector
	
	
	#ifdef PRECOMP
	Bmoment3d (2*n-1, q, nb_Array, v1, v2, v3, v4, binomialMat, precomp, Bmoment, matValNodes);        // using the algorithm with precomputed arrays;
	
	#else
	Bmoment3d_Index(2*n-1, q, nb_Array, Bmoment, BmomentInter, quadraWN);
	int M = MAX(2*n-1,q-1); // M is used for indexing
	
	#endif
	
	transform_BmomentC_Convec3d (n, q, Bmoment, Bmomentab, normalMat); 
	
	
	int p = n-1;

  int iMu=0, iMu1=1, iMu2=2, iMu3=3;
  for (int mu0=p; mu0>=0; mu0--, iMu1 +=p-mu0+1, iMu2++, iMu3++)
  {
		int mu2PlusMu3=0;
		for (int mu1=p-mu0; mu1>=0; mu1--, mu2PlusMu3++, iMu2++, iMu3++ )
		{
			int mu3=0;
			for (int mu2=p-mu0-mu1; mu2>=0; mu2--, mu3++, iMu++, iMu1++, iMu2++, iMu3++)
			{
				int iEta=0, iEta1=1, iEta2=2, iEta3=3;			
				for (int eta0=n; eta0>=0; eta0--, iEta1 += n-eta0+1, iEta2++, iEta3++)
				{
					#ifdef PRECOMP
					int iMuEta0 = position3d_sum (p - mu0, n - eta0);	// p-mu0=mu1+mu2+mu3, n-eta0=eta1+eta2+eta3	
					#else // not PRECOMP
					int iMuEta0 = (mu0+eta0)*(M+1)*(M+1);
					#endif	

					double v = binomialMat[mu0][eta0] ;
					int eta2PlusEta3 = 0 ;
					for (int eta1 = n-eta0 ; eta1>=0; eta1--, eta2PlusEta3++, iEta2++, iEta3++)
					{
						
						#ifdef PRECOMP
						int iMuEta1 = iMuEta0 + position3d_sum2 (p-mu0-mu1, n-eta0-eta1);	// p-mu0-mu1=mu2+mu3, n-eta0-eta1=eta2+eta3
						#else
						int iMuEta1 = iMuEta0 + (mu1+eta1)*(M+1);
						#endif

						v *= binomialMat[mu1][eta1];
						int eta3=0;
						for (int eta2=n-eta0-eta1; eta2>=0; eta2--, eta3++, iEta++, iEta1++, iEta2++, iEta3++)
						{

							double w = v * binomialMat[mu2][eta2] * binomialMat[mu3][eta3];	
										
							w *= Const;
							int iMuEta;

							#ifdef PRECOMP
							iMuEta = iMuEta1 + eta3 +mu3;
							#else
							iMuEta = iMuEta1 + eta2 + mu2;
							#endif // end not PRECOMP

							convecMat[iMu] [iEta]   += w * Bmomentab[iMuEta][0]; // alpha=[1,0,0,0]
							convecMat[iMu1][iEta]   += w * Bmomentab[iMuEta][1]; //alpha=[0,1,0,0]
							convecMat[iMu2][iEta]   += w * Bmomentab[iMuEta][2]; //alpha=[0,0,1,0]
							convecMat[iMu3][iEta]   += w * Bmomentab[iMuEta][3]; //alpha=[0,0,0,1]
															
						}
						v /= binomialMat[mu1][eta1];	
					}
				}			
			}
		}
  }
  
  t1 = clock();
  
					  
  #ifdef CHECK							// check output
  std::cout<<"\nConvective matrix entries:\n";
  for (int mu0=n; mu0>=0; mu0--)
  {
		for (int mu1=n-mu0; mu1>=0; mu1--)
		{
			for (int mu2=n-mu0-mu1; mu2>=0; mu2--)
			{
			int mu3=n-mu0-mu1-mu2; int iMu=position3d(mu1,mu2,mu3);
			for (int eta0=n; eta0>=0; eta0--)
			{
				for (int eta1=n-eta0; eta1>=0; eta1--)
				{
				for (int eta2=n-eta0-eta1; eta2>=0; eta2--)
				{
					int eta3=n-eta0-eta1-eta2; int iEta=position3d(eta1,eta2,eta3);
					printf("%.04e\t",convecMat[iMu][iEta]);
				}
				}
			}
			std::cout<<"\n";
			}	  
		}
  } 

  #endif	

  double cpu_time_used = ((double)(t1-t0))/CLOCKS_PER_SEC;

  return cpu_time_used;
	
	
}


//Stiffness matrix of order n associated with variable coefficients
// The entries of the stiffness matrix are indexing using lexicographical order
//WARNING: input quadraWN must be the the q-point quadrature
// v1, v2, v3, v4 are the element's vertices
// binomialMat stores binomial coefficients
// scalarMat contains weighted inner products of normals to the element's edges
// cputime contains cpu timings
// Bmoment contains B-moments associated with stiffness matrix coefficients
// Bmomentab contains products of Bmoments with normals to the edges of <v1,v2,v3,v4>
// computed stiffness matrix stored into stiffMat array
// quadraWN contains Gauss-Jacobi quadrature weights and nodes
#ifdef PRECOMP
// precomp contains precomputed arrays needed for computing B-moments associated with stiffness matrix coefficients
// matValNodes contains values of stiffness matrix coefficients at the quadrature points
double
Stiff3d (int n, int q, double v1[3], double v2[3], double v3[3], double v4[3], double **stiffMat, double **matValNodes, double **quadraWN, double **binomialMat, double normalMat[][3], 
	   double **precomp, double **Bmoment, double **Bmomentab, double cpu_time[5] )
#else
// BmomentInter contains intermediate values needed in the computation of the B-moments associated with stiffness matrix coefficients
double
Stiff3d (int n, int q, double v1[3], double v2[3], double v3[3], double v4[3], double **stiffMat, double **quadraWN, double **binomialMat, double normalMat[][3], double **Bmoment, double **BmomentInter, double **Bmomentab, double cpu_time[5] )
#endif
{
	
  
  int Len= ( (n+3)*(n+2)*(n+1) ) / 6;



  for (int i=0; i<Len; i++)
  {
		for (int j=0; j<Len; j++)
		{
			stiffMat[i][j] = 0.;
		}
  }


  clock_t t0, t1, t1Bis, t2, t3;

  t0=clock();

  
  double Const =     n * n / 9. / Volume3d (v1, v2, v3, v4) / Volume3d (v1, v2, v3, v4) / binomialMat[n - 1][n - 1];
  
  
  int nb_Array=6; // Stiff needs Bmoments associated with symmetric 3 by 3 matrix-valued function
  
  #ifdef PRECOMP
  cpu_time[4]= Bmoment3d (2*n-2, q, nb_Array, v1, v2, v3, v4, binomialMat, precomp, Bmoment, matValNodes);        // using the algorithm with precomputed arrays;
  
   
  #else
  
  cpu_time[4]= Bmoment3d_Index(2*n-2, q, nb_Array, Bmoment, BmomentInter, quadraWN);
	int M = MAX(2*n-2,q-1); // mm is used for indexing
  
  #endif // end not PRECOMP



  t1=clock();

  t1Bis=clock();

  cpu_time[0]= ( (double)(t1Bis-t1) )/CLOCKS_PER_SEC;	// time for moments

  transform_BmomentC_Stiff3d (n,q, Bmoment, Bmomentab, normalMat); 

  t2=clock();

  cpu_time[1] = ( (double)(t2-t1Bis) ) /CLOCKS_PER_SEC;	//  time for transform_BmomentC



  int p = n-1;

  int iMu=0, iMu1=1, iMu2=2, iMu3=3;
  for (int mu0=p; mu0>=0; mu0--, iMu1 +=p-mu0+1, iMu2++, iMu3++)
  {
	int mu2PlusMu3=0;
		for (int mu1=p-mu0; mu1>=0; mu1--, mu2PlusMu3++, iMu2++, iMu3++ )
		{
			int mu3=0;
			for (int mu2=p-mu0-mu1; mu2>=0; mu2--, mu3++, iMu++, iMu1++, iMu2++, iMu3++)
			{
				int iEta=0, iEta1=1, iEta2=2, iEta3=3;			
				for (int eta0=p; eta0>=0; eta0--, iEta1 += p-eta0+1, iEta2++, iEta3++)
				{
					#ifdef PRECOMP
					int iMuEta0 = position3d_sum (p - mu0, p - eta0);	// p-mu0=mu1+mu2+mu3, p-eta0=eta1+eta2+eta3	
					#else // not PRECOMP
					int iMuEta0 = (mu0+eta0)*(M+1)*(M+1);
					#endif	

					double v = binomialMat[mu0][eta0] ;
					int eta2PlusEta3 = 0 ;
					for (int eta1 = p-eta0 ; eta1>=0; eta1--, eta2PlusEta3++, iEta2++, iEta3++)
					{
							
						#ifdef PRECOMP
						int iMuEta1 = iMuEta0 + position3d_sum2 (p-mu0-mu1, p-eta0-eta1);	// p-mu0-mu1=mu2+mu3, p-eta0-eta1=eta2+eta3
						#else
						int iMuEta1 = iMuEta0 + (mu1+eta1)*(M+1);
						#endif

						v *= binomialMat[mu1][eta1];
						int eta3=0;
						for (int eta2=p-eta0-eta1; eta2>=0; eta2--, eta3++, iEta++, iEta1++, iEta2++, iEta3++)
						{

							double w = v * binomialMat[mu2][eta2] * binomialMat[mu3][eta3];	//double w = binomialMat[mu0][eta0] * binomialMat[mu1][eta1] * binomialMat[mu2][eta2] * binomialMat[mu3][eta3];

										
							w *= Const;
							int iMuEta;

							#ifdef PRECOMP
							iMuEta = iMuEta1 + eta3 +mu3;
							#else
							iMuEta = iMuEta1 + eta2 + mu2;
							#endif // end not PRECOMP



							stiffMat[iMu][iEta]   += w * Bmomentab[iMuEta][0]; //alfa=[1,0,0,0], beta=[1,0,0,0]
							stiffMat[iMu][iEta1]  += w * Bmomentab[iMuEta][1]; //beta=[0,1,0,0]
							stiffMat[iMu][iEta2]  += w * Bmomentab[iMuEta][2]; //beta=[0,0,1,0]
							stiffMat[iMu][iEta3]  += w * Bmomentab[iMuEta][3]; //beta=[0,0,1,0]

													
							stiffMat[iMu1][iEta]  += w * Bmomentab[iMuEta][1]; //alfa=[0,1,0,0], beta=[1,0,0,0]
							stiffMat[iMu1][iEta1] += w * Bmomentab[iMuEta][4]; //beta=[0,1,0,0] 
							stiffMat[iMu1][iEta2] += w * Bmomentab[iMuEta][5]; //beta=[0,0,1,0]
							stiffMat[iMu1][iEta3] += w * Bmomentab[iMuEta][6]; //beta=[0,0,0,1]
							

												
							stiffMat[iMu2][iEta]  += w * Bmomentab[iMuEta][2]; //alfa=[0,0,1,0], beta=[1,0,0,0]
							stiffMat[iMu2][iEta1] += w * Bmomentab[iMuEta][5]; //beta=[0,1,0,0]
							stiffMat[iMu2][iEta2] += w * Bmomentab[iMuEta][7]; //beta=[0,0,1,0]
							stiffMat[iMu2][iEta3] += w * Bmomentab[iMuEta][8]; //beta=[0,0,0,1]

							
							stiffMat[iMu3][iEta]  += w * Bmomentab[iMuEta][3]; //alfa=[0,0,0,1], beta=[1,0,0,0]
							stiffMat[iMu3][iEta1] += w * Bmomentab[iMuEta][6]; //beta=[0,1,0,0]
							stiffMat[iMu3][iEta2] += w * Bmomentab[iMuEta][8]; //beta=[0,0,1,0]
							stiffMat[iMu3][iEta3] += w * Bmomentab[iMuEta][9]; //beta=[0,0,0,1] 
										
						}
						v /= binomialMat[mu1][eta1];	
					}
				}
			}
		}
  }


  t3=clock();


  cpu_time[2]=((double) (t3-t2) )	/ CLOCKS_PER_SEC ;

					  
  #ifdef CHECK							// check output
  std::cout<<"\nStiffness matrix entries:\n";
  for (int mu0=n; mu0>=0; mu0--)
  {
	for (int mu1=n-mu0; mu1>=0; mu1--)
	{
	  for (int mu2=n-mu0-mu1; mu2>=0; mu2--)
	  {
		int mu3=n-mu0-mu1-mu2; int iMu=position3d(mu1,mu2,mu3);
		for (int eta0=n; eta0>=0; eta0--)
		{
		  for (int eta1=n-eta0; eta1>=0; eta1--)
		  {
			for (int eta2=n-eta0-eta1; eta2>=0; eta2--)
			{
			  int eta3=n-eta0-eta1-eta2; int iEta=position3d(eta1,eta2,eta3);
			  printf("%.02e\t",stiffMat[iMu][iEta]);
			}
		  }
		}
		std::cout<<"\n";
	  }	  
	}
  } 

  #endif	

  cpu_time[3] = ((double)(t3-t0))/CLOCKS_PER_SEC;

  return cpu_time[3];	//return cpu_time_used;

}



//routine for initializing pointers used in the computation of the elemental quantities
// associated with variable data

// v1, v2, v3, v4 are the element's vertices
// n is the order of the B-moments
// q^3 is the number of quadrature points
// nDash and m are some intermediate values
// nb_Array is used to specify that the coefficients are scalar-valued
// Cval stores coefficients values at the quadrature points
// quadraWN contains Gauss-Jacobi quadrature weights and nodes
// f is a scalar-valued function which produces the B-moments coefficients
// functval is a flag which indicates the input used for the B-moments coefficients
#ifdef PRECOMP
void
assign_pointers_Bmom3d (double v1[3], double v2[3], double v3[3], double v4[3],
											int n, int q, int nDash, int m, int nb_Array,
											double **matValNodes, double *Cval, double **quadraWN,
											double **precomp, double (*f) (double[3]), int functval)
#else
void
assign_pointers_Bmom3d (double v1[3], double v2[3], double v3[3], double v4[3],
											int n, int q, int nDash, int m, int nb_Array,
											double *Cval, double **quadraWN,
											double **Bmoment, double (*f) (double[3]), int functval)
#endif
{
	assign_quadra3d(q, quadraWN ); // initialize quadrature weights and nodes
	
	#ifdef PRECOMP

              
	if (functval == 1) // using function values as input
		data_at_Nodes_Cval3d (matValNodes, q, Cval, nb_Array);
  

	else // by default: using function definition as input	
		data_at_Nodes_Bmom3d (f, matValNodes, q, quadraWN, v1, v2, v3, v4);   
																																						
  
	init_precomp3d(precomp, nDash, q, m, quadraWN);

  #else //not PRECOMP
	
	if (functval == 1)// using function values as input
		init_Bmoment3d_Cval (Cval, q, v1, v2, v3, v4, Bmoment, nb_Array);// careful: this routine should be called with "BmomentInter"	

  else
		init_BmomentC_Bmom3d (f, q, v1, v2, v3, v4, Bmoment, quadraWN);

  #endif // end not PRECOMP
	
}

// v1, v2, v3, v4 are the element's vertices
// n is the order of the B-moments
// q^3 is the number of quadrature points
// nDash and m are some intermediate values
// nb_Array is used to specify that the coefficients are scalar-valued
// Cval stores coefficients values at the quadrature points
// quadraWN contains Gauss-Jacobi quadrature weights and nodes
// f is a scalar-valued function which produces the mass matrix coefficients
// functval is a flag which indicates the input used for the mass matrix coefficients
#ifdef PRECOMP
void
assign_pointers_Mass3d (double v1[3], double v2[3], double v3[3], double v4[3],
											int n, int q, int nDash, int m, int nb_Array,
											double **matValNodes, double *Cval, double **quadraWN,
											double **precomp, double (*f) (double[3]), int functval)
#else
void
assign_pointers_Mass3d (double v1[3], double v2[3], double v3[3], double v4[3],
											int n, int q, int nDash, int m, int nb_Array,
											double *Cval, double **quadraWN,
											double **Bmoment, double (*f) (double[3]), int functval)
#endif
{

	assign_quadra3d(q, quadraWN ); // initialize quadrature weights and nodes
	
	
	#ifdef PRECOMP
             
	if (functval == 1) // using function values as input
		data_at_Nodes_Cval3d (matValNodes, q, Cval, nb_Array);
  
	else //by default: using function definition as input		
		data_at_Nodes_Mass3d (f, matValNodes, q, quadraWN, v1, v2, v3, v4);
  
	init_precomp3d(precomp, nDash, q, m, quadraWN);

  #else //not PRECOMP
	
	if (functval == 1) // using function values as input
		init_Bmoment3d_Cval (Cval, q, v1, v2, v3, v4, Bmoment, nb_Array);// careful: the Bmoment initialization is done using "BmomentInter"
	
  else // by default: using function definition as input
		init_BmomentC_Mass3d (f, q, v1, v2, v3, v4, Bmoment, quadraWN);

  #endif // end not PRECOMP
	
}

// v1, v2, v3, v4 are the element's vertices
// n is the order of the B-moments
// q^3 is the number of quadrature points
// nDash and m are some intermediate values
// nb_Array is used to specify that the coefficients are vector-valued
// Cval stores coefficients values at the quadrature points
// quadraWN contains Gauss-Jacobi quadrature weights and nodes
// b is a vector-valued function which produces the convective matrix coefficients
// functval is a flag which indicates the input used for the convective matrix coefficients
#ifdef PRECOMP
void
assign_pointers_Convec3d (double v1[3], double v2[3], double v3[3], double v4[3],
											int n, int q, int nDash, int m, int nb_Array,
											double **matValNodes, double *Cval, double **quadraWN,
											double **precomp, void (*b) (double[3], double[3]), int functval )
#else
void
assign_pointers_Convec3d (double v1[3], double v2[3], double v3[3], double v4[3],
											int n, int q, int nDash, int m, int nb_Array,
											double *Cval, double **quadraWN,
											double **Bmoment, void (*b) (double[3], double[3]), int functval)
#endif
{

	assign_quadra3d(q, quadraWN ); // initialize quadrature weights and nodes
	
	
	#ifdef PRECOMP
               
	if (functval == 1) // using function values as input
		data_at_Nodes_Cval3d (matValNodes, q, Cval, nb_Array);
  
	else	//by default: using function definition as input
		data_at_Nodes_Convec3d (b, matValNodes, q, quadraWN, v1, v2, v3, v4);													
  
	init_precomp3d(precomp, nDash, q, m, quadraWN);

  #else //not PRECOMP
	
	if (functval == 1) // using array of function values as input
		init_Bmoment3d_Cval (Cval, q, v1, v2, v3, v4, Bmoment, nb_Array);// careful: the Bmoment initialization is done using "BmomentInter"
	
  else // by default: using function definition as input
		init_BmomentC_Convec3d (b, q, v1, v2, v3, v4, Bmoment, quadraWN);
	

  #endif // end not PRECOMP
	
}

// v1, v2, v3, v4 are the element's vertices
// n is the order of the B-moments
// q^3 is the number of quadrature points
// nDash and m are some intermediate values
// nb_Array is used to specify that the coefficients are matrix-valued
// Cval stores coefficients values at the quadrature points
// quadraWN contains Gauss-Jacobi quadrature weights and nodes
// b is a vector-valued function which produces the stiffness matrix coefficients
// functval is a flag which indicates the input used for the stiffness matrix coefficients
#ifdef PRECOMP
void
assign_pointers_Stiff3d (double v1[3], double v2[3], double v3[3], double v4[3],
											int n, int q, int nDash, int m, int nb_Array,
											double **matValNodes, double *Cval, double **quadraWN,
											double **precomp, void (*A) (double[3], double[3][3]), int functval)
#else
void
assign_pointers_Stiff3d (double v1[3], double v2[3], double v3[3], double v4[3],
											int n, int q, int nDash, int m, int nb_Array,
											double *Cval, double **quadraWN,
											double **Bmoment, void (*A) (double[3], double[3][3]), int functval)
#endif
{
	assign_quadra3d(q, quadraWN ); // initialize quadrature weights and nodes
	
	#ifdef PRECOMP
              
	if (functval == 1)  // using function values as input
		data_at_Nodes_Cval3d (matValNodes, q, Cval, nb_Array);
  
	else	// by default: using function definition as input
		data_at_Nodes_Stiff3d (A, matValNodes, q, quadraWN, v1, v2, v3, v4);   
  

	init_precomp3d(precomp, nDash, q, m, quadraWN);

  #else //not PRECOMP
	
	if (functval == 1)
		init_Bmoment3d_Cval (Cval, q, v1, v2, v3, v4, Bmoment, nb_Array);

  else // by default: using function definition as input  
		init_BmomentC_Stiff3d (A, q, v1, v2, v3, v4, Bmoment, quadraWN); 
  
  #endif // end not PRECOMP
	
}

// compute Bmoment of order n associated with constant coefficients 1
// Bmoment is an array of length ((n + 2) * (n + 1)) / 2
// v1, v2, v3 are the element's vertices
void
get_Bmoments3d_const (double **Bmoment, int n, double v1[3], double v2[3], double v3[3], double v4[3])
{
	
	double **binomialMat;
	
	int len_binomial = 2*n+3;
  binomialMat = create_BinomialMat(len_binomial); // store binomial coefficients
  computeBinomials(binomialMat, len_binomial); //compute binomials
	
	
	Bmoment3d_const (n, v1, v2, v3, v4, binomialMat, Bmoment); // compute B-moments
	
	delete_BinomialMat (binomialMat, len_binomial); // free allocated memory
	
	#ifdef CHECK
	int lenMoments = ((n+3)*(n+2)*(n+1)) / 6;
  std::cout<<"B-moment entries stored into array Bmoment of length "<<lenMoments<<"\n";
  #endif

}



// compute Bmoment associated with function f
// Bmoment is an array of length ((n+3)*(n + 2) * (n + 1)) / 6 with PRECOMP,
// and (n + 1)^3 with non-PRECOMP
// f is a scalar-valued function which produces the B-moments coefficients
// Cval stores the coefficients values at the quadrature points
// v1, v2, v3, v4 are the element's vertices
// functval allows the option to use array of function values at quadrature nodes as input for the B-moments coefficients
void
get_Bmoments3d(double **Bmoment, int n, double (*f)(double[3]), double *Cval, double v1[3], double v2[3],
						 double v3[3], double v4[3], int functval)
{
	#ifdef PRECOMP
	double **binomialMat; 
	double **precomp;
	double **matValNodes;
	#else
	double **BmomentInter;
	#endif
	

	double **quadraWN;
	
	#ifdef PRECOMP
  int len_binomial = 2*n+3;
  binomialMat = create_BinomialMat(len_binomial); // store binomial coefficients
  computeBinomials(binomialMat, len_binomial); //compute binomials
  #endif
  
  
  // initialize number of quadrature pointers, and integers needed for indexing Bmoment entries
  int q = n+1; // for the B-moments, the number of quadrature points is n+1 by default
  int nDash = n; // nDash stands for the Bmoment order
  int m = MAX(n,q-1); // in case value of q is increased,
											// m is used to create sufficiently large precomp
  
  int nb_Array = 1;
   
  //allocates memory to quadraWN
	int len_Quadra = (q + 1);     // space required for storing Jacobi nodes of order q is q, BUT indexing starts at 1
  quadraWN = create_quadraWN3d(len_Quadra); // store quadrature weights and nodes of a fixed degree (no-storing algorithm)
	

	
	#ifdef PRECOMP
  //allocates memory to MatValNodes
	int len_matValNodes = q * q * q;      // space required for 3D array with dimension q
  matValNodes = create_matValNodes3d(len_matValNodes);
	precomp = create_precomp3d(m+1); // store precomputed arrays  
	
	#else	
	int lenMoments = len_Moments3d(n, q);
	BmomentInter = create_Bmoment(lenMoments, nb_Array);
	#endif
	
	
	#ifdef PRECOMP
	assign_pointers_Bmom3d (v1, v2, v3, v4, n, q, nDash, m, nb_Array,
												matValNodes, Cval, quadraWN, precomp, f, functval);
	#else
	assign_pointers_Bmom3d (v1, v2, v3, v4, n, q, nDash, m, nb_Array,
												Cval, quadraWN, BmomentInter, f, functval);
	#endif
																		
	// store Bmoments into array Bmoment
  #ifdef PRECOMP
	Bmoment3d (n, q, nb_Array, v1, v2, v3, v4, binomialMat, precomp, Bmoment, matValNodes);  
  #else
  Bmoment3d_Index (n, q, nb_Array, Bmoment, BmomentInter, quadraWN);
  #endif
	
	// free allocated memory
	#ifdef PRECOMP
	delete_pointers_Bmom(precomp, matValNodes, quadraWN);
	#else
	delete_pointers_Bmom(BmomentInter, quadraWN);
	#endif
  
  #ifdef PRECOMP
  delete_BinomialMat (binomialMat, len_binomial);
  #endif
  
  #ifdef CHECK
  #ifdef PRECOMP
  int lenMoments = len_Moments3d(n, q);
	#endif
  std::cout<<"B-moment entries stored into array Bmoment of length "<<lenMoments<<"\n";
  #endif
  
	
}


// compute mass matrix associated with function f
// the output matrix is of dimention ((n+1)*(n+2)*(n+3))/6
// f is a scalar-valued function which produces the B-moments coefficients
// Cval stores the coefficients values at the quadrature points
// v1, v2, v3, v4 are the element's vertices
// functval allows the option to use array of function values at quadrature nodes as input for the B-moments coefficients
void
get_mass3d(double **massMat, int n, double (*f)(double[3]), double *Cval, 
				 double v1[3], double v2[3], double v3[3], double v4[3], int functval)
{
	
  double **binomialMat; // store binomial coefficients
  
	#ifdef PRECOMP
  double **precomp;	// needs to be created, since passed as arguments into Mass
  double **matValNodes;
	#else
	double **BmomentInter;
	#endif
  
  double **Bmoment; 
  double **quadraWN;	// store quadrature weights and nodes of a fixed degree (no-storing algorithm)
	
	int len_binomial = 2*n+3;
	binomialMat = create_BinomialMat(len_binomial);
	
	// initialize number of quadrature pointers, and integers needed for indexing Bmoment entries
  int q = n+1;                    // the number of quadrature points is n+1  
  int nDash = 2 * n;            // the Bmoment order required for the mass matrix is 2n
  int m = MAX(nDash,q-1);   // m is used for indexing with non-PRECOMP, and for allowing sufficient size to "precomp"
  int nb_Array = 1;             // the Bmoment required is associated with a SCALAR function
  
	int len_Quadra = (q + 1);     // space required for storing Jacobi nodes of order q is q, BUT indexing starts at 1	
  quadraWN = create_quadraWN3d(len_Quadra);
	
	
	// initialize auxilliary arrays
	computeBinomials(binomialMat, len_binomial); //compute binomials
		
	int lenMoments = len_Moments3d(nDash,q);
  
  Bmoment = create_Bmoment(lenMoments, nb_Array);
  
	
	
	#ifdef PRECOMP
	int len_matValNodes = q * q * q;      // space required for 3D array with dimension q	
  matValNodes = create_matValNodes3d(len_matValNodes);
	precomp = create_precomp3d(m+1); // store precomputed arrays
	
	#else	
	BmomentInter = create_Bmoment(lenMoments, nb_Array);
	#endif
	
	
	//assign values to auxilliary arrays
	#ifdef PRECOMP
	assign_pointers_Mass3d (v1, v2, v3, v4, n, q, nDash, m, nb_Array,matValNodes, Cval, quadraWN, precomp, f, functval);
	#else
	assign_pointers_Mass3d (v1, v2, v3, v4, n, q, nDash, m, nb_Array, Cval, quadraWN, BmomentInter, f, functval);
	#endif
									
	// store mass matrix entries into array massMat
	#ifdef PRECOMP
	Mass3d (n, q, v1, v2, v3, v4, binomialMat, precomp, Bmoment, massMat,
				matValNodes, quadraWN);
	#else
	Mass3d (n, q, v1, v2, v3, v4, binomialMat, Bmoment, BmomentInter, massMat, quadraWN);
	#endif

	
	
	//free allocated memory
		#ifdef PRECOMP
		delete_pointers_Mass(precomp, Bmoment, matValNodes, quadraWN);
		#else
		delete_pointers_Mass(Bmoment, BmomentInter, quadraWN);
		#endif
	
  delete_BinomialMat (binomialMat, len_binomial);
	
	
	#ifdef CHECK
	int len_Mass = len_Mat3d(n); // dimension of the elemental mass matrix
	std::cout<<"Mass matrix entries stored into array massMat of dimension "<<len_Mass<<"\n";
	#endif

	
}



// compute convective matrix associated with vector-valued function b
// the output matrix is of dimention ((n+1)*(n+2)*(n+3))/6
// b is a vector-valued function which produces the convective matrix coefficients
// Cval stores the coefficients values at the quadrature points
// v1, v2, v3, v4 are the element's vertices
// functval allows the option to use array of function values at quadrature nodes as input for the convective matrix coefficients
void
get_convec3d(double **convecMat, int n, void (*b) (double[3], double[3]), double *Cval,
					 double v1[3], double v2[3], double v3[3], double v4[3], int functval)
{
	
	
  double **binomialMat; // store binomial coefficients  
  double normalMat[4][3] = { {0, 0, 0}, {0, 0, 0}, {0, 0 , 0}, {0, 0 , 0} };  // store normals to the edges
  
  #ifdef PRECOMP
  double **precomp;	// need to be created, since passed as arguments into Convec
  double **matValNodes;
  #else
  double **BmomentInter;
  #endif
  
  
  double **Bmoment, **Bmomentab; // need to be created, since passed as arguments into Convec
  
  double **quadraWN;
	
	int len_binomial = 2*n+3;
	binomialMat = create_BinomialMat(len_binomial);
	
	// initialize number of quadrature pointers, and integers needed for indexing Bmoment entries
	int q = n+1;                    // the number of quadrature points is n+1  
  int nDash = 2 * n - 1;        // Bmoment order convective matrix
	int m = MAX (nDash, q-1);       // m is used for indexing with non-PRECOMP and for "precomp" size

  int nb_Array = 3;             //Convec needs Bmoment associated with vector-valued function
    
  int len_Quadra = (q + 1);     // space required for storing Jacobi nodes of order q is q, BUT indexing starts at 1
	
	// allocates memory for quadraWN
  quadraWN = create_quadraWN3d(len_Quadra);
	
	// initialize auxilliary arrays
	computeBinomials(binomialMat, len_binomial); //compute binomials
	normals3d (v1, v2, v3, v4, normalMat); // compute normals to the edges
	
	int lenMoments = len_Moments3d(nDash, q);
  
  Bmoment = create_Bmoment(lenMoments, nb_Array);
  Bmomentab = create_Bmoment(lenMoments, 4); // Bmomentab contains inner products of normals with Bmoments
	
	#ifdef PRECOMP
	int len_matValNodes = q * q * q;      // space required for 3D array with dimension q		
  matValNodes = create_matValNodes3d(len_matValNodes);
	precomp = create_precomp3d(m+1); // store precomputed arrays
	
	#else	
	BmomentInter = create_Bmoment(lenMoments, nb_Array);
	#endif
	

	
	//assign values to auxilliary arrays
	#ifdef PRECOMP
	assign_pointers_Convec3d (v1, v2, v3, v4, n, q, nDash, m, nb_Array,matValNodes, Cval, quadraWN, precomp, b, functval);
	#else
	assign_pointers_Convec3d (v1, v2, v3, v4, n, q, nDash, m, nb_Array, Cval, quadraWN, BmomentInter, b, functval);
	#endif
									
	// store convective matrix entries into array convecMat
	#ifdef PRECOMP
	Convec3d (n, q, v1, v2, v3, v4, binomialMat, normalMat, precomp,
					Bmoment, Bmomentab, convecMat, matValNodes, quadraWN);
	#else
	Convec3d (n, q, v1, v2, v3, v4, binomialMat, normalMat, Bmoment, BmomentInter, Bmomentab, convecMat, quadraWN);
	#endif
		 
	
		#ifdef PRECOMP
		delete_pointers(precomp, Bmoment, Bmomentab, 
														matValNodes, quadraWN);
		#else
		delete_pointers(Bmoment, BmomentInter, Bmomentab, 
														quadraWN);
		#endif // end not PRECOMP
	
  delete_BinomialMat (binomialMat, len_binomial);
	
	
	#ifdef CHECK
	int len_Convec = len_Mat3d(n); // dimension of elemental convective matrix
	std::cout<<"Convective matrix entries stored into array convecMat of dimension "<<len_Convec<<"\n";
	#endif
	
}


// compute stiffness matrix associated with matrix-valued function A
// the output matrix is of dimention ((n+1)*(n+2)*(n+3))/6
// A is a vector-valued function which produces the stiffness matrix coefficients
// Cval stores the coefficients values at the quadrature points
// v1, v2, v3, v4 are the element's vertices
// functval allows the option to use array of function values at quadrature nodes as input for the stiffness matrix coefficients
void
get_stiffness3d(double **stiffMat, int n, void (*A) (double [3], double [3][3]), double *Cval,
							double v1[3], double v2[3], double v3[3], double v4[3], int functval)
{

  double **binomialMat; // store binomial coefficients  
  double cputime[5]; // needed, since passed as argument in Stiff  
  double normalMat[4][3] = { {0, 0, 0}, {0, 0, 0}, {0, 0, 0}, {0, 0, 0} };  // store normals to the edges
	
	int len_binomial = 2*n+3;
	binomialMat = create_BinomialMat(len_binomial);
	
	
	#ifdef PRECOMP
	double **precomp;	// need to be created, since passed as arguments into Stiff
	double **matValNodes;
	#else
	double **BmomentInter;
	#endif
	
	double **Bmoment, **Bmomentab; // need to be created, since passed as arguments into Stiff
   
  double **quadraWN;

	
	// initialize number of quadrature pointers, and integers needed for indexing Bmoment entries
  int q = n+1;                    // the number of quadrature points is n+1
  
  int nDash = 2 * n - 2;        // the Bmoment order required for the stiffness matrix is 2n-2

	int m = MAX (nDash, q-1);       // m is used for indexing with non-PRECOMP, and for allowing sufficient size to "precomp"

  int nb_Array = 6;             //Stiff needs Bmoment associated with symmetric 3 by 3 matrix valued function
	int len_Quadra = (q + 1);     // space required for storing Jacobi nodes of order q is q, BUT indexing starts at 1
	
	// allocates memory for quadraWN
  quadraWN = create_quadraWN3d(len_Quadra);
	
	
	// initialize auxilliary arrays
	computeBinomials(binomialMat, len_binomial); //compute binomials
	normals3d (v1, v2, v3, v4, normalMat);
	
	int lenMoments = len_Moments3d(nDash, q);
  
  Bmoment = create_Bmoment(lenMoments, nb_Array);
  Bmomentab = create_Bmoment(lenMoments, 10); // multiply normals to Bmoments and store into Bmomentab: used with Stiff
	
	#ifdef PRECOMP
	int len_matValNodes = q * q * q;      // space required for 3D array with dimension q
  matValNodes = create_matValNodes3d(len_matValNodes);
	precomp = create_precomp3d(m+1);	// store precomputed arrays
	
	#else	
	BmomentInter = create_Bmoment(lenMoments, nb_Array);
	#endif
	


	//assign values to auxilliary arrays
	#ifdef PRECOMP
	assign_pointers_Stiff3d (v1, v2, v3, v4, n, q, nDash, m, nb_Array, matValNodes, Cval, quadraWN, precomp, A, functval );
	#else
	assign_pointers_Stiff3d (v1, v2, v3, v4, n, q, nDash, m, nb_Array, Cval, quadraWN, BmomentInter, A, functval);
	#endif
									
	// store stiffness matrix entries into array stiffMat
	#ifdef PRECOMP
	Stiff3d (n, q, v1, v2, v3, v4, stiffMat, matValNodes, quadraWN, binomialMat, 
				 normalMat, precomp, Bmoment, Bmomentab, cputime );
	#else
	Stiff3d (n, q, v1, v2, v3, v4, stiffMat, quadraWN, binomialMat, 
				 normalMat, Bmoment, BmomentInter, Bmomentab, cputime );
	#endif
	
	
	// free allocated memory
		#ifdef PRECOMP
		delete_pointers(precomp, Bmoment, Bmomentab, 
														matValNodes, quadraWN);
		#else
		delete_pointers(Bmoment, BmomentInter, Bmomentab, 
														quadraWN);
		#endif
	
	delete_BinomialMat (binomialMat, len_binomial);
	
	int len_Stiff = len_Mat3d(n); // dimension of the elemental stiffness matrix
	
	std::cout<<"Stiffness matrix entries stored into array stiffMat of dimension "<<len_Stiff<<"\n";
		
}


/////////////////////////////////////////////////////////////////////////////////////////// 2D routines /////////////////////////////////


#ifdef PRECOMP


/////////////////////////// using the algorithm with precomputed arrays //////////////////////



// computes Bmoment vector entries into Bmoment array
// matValNodes initialized by means of data_at_Nodes_* or data_at_Nodes_Cval2d routines
// parameter q stands for the number of quadrature points in each direction
// precomp contains precomputed arrays used in the B-moments computation
// binomialMat contains binomial coefficients
// nb_Array determines the length of the Bmoment (whether the output is associated with a scalar-, vector- or matrix-valued function)
double
Bmoment2d (int n, int q, int mp, int nb_Array, double v1[2], double v2[2], double v3[2], double **binomialMat, 
		  double **precomp, double **Bmoment, double **matValNodes)
{


  clock_t t0, t1;

  t0 = clock ();


  int mm = ((n + 2) * (n + 1)) / 2;

  // initialize all the entries of loadMat since they are modified at each function call !!
  for (int mu = 0; mu < mm; mu++)
    {
      for (int i = 0; i < nb_Array; i++)
        Bmoment[mu][i] = 0.0;
    }

  double Const = Area2d (v1, v2, v3) / 4.;        // the division by 4 comes from the Jacobi transformation mapping the triangle
  // to the square [-1;1]^2
  // with the non-precomputed method, the triangle is mapped to the unit square [0,1]^2
  // and uses Stroud weights and nodes on [0,1]^2

  double H[nb_Array];


  for (int mu0 = 0; mu0 <= n; mu0++)
    {
			for (int j = 0; j < q; j++)
        {

          for (int ell = 0; ell < nb_Array; ell++)
            H[ell] = 0;

					for (int i = 0; i < q; i++)
            {
							int index_ij = position2d2 (i, j, q-1);  // this is the indexing used in data_at_Nodes


              for (int ell = 0; ell < nb_Array; ell++)
								H[ell] += precomp[2*(mp+1) + mu0][i] * precomp[3*(mp+1) + mu0][i] * matValNodes[index_ij][ell];

            }

						for (int mu2 = 0; mu2 <= n - mu0; mu2++)
            {
							int mu1 = n - mu2 - mu0;
              int iMu = position2d (mu1, mu2); 


              double ITmu[nb_Array];
              for (int ell = 0; ell < nb_Array; ell++)
                ITmu[ell] = 0;

							double tmp = precomp[mu2][j] * precomp[(mp+1)+mu1][j] * (double) (binomialMat[mu2 + mu0][mu1]) * binomialMat[mu2][mu0] * Const;

              for (int ell = 0; ell < nb_Array; ell++)
                ITmu[ell] += H[ell] * tmp;

              for (int ell = 0; ell < nb_Array; ell++)
                Bmoment[iMu][ell] += ITmu[ell];

            }
        }
    }


  t1 = clock ();


#ifdef CHECK
	std::cout.precision(6);
  std::cout << "\nBmoments entries (PRECOMP method):\n";
  int iMu = 0;                  // check output

  for (int mu1 = n; mu1 >= 0; mu1--)
    {
      for (int mu2 = n - mu1; mu2 >= 0; mu2--, iMu++)
        {
					std::cout<<"Bmoment"<<"["<<mu1<<","<<mu2<<","<<n-mu1-mu2<<"]: ";
          for (int ell = 0; ell < nb_Array; ell++)
            std::cout << std::scientific <<Bmoment[iMu][ell] << "\t";
        std::cout<<"\n";
				}
    }
  std::cout << "\n";
#endif

  return ((double) (t1 - t0)) / CLOCKS_PER_SEC;


}


// initialize precomp entries
// n stands for the B-moment order
// q^2 quadrature points are used
// quadraWN contains Gauss-Jacobi quadrature weights and nodes
void init_precomp2d(double **precomp, int n, int q, int m, double **quadraWN)
{
	
	#ifdef GAUJAC
	double *legendre_x = quadraWN[1]; // legendre_x is pointer which points to the address quadraWN[1]
  double *legendre_w = quadraWN[0];
	
	double *jacobi_x = quadraWN[3];
	double *jacobi_w = quadraWN[2];
	
	#endif // end GAUJAC
	
	
	  for (int mu1 = 0; mu1 < n + 1; mu1++)
    {
			for (int j = 0; j < q ; j++)
        {
					#ifdef GAUJAC // use gaujac routine in GaussJacobi.cpp
					
					precomp[mu1][j] = sqrt (legendre_w[j+1]) * pow ((1 - legendre_x[j+1]) / 2, mu1); // indices start at 1 with GAUJAC
          precomp[(m+1) + mu1][j] = sqrt (legendre_w[j+1]) * pow ((1 + legendre_x[j+1]) / 2, mu1);
          precomp[2*(m+1) + mu1][j] = sqrt (jacobi_w[j+1]) * pow ((1 - jacobi_x[j+1]) / 2, n - mu1);
          precomp[3*(m+1)+ mu1][j] = sqrt (jacobi_w[j+1]) * pow ((1 + jacobi_x[j+1]) / 2, mu1);
					
					#else // use JacobiGaussNodes.h
					
					precomp[mu1][j] = sqrt (legendre[0][q - 2][j]) * pow ((1 - legendre[1][q - 2][j]) / 2, mu1);
          precomp[(m+1) + mu1][j] = sqrt (legendre[0][q - 2][j]) * pow ((1 + legendre[1][q - 2][j]) / 2, mu1);
          precomp[2*(m+1) + mu1][j] = sqrt (jacobi[0][q - 2][j]) * pow ((1 - jacobi[1][q - 2][j]) / 2, n - mu1);
          precomp[3*(m+1)+ mu1][j] = sqrt (jacobi[0][q - 2][j]) * pow ((1 + jacobi[1][q - 2][j]) / 2, mu1);
				
					#endif

        }
    }

}


// allocate memory to precomp array
double **
create_precomp2d(int len_precomp)
{
  double **precomp = new double *[4*len_precomp];
  double *precomp_array = new double [4*len_precomp * len_precomp];
  
  double *p = precomp_array;
  for (int i=0; i< 4*len_precomp; p += len_precomp, i++)
	precomp[i] = p;
  
  return precomp;
}





#else // not PRECOMP

//initialize Bmoment by the values of the function f at the quadrature points of order q
//f given as function in Cartesian coordinates, realised with (double)(*f) (double [2])
// q^2 is the number of quadrature points
// v1, v2, v3 are the element's vertices
// computed B-moments are stored into Bmoment array
// quadraWN contains Gauss-Jacobi quadrature weights and nodes
void
init_BmomentC_Bmom2d (double (*f) (double[2]), int q, double v1[2], double v2[2], double v3[2], 
			   double **Bmoment, double **quadraWN )
{

  double b1, b2, b3;
  int index_ij = 0;

  
  double scalingConst = 2 * Area2d(v1, v2, v3); // NEED this scaling constant, as result depends on Area2d(v1,v2,v3)


	for (int i = 0; i < q; i++)
    {
			b1 = quadraWN[1][i + 1]; // shift due to the fact that nodes indexing starts at 1

			for (int j = 0; j < q; j++)
        {
          double v[2];

					index_ij = position2d2 (i, j, q-1);
					
					b2 = quadraWN[3][j + 1] * (1 - b1);
          b3 = 1 - b1 - b2;

          bary2cart2d (b1, b2, b3, v1, v2, v3, v);        // stores b1*v1+b2*v2+b3*v3 into v;


					double functVal = (*f) (v);
					Bmoment[index_ij][0] = scalingConst * functVal;

        }
    }
}


//initialize Bmoment by the values of the function f at the quadrature points of order q
//f given as function in Cartesian coordinates, realised with (double)(*f) (double [2])
// q^2 is the number of quadrature points
// v1, v2, v3 are the element's vertices
// computed B-moments are stored into Bmoment array
// quadraWN contains Gauss-Jacobi quadrature weights and nodes
void
init_BmomentC_Mass2d (double (*f) (double[2]), int q, double v1[2], double v2[2], double v3[2], 
			   double **Bmoment, double **quadraWN )
{

  double b1, b2, b3;
  int index_ij = 0;

  
  double scalingConst = 2 * Area2d(v1, v2, v3); // Jacobian of Duffy transformation


	for (int i = 0; i < q; i++)
    {
			b1 = quadraWN[1][i + 1]; // shift due to the fact that nodes indexing starts at 1

			for (int j = 0; j < q; j++)
        {
          double v[2];

					index_ij = position2d2 (i, j, q-1); //in fact sequential access on this case>> maybe NOT anymore when q < n
					
					b2 = quadraWN[3][j + 1] * (1 - b1);
          b3 = 1 - b1 - b2;

          bary2cart2d (b1, b2, b3, v1, v2, v3, v);        // stores b1*v1+b2*v2+b3*v3 into v;

					double functVal = (*f) (v);
					Bmoment[index_ij][0] = scalingConst * functVal;
				 
        }
    }
}


//initialize Bmoment by the values of the function b at the quadrature points of order q
//b given as vector-valued function in Cartesian coordinates, realised with (void)(*b) (double [2], double[2] )
// q^2 is the number of quadrature points
// v1, v2, v3 are the element's vertices
// computed B-moments are stored into Bmoment array
// quadraWN contains Gauss-Jacobi quadrature weights and nodes
void
init_BmomentC_Convec2d ( void (*b) (double[2], double[2]) ,int q, double v1[2], double v2[2], double v3[2], 
			   double **Bmoment, double **quadraWN )
{

  double b1, b2, b3;
  int index_ij = 0;

  double vect[2];            // store intermediate matrix values
  
  double scalingConst = 2 * Area2d(v1, v2, v3); // Jacobian of Duffy transformation


	for (int i = 0; i < q; i++)
    {
			b1 = quadraWN[1][i + 1]; // shift due to the fact that nodes indexing starts at 1

			for (int j = 0; j < q; j++)
        {
          double v[2];

					index_ij = position2d2 (i, j, q-1); //in fact sequential access on this case>> maybe NOT anymore when q < n
					
					b2 = quadraWN[3][j + 1] * (1 - b1);
          b3 = 1 - b1 - b2;

          bary2cart2d (b1, b2, b3, v1, v2, v3, v);        // stores b1*v1+b2*v2+b3*v3 into v;


					(*b)(v, vect); // puts b(v) into vect
				
					Bmoment[index_ij][0] = scalingConst * vect[0];
					Bmoment[index_ij][1] = scalingConst * vect[1];

        }
    }
}


//initialize Bmoment by the values of the function C at the quadrature points of order q
//C given as (symmetric) matrix-valued function in Cartesian coordinates, realised with (void)(*C) (double [2], double[2][2] )
// q^2 is the number of quadrature points
// v1, v2, v3 are the element's vertices
// computed B-moments are stored into Bmoment array
// quadraWN contains Gauss-Jacobi quadrature weights and nodes
void
init_BmomentC_Stiff2d ( void (*C) (double[2], double[2][2]),int q, double v1[2], double v2[2], double v3[2], 
			   double **Bmoment, double **quadraWN )
{

  double b1, b2, b3;
  int index_ij = 0;

  double matC[2][2];            // store intermediate matrix values
  
  double scalingConst = 2 * Area2d(v1, v2, v3); // Jacobian of Duffy transformation


	for (int i = 0; i < q; i++)
    {
			b1 = quadraWN[1][i + 1]; // shift due to the fact that nodes indexing starts at 1

			for (int j = 0; j < q; j++)
        {
          double v[2];

					index_ij = position2d2 (i, j, q-1); //in fact sequential access on this case>> maybe NOT anymore when q < n
					
					b2 = quadraWN[3][j + 1] * (1 - b1);
          b3 = 1 - b1 - b2;

          bary2cart2d (b1, b2, b3, v1, v2, v3, v);        // stores b1*v1+b2*v2+b3*v3 into v;


					(*C) (v, matC);       // puts C(v) into matC

					Bmoment[index_ij][0] = scalingConst * matC[0][0];
					Bmoment[index_ij][1] = scalingConst * matC[0][1];
					Bmoment[index_ij][2] = scalingConst * matC[1][1];
				
        }
    }
}



//initialize Bmoment by the coefficients values at the q-Stroud nodes ;
//the matrix, vector or scalar coefficients values are stored in Cval array: 
// matrix C: 3 values C[0][0], C[0][1], C[1][1] (since C is symmetric)
// vector b: 2 values b[0], b[1]
// function f: 1 value f
// for each quadrature point, altogether 3*(q+1)^2 values;
//the order of points the same as in 'stroud_bary2d' 
// include extra parameter nb_Array (in order to allow various kinds of data (scalar,vector,or matrix-valued)
// WARNING: Cval needs to have the CORRECT size
// q^2 is the number of quadrature points
void
init_Bmoment2d_Cval (double *Cval, int q,double v1[2], double v2[2], double v3[2],
				   double **Bmoment, int nb_Array) 
                                                                                
{
	  
  double scalingConst = 2 * Area2d(v1, v2, v3); // Jacobian of Duffy transformation
  
  int index_ij = 0;
  double *val = Cval;

	for (int i = 0; i < q; i++)
	{
		for (int j = 0; j < q; j++)
		{
			for (int ell = 0; ell < nb_Array; ell++)
				Bmoment[index_ij][ell] = scalingConst * (*val++);

			index_ij++;
		}
	}
}




//compute B-moments of order n using q quadrature points in each direction
// q^2 is the number of quadrature points
// nb_Array determines the type of data with which the Bmoments are associated
// computed B-moments stored into Bmoment array
// quadraWN contains Gauss-Jacobi quadrature weights and nodes
double
Bmoment2d_Index (int n, int q, int nb_Array, double **Bmoment, double **BmomentInter, double **quadraWN)
{

  clock_t t0, t1;

  t0 = clock ();


	int m = MAX (n, q-1);           // m will be used for indexing
    

  //  initialize BmomentInter, at this point, array Bmoment has been initialized with function values
  for (int i = 0; i <= m; i++)
    {
      for (int j = 0; j <= m; j++)
        {
          int index_ij = position2d2 (i, j, m);

          for (int ell = 0; ell < nb_Array; ell++)
            BmomentInter[index_ij][ell] = 0;
        }
    }
    
    
  double xi, wgt, s, r, B;


  double fact[nb_Array];


  // convert first index

	for (int i = 0; i < q; i++)
    {  
			xi = quadraWN[1][i + 1];
      wgt = quadraWN[0][i + 1];   
	  
      s = 1 - xi;
      r = xi / (1 - xi);

      B = wgt * pow (s, n);
      for (int mu1 = 0; mu1 <= n; mu1++)
        {
					for (int j = 0; j < q; j++)
            {
              int index_mu1j = position2d2 (mu1, j, m);

							int index_ij = position2d2 (i, j, q-1);  // init_BmomentC uses this indexing

              for (int ell = 0; ell < nb_Array; ell++)
                {
                  fact[ell] = B * Bmoment[index_ij][ell];
									
                  BmomentInter[index_mu1j][ell] += fact[ell];
                }

            }
          B *= r * (n - mu1) / (1 + mu1);
        }
    }
    

  for (int mu1 = 0; mu1 <= n; mu1++)
    {
      for (int mu2 = 0; mu2 <= n - mu1; mu2++)
        {
          int index_mu1mu2 = position2d2 (mu1, mu2, m);

          for (int ell = 0; ell < nb_Array; ell++)
            Bmoment[index_mu1mu2][ell] = 0;

        }
    }


  // convert second index

	for (int j = 0; j < q; j++)
    {
			
			xi  = quadraWN[3][j + 1];
      wgt = quadraWN[2][j + 1];
	  
	  
      s = 1 - xi;
      r = xi / (1 - xi);

      for (int mu1 = 0; mu1 <= n; mu1++)
        {
          B = wgt * pow (s, n - mu1);
          for (int mu2 = 0; mu2 <= n - mu1; mu2++)
            {
              int index_mu1mu2 = position2d2 (mu1, mu2, m);
              int index_mu1j = position2d2 (mu1, j, m);

              for (int ell = 0; ell < nb_Array; ell++)
                {
                  fact[ell] = B * BmomentInter[index_mu1j][ell];
                  Bmoment[index_mu1mu2][ell] += fact[ell];
                }

              B *= r * (n - mu1 - mu2) / (1 + mu2);
            }
        }
    }
    


  t1 = clock ();



#ifdef CHECK
std::cout.precision(6);
  std::cout << "\nBmoments entries:\n";
  // check results...

  for (int mu1 = n; mu1 >= 0; mu1--)
    {
      for (int mu2 = n-mu1; mu2 >= 0; mu2--)
        {
          int iMu = position2d2 (mu1, mu2, m);
					
					std::cout<<"Bmoment"<<"["<<mu1<<","<<mu2<<","<<n-mu1-mu2<<"]: ";
          for (int ell = 0; ell < nb_Array; ell++)
            std::cout<<std::scientific<<Bmoment[iMu][ell] << "\t";
        std::cout<<"\n";
				}      
    }
  std::cout << "\n";
#endif



  return ((double) (t1 - t0)) / CLOCKS_PER_SEC;


}


#endif // end not PRECOMP


// create_matValNodes, delete_matValNodes  needed by non-PRECOMP H(curl) routines:

// free memory allocated to matValNodes
void delete_matValNodes(double **matValNodes)
{
  delete matValNodes[0];
  delete matValNodes;
}

// allocates memory to matValNodes
// matValNodes is used to store coefficients values at the quadrature nodes
double **
create_matValNodes2d(int len_matValNodes)
{
  double **matValNodes = new double *[len_matValNodes];
  double *matValNodes_array = new double[len_matValNodes * 3];  // by default: with Stiff, needs 3 independent entries

  double *p_matVal = matValNodes_array;
  for (int i = 0; i < len_matValNodes; i++, p_matVal += 3)
    matValNodes[i] = p_matVal;
  
  return matValNodes;
}



// computes Bmoments of order n into Bmoment array
// Bmoments associated with constant coefficients equal to 1
void
Bmoment2d_const (int n, double v1[2], double v2[2], double v3[2], double **binomialMat, double **Bmoment)
{
	
	int mm = ((n + 2) * (n + 1)) / 2;
	
	double Const =  Area2d (v1, v2, v3) / binomialMat[n][2];
	
	for (int mu = 0; mu < mm; mu++)
	{
		Bmoment[mu][0] = Const;
	}
	
	#ifdef CHECK
	std::cout.precision(6);
  std::cout << "\nBmoments entries (constant data):\n";
  int iMu = 0;                  // check results...

  for (int mu1 = n; mu1 >= 0; mu1--)
    {
      for (int mu2 = n - mu1; mu2 >= 0; mu2--, iMu++)
        {
					std::cout<<"Bmoment"<<"["<<mu1<<","<<mu2<<","<<n-mu1-mu2<<"]: ";
          std::cout << std::scientific <<Bmoment[iMu][0] << "\n";
				}
    }
  std::cout << "\n";
	#endif
    
}


/************************** Auxiliary routines ***********************/


// when non-PRECOMP is used, the Bmoment entries are stored
// using position2d2
int
position2d2 (int i, int j, int n)    // index (i,j) on the square {0,...,n}^2
{
  return i * (n + 1) + j;
}

//lexicographical position2d of eta=[eta1,eta2, .]
// the mass, convective and stiffness matrix entries are stored
// using "position2d"
int
position2d (int eta1, int eta2)
{

  return ((eta1 + eta2) * (eta1 + eta2 + 1)) / 2 + eta2;

}


// computes area of triangle < v1,v2,v3 >
double
Area2d (double v1[2], double v2[2], double v3[2]) 
{
  double x1 = v1[0];
  double y1 = v1[1];
  double x2 = v2[0];
  double y2 = v2[1];
  double x3 = v3[0];
  double y3 = v3[1];

  return (x2 * y3 - x1 * y3 - x3 * y2 + x1 * y2 + x3 * y1 - x2 * y1) / 2;
}


// multiply 2 X 2 matrix with 2 X 1 vector
void
matrixVectorMultiply2d (double Mat[2][2], double v[2], double matVectMult[2])     
{
  for (int j = 0; j < 2; j++)
    matVectMult[j] = 0;

  for (int i = 0; i < 2; i++)
    {
      for (int j = 0; j < 2; j++)
        matVectMult[i] += Mat[i][j] * v[j];
    }
}

// computes lexicographical position2d of mu+eta
int
position2d2 (int mu1, int mu2, int eta1, int eta2)       
{
  return ((mu1 + eta1 + mu2 + eta2 + 1) * (mu1 + eta1 + mu2 + eta2)) / 2 + mu2 + eta2;
}


// computes lexicographical position2d of mu+eta
int
position2d_sum (int mu12, int eta12)      
{
  return ((mu12 + eta12 + 1) * (mu12 + eta12)) / 2;
}

//computes lexicographical position2d of mu+eta+alfa+beta
int
position2d4 (int mu1, int mu2, int eta1, int eta2, int alfa1, int alfa2, int beta1, int beta2)   
{
  return ((mu1 + alfa1 + eta1 + beta1 + mu2 + alfa2 + eta2 + beta2 + 1) * (mu1 + alfa1 + eta1 + beta1 + mu2 + alfa2 + eta2 + beta2)) / 2 + mu2 + alfa2 + eta2 + beta2;
}




//convert barycentric coordinates (b1,b2,b3) of a point w.r.t. vertices v1,v2,v3 into Cartesian coordinates v
void
bary2cart2d (double b1, double b2, double b3, double v1[2], double v2[2], double v3[2], double v[2])
{
  v[0] = b1 * v1[0] + b2 * v2[0] + b3 * v3[0];
  v[1] = b1 * v1[1] + b2 * v2[1] + b3 * v3[1];
}


//initialisation of the arrays of quadrature knots and weights used by 'gaussJacobiUnit'
double **
create_quadraWN2d (int len_Quadra)
{
  double **quadraWN = new double *[4];
  double *quadraWN_array = new double[4 * len_Quadra];
	

  double *p_quadra = quadraWN_array;
  for (int i = 0; i < 4; p_quadra += len_Quadra, i++)
    {
      quadraWN[i] = p_quadra;
    }
  return quadraWN;
}


//Computes barycentric coordinates of triangle Stroud quadrature points for BB moments of degree m; 
//The array B contains barycentric coordinates in triples: b1,b2,b3, b1,b2,b3, ... 
//which corresponds to a matlab matrix with three rows (each for a bary. coordinate);
// There are q^2 points, hence the allocated size of B must be at least 3*q^2
void
stroud_bary2d (int q, double *B, double **quadraWN )
{	
	
	#ifdef PRECOMP
	#ifdef GAUJAC
	double *legendre_x = quadraWN[1]; // legendre_x points to the address quadraWN[1]	
	double *jacobi_x = quadraWN[3];	
	#endif // end GAUJAC
	#endif
	
  double b1, b2, b3;
  double *b = B;


	#ifdef PRECOMP
	
	for (int i = 0; i < q; i++)
	{
		for (int j = 0; j < q; j++)
		{

			#ifdef GAUJAC
			b3 = (1 - jacobi_x[i+1]) * (1 - legendre_x[j+1]) / 4; // indices start at 1 with GAUJAC
			b1 = (1 + jacobi_x[i+1]) / 2;
			b2 = (1 - jacobi_x[i+1]) * (1 + legendre_x[j+1]) / 4;
			#else
			b3 = (1 - jacobi[1][q - 2][i]) * (1 - legendre[1][q - 2][j]) / 4; 
			b1 = (1 + jacobi[1][q - 2][i]) / 2;
			b2 = (1 - jacobi[1][q - 2][i]) * (1 + legendre[1][q - 2][j]) / 4;
			#endif
			
			*b++ = b1;
			*b++ = b2;
			*b++ = b3;				
		}					
	}
	
	#else // not PRECOMP
	
  for (int i = 0; i < q; i++)
	{
		b1 = quadraWN[1][i+1]; // shift due to the fact that nodes indexing starts at 1

		for (int j = 0; j < q; j++)
		{
			*b++ = b1;
			*b++ = b2 = quadraWN[3][j + 1] * (1 - b1);
			
			b3 = 1 - b1 - b2;
			*b++ = b3;
		}
	}
    
  #endif // end non-PRECOMP
}

//like stroud_bary2d, but also returns the weights in the array W. The weights need to be multiplied
//by the area of the triangle. The allocated size of W must be at least q^2
//WARNING: need to check the weights again
void
stroud_bary2dw (int q, double *B, double *W, double **quadraWN)
{
  double b1, b2, b3;
  double *b = B;
  double *ww = W;


  for (int i = 0; i < q; i++)
    {
      b1 = quadraWN[1][i + 1]; // shift due to the fact that nodes indexing starts at 1

      for (int j = 0; j < q; j++)
        {
          *b++ = b1;
          *b++ = b2 = quadraWN[3][j + 1] * (1 - b1);
					b3 = 1 - b1 - b2;
					
          *b++ = b3;
          *ww++ = quadraWN[0][i + 1] * quadraWN[2][j + 1] * 2.0;      //0.5; Corrected against H1-paper

        }
    }
}


//Computes barycentric coordinates of triangle Stroud quadrature points for BB moments of degree m; 
//The array B contains barycentric coordinates in triples: b1,b2,b3, b1,b2,b3, ... 
//which corresponds to a matlab matrix with three rows (each for a bary. coordinate);
// There are q^2 points, hence the allocated size of B must be at least 3*q^2
void
stroud_nodes_bary2d (int q, double *B)
{	
	
	double **quadraWN;
	
	int len_Quadra = q+1;  // space required for storing Jacobi nodes of order q is q, BUT indexing starts at 1	
	quadraWN = create_quadraWN2d(len_Quadra);
	
	// initialize quadrature weights and nodes
	assign_quadra2d(q, quadraWN); 
	
	#ifdef PRECOMP
	#ifdef GAUJAC
	double *legendre_x = quadraWN[1]; // legendre_x is pointer which points to the address quadraWN[1]	
	double *jacobi_x = quadraWN[3];	
	#endif // end GAUJAC
	#endif
	
  double b1, b2, b3;
  double *b = B;


	#ifdef PRECOMP
	
	for (int i = 0; i < q; i++)
	{
		for (int j = 0; j < q; j++)
		{

			#ifdef GAUJAC
			b3 = (1 - jacobi_x[i+1]) * (1 - legendre_x[j+1]) / 4; // indices start at 1 with GAUJAC
			b1 = (1 + jacobi_x[i+1]) / 2;
			b2 = (1 - jacobi_x[i+1]) * (1 + legendre_x[j+1]) / 4;
			#else
			b3 = (1 - jacobi[1][q - 2][i]) * (1 - legendre[1][q - 2][j]) / 4; 
			b1 = (1 + jacobi[1][q - 2][i]) / 2;
			b2 = (1 - jacobi[1][q - 2][i]) * (1 + legendre[1][q - 2][j]) / 4;
			#endif
			
			*b++ = b1;
			*b++ = b2;
			*b++ = b3;				
		}					
	}
	
	#else // not PRECOMP
	
  for (int i = 0; i < q; i++)
	{
		b1 = quadraWN[1][i+1]; // shift due to the fact that nodes indexing starts at 1

		for (int j = 0; j < q; j++)
		{
			*b++ = b1;
			*b++ = b2 = quadraWN[3][j + 1] * (1 - b1);
			b3 = 1 - b1 - b2;
			*b++ = b3;
		}
	}
    
  #endif // end non-PRECOMP
  
  delete_quadraWN(quadraWN);
	

}

// routine which stores function values at Stroud nodes
// Stroud nodes' barycentric coordinates produced by stroud_bary2d
// barycentric coordinates stored in array B
// size of B is at least 3*q^2
// function values stored into Cval
// f is a scalar-valued function
void
scalar_values_at_Stroud2d(int q, double *Cval, double *B, double (*f)(double[2]),
												double v1[2], double v2[2], double v3[2] )
{
	
	double *bary = B;
	
	double b1, b2, b3;
	double v[2];
	
	for (int i=0; i<q; i++)
	{
		for (int j=0; j<q; j++)
		{
			b1 = *bary++;
			b2 = *bary++;
			b3 = *bary++; 
			
			bary2cart2d (b1, b2, b3, v1, v2, v3, v); // v is a Stroud node in Cartesian coordinates
			
			*Cval++ = (*f)(v);
			
		}
	}
	
}

// routine which stores function values at Stroud nodes
// Stroud nodes' barycentric coordinates produced by stroud_bary2d
// barycentric coordinates stored in array B
// size of B is at least 3*q^2
// function values stored into Cval
// b is a vector-valued function
void
vector_values_at_Stroud2d(int q, double *Cval, double *B, void (*b) (double[2], double[2]),
												double v1[2], double v2[2], double v3[2] )
{

	double *bary = B;
	
	double b1, b2, b3;
	double v[2];
	
	for (int i=0; i<q; i++)
	{
		for (int j=0; j<q; j++)
		{
			b1 = *bary++;
			b2 = *bary++;
			b3 = *bary++; /// check this...
			
			bary2cart2d (b1, b2, b3, v1, v2, v3, v); // v is a Stroud node in Cartesian coordinates
			
			double vect[2];
			(*b)(v,vect);
			
			*Cval++ =  vect[0];
			*Cval++ =  vect[1];
			
		}
	}

}

// routine which stores function values at Stroud nodes
// Stroud nodes' barycentric coordinates produced by stroud_bary2d
// barycentric coordinates stored in array B
// size of B is at least 3*q^2
// function values stored into Cval
// C is a matrix-valued function
void
matrix_values_at_Stroud2d(int q, double *Cval, double *B, void (*C) (double[2], double[2][2]),
												double v1[2], double v2[2], double v3[2] )
{

	double *bary = B;
	
	double b1, b2, b3;
	double v[2];
	
	for (int i=0; i<q; i++)
	{
		for (int j=0; j<q; j++)
		{
			b1 = *bary++;
			b2 = *bary++;
			b3 = *bary++;
			
			bary2cart2d (b1, b2, b3, v1, v2, v3, v); // v is a Stroud node in Cartesian coordinates
			
			double mat[2][2];
			(*C)(v,mat); // mat = C(v)
	
			*Cval++ =  mat[0][0];
			*Cval++ =  mat[0][1];
			*Cval++ =  mat[1][1]; // C is symmetric
			
		}
	}

}





// compute normals to the edges of triangle <v1,v2,v3>
void
normals2d (double v1[2], double v2[2], double v3[2], double normalMat[][2])       // stores normals to the edges into matrix N
{
  normalMat[0][0] = v2[1] - v3[1];
  normalMat[0][1] = v3[0] - v2[0];
  normalMat[1][0] = v3[1] - v1[1];
  normalMat[1][1] = v1[0] - v3[0];
  normalMat[2][0] = v1[1] - v2[1];
  normalMat[2][1] = v2[0] - v1[0];
}

// computes scalar product of v1 and v2
double
scalarProd2d (double v[2], double w[2])
{
  double Prod = 0;
  for (int i = 0; i < 2; i++)
    Prod += v[i] * w[i];
  return Prod;
}


// compute inner products of normals to the edges
void
scalarMatrix2d (double scalarMat[][3], double v1[2], double v2[2], double v3[2], double normalMat[][2])
{

  for (int i = 0; i < 3; i++)
    {
      for (int j = 0; j < 3; j++)
        scalarMat[i][j] = 0;
    }


  for (int alfa0 = 0; alfa0 <= 1; alfa0++)
    {
      for (int alfa1 = 0; alfa1 <= 1 - alfa0; alfa1++)
        {
          int alfa2 = 1 - alfa0 - alfa1;
          int iAlfa = position2d (alfa1, alfa2);
          double vAlfa[2] = { normalMat[iAlfa][0], normalMat[iAlfa][1] };
          for (int beta0 = 0; beta0 <= 1; beta0++)
            {
              for (int beta1 = 0; beta1 <= 1 - beta0; beta1++)
                {
                  int beta2 = 1 - beta0 - beta1;
                  int iBeta = position2d (beta1, beta2);
                  double vBeta[2] = { normalMat[iBeta][0], normalMat[iBeta][1] };

                  scalarMat[iAlfa][iBeta] += scalarProd2d (vAlfa, vBeta);
                }
            }
        }
    }

}

// Computes array containing n_i Coeff n_j, where n_i, n_j are
// the normals to the edges of the triangle <v1, v2, v3>
// Coeff[3] contains the entries of the constant (symmetric) coefficient matrix associated with the stiffness matrix
void
scalarMatrix2d_Coeff (double scalarMat[][3], double v1[2], double v2[2], double v3[2], double normalMat[][2], double Coeff[3])
{

  for (int i = 0; i < 3; i++)
    {
      for (int j = 0; j < 3; j++)
        scalarMat[i][j] = 0;
    }
    
  double Mat[2][2];

	Mat[0][0] = Coeff[0]; // Mat is used to build the symmetric coefficient matrix
	Mat[0][1] = Mat[1][0] = Coeff[1];
	Mat[1][1] = Coeff[2];



 for (int beta0 = 0; beta0 <= 1; beta0++)
		{
			for (int beta1 = 0; beta1 <= 1 - beta0; beta1++)
			{
				int beta2 = 1 - beta0 - beta1;
				int iBeta = position2d (beta1, beta2);
				double vBeta[2] = { normalMat[iBeta][0], normalMat[iBeta][1] };
				
				double matVectMult[2];
				matVectMult[0] = Mat[0][0] * vBeta[0] + Mat[0][1] * vBeta[1];
				matVectMult[1] = Mat[1][0] * vBeta[0] + Mat[1][1] * vBeta[1];
				
				for (int alfa0 = 0; alfa0 <= 1; alfa0++)
				{
					for (int alfa1 = 0; alfa1 <= 1 - alfa0; alfa1++)
					{
			
						int alfa2 = 1 - alfa0 - alfa1;
						int iAlfa = position2d (alfa1, alfa2);
						double vAlfa[2] = { normalMat[iAlfa][0], normalMat[iAlfa][1] };						

						scalarMat[iAlfa][iBeta] += scalarProd2d (vAlfa, matVectMult);
					}
				}
			}
    }

}


// computes array innerProdMat containing inner product of normals
// with vectCoeff
// vectCoeff contains the entries of the constant coefficient vector associated with the convective matrix
void
innerProd_Coeff2d (double normalMat[][2], double innerProdMat[3], double vectCoeff[2])
{

  for (int i = 0; i < 3; i++)
		innerProdMat[i] = 0;
    
	innerProdMat[0] = normalMat[0][0] * vectCoeff[0] + normalMat[0][1] * vectCoeff[1];  //beta=[1,0,0]
	innerProdMat[1] = normalMat[1][0] * vectCoeff[0] + normalMat[1][1] * vectCoeff[1]; // beta=[0,1,0]
	innerProdMat[2] = normalMat[2][0] * vectCoeff[0] + normalMat[2][1] * vectCoeff[1]; // beta=[0,0,1]
			 
}


// initialize pointers for the quadrature weights and nodes
void
assign_quadra2d(int q, double **quadraWN )
{
	
	#ifdef GAUJAC
	
	#else
	
	if (q>80)
	{
		std::cout<<"\nThe polynomial order is too large. Activate GAUJAC option.\n";
		exit (EXIT_FAILURE);
	}
	#endif
	
	#ifdef PRECOMP
	#ifdef GAUJAC
	
	double *legendre_x, *legendre_w;
	double *jacobi_x, *jacobi_w;
	
	legendre_x = quadraWN[1]; // legendre_x points to the address quadraWN[1], thus the effective MODIFICATION of quadraWN[1] entries
  legendre_w = quadraWN[0]; 
	gaujac (legendre_x, legendre_w, q, 0, 0);   // stores nodes and weights of Gauss-Jacobi rule on [-1;1] into x and w
				
	jacobi_x = quadraWN[3];
	jacobi_w = quadraWN[2];
	gaujac(jacobi_x, jacobi_w, q, 1, 0);
	
	#endif // end GAUJAC
	
	#else // not PRECOMP
  gaussJacobiUnit2D (q, quadraWN); // macro GAUJAC implemented in gaussJacobiUnit2D
  #endif
  
}

// compute length of Bmoments
// this depends on whether or not PRECOMP is used
// with non-PRECOMP, more memory is required,
// since entries are indexed as domain points of the square (as opposed to the triangle)
int
len_Moments2d(int n, int q)
{
	int mm, lenMoments; // used for indexing
	
	#ifdef PRECOMP
	mm = n; // for PRECOMP, lenMoments required is always determined by Bmoment order (and NOT quadrature rule used)
		  // because indexing INDEPENDENT of MAX(n,q-1)
  lenMoments = ((n + 2) * (n + 1)) / 2; 
  #else
	mm = MAX (n, q-1);              // mm will be used for indexing	
  lenMoments = (mm + 1) * (mm + 1);
  #endif
  
  return lenMoments;
}



// compute dimension of the elemental matrices
int 
len_Mat2d(int n)
{
	return ((n+1)*(n+2))/2;
}


// compute mass matrix of order n with constant coefficients equal to 1
// v1, v2, v3 are the element's vertices
// binomialMat contains binomial coefficients
// computed mass matrix entries are stored into massMat array
double
Mass2d_const (int n , double v1[2], double v2[2], double v3[2], double **binomialMat, 
						double **massMat)
{
  // initialization of massMat
  int lenMass = ((n + 1) * (n + 2)) / 2;

  for (int iEta = 0; iEta < lenMass; iEta++)
    {
      for (int iMu = 0; iMu < lenMass; iMu++)
        massMat[iEta][iMu] = 0;
    }


  clock_t t0, t1;
  double cpu_time_used;

  t0 = clock ();


  double Const = Area2d (v1, v2, v3) / binomialMat[n][n] / binomialMat[2 * n][2];

  //Using Pascal matrix: loops alternating mu and eta components 
  int iMu = 0;
  for (int mu0 = n; mu0 >= 0; mu0--)
    {
      int iEta = 0;
      for (int eta0 = n; eta0 >= 0; eta0--)
        {

          double v = Const * binomialMat[mu0][eta0];

          int mu2 = 0;
          for (int mu1 = n - mu0; mu1 >= 0; mu1--, mu2++, iMu++)
            {
						  
              int eta2 = 0;
              for (int eta1 = n - eta0; eta1 >= 0; eta1--, eta2++, iEta++)
                {
				  
                  double w = v * binomialMat[mu1][eta1] * binomialMat[mu2][eta2];
                  massMat[iMu][iEta] = w;

                }
              //return iEta to process the next mu1
              if (mu1 > 0)
                iEta -= eta2;   //iEta -= n - eta0 + 1; //iEta = iEta_temp; 
            }

          //return iMu to process the next eta0
          if (eta0 > 0)
            iMu -= mu2;         //iMu -= n - mu0 + 1; //iMu = iMu_temp; 
        }
    }


  t1 = clock ();

#ifdef CHECK

	std::cout<<"\nMass matrix entries:\n";
  iMu = 0;
  for (int mu0 = n; mu0 >= 0; mu0--)
    {
      int mu2 = 0;
      for (int mu1 = n - mu0; mu1 >= 0; mu1--, mu2++, iMu++)
        {
          int iEta = 0;
          for (int eta0 = n; eta0 >= 0; eta0--)
            {
              int eta2 = 0;
              for (int eta1 = n - eta0; eta1 >= 0; eta1--, eta2++, iEta++)
                {
                  printf ("%.6e\t", massMat[iMu][iEta]);
                }
            }
          std::cout << "\n";
        }
    }

#endif


  cpu_time_used = ((double) (t1 - t0)) / CLOCKS_PER_SEC;
  return cpu_time_used;
}

// high-level routine for computing mass matrix of order n with constant coefficients
// v1, v2, v3 are the element's vertices
// computed mass matrix entries are stored into massMat array
void
get_mass2d_const(double **massMat, int n, double v1[2], double v2[2], double v3[2])
{
	double **binomialMat; // store binomial coefficients
	int len_binomial = 2*n+2;
	binomialMat = create_BinomialMat(len_binomial);
	computeBinomials(binomialMat, len_binomial); //compute binomials
	
	// compute mass matrix with constant coefficient f0 = 1
	Mass2d_const (n , v1, v2, v3, binomialMat, massMat);
	
	delete_BinomialMat (binomialMat, len_binomial);
	
	
	#ifdef CHECK
	int len_Mass = len_Mat2d(n); // dimension of the elemental mass matrix
	std::cout<<"Mass matrix entries stored into array massMat of dimension "<<len_Mass<<"\n";
	#endif
}


// compute mass matrix of order n with variable coefficients
// q^2 is the number of quadrature points
// v1, v2, v3 are the element's vertices
// binomialMat stores binomial coefficients
// Bmoment contains B-moments associated with mass matrix coefficients
// quadraWN contains Gauss-Jacobi quadrature weights and nodes
// computed mass matrix stored into massMat array
#ifdef PRECOMP
// precomp contains precomputed arrays
// matValNodes contains coefficients values at the quadrature nodes
double
Mass2d (int n, int q, double v1[2], double v2[2], double v3[2], double **binomialMat, double **precomp,double **Bmoment,
double **massMat, double **matValNodes, double **quadraWN)
#else
// BmomentInter contains intermediate values required for the B-moments' computation
double
Mass2d (int n, int q, double v1[2], double v2[2], double v3[2], double **binomialMat, double **Bmoment, double **BmomentInter, double **massMat, double **quadraWN)
#endif
{	
	
  // initialization of massMat
  int lenMass = ((n + 1) * (n + 2)) / 2;

  for (int iEta = 0; iEta < lenMass; iEta++)
    {
      for (int iMu = 0; iMu < lenMass; iMu++)
        massMat[iEta][iMu] = 0;
    }


  clock_t t0, t1;
  double cpu_time_used;

  t0 = clock ();



  double Const = 1. / binomialMat[n][n];

	#ifdef PRECOMP
	;
	#else
	//WARNING: since q might be arbitrarily chosen, careful about indexing with non-PRECOMP:
	int M = MAX(2*n,q-1);
	#endif
		
  int nb_Array = 1;             // the required Bmoments are associated with a SCALAR function


#ifdef PRECOMP
	int mp = MAX(2*n,q-1);
	Bmoment2d (2 * n, q, mp, nb_Array, v1, v2, v3, binomialMat, precomp, Bmoment, matValNodes);
#else //not PRECOMP
  Bmoment2d_Index (2 * n, q, nb_Array, Bmoment, BmomentInter, quadraWN);
#endif // end not PRECOMP


  //Using Pascal matrix: loops alternating mu and eta components 
  int iMu = 0;
  for (int mu0 = n; mu0 >= 0; mu0--)
    {
      int iEta = 0;
      for (int eta0 = n; eta0 >= 0; eta0--)
        {


#ifdef PRECOMP
          int iMuEta0 = position2d_sum (n - mu0, n - eta0);       // n-mu0 = mu1+mu2, n-eta0 = eta1+eta2
#else // not PRECOMP
					int iMuEta0 = (mu0 + eta0) * (M + 1);     // the Bmoments are indexed w.r.t position2d2(. , MAX(2n,q-1) )
#endif

          double v = Const * binomialMat[mu0][eta0];

          int mu2 = 0;
          for (int mu1 = n - mu0; mu1 >= 0; mu1--, mu2++, iMu++)
            {
						  
              int eta2 = 0;
              for (int eta1 = n - eta0; eta1 >= 0; eta1--, eta2++, iEta++)
                {
				  
                  double w = v * binomialMat[mu1][eta1] * binomialMat[mu2][eta2];


                  int iMuEta;
#ifdef PRECOMP
                  iMuEta = iMuEta0 + mu2 + eta2;
#else // not PRECOMP
                  iMuEta = iMuEta0 + mu1 + eta1;
#endif // end not PRECOMP

                  massMat[iMu][iEta] = w * Bmoment[iMuEta][0];


                }
              if (mu1 > 0)
                iEta -= eta2;   //iEta -= n - eta0 + 1; //iEta = iEta_temp; 
            }

          if (eta0 > 0)
            iMu -= mu2;         //iMu -= n - mu0 + 1; //iMu = iMu_temp; 
        }
    }


  t1 = clock ();

#ifdef CHECK
	std::cout<<"\nMass matrix entries:\n";

  iMu = 0;
  for (int mu0 = n; mu0 >= 0; mu0--)
    {
      int mu2 = 0;
      for (int mu1 = n - mu0; mu1 >= 0; mu1--, mu2++, iMu++)
        {
          int iEta = 0;
          for (int eta0 = n; eta0 >= 0; eta0--)
            {
              int eta2 = 0;
              for (int eta1 = n - eta0; eta1 >= 0; eta1--, eta2++, iEta++)
                {
                  printf ("%.6e\t", massMat[iMu][iEta]);
                }
            }
          std::cout << "\n";
        }
    }

#endif


  cpu_time_used = ((double) (t1 - t0)) / CLOCKS_PER_SEC;
  return cpu_time_used;
}






//Stiffness matrix of order n with constant coefs ;
//The ordering of the domain points in the rows and columns of the stiffness
//matrix stiffMat is as follows:
//                                                    v1
//                                                    1
//                                                   2 3
//                                                  4 5 6
//                                                7 8 9 10
//                                               ..........
//                                             v2          v3
//
// v1, v2, v3 are the element's vertices
// binomialMat stores binomial coefficients
// scalarMat contains weighted inner products of normals to the element's edges
// cputime contains cpu timings
// computed stiffness matrix stored into stiffMat array
// Coeff stores the upper triangular entries of the (symmetric) coefficient associated
// with the stiffness matrix
double
Stiff2d_const (int n, double v1[2], double v2[2], double v3[2], double **binomialMat,
						 double scalarMat[][3], double cputime[3], double **stiffMat,
						 double Coeff[3])
{

  int Len = ((n + 2) * (n + 1)) / 2;


  // initialize stiffMat to the zero matrix
  for (int i = 0; i < Len; i++)
    {
      for (int j = 0; j < Len; j++)
        stiffMat[i][j] = 0.0;
    }


  double Const = n * n / 4. / Area2d (v1, v2, v3) / binomialMat[n - 1][n - 1] / binomialMat[2 * n - 2][2];        // this corresponds to the constant coefficient case 

  clock_t t0, t1, t2, t3;
  double cpu_time_used;

  t0 = clock ();

	//scale the alpha-beta matrix (factor out "Const")
  double scalarMat_scaled[3][3];

  for (int i = 0; i < 3; i++)
    for (int j = 0; j < 3; j++)
      scalarMat_scaled[i][j] = scalarMat[i][j] * Const;


  t1 = clock ();


  int m = n - 1;
	

  // the same loop as in Mass, but with m=n-1 instead of n, and with moving stencil
  // of position2ds in the stiffness matrix
  int iMu = 0;
  int iMu1 = 1;
  int iMu2 = 2;

  for (int mu0 = m; mu0 >= 0; mu0--, iMu1++, iMu2++)
    {
      int iEta = 0;
      int iEta1 = 1;
      int iEta2 = 2;

      for (int eta0 = m; eta0 >= 0; eta0--, iEta1++, iEta2++)
        {

          double v = binomialMat[mu0][eta0];    //to reduce the number of accesses to binomialMat, for 3D and higher
          //this way the number of multiplications may be reduced, too


          int mu2 = 0;          // mu1=m-mu0-mu2
          for (int mu1 = m - mu0; mu1 >= 0; mu1--, mu2++, iMu++, iMu1++, iMu2++)
            {

              int eta2 = 0;     // eta2=m-eta0
              for (int eta1 = m - eta0; eta1 >= 0; eta1--, eta2++, iEta++, iEta1++, iEta2++)
                {

                  double w = v * binomialMat[mu1][eta1] * binomialMat[mu2][eta2];       //use Pascal directly


                  stiffMat[iMu][iEta] += w * scalarMat_scaled[0][0];    //alfa=[1,0,0], beta=[1,0,0]
                  stiffMat[iMu][iEta1] += w * scalarMat_scaled[0][1];   //beta=[0,1,0]
                  stiffMat[iMu][iEta2] += w * scalarMat_scaled[0][2];   //beta=[0,0,1]


                  stiffMat[iMu1][iEta] += w * scalarMat_scaled[1][0];   //alfa=[0,1,0], beta=[1,0,0]
                  stiffMat[iMu1][iEta1] += w * scalarMat_scaled[1][1];  //beta=[0,1,0] 
                  stiffMat[iMu1][iEta2] += w * scalarMat_scaled[1][2];  //beta=[0,0,1]


                  stiffMat[iMu2][iEta] += w * scalarMat_scaled[2][0];   //alfa=[0,0,1], beta=[1,0,0]
                  stiffMat[iMu2][iEta1] += w * scalarMat_scaled[2][1];  //beta=[0,1,0]
                  stiffMat[iMu2][iEta2] += w * scalarMat_scaled[2][2];  //beta=[0,0,1]


                }

              if (mu1 > 0)      //return iEta, iEta1, iEta2 to process the next mu1
                {
                  iEta -= eta2; //iEta -= m - eta0 +1;
                  iEta1 -= eta2;
                  iEta2 -= eta2;
                }
            }


          if (eta0 > 0)         //return iMu, iMu1, iMu2 to process the next eta0
            {
              iMu -= mu2;       //iMu -= n - mu0 + 1; //iMu = iMu_temp; 
              iMu1 -= mu2;
              iMu2 -= mu2;
            }
        }
    }



  t2 = clock ();


	#ifdef CHECK
	std::cout<<"\nStiffness matrix entries:\n";

  iMu = 0;
  for (int mu0 = n; mu0 >= 0; mu0--)
    {
      int mu2 = 0;
      for (int mu1 = n - mu0; mu1 >= 0; mu1--, mu2++, iMu++)
        {
          int iEta = 0;
          for (int eta0 = n; eta0 >= 0; eta0--)
            {
              int eta2 = 0;
              for (int eta1 = n - eta0; eta1 >= 0; eta1--, eta2++, iEta++)
                {
                  printf ("% .4e  ", stiffMat[iMu][iEta]);
                }
            }
          std::cout << "\n";
        }
    }
  printf("\n");

	#endif


  t3 = clock ();




  cputime[0] = ((double) (t1 - t0)) / CLOCKS_PER_SEC;
  cputime[1] = ((double) (t2 - t1)) / CLOCKS_PER_SEC;
  cputime[2] = ((double) (t3 - t2)) / CLOCKS_PER_SEC;

  cpu_time_used = ((double) (t2 - t0)) / CLOCKS_PER_SEC;
  return cpu_time_used;

}


// high-level routine for stiffness matrix of order n with constant coefficients
// computed stiffness matrix stored into stiffMat array
// v1, v2, v3 are the element's vertices
// Coeff contains the upper-triangular entries of the (symmetric) matrix-valued
// coefficient associated with the stiffness matrix
void
get_stiffness2d_const (double **stiffMat, int n, double v1[2], double v2[2], double v3[2], 
								 double Coeff[3])
{
	double **binomialMat; // store binomial coefficients  
  double cputime[3]; // needed, since passed as argument in Stiff  
  double normalMat[3][2] = { {0, 0}, {0, 0}, {0, 0} };  // store normals to the edges
  double scalarMat[3][3];       // passed as argument in Stiff (used for constant case)    
	
	int len_binomial = 2*n+2;
	binomialMat = create_BinomialMat(len_binomial);
	
	// initialize auxilliary arrays
	computeBinomials(binomialMat, len_binomial); //compute binomials
	normals2d (v1, v2, v3, normalMat); // compute normals to the edges
	scalarMatrix2d_Coeff (scalarMat, v1, v2, v3, normalMat, Coeff); // compute inner products of normals
	
	// compute stiffness matrix with constant coefficient
	Stiff2d_const(n, v1, v2, v3, binomialMat, scalarMat, cputime, stiffMat, Coeff);
	
	delete_BinomialMat (binomialMat, len_binomial);
	
	
	#ifdef CHECK
	int len_Stiff = len_Mat2d(n); // dimension of the elemental stiffness matrix
	std::cout<<"Stiffness matrix entries stored into array stiffMat of dimension "<<len_Stiff<<"\n";
	#endif	
	
}


// compute convective matrix of order n associated with constant coefficients equal to vectCoeff
// v1, v2, v3 are the element's vertices
// binomialMat stores binomial coefficients
// normalMat contains normals to the edges of <v1,v2,v3>
// innerProdMat contains inner products of vectCoeff with normals
// computed convective matrix stored into convecMat array
// vectCoeff stores the constant vector-valued coefficients associated with the convective matrix
double
Convec2d_const (int n, double v1[2], double v2[2], double v3[2], double **binomialMat, 
							double normalMat[][2], double innerProdMat[3], double **convecMat,
							double vectCoeff[2])
{
  
  
  int Len = ((n + 2) * (n + 1)) / 2; // dimension of the convective matrix
  
  // initialize stiffMat to the zero matrix
  for (int i = 0; i < Len; i++)
    {
      for (int j = 0; j < Len; j++)
        convecMat[i][j] = 0.0;
    }
    
  double Const = - n / 2. / binomialMat[n][n - 1] / binomialMat[2 * n - 1][2];  // this corresponds to the constant coefficient case 
  
  clock_t t0, t1;
  t0 = clock ();
  
	
	// scale the normals (factor out "Const")
	double innerProdMat_scaled[3];
  for (int i = 0; i<3; i++)
		innerProdMat_scaled[i] = innerProdMat[i] * Const;
	
  
  int m = n-1; 
  
  
  int iMu = 0;
  int iMu1 = 1;
  int iMu2 = 2;
  
  for (int mu0 = n; mu0 >= 0; mu0--, iMu1++, iMu2++) // mu is a domain point of order n
    {
      int iEta = 0;
      int iEta1 = 1;
      int iEta2 = 2;

      for (int eta0 = m; eta0 >= 0; eta0--, iEta1++, iEta2++) // eta is a domain point of order n-1 (scattering approach for summation)
        {
		  		  
		  double v = binomialMat[mu0][eta0];    //to reduce the number of accesses to binomialMat, for 3D and higher
												//this way the number of multiplications may be reduced, too
          int mu2 = 0;          // mu1=n-mu0-mu2
          for (int mu1 = n - mu0; mu1 >= 0; mu1--, mu2++, iMu++, iMu1++, iMu2++)
		  {
			 int eta2 = 0;     // eta2=m-eta0
              for (int eta1 = m - eta0; eta1 >= 0; eta1--, eta2++, iEta++, iEta1++, iEta2++)
                {
                  double w = v * binomialMat[mu1][eta1] * binomialMat[mu2][eta2];       //use Pascal directly
                  

									convecMat[iEta] [iMu] += w * innerProdMat_scaled[0];   //beta=[1,0,0]
                  convecMat[iEta1][iMu] += w * innerProdMat_scaled[1];   //beta=[0,1,0]
                  convecMat[iEta2][iMu] += w * innerProdMat_scaled[2];   //beta=[0,0,1]
                  
                                    
				}
				
				if (mu1 > 0)      //return iEta, iEta1, iEta2 to process the next mu1
                {
                  iEta -= eta2; //iEta -= m - eta0 +1;
                  iEta1 -= eta2;
                  iEta2 -= eta2;
                }			
		  }
		
		  if (eta0 > 0)         //return iMu, iMu1, iMu2 to process the next eta0
            {
              iMu -= mu2;       //iMu -= n - mu0 + 1; //iMu = iMu_temp; 
              iMu1 -= mu2;
              iMu2 -= mu2;
            }
		  
		}
	}
	
  t1 = clock ();
	
  #ifdef CHECK
  std::cout<<"\nConvective matrix entries:\n";
  
  iMu = 0;
  for (int mu0 = n; mu0 >= 0; mu0--)
    {
      int mu2 = 0;
      for (int mu1 = n - mu0; mu1 >= 0; mu1--, mu2++, iMu++)
        {
          int iEta = 0;
          for (int eta0 = n; eta0 >= 0; eta0--)
            {
              int eta2 = 0;
              for (int eta1 = n - eta0; eta1 >= 0; eta1--, eta2++, iEta++)
                {
                  printf ("%.4e\t", convecMat[iMu][iEta]);
                }
            }
          std::cout << "\n";
        }
    }

  #endif
  
  double cpu_time_used = ((double) (t1 - t0)) / CLOCKS_PER_SEC;
  return cpu_time_used;
  
}



// high-level routine for convective matrix of order n associated with constant coefficients
// computed convective matrix stored into convecMat array
// v1, v2, v3 are the element's vertices
// vectCoeff contains the constant vector-valued coefficients associated with the convective matrix
void
get_convec2d_const (double **convecMat, int n, double v1[2], double v2[2], double v3[2],
									double vectCoeff[2])
{
	double **binomialMat; // store binomial coefficients  
  double normalMat[3][2] = { {0, 0}, {0, 0}, {0, 0} };  // store normals to the edges
  double innerProdMat[3]; // store inner products of vectCoeff with normals
  
  int len_binomial = 2*n+2;
	binomialMat = create_BinomialMat(len_binomial);
	
	// initialize auxilliary arrays
	computeBinomials(binomialMat, len_binomial); //compute binomials
	normals2d (v1, v2, v3, normalMat); // compute normals to the edges
	innerProd_Coeff2d (normalMat, innerProdMat, vectCoeff);
	
	// compute convective matrix with constant coefficient
	Convec2d_const (n, v1, v2, v3, binomialMat, normalMat, innerProdMat, convecMat, vectCoeff);
	
	delete_BinomialMat (binomialMat, len_binomial);
	
	
	#ifdef CHECK
	int len_Convec = len_Mat2d(n); // dimension of elemental convective matrix
	std::cout<<"Convective matrix entries stored into array convecMat of dimension "<<len_Convec<<"\n";
  #endif

}



// create two versions of transform_BmomentC, so that
// Convec, Stiff require no precompiler (of type CONVEC,....)

// computes inner product of vector-valued B-moments with normals
// n is the order of the finite element
// q is the number of quadrature points used in each direction
// Bmoment contains B-moments associated with vector-valued coefficients
// normalMat stores normals
// computed inner product are stored into Bmomentab array
void
transform_BmomentC_Convec2d (int n, int q, double **Bmoment, double **Bmomentab, double normalMat[][2])
{
  int m, mm;

  #ifdef PRECOMP
  

  m = 2 * n - 1;
	
  mm = ((m + 2) * (m + 1)) / 2; // with PRECOMP, required Bmoment size is determined by Bmoment order
  
  #else //not PRECOMP
  
	m = MAX (2 * n - 1, q-1);

  mm = (m + 1) * (m + 1); // with no storing algorithm, required Bmoment size is determined by MAX( Bmoment order, number of quadrature points )
  
  #endif


  for (int mu = 0; mu < mm; mu++)
    {
	  
			double Vec[2];
			Vec[0] = Bmoment[mu][0]; // Vec is used to store Bmoment[mu] entries
			Vec[1] = Bmoment[mu][1];
			
			Bmomentab[mu][0] = normalMat[0][0] * Vec[0] + normalMat[0][1] * Vec[1];  //beta=[1,0,0]
			Bmomentab[mu][1] = normalMat[1][0] * Vec[0] + normalMat[1][1] * Vec[1]; // beta=[0,1,0]
			Bmomentab[mu][2] = normalMat[2][0] * Vec[0] + normalMat[2][1] * Vec[1]; // beta=[0,0,1]
	  
		}


}


// routine used to pre-multiply normals with the Bmoments
// pre-multiply matrix-valued B-moments with normals
// n is the order of the finite element
// q is the number of quadrature points used in each direction
// Bmoment contains B-moments associated with matrix-valued coefficients
// normalMat stores normals
// computed inner product are stored into Bmomentab array
void
transform_BmomentC_Stiff2d (int n, int q, double **Bmoment, double **Bmomentab, double normalMat[][2])
{
  int m, mm;

  #ifdef PRECOMP
  
 
  m = 2 * n - 2;
 
  mm = ((m + 2) * (m + 1)) / 2; // with PRECOMP, required Bmoment size is determined by Bmoment order
  
  #else //not PRECOMP
  
  
	m = MAX (2 * n - 2, q-1); 
  
  mm = (m + 1) * (m + 1); // with no storing algorithm, required Bmoment size is determined by MAX( Bmoment order, number of quadrature points )
  
  #endif


  for (int mu = 0; mu < mm; mu++)
    {

      double Mat[2][2];

      Mat[0][0] = Bmoment[mu][0]; // Mat is used to store Bmoment[mu] entries
      Mat[0][1] = Mat[1][0] = Bmoment[mu][1];
      Mat[1][1] = Bmoment[mu][2];

      double matVectMult[2];

      matVectMult[0] = Mat[0][0] * normalMat[0][0] + Mat[0][1] * normalMat[0][1];
      matVectMult[1] = Mat[1][0] * normalMat[0][0] + Mat[1][1] * normalMat[0][1];


      Bmomentab[mu][0] = normalMat[0][0] * matVectMult[0] + normalMat[0][1] * matVectMult[1];   //alfa=[1,0,0], beta=[1,0,0]
      Bmomentab[mu][1] = normalMat[1][0] * matVectMult[0] + normalMat[1][1] * matVectMult[1];   //alfa=[0,1,0], beta=[1,0,0]
      Bmomentab[mu][2] = normalMat[2][0] * matVectMult[0] + normalMat[2][1] * matVectMult[1];   //alfa=[0,0,1], beta=[1,0,0]


      matVectMult[0] = Mat[0][0] * normalMat[1][0] + Mat[0][1] * normalMat[1][1];
      matVectMult[1] = Mat[1][0] * normalMat[1][0] + Mat[1][1] * normalMat[1][1];

      //Bmomentab[mu][1] = normalMat[0][0]*matVectMult[0] + normalMat[0][1]*matVectMult[1]; //alfa=[1,0,0], beta=[0,1,0] // redundancy
      Bmomentab[mu][3] = normalMat[1][0] * matVectMult[0] + normalMat[1][1] * matVectMult[1];   //alfa=[0,1,0], beta=[0,1,0]
      Bmomentab[mu][4] = normalMat[2][0] * matVectMult[0] + normalMat[2][1] * matVectMult[1];   //alfa=[0,0,1], beta=[0,1,0]


      matVectMult[0] = Mat[0][0] * normalMat[2][0] + Mat[0][1] * normalMat[2][1];
      matVectMult[1] = Mat[1][0] * normalMat[2][0] + Mat[1][1] * normalMat[2][1];


      //Bmomentab[mu][2] = normalMat[0][0]*matVectMult[0] + normalMat[0][1]*matVectMult[1]; //alfa=[1,0,0], beta=[0,0,1] // redundancy
      //Bmomentab[mu][4] = normalMat[1][0]*matVectMult[0] + normalMat[1][1]*matVectMult[1]; //alfa=[0,1,0], beta=[0,0,1]
      Bmomentab[mu][5] = normalMat[2][0] * matVectMult[0] + normalMat[2][1] * matVectMult[1];   //alfa=[0,0,1], beta=[0,0,1]

    }

}

 
// Convective matrix of order n associated with variable coefficients
// q^2 is the number of quadrature points
// v1, v2, v3 are the element's vertices
// binomialMat stores binomial coefficients
// normalMat stores normals to the edges of <v1,v2,v3>
// Bmoment array contains B-moments associated with convective matrix coefficients
// Bmomentab contains contains inner products of convective matrix coefficients with normals
// computed convective matrix stored into convecMat array
// quadraWN contains Gauss-Jacobi quadrature weights and nodes
#ifdef PRECOMP
// matValNodes stores coefficients values at the quadrature points
double
Convec2d (int n, int q, double v1[2], double v2[2], double v3[2], double **binomialMat, double normalMat[][2],
	   double **precomp, 
	   double **Bmoment, double **Bmomentab, double **convecMat, double **matValNodes,
	   double **quadraWN)
#else
// BmomentInter contains intermediate values required in the B-moments computation
double
Convec2d (int n, int q, double v1[2], double v2[2], double v3[2], double **binomialMat, double normalMat[][2],
	   double **Bmoment, double **BmomentInter, double **Bmomentab, double **convecMat,
	   double **quadraWN)
#endif
{
    
  int nb_Array = 2;             // the required B-moments are associated with a vector-valued function

  //WARNING: initialization of Bmoments entries must be done BEFORE calling Convec
  #ifdef PRECOMP                  // using the algorithm with precomputed arrays;
	int mp = MAX(2*n-1,q-1);
	Bmoment2d (2 * n - 1, q, mp, nb_Array, v1, v2, v3, binomialMat, precomp, Bmoment, matValNodes);       // the function C does not need to be in the arguments of BmomentC
  #else //not PRECOMP
  Bmoment2d_Index (2 * n - 1, q, nb_Array, Bmoment, BmomentInter, quadraWN); // using the no-storing algorithm
  #endif
  

  transform_BmomentC_Convec2d (n, q, Bmoment, Bmomentab, normalMat); 
	
  
  int Len = ((n + 2) * (n + 1)) / 2; // dimension of the convective matrix
  
  // initialize stiffMat to the zero matrix
  for (int i = 0; i < Len; i++)
    {
      for (int j = 0; j < Len; j++)
        convecMat[i][j] = 0.0;
    }
    
  
  clock_t t0, t1;
  t0 = clock ();
  

  double Const = - n / 2. / Area2d(v1, v2, v3) / binomialMat[n][n - 1]; // taking account of scaling between normals and gradients
  
  int m = n-1; 
  
	#ifdef PRECOMP
	;
	#else
  int M = MAX(2 * n - 1, q-1); // M is used for indexing with non-PRECOMP
																// when q chosen independently of n, careful with indexing
	#endif
  
  int iMu = 0;
  int iMu1 = 1;
  int iMu2 = 2;
  
  for (int mu0 = n; mu0 >= 0; mu0--, iMu1++, iMu2++) // mu is a domain point of order n
    {
      int iEta = 0;
      int iEta1 = 1;
      int iEta2 = 2;

      for (int eta0 = m; eta0 >= 0; eta0--, iEta1++, iEta2++) // eta is a domain point of order n-1 (scattering approach for summation)
        {
		  
		  #ifdef PRECOMP
          int iMuEta0 = position2d_sum (n - mu0, m - eta0);       // n-mu0=mu1+mu2, m-eta0=eta1+eta2
		  #else //not PRECOMP
          int iMuEta0 = (mu0 + eta0) * (M + 1);
		  #endif
		  
		  double v = binomialMat[mu0][eta0];    //to reduce the number of accesses to binomialMat, for 3D and higher
												//this way the number of multiplications may be reduced, too
          int mu2 = 0;          // mu1=n-mu0-mu2
          for (int mu1 = n - mu0; mu1 >= 0; mu1--, mu2++, iMu++, iMu1++, iMu2++)
		  {
			 int eta2 = 0;     // eta2=m-eta0
              for (int eta1 = m - eta0; eta1 >= 0; eta1--, eta2++, iEta++, iEta1++, iEta2++)
                {
                  double w = v * binomialMat[mu1][eta1] * binomialMat[mu2][eta2];       //use Pascal directly
                  
//                   #ifdef VARIABLE
                  w *= Const;
                  int iMuEta;

				  #ifdef PRECOMP
                  iMuEta = iMuEta0 + mu2 + eta2;        //position2d2 (mu1, mu2, eta1, eta2);
				  #else //not PRECOMP
                  iMuEta = iMuEta0 + mu1 + eta1;
				  #endif // end PRECOMP


                  convecMat[iEta] [iMu] += w * Bmomentab[iMuEta][0];     //beta=[1,0,0]
                  convecMat[iEta1][iMu] += w * Bmomentab[iMuEta][1];     //beta=[0,1,0]
                  convecMat[iEta2][iMu] += w * Bmomentab[iMuEta][2];     //beta=[0,0,1]
                                                      
				}
				
				if (mu1 > 0)      //return iEta, iEta1, iEta2 to process the next mu1
                {
                  iEta -= eta2; //iEta -= m - eta0 +1;
                  iEta1 -= eta2;
                  iEta2 -= eta2;
                }			
		  }
		
		  if (eta0 > 0)         //return iMu, iMu1, iMu2 to process the next eta0
            {
              iMu -= mu2;       //iMu -= n - mu0 + 1; //iMu = iMu_temp; 
              iMu1 -= mu2;
              iMu2 -= mu2;
            }
		  
		}
	}
	
  t1 = clock ();
	
  #ifdef CHECK
  std::cout<<"\nConvective matrix entries:\n";
  
  iMu = 0;
  for (int mu0 = n; mu0 >= 0; mu0--)
    {
      int mu2 = 0;
      for (int mu1 = n - mu0; mu1 >= 0; mu1--, mu2++, iMu++)
        {
          int iEta = 0;
          for (int eta0 = n; eta0 >= 0; eta0--)
            {
              int eta2 = 0;
              for (int eta1 = n - eta0; eta1 >= 0; eta1--, eta2++, iEta++)
                {
                  printf ("%.4e\t", convecMat[iMu][iEta]);
                }
            }
          std::cout << "\n";
        }
    }

  #endif
  
  double cpu_time_used = ((double) (t1 - t0)) / CLOCKS_PER_SEC;
  return cpu_time_used;
  
}




//Stiffness matrix of order n associated with variable coefs;
//if not PRECOMP, this routine is independent of C.
//The ordering of the domain points in the rows and columns of the stiffness
//matrix stiffMat is as follows:
//                                                    v1
//                                                    1
//                                                   2 3
//                                                  4 5 6
//                                                7 8 9 10
//                                               ..........
//                                             v2          v3
//
//WARNING: input quadraWN must be the the q-point quadrature
// v1, v2, v3 are the element's vertices
// binomialMat stores binomial coefficients
// scalarMat contains weighted inner products of normals to the element's edges
// cputime contains cpu timings
// Bmoment contains B-moments associated with stiffness matrix coefficients
// Bmomentab contains products of Bmoments with normals to the edges of <v1,v2,v3>
// computed stiffness matrix stored into stiffMat array
// quadraWN contains Gauss-Jacobi quadrature weights and nodes
#ifdef PRECOMP
// precomp contains precomputed arrays needed for computing B-moments associated with stiffness matrix coefficients
// matValNodes contains values of stiffness matrix coefficients at the quadrature points
double
Stiff2d (int n, int q, double v1[2], double v2[2], double v3[2], double **binomialMat, double scalarMat[][3], double normalMat[][2], double cputime[3],
	   double **precomp, 
	   double **Bmoment, double **Bmomentab, double **stiffMat, double **matValNodes,
	   double **quadraWN)
#else
// BmomentInter contains intermediate values needed in the computation of the B-moments associated with stiffness matrix coefficients
double
Stiff2d (int n, int q, double v1[2], double v2[2], double v3[2], double **binomialMat, double scalarMat[][3], double normalMat[][2], double cputime[3], 
	   double **Bmoment, double **BmomentInter, double **Bmomentab, double **stiffMat, double **quadraWN)
#endif
{
	
  int nb_Array = 3;             // since the required B-moments are associated with a symmetric 2 by 2 matrix-valued function C

//WARNING: initialization of Bmoments entries must be done BEFORE calling Stiff2d
#ifdef PRECOMP                  // using the algorithm with precomputed arrays;
	int mp = MAX(2*n-2,q-1);
	Bmoment2d (2 * n - 2, q, mp, nb_Array, v1, v2, v3, binomialMat, precomp, Bmoment, matValNodes);       // the function C does not need to be in the arguments of BmomentC
#else //not PRECOMP
  Bmoment2d_Index (2 * n - 2, q, nb_Array, Bmoment, BmomentInter, quadraWN); // using the no-storing algorithm
#endif


  transform_BmomentC_Stiff2d (n, q, Bmoment, Bmomentab, normalMat);


  int Len = ((n + 2) * (n + 1)) / 2;
  

  // initialize stiffMat to the zero matrix
  for (int i = 0; i < Len; i++)
    {
      for (int j = 0; j < Len; j++)
        stiffMat[i][j] = 0.0;
    }


  clock_t t0, t1, t2, t3;
  double cpu_time_used;

  t0 = clock ();


  t1 = clock ();


  double Const = n * n / 4. / Area2d (v1, v2, v3) / Area2d (v1, v2, v3) / binomialMat[n - 1][n - 1];       // taking account of scaling between normals and gradients



  int m = n - 1;
	
	#ifdef PRECOMP
	;
	#else
	int M = MAX(2*n-2,q-1); // with q independently chosen from n, careful with indexing
	#endif


  // the same loop as in Mass, but with m=n-1 instead of n, and with moving stencil
  // of position2ds in the stiffness matrix
  int iMu = 0;
  int iMu1 = 1;
  int iMu2 = 2;

  for (int mu0 = m; mu0 >= 0; mu0--, iMu1++, iMu2++)
    {
      int iEta = 0;
      int iEta1 = 1;
      int iEta2 = 2;

      for (int eta0 = m; eta0 >= 0; eta0--, iEta1++, iEta2++)
        {


#ifdef PRECOMP
          int iMuEta0 = position2d_sum (m - mu0, m - eta0);       // m-mu0=mu1+mu2, m-eta0=eta1+eta2
#else //not PRECOMP
          int iMuEta0 = (mu0 + eta0) * (M + 1);
#endif

          double v = binomialMat[mu0][eta0];    //to reduce the number of accesses to binomialMat, for 3D and higher
          //this way the number of multiplications may be reduced, too


          int mu2 = 0;          // mu1=m-mu0-mu2
          for (int mu1 = m - mu0; mu1 >= 0; mu1--, mu2++, iMu++, iMu1++, iMu2++)
            {

              int eta2 = 0;     // eta2=m-eta0
              for (int eta1 = m - eta0; eta1 >= 0; eta1--, eta2++, iEta++, iEta1++, iEta2++)
                {

                  double w = v * binomialMat[mu1][eta1] * binomialMat[mu2][eta2];       //use Pascal directly


                  w *= Const;
                  int iMuEta;

#ifdef PRECOMP
                  iMuEta = iMuEta0 + mu2 + eta2;        //position2d2 (mu1, mu2, eta1, eta2);
#else //not PRECOMP
                  iMuEta = iMuEta0 + mu1 + eta1;
#endif // end PRECOMP


                  stiffMat[iMu][iEta] += w * Bmomentab[iMuEta][0];      //alfa=[1,0,0], beta=[1,0,0]
                  stiffMat[iMu][iEta1] += w * Bmomentab[iMuEta][1];     //beta=[0,1,0]
                  stiffMat[iMu][iEta2] += w * Bmomentab[iMuEta][2];     //beta=[0,0,1]


                  stiffMat[iMu1][iEta] += w * Bmomentab[iMuEta][1];     //alfa=[0,1,0], beta=[1,0,0]
                  stiffMat[iMu1][iEta1] += w * Bmomentab[iMuEta][3];    //beta=[0,1,0] 
                  stiffMat[iMu1][iEta2] += w * Bmomentab[iMuEta][4];    //beta=[0,0,1]


                  stiffMat[iMu2][iEta] += w * Bmomentab[iMuEta][2];     //alfa=[0,0,1], beta=[1,0,0]
                  stiffMat[iMu2][iEta1] += w * Bmomentab[iMuEta][4];    //beta=[0,1,0]
                  stiffMat[iMu2][iEta2] += w * Bmomentab[iMuEta][5];    //beta=[0,0,1]


                }

              if (mu1 > 0)      //return iEta, iEta1, iEta2 to process the next mu1
                {
                  iEta -= eta2; //iEta -= m - eta0 +1;
                  iEta1 -= eta2;
                  iEta2 -= eta2;
                }
            }


          if (eta0 > 0)         //return iMu, iMu1, iMu2 to process the next eta0
            {
              iMu -= mu2;       //iMu -= n - mu0 + 1; //iMu = iMu_temp; 
              iMu1 -= mu2;
              iMu2 -= mu2;
            }
        }
    }



  t2 = clock ();



#ifdef CHECK
  printf("\nStiffness matrix entries:\n");
  iMu = 0;
  for (int mu0 = n; mu0 >= 0; mu0--)
    {
      int mu2 = 0;
      for (int mu1 = n - mu0; mu1 >= 0; mu1--, mu2++, iMu++)
        {
          int iEta = 0;
          for (int eta0 = n; eta0 >= 0; eta0--)
            {
              int eta2 = 0;
              for (int eta1 = n - eta0; eta1 >= 0; eta1--, eta2++, iEta++)
                {
                  printf ("% .4e  ", stiffMat[iMu][iEta]);
                }
            }
          std::cout << "\n";
        }
    }
  printf("\n");

#endif

#ifdef DEB
  // Debugging


  if (n == 20)
    {
      fprintf (stderr, "\n%1.16e\n", stiffMat[12][15]);
      fprintf (stderr, "-1.0830930185768896e-02 (degree 20) \n");
    }
  else if (n == 21)
    {
      fprintf (stderr, "\n%1.16e\n", stiffMat[12][15]);
      fprintf (stderr, "-1.0838699863090103e-02 (degree 21) \n");
    }


  if (n == 20)
    {
      fprintf (stderr, "\n%1.16e\n", stiffMat[Len - 3][Len - 11]);
      fprintf (stderr, "2.4480224702694113e-03 (degree 20)\n");
    }

  else if (n == 21)
    {
      fprintf (stderr, "\n%1.16e\n", stiffMat[Len - 3][Len - 11]);
      fprintf (stderr, "2.6240178306159473e-03 (degree 21)\n");
    }


#endif // endif DEB



  t3 = clock ();




  cputime[0] = ((double) (t1 - t0)) / CLOCKS_PER_SEC;
  cputime[1] = ((double) (t2 - t1)) / CLOCKS_PER_SEC;
  cputime[2] = ((double) (t3 - t2)) / CLOCKS_PER_SEC;

  cpu_time_used = ((double) (t2 - t0)) / CLOCKS_PER_SEC;
  return cpu_time_used;

}






//routines for initializing pointers used in the computation of the elemental quantities
// associated with variable data

// v1, v2, v3 are the element's vertices
// n is the order of the B-moments
// q^2 is the number of quadrature points
// nDash and m are some intermediate values
// nb_Array is used to specify that the coefficients are scalar-valued
// Cval stores coefficients values at the quadrature points
// quadraWN contains Gauss-Jacobi quadrature weights and nodes
// f is a scalar-valued function which produces the B-moments coefficients
// functval is a flag which indicates the input used for the B-moments coefficients
#ifdef PRECOMP
// precomp stores precomputed arrays used in the B-moments' computation
void
assign_pointers_Bmom2d (double v1[2], double v2[2], double v3[2], int n, int q, int nDash, int m, int nb_Array,
								double **matValNodes, double *Cval, double **quadraWN,
								double **precomp, double (*f) (double[2]), int functval)
#else
void
assign_pointers_Bmom2d (double v1[2], double v2[2], double v3[2], int n, int q, int nDash, int m, int nb_Array,
								double *Cval, double **quadraWN,
								double **Bmoment, double (*f) (double[2]), int functval)
#endif
{
	
	// initialize quadrature weights and nodes
	assign_quadra2d(q, quadraWN);
	  
   
  #ifdef PRECOMP  

  // using function values as input
	if (functval == 1)
		data_at_Nodes_Cval2d (matValNodes, q, Cval, nb_Array);
  
	// by default: using function definition as input
	else
		data_at_Nodes_Bmom2d (f, matValNodes, q, quadraWN, v1, v2, v3); 																																							
  
	init_precomp2d(precomp, nDash, q, m, quadraWN);

  #else //not PRECOMP

	// using function values as input
  if (functval == 1)
		init_Bmoment2d_Cval (Cval, q, v1, v2, v3, Bmoment, nb_Array);
	
  // by default: using function definition as input
  else
		init_BmomentC_Bmom2d (f, q, v1, v2, v3, Bmoment, quadraWN);
	

  #endif // end not PRECOMP
  
}



// v1, v2, v3 are the element's vertices
// n is the order of the B-moments
// q^2 is the number of quadrature points
// nDash and m are some intermediate values
// nb_Array is used to specify that the coefficients are scalar-valued
// Cval stores coefficients values at the quadrature points
// quadraWN contains Gauss-Jacobi quadrature weights and nodes
// f is a scalar-valued function which produces the mass matrix coefficients
// functval is a flag which indicates the input used for the mass matrix coefficients
#ifdef PRECOMP
// precomp stores precomputed arrays used in the computation of the B-moments associated with the mass matrix coefficients
void
assign_pointers_Mass2d (double v1[2], double v2[2], double v3[2], int n, int q, int nDash, 
											int m, int nb_Array, double **matValNodes, double *Cval, double **quadraWN, double **precomp, double (*f) (double[2]), int functval)
#else
void
assign_pointers_Mass2d (double v1[2], double v2[2], double v3[2], int n, int q, int nDash, 
											int m, int nb_Array, double *Cval, double **quadraWN, double **Bmoment, double (*f) (double[2]), int functval)
#endif
{
	  
	// initialize quadrature weights and nodes
	assign_quadra2d(q, quadraWN);    
   
  #ifdef PRECOMP
  
  // using function values as input
	if (functval == 1)
		data_at_Nodes_Cval2d (matValNodes, q, Cval, nb_Array);
  
	// by default: using function definition as input
	else
		// pre-computes values of f at quadrature nodes of degree q 
		data_at_Nodes_Mass2d (f, matValNodes, q, quadraWN, v1, v2, v3);																																								

	init_precomp2d(precomp, nDash, q, m, quadraWN);

  #else //not PRECOMP

  // using function values as input
  if (functval == 1)
		init_Bmoment2d_Cval (Cval, q, v1, v2, v3, Bmoment, nb_Array);
	
  // by default: using function definition as input
  else
		init_BmomentC_Mass2d (f, q, v1, v2, v3, Bmoment, quadraWN);

  #endif // end not PRECOMP
  
}



// v1, v2, v3 are the element's vertices
// n is the order of the B-moments
// q^2 is the number of quadrature points
// nDash and m are some intermediate values
// nb_Array is used to specify that the coefficients are vector-valued
// Cval stores coefficients values at the quadrature points
// quadraWN contains Gauss-Jacobi quadrature weights and nodes
// b is a vector-valued function which produces the convective matrix coefficients
// functval is a flag which indicates the input used for the convective matrix coefficients
#ifdef PRECOMP
// precomp stores precomputed arrays used in the computation of the B-moments associated with the convective matrix coefficients
void
assign_pointers_Convec2d (double v1[2], double v2[2], double v3[2], int n, int q, int nDash, int m, int nb_Array,
								double **matValNodes, double *Cval, double **quadraWN,
								double **precomp,
								void (*b) (double[2], double[2]), int functval)
#else
void
assign_pointers_Convec2d (double v1[2], double v2[2], double v3[2], int n, int q, int nDash, int m, int nb_Array,
								double *Cval, double **quadraWN,
								double **Bmoment,
								void (*b) (double[2], double[2]), int functval)
#endif
{
	   
	// initialize quadrature weights and nodes
	assign_quadra2d(q, quadraWN);
  
   
  #ifdef PRECOMP  


  // using function values as input
  if (functval == 1)
		data_at_Nodes_Cval2d (matValNodes, q, Cval, nb_Array);
  
	// by default: using function definition as input
	else
		// pre-computes values of b at quadrature nodes of degree q 
		data_at_Nodes_Convec2d (b, matValNodes, q, quadraWN, v1, v2, v3);																																						 
 
	init_precomp2d(precomp, nDash, q, m, quadraWN);

  #else //not PRECOMP

  // using function values as input
  if (functval==1)
		init_Bmoment2d_Cval (Cval, q, v1, v2, v3, Bmoment, nb_Array);
	
  // by default: using function definition as input
  else
		init_BmomentC_Convec2d (b, q, v1, v2, v3, Bmoment, quadraWN);
  

  #endif // end not PRECOMP
  
}



// v1, v2, v3 are the element's vertices
// n is the order of the B-moments
// q^2 is the number of quadrature points
// nDash and m are some intermediate values
// nb_Array is used to specify that the coefficients are matrix-valued
// Cval stores coefficients values at the quadrature points
// quadraWN contains Gauss-Jacobi quadrature weights and nodes
// b is a vector-valued function which produces the stiffness matrix coefficients
// functval is a flag which indicates the input used for the stiffness matrix coefficients
#ifdef PRECOMP
// precomp stores precomputed arrays used in the computation of the B-moments associated with the stiffness matrix coefficients
void
assign_pointers_Stiff2d (double v1[2], double v2[2], double v3[2], int n, int q, int nDash, 
											 int m, int nb_Array, double **matValNodes, double *Cval, 
											 double **quadraWN, double **precomp,
											 void (*C) (double[2], double[2][2]),
											 int functval)
#else
void
assign_pointers_Stiff2d (double v1[2], double v2[2], double v3[2], int n, int q, int nDash, 
											 int m, int nb_Array, double *Cval, 
											 double **quadraWN, double **Bmoment,
											 void (*C) (double[2], double[2][2]),
											 int functval)
#endif
{
	  
	// initialize quadrature weights and nodes
	assign_quadra2d(q, quadraWN);
	  
   
  #ifdef PRECOMP  

  // using function values as input
	if (functval==1)
		data_at_Nodes_Cval2d (matValNodes, q, Cval, nb_Array);
	// by default: using function definition as input
	else
		// pre-computes values of entries of C at quadrature nodes of degree q    
		data_at_Nodes_Stiff2d (C, matValNodes, q, quadraWN, v1, v2, v3);    
  
	init_precomp2d(precomp, nDash, q, m, quadraWN);

  #else //not PRECOMP

  // using function values as input
	if (functval==1)
		init_Bmoment2d_Cval (Cval, q, v1, v2, v3, Bmoment, nb_Array);
	
  // by default: using function definition as input
  else
		// important initialization of the Bmoments, otherwise get zero entries for the stiffness matrix
		init_BmomentC_Stiff2d (C, q, v1, v2, v3, Bmoment, quadraWN); 

  #endif // end not PRECOMP
  
}

// compute Bmoment of order n associated with constant coefficients 1
// Bmoment is an array of length ((n + 2) * (n + 1)) / 2
// v1, v2, v3 are the element's vertices
void
get_Bmoments2d_const (double **Bmoment, int n, double v1[2], double v2[2], double v3[2])
{
	double **binomialMat;
	
	int len_binomial = 2*n+2;
  binomialMat = create_BinomialMat(len_binomial); // store binomial coefficients
  computeBinomials(binomialMat, len_binomial); //compute binomials
	
	Bmoment2d_const (n, v1, v2, v3, binomialMat, Bmoment); // compute B-moments
	
	delete_BinomialMat (binomialMat, len_binomial); // free allocated memory
	
	#ifdef CHECK
	int lenMoments = ((n+2)*(n+1)) / 2;
  std::cout<<"B-moment entries stored into array Bmoment of length "<<lenMoments<<"\n";
  #endif
}



// compute Bmoment of order n associated with function f
// Bmoment is an array of length ((n + 2) * (n + 1)) / 2 with PRECOMP and (n + 1)^2 with non-PRECOMP
// f is a scalar-valued function which produces the B-moments coefficients
// Cval stores the coefficients values at the quadrature points
// v1, v2, v3 are the element's vertices
// functval allows the option to use array of function values at quadrature nodes as input for the B-moments coefficients
void
get_Bmoments2d(double **Bmoment, int n, double (*f)(double[2]), double *Cval, double v1[2], double v2[2], double v3[2], int functval)
{
	
	#ifdef PRECOMP
	double **binomialMat; // needed by assign_pointers routine
	double **precomp;
	double **matValNodes;
	#else
	double **BmomentInter;
	#endif
	
	double **quadraWN;

	#ifdef PRECOMP
  int len_binomial = 2*n+2;
  binomialMat = create_BinomialMat(len_binomial); // store binomial coefficients
  computeBinomials(binomialMat, len_binomial); //compute binomials
  #endif
  
  
  // initialize number of quadrature pointers, and integers needed for indexing Bmoment entries
  int q = n+1; // for the B-moments, the number of quadrature points is n+1 by default
  int nDash = n; // nDash stands for the Bmoment order
  int m = MAX(n,q-1); // in case value of q is increased,
											// m is used to create sufficiently large precomp
  
  int nb_Array = 1;
   
  //allocates memory to quadraWN
	int len_Quadra = (q + 1);     // space required for storing Jacobi nodes of order q is q, BUT indexing starts at 1
  quadraWN = create_quadraWN2d(len_Quadra); // store quadrature weights and nodes of a fixed degree (no-storing algorithm)
	
	
	#ifdef PRECOMP
  //allocates memory to MatValNodes
	int len_matValNodes = q * q ;      // space required for 2D array with dimension q
  matValNodes = create_matValNodes2d(len_matValNodes);
	precomp = create_precomp2d(m+1); // store precomputed arrays 
	#else
	int lenMoments = len_Moments2d(n, q);
	BmomentInter = create_Bmoment(lenMoments, nb_Array);
	#endif
	
	//assign values to auxilliary arrays

	#ifdef PRECOMP 
	assign_pointers_Bmom2d (v1, v2, v3, n, q, nDash, m, nb_Array,matValNodes, Cval, quadraWN, precomp, f, functval); 
	#else
	assign_pointers_Bmom2d (v1, v2, v3, n, q, nDash, m, nb_Array, Cval, quadraWN, Bmoment, f, functval); 
	#endif
	
									
	// store Bmoments into array Bmoment
  #ifdef PRECOMP 
	Bmoment2d (n, q, m, nb_Array, v1, v2, v3, binomialMat, precomp, Bmoment, matValNodes); 
  #else
  Bmoment2d_Index (n, q, nb_Array, Bmoment, BmomentInter, quadraWN);
  #endif
	
	#ifdef PRECOMP
	delete_pointers_Bmom(precomp,
																matValNodes, quadraWN);
	#else
	delete_pointers_Bmom(BmomentInter,
																quadraWN);
	#endif
	
  #ifdef PRECOMP
  delete_BinomialMat (binomialMat, len_binomial);
  #endif
  
  #ifdef CHECK
  #ifdef PRECOMP
  int lenMoments = len_Moments2d(n, q);
  #endif
  std::cout<<"B-moment entries stored into array Bmoment of length "<<lenMoments<<"\n";
  #endif
  
	
}



// compute mass matrix associated with function f
// the output matrix is of dimention ((n+1)*(n+2))/2
// f is a scalar-valued function which produces the mass matrix coefficients
// Cval stores the coefficients values at the quadrature points
// v1, v2, v3 are the element's vertices
// functval allows the option to use array of function values at quadrature nodes as input for the mass matrix coefficients
void
get_mass2d(double **massMat, int n, double (*f)(double[2]), double *Cval, double v1[2], double v2[2], double v3[2], int functval)
{
	
  double **binomialMat; // store binomial coefficients
  
  #ifdef PRECOMP
  double **precomp;
	double **matValNodes;
  #else
  double **BmomentInter;
  #endif
  
 
  double **Bmoment;   

  double **quadraWN;	// store quadrature weights and nodes of a fixed degree
	
	int len_binomial = 2*n+2;
	binomialMat = create_BinomialMat(len_binomial);
	
	// initialize number of quadrature pointers, and integers needed for indexing Bmoment entries
  int q = n+1;                    // the number of quadrature points is n+1  
  int nDash = 2 * n;            // the Bmoment order required for the mass matrix is 2n
  int m = MAX(nDash,q-1);                //m = MAX(nDash, q-1); 
																// m is used for indexing only with non-PRECOMP
																// BUT m also needed with PRECOMP for allowing sufficient size to pointer "precomp"
  int nb_Array = 1;             // the Bmoment required is associated with a SCALAR function
  
	int len_Quadra = (q + 1);     // space required for storing Jacobi nodes of order q is q, BUT indexing starts at 1	
  quadraWN = create_quadraWN2d(len_Quadra);
	
	
	// initialize auxilliary arrays
	computeBinomials(binomialMat, len_binomial); //compute binomials
		
	int mm, lenMoments;
  
  #ifdef PRECOMP
  mm = nDash;  // for PRECOMP, lenMoments required is always determined by Bmoment order (and NOT quadrature rule used)
  lenMoments = ((mm + 2) * (mm + 1)) / 2;
  #else
	mm = MAX (nDash, q-1);          // mm will be used for indexing	
  lenMoments = (mm + 1) * (mm + 1);
  #endif
  
  Bmoment = create_Bmoment(lenMoments, nb_Array);
 
	
	#ifdef PRECOMP
	int len_matValNodes = q * q ;      // space required for 2D array with dimension q	
  matValNodes = create_matValNodes2d(len_matValNodes);
	precomp = create_precomp2d(m+1); // store precomputed arrays
	#else
	BmomentInter = create_Bmoment(lenMoments, nb_Array);
	#endif
	
	
	//assign values to auxilliary arrays
	#ifdef PRECOMP
	assign_pointers_Mass2d (v1, v2, v3, n, q, nDash, m, nb_Array,matValNodes, Cval, quadraWN, precomp, f, functval); 
	#else
	assign_pointers_Mass2d (v1, v2, v3, n, q, nDash, m, nb_Array, Cval, quadraWN, Bmoment, f, functval);
	#endif
									
	// store mass matrix entries into array massMat
	#ifdef PRECOMP
	Mass2d (n, q, v1, v2, v3, binomialMat, precomp, Bmoment, massMat, matValNodes, quadraWN);
	#else
	Mass2d (n, q, v1, v2, v3, binomialMat, Bmoment, BmomentInter, massMat, quadraWN);
	#endif
	
	
	#ifdef PRECOMP
	delete_pointers_Mass(precomp, Bmoment, matValNodes, quadraWN);
	#else
	delete_pointers_Mass(Bmoment, BmomentInter, quadraWN);
	#endif
	
  delete_BinomialMat (binomialMat, len_binomial);
	
	
	#ifdef CHECK
	int len_Mass = len_Mat2d(n); // dimension of the elemental mass matrix
	std::cout<<"Mass matrix entries stored into array massMat of dimension "<<len_Mass<<"\n";
	#endif

	
}



// compute convective matrix associated with vector-valued function b
// the output matrix is of dimention ((n+1)*(n+2))/2
// b is a vector-valued function which produces the convective matrix coefficients
// Cval stores the coefficients values at the quadrature points
// v1, v2, v3 are the element's vertices
// functval allows the option to use array of function values at quadrature nodes as input for the convective matrix coefficients
void
get_convec2d(double **convecMat, int n, void (*b) (double[2], double[2]), double *Cval, double v1[2], double v2[2], double v3[2], int functval)
{

  double **binomialMat; // store binomial coefficients  
  double normalMat[3][2] = { {0, 0}, {0, 0}, {0, 0} };  // store normals to the edges
  
  #ifdef PRECOMP
  double **precomp;
	double **matValNodes; 
  #else
  double **BmomentInter;
  #endif
  
 
  double **Bmoment, **Bmomentab; // need to be created, since passed as arguments into Convec
  
  double **quadraWN;
	
	int len_binomial = 2*n+2;
	binomialMat = create_BinomialMat(len_binomial);
	
	// initialize number of quadrature pointers, and integers needed for indexing Bmoment entries
	int q = n+1;                    // the number of quadrature points is n+1  
  int nDash = 2 * n - 1;        // the Bmoment order required for the convective matrix is 2n-1
	int m = MAX (nDash, q-1);       // m is used for indexing: only use MAX(nDash,q-1) for indexing with no storing algorithm
																// BUT m also needed with PRECOMP for allowing sufficient size to pointer "precomp"

  int nb_Array = 2;             //Convec needs Bmoment associated with vector-valued function
    
  int len_Quadra = (q + 1);     // space required for storing Jacobi nodes of order q is q, BUT indexing starts at 1
	
	// allocates memory to quadraWN
  quadraWN = create_quadraWN2d(len_Quadra);
	
	// initialize auxilliary arrays
	computeBinomials(binomialMat, len_binomial); //compute binomials
	normals2d (v1, v2, v3, normalMat); // compute normals to the edges
	
	int mm, lenMoments;
  
  #ifdef PRECOMP
  mm = nDash;  // for PRECOMP, lenMoments required is always determined by Bmoment order (and NOT quadrature rule used)
								// because indexing INDEPENDENT of MAX(n,q-1)
  lenMoments = ((mm + 2) * (mm + 1)) / 2;
  #else
	mm = MAX (nDash, q-1);          // m will be used for indexing
  lenMoments = (mm + 1) * (mm + 1);
  #endif
  
  Bmoment = create_Bmoment(lenMoments, nb_Array);
  Bmomentab = create_Bmoment(lenMoments, 3); // Bmomentab contains inner products of normals with Bmoments
	
	#ifdef PRECOMP
	int len_matValNodes = q * q ;      // space required for 2D array with dimension q		
  matValNodes = create_matValNodes2d(len_matValNodes);
	precomp = create_precomp2d(m+1); // store precomputed arrays
	#else
	BmomentInter = create_Bmoment(lenMoments, nb_Array);
	#endif
	
	
	//assign values to auxilliary arrays
	#ifdef PRECOMP
	assign_pointers_Convec2d (v1, v2, v3, n, q, nDash, m, nb_Array,matValNodes, Cval, quadraWN, precomp, b, functval);
	#else
	assign_pointers_Convec2d (v1, v2, v3, n, q, nDash, m, nb_Array, Cval, quadraWN, Bmoment, b, functval);
	#endif
									
	// store convective matrix entries into array convecMat
	#ifdef PRECOMP
	Convec2d (n, q, v1, v2, v3, binomialMat, normalMat, precomp,
		 Bmoment, Bmomentab, convecMat, matValNodes, quadraWN);
	#else
	Convec2d (n, q, v1, v2, v3, binomialMat, normalMat,
		 Bmoment, BmomentInter, Bmomentab, convecMat, quadraWN);
	#endif
		 
	
	#ifdef PRECOMP
	delete_pointers(precomp, Bmoment, Bmomentab, matValNodes, quadraWN);
	#else
	delete_pointers(Bmoment, BmomentInter, Bmomentab, quadraWN);
	#endif
	
  delete_BinomialMat (binomialMat, len_binomial);
	
	
	#ifdef CHECK
	int len_Convec = len_Mat2d(n); // dimension of elemental convective matrix
	std::cout<<"Convective matrix entries stored into array convecMat of dimension "<<len_Convec<<"\n";
	#endif
	
}


// compute stiffness matrix associated with matrix-valued function C
// the output matrix is of dimention ((n+1)*(n+2))/2
// the output matrix is of dimention ((n+1)*(n+2))/2
// C is a vector-valued function which produces the stiffness matrix coefficients
// Cval stores the coefficients values at the quadrature points
// v1, v2, v3 are the element's vertices
// functval allows the option to use array of function values at quadrature nodes as input for the stiffness matrix coefficients
void
get_stiffness2d(double **stiffMat, int n, void (*C) (double [2], double [2][2]), double *Cval, double v1[2], double v2[2], double v3[2], int functval)
{

	
  double **binomialMat; // store binomial coefficients  
  double cputime[3]; // needed, since passed as argument in Stiff  
  double normalMat[3][2] = { {0, 0}, {0, 0}, {0, 0} };  // store normals to the edges
  double scalarMat[3][3];       // passed as argument in Stiff (used for constant case)    

	
	int len_binomial = 2*n+2;
	binomialMat = create_BinomialMat(len_binomial);
	
	#ifdef PRECOMP
	double **precomp;	
	double **matValNodes;
	#else
	double **BmomentInter;
	#endif
	

	double **Bmoment, **Bmomentab; // need to be created, since passed as arguments into Stiff
  double **quadraWN;

	
	// initialize number of quadrature pointers, and integers needed for indexing Bmoment entries
  int q = n+1;                    // the number of quadrature points is n+1
  
  int nDash = 2 * n - 2;        // the Bmoment order required for the stiffness matrix is 2n-2

	int m = MAX (nDash, q-1);       // m is used for indexing: only use MAX(nDash,q-1) for indexing with no storing algorithm
								// BUT m also needed with PRECOMP for allowing sufficient size to pointer "precomp"

  int nb_Array = 3;             //Stiff needs Bmoment associated with symmetric 2 by 2 matrix valued function
	int len_Quadra = (q + 1);     // space required for storing Jacobi nodes of order q is q, BUT indexing starts at 1
	
	// allocates memory for quadraWN
  quadraWN = create_quadraWN2d(len_Quadra);
	
	
	// initialize auxilliary arrays
	computeBinomials(binomialMat, len_binomial); //compute binomials
	normals2d (v1, v2, v3, normalMat);
	
	int mm, lenMoments;
  
  #ifdef PRECOMP
  mm = nDash;                   // for PRECOMP, lenMoments required is always determined by Bmoment order (and NOT quadrature rule used)
								// because indexing INDEPENDENT of MAX(n,q-1)
  lenMoments = ((mm + 2) * (mm + 1)) / 2;
  #else
	mm = MAX (nDash, q-1);          // mm will be used for indexing
  lenMoments = (mm + 1) * (mm + 1);
  #endif
  
  Bmoment = create_Bmoment(lenMoments, nb_Array);
  Bmomentab = create_Bmoment(lenMoments, 6); // multiply normals to Bmoments and store into Bmomentab: used with Stiff
	
	#ifdef PRECOMP
	int len_matValNodes = q * q ;      // space required for 2D array with dimension q
  matValNodes = create_matValNodes2d(len_matValNodes);
	precomp = create_precomp2d(m+1);	// store precomputed arrays
	#else
	BmomentInter = create_Bmoment(lenMoments, nb_Array);
	#endif	
	
	//assign values to auxilliary arrays
	#ifdef PRECOMP
	assign_pointers_Stiff2d(v1, v2, v3, n, q, nDash, m, nb_Array,matValNodes, Cval, quadraWN, precomp, C, functval);
	#else
	assign_pointers_Stiff2d(v1, v2, v3, n, q, nDash, m, nb_Array, Cval, quadraWN, Bmoment, C, functval);
	#endif
// 	#endif
									
	// store stiffness matrix entries into array stiffMat
	#ifdef PRECOMP
	Stiff2d (n, q, v1, v2, v3, binomialMat, scalarMat, normalMat, cputime, precomp,
				 Bmoment, Bmomentab, stiffMat, matValNodes, quadraWN);
	#else
	Stiff2d (n, q, v1, v2, v3, binomialMat, scalarMat, normalMat, cputime,
				 Bmoment, BmomentInter, Bmomentab, stiffMat, quadraWN);
	#endif
	

	#ifdef PRECOMP
	delete_pointers(precomp, Bmoment, Bmomentab, matValNodes, quadraWN);
	#else
	delete_pointers(Bmoment, BmomentInter, Bmomentab, quadraWN);
	#endif

	
	delete_BinomialMat (binomialMat, len_binomial);
	
	
	#ifdef CHECK
	int len_Stiff = len_Mat2d(n); // dimension of the elemental stiffness matrix
	std::cout<<"Stiffness matrix entries stored into array stiffMat of dimension "<<len_Stiff<<"\n";
	#endif	
	
}


#include <stdio.h>
#include <math.h>
#include <time.h>
#include <iostream>

#include "bbfem.h"


// example of coefficient function (used with mass matrix and load vector)
double 
f0(double v[3])
{
	return sin(v[0]*v[1]*v[2]);
}

#ifdef CONSTANT
int main()
{
// 		//vertices (standard tetrahedron)
// 	double v1[3] = { 0, 0, 0};
// 	double v2[3] = { 1, 0, 0};
// 	double v3[3] = { 0, 1, 0};
// 	double v4[3] = { 0, 0, 1};

	//vertices (particular tetrahedron)
  double v1[3] = { 1.2  , 3.4, 0}; 
  double v2[3] = { -1.5 , 2. , 0};
  double v3[3] = { 0.1  , -1., 0};
	double v4[3] = {1. , 1., 1.};

	int n; // degree of the Bernstein polynomial basis
  std::cout<<"Enter a value for the polynomial order n:";
  std::cin>>n;
	
	double **Bmoment; // pointer used for Bmoment entries
	int lenMoments = ((n+3)*(n+2)*(n+1))/6; 
	int nb_Array = 1; // the Bmoments are associated with scalar-valued coefficients equal to 1
	
	Bmoment = create_Bmoment(lenMoments, nb_Array); //allocate memory to Bmoment	
	
	get_Bmoments3d_const (Bmoment, n, v1, v2, v3, v4); // store B-moments into Bmoment array
	
	// Insert your code here to make use of Bmoment. It will be destroyed in the next line!
	
	delete_Bmoment(Bmoment);
}

#else // not CONSTANT

int main()
{
// 	// vertices (standard tetrahedron)
//   double v1[3] = {0, 0, 0};
//   double v2[3] = {1, 0, 0};
//   double v3[3] = {0, 1, 0};
// 	double v4[3] = {0, 0, 1};

	//vertices (particular tetrahedron)
  double v1[3] = { 1.2  , 3.4, 0}; 
  double v2[3] = { -1.5 , 2. , 0};
  double v3[3] = { 0.1  , -1., 0};
	double v4[3] = {1. , 1., 1.};
  
  int n; // degree of the B-moments
  std::cout<<"Enter a value for the polynomial order n:";
  std::cin>>n;
	
	int q=n+1; // q stands for the number of quadrature points used
	int nb_Array = 1; // the Bmoments are associated with a scalar-valued function
	
	double *Cval;
	
	int functval = 0; //default: using a routine (f) for B-moments' coefficients
	
	double **Bmoment; // pointer used for Bmoment entries
	int lenMoments = len_Moments3d(n, q); // memory required for storing Bmoments depends on whether or not PRECOMP is used
	
	
	double (*f) (double[3]) = f0; // change here if want Bmoments associated with another function
	

	
	#ifdef FUNCT_VAL
	functval = 1;  //using the values stored in Cval for B-moments' coefficients
	
	double *B; // store barycentric coordinates of Stroud nodes
	B = new double [q*q*q*4];
	stroud_nodes_bary3d (q, B);
	
	int LEN = q * q * q;  // space required for 2D array with dimension q+1	
  Cval = new double[LEN * nb_Array];    //Cval entries are stored in LINEAR memory, and used directly
  #endif
  
	
	#ifdef FUNCT_VAL
	scalar_values_at_Stroud3d(q, Cval, B, f, v1, v2, v3, v4); // will put the values of f at the Stroud nodes into Cval
	#endif
	
	Bmoment = create_Bmoment(lenMoments, nb_Array); //allocate memory to Bmoment	
	
	// store Bmoment entries into Bmoments
	get_Bmoments3d(Bmoment, n, f, Cval, v1, v2, v3, v4, functval);
	
		
	//free allocated memory
	#ifdef FUNCT_VAL
	delete Cval;
	delete B;
	#endif
	
	
	// Insert your code here to make use of Bmoment. It will be destroyed in the next line!
	
	delete_Bmoment(Bmoment);
}

#endif
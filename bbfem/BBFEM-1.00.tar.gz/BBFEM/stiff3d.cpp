#include <stdio.h>
#include <math.h>
#include <time.h>
#include <iostream>

#include "bbfem.h"


// example of coefficient matrix A (used with stiffness matrix)
void
A0(double v[3], double matC[3][3]) 
{
// 	// identity matrix
//   matC[0][0]=1; matC[0][1]=0; matC[0][2]=0;
//   matC[1][0]=0; matC[1][1]=1; matC[1][2]=0;
//   matC[2][0]=0; matC[2][1]=0; matC[2][2]=1;
	
	// non-trivial matrix example
	matC[0][0]= sin(v[0]*v[1]); matC[0][1]=0; matC[0][2]=0;
  matC[1][0]=0; matC[1][1]=1; matC[1][2]=0;
  matC[2][0]=0; matC[2][1]=0; matC[2][2]=exp(v[2]);
}


#ifdef CONSTANT

int main()
{
// 	//vertices (standard tetrahedron)
// 	double v1[3] = { 0, 0, 0};
// 	double v2[3] = { 1, 0, 0};
// 	double v3[3] = { 0, 1, 0};
// 	double v4[3] = { 0, 0, 1};

	//vertices (particular tetrahedron)
  double v1[3] = { 1.2  , 3.4, 0}; 
  double v2[3] = { -1.5 , 2. , 0};
  double v3[3] = { 0.1  , -1., 0};
	double v4[3] = {1. , 1., 1.};

	int n; // degree of the Bernstein polynomial basis
  std::cout<<"Enter a value for the polynomial order n:";
  std::cin>>n;
	
	double Coeff[6] = {1., 0., 0., 1., 0., 1.}; // upper triangular entries of (symmetric) matrix associated with stiffness matrix
	
	
	double **stiffMat;  // store stiffness matrix entries
  int len_Stiff = len_Mat3d(n); // allocate memory to stiffMat
  stiffMat = create_Mat(len_Stiff);
	
	get_stiffness3d_const (stiffMat, n, v1, v2, v3, v4, Coeff); // compute stiffness matrix
	
	// Insert your code here to make use of stiffMat. It will be destroyed in the next line!
	
	// free allocated memory;
	delete_Mat(stiffMat);
	
}

#else // not CONSTANT

int main()
{
// 	//vertices (standard tetrahedron)
// 	double v1[3] = { 0, 0, 0};
// 	double v2[3] = { 1, 0, 0};
// 	double v3[3] = { 0, 1, 0};
// 	double v4[3] = { 0, 0, 1};

	//vertices (particular tetrahedron)
  double v1[3] = { 1.2  , 3.4, 0}; 
  double v2[3] = { -1.5 , 2. , 0};
  double v3[3] = { 0.1  , -1., 0};
	double v4[3] = {1. , 1., 1.};

	int n; // degree of the Bernstein polynomial basis
  std::cout<<"Enter a value for the polynomial order n:";
  std::cin>>n;
	
	double *Cval; // store array of function values at Stroud quadrature nodes, dummy argument of get_stiffness unless FUNCT_VAL macro is activated
	
	int functval = 0; //default: using a routine (A) for stiffness matrix coefficients
	
	#ifdef FUNCT_VAL
	functval = 1;  //using the values stored in Cval for stiffness matrix coefficients
	int q = n+1;
	int nb_Array = 6; // the stiffness matrix is associated with (symmetric) matrix-valued data
	
	double *B; // store barycentric coordinates of Stroud nodes
	B = new double [q*q*q*4];
	stroud_nodes_bary3d (q, B);
	
	int LEN = q * q * q;  // space required for 3D array with dimension q	
  Cval = new double[LEN * nb_Array];    //Cval entries are stored in LINEAR memory, and used directly
  #endif
	
	void (*A) (double[3], double[3][3]) = A0; // change here if want stiffness matrix associated with another matrix-valued function
	
	#ifdef FUNCT_VAL
	matrix_values_at_Stroud3d(q, Cval, B, A, v1, v2, v3, v4); // will put the values of A at the Stroud nodes into Cval
	#endif
	
	double **stiffMat;  // store stiffness matrix entries
  int len_Stiff = len_Mat3d(n); // allocate memory to stiffMat
  stiffMat = create_Mat(len_Stiff);
	
	get_stiffness3d(stiffMat, n, A, Cval, v1, v2, v3, v4, functval); // compute elemental stiffness matrix	
	
	// free allocated memory
	#ifdef FUNCT_VAL
	delete Cval;
	delete B;
	#endif
	
	
	// Insert your code here to make use of stiffMat. It will be destroyed in the next line!
	
	
	delete_Mat(stiffMat);

}

#endif // end not CONSTANT
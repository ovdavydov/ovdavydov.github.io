//  This file is part of BBFEM.
//  
//   Authors: Mark Ainsworth
// 				    Division of Applied Mathematics
// 				    Brown University
// 				    182 George Street
// 				    Providence, RI 02912
// 				    e-mail: Mark_Ainsworth@Brown.edu
//
//            Gaelle Andriamaro
// 	  			  University of Strathclyde
// 	  			  Department of Mathematics and Statistics
//           	26 Richmond Street
// 	  			  Glasgow G1 1XH
// 	  			  Scotland, UK
// 	          e-mail: gaelle.andriamaro@strath.ac.uk
//  
//            Oleg Davydov
// 	  			  University of Strathclyde
// 	  			  Department of Mathematics and Statistics
//           	26 Richmond Street
// 	  			  Glasgow G1 1XH
// 	  			  Scotland, UK
// 	  			  e-mail: oleg.davydov@strath.ac.uk
// 
// 
//   Copyright (C) 2013 Mark Ainsworth, Gaelle Andriamaro and Oleg Davydov
// 
// 
// This package is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2, or (at your option)
// any later version.
// 
// This package is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this package; see the file COPYING.  If not, write to
// the Free Software Foundation, 59 Temple Place - Suite 330,
// Boston, MA 02111-1307, USA.  


#include <stdio.h>
#include <math.h>
#include <time.h>
#include <iostream>

#include <stdlib.h>

#include "bbfem.h"

#include "bbfem2dCurl.h"



#ifdef GAUJAC

#else
//#include "JacobiGaussNodes.h"
extern double legendre[2][85][85];
extern double jacobi[2][85][85];
#endif


#ifndef MAX
#define MAX(a,b) ( (a) > (b) ? (a) : (b) )
#endif

#define 	DELTA(i, j)   ((i==j)?1:0)

#define 	EPS_ij(i, j)   ((i==j)?1.:0.5) 	// computes scaling constant appearing in M_WW
#define 	EPS_2(i, j)   ((i==j)?1:0) // computes scaling constant appearing in M_sigmaW

#define 	INDEX_2(i, j)   (  ( (i+j+3)%3==0)?1:0 ) // computes auxilliary index for M_WW



//// COMPUTING ELEMENT MASS MATRIX //////////////////////////////////////////


// returns dimensions of H(curl) elemental matrices (corresponding to spanning set)
int 
dimCurl(int n)
{
	int Len;
  if (n>1)
		Len = ( (n+1)*(n+2) ) / 2 +  ( n*(n+1) ) / 2 + 3;
  else
		Len = 3; // only Whitney elements
		
	return Len;
}

// returns dimension of non-gradient sub-matrices
int 
dim_nonGradCurl(int n)
{
	int Len;
	if (n>1)
		Len = ( n*(n+1) ) / 2 + 3;
	else
		Len = 3;
	return Len;
}


// allocate memory to cRing coefficients
double **
create_cRing(int n)
{
	int len_CRing = n*(n+1) ; // 2 sequences of length (n*(n+1))/2
	int CRing_col = 3; // CRing has 3 columns
	
	double **cRing = new double *[len_CRing];
	double *cRing_array = new double [len_CRing * CRing_col];
	
	double *p1 = cRing_array;
	for (int i=0; i < len_CRing; p1 += CRing_col, i++)
		cRing[i] = p1;
	
	return cRing;
}

void
delete_cRing(double **cRing)
{
	delete cRing[0];
	delete cRing;
}


#ifdef PRECOMP
void
delete_pointers_Curl(double **precomp, double **Bmoment,
										 double **BmomentInter,
										 double **matValNodes, double **quadraWN)
#else
void
delete_pointers_Curl(double **Bmoment, double **BmomentInter,
										 double **matValNodes,
										 double **quadraWN)
#endif
{
	#ifdef PRECOMP
  delete_precomp(precomp);
  #endif
  
  delete_Bmoment(Bmoment);	
 
  delete_matValNodes(matValNodes);
	delete_Bmoment(BmomentInter);

  delete_quadraWN(quadraWN);  
  
}

// routine used to pre-multiply normals with the Bmoments
// pre-multiply matrix-valued B-moments with normals
// n is the order of the finite element
// q is the number of quadrature points used in each direction
// Bmoment contains B-moments associated with matrix-valued coefficients
// normalMat stores normals
// computed inner product are stored into Bmomentab array
void
transform_BmomentC_Mass2dCurl (int n, int q, double **Bmoment, double **Bmomentab, double normalMat[][2])
{
  int m, mm;

  #ifdef PRECOMP
	m = n;
  mm = ((m + 2) * (m + 1)) / 2; // with PRECOMP, required Bmoment size is determined by Bmoment order
  
  #else //not PRECOMP
  
  m = MAX (n, q-1);	
  mm = (m + 1) * (m + 1); // with no storing algorithm, required Bmoment size is determined by MAX( Bmoment order, number of quadrature points )
  
  #endif


  for (int mu = 0; mu < mm; mu++)
	{

		double Mat[2][2];

		Mat[0][0] = Bmoment[mu][0]; // Mat is used to store Bmoment[mu] entries
		Mat[0][1] = Mat[1][0] = Bmoment[mu][1];
		Mat[1][1] = Bmoment[mu][2];

		double matVectMult[2];

		matVectMult[0] = Mat[0][0] * normalMat[0][0] + Mat[0][1] * normalMat[0][1];
		matVectMult[1] = Mat[1][0] * normalMat[0][0] + Mat[1][1] * normalMat[0][1];


		Bmomentab[mu][0] = normalMat[0][0] * matVectMult[0] + normalMat[0][1] * matVectMult[1];   //alfa=[1,0,0], beta=[1,0,0]
		Bmomentab[mu][1] = normalMat[1][0] * matVectMult[0] + normalMat[1][1] * matVectMult[1];   //alfa=[0,1,0], beta=[1,0,0]
		Bmomentab[mu][2] = normalMat[2][0] * matVectMult[0] + normalMat[2][1] * matVectMult[1];   //alfa=[0,0,1], beta=[1,0,0]


		matVectMult[0] = Mat[0][0] * normalMat[1][0] + Mat[0][1] * normalMat[1][1];
		matVectMult[1] = Mat[1][0] * normalMat[1][0] + Mat[1][1] * normalMat[1][1];

		//Bmomentab[mu][1] = normalMat[0][0]*matVectMult[0] + normalMat[0][1]*matVectMult[1]; //alfa=[1,0,0], beta=[0,1,0] // redundancy
		Bmomentab[mu][3] = normalMat[1][0] * matVectMult[0] + normalMat[1][1] * matVectMult[1];   //alfa=[0,1,0], beta=[0,1,0]
		Bmomentab[mu][4] = normalMat[2][0] * matVectMult[0] + normalMat[2][1] * matVectMult[1];   //alfa=[0,0,1], beta=[0,1,0]


		matVectMult[0] = Mat[0][0] * normalMat[2][0] + Mat[0][1] * normalMat[2][1];
		matVectMult[1] = Mat[1][0] * normalMat[2][0] + Mat[1][1] * normalMat[2][1];


		//Bmomentab[mu][2] = normalMat[0][0]*matVectMult[0] + normalMat[0][1]*matVectMult[1]; //alfa=[1,0,0], beta=[0,0,1] // redundancy
		//Bmomentab[mu][4] = normalMat[1][0]*matVectMult[0] + normalMat[1][1]*matVectMult[1]; //alfa=[0,1,0], beta=[0,0,1]
		Bmomentab[mu][5] = normalMat[2][0] * matVectMult[0] + normalMat[2][1] * matVectMult[1];   //alfa=[0,0,1], beta=[0,0,1]

	}
	
	#ifdef CHECK_transform
	std::cout<<"Bmomentab entries:\n";
	for (int mu0=n; mu0>=0; mu0--)
	{
		int mu2=0;
		for (int mu1=n-mu0; mu1>=0; mu1--,mu2++)
		{
			std::cout<<"["<<mu0<<","<<mu1<<","<<mu2<<"]: ";
			#ifdef PRECOMP
			int iMu = position2d(mu1,mu2);
			#else
			int iMu = position2d2(mu0,mu1,m);
			#endif
			for (int k=0 ; k<6; k++)
				std::cout<<Bmomentab[iMu][k]<<"\t";
			std::cout<<"\n";
		}
		
	}
  #endif  
  

}


// copy coefficients values initialized by data_at_Nodes into Bmoment
// this routine allows for FUNCT_VAL option to be possible with non-PRECOMP
void
copy_Data_at_Stroud(int q, double v1[2], double v2[2], double v3[2],
													double **Bmoment, double **matValNodes, int nb_Array)
{
	
	for (int i = 0; i < q; i++)
	{
		for (int j = 0; j < q; j++)
		{
			int index_ij = position2d2 (i, j, q-1);
			
			for (int ell=0; ell < nb_Array ; ell++)
				Bmoment[index_ij][ell] = matValNodes[index_ij][ell];
		}
	}
	
}
				



// lowers the moment from order p to order l
// assuming that Bmoment of order p are stored into Bmoment00, Bmoment01,..., and DESTROYS initial entries of Bmoment and BmomentInter
// CAREFUL: after application of LowerMoment, order w.r.t. position2d2( . , l) and NOT position2d2( . , max(p,q) )
void 
LowerMoment( int p , int q, int l, double **Bmoment, 
						 double **BmomentInter, int nb_Array) 	
{
		
  int m=p; 
  #ifdef PRECOMP
  
  #else // re-order Bmoment entries following index(. , p) 
  if (p!=q-1)
	{
		int mm = MAX(p,q-1); // used for indexing with non-PRECOMP:
		// since q chosen independently of n, re-order Bmoment w.r.t. position2d2( . , p):
		for (int mu1 = p; mu1 >= 0; mu1--)
		{
			for (int mu2 = p-mu1; mu2 >= 0; mu2--)
			{
				int iMu_high = position2d2 (mu1, mu2, mm);
				int iMu_low = position2d2 (mu1, mu2, p);
				
				for (int ell = 0; ell < nb_Array; ell++)
					BmomentInter[iMu_low][ell] = Bmoment [iMu_high][ell]; 
			}      
		}
		
		for (int mu1 = p; mu1 >= 0; mu1--)
		{
			for (int mu2 = p-mu1; mu2 >= 0; mu2--)
			{
				int iMu_low = position2d2 (mu1, mu2, p);
				
				for (int ell = 0; ell < nb_Array; ell++)
					Bmoment[iMu_low][ell] = BmomentInter [iMu_low][ell]; 
			}      
		}	
	}
  #endif // end non-PRECOMP
	
		
	// start moment-lowering:
  for (int k=1; k<m-l+1; k++)
  {
		
		for (int alpha0=m-k; alpha0>=0; alpha0--)
		{
			int alpha2=0;
			
			#ifdef PRECOMP
			int iAlpha = ((m-k-alpha0)*(m-k-alpha0+1)) / 2; // using position2d indexing
			#else
			int iAlpha = alpha0*(m-k+1); // using position2d2( . , m-k) indexing
			#endif
			for (int alpha1=m-k-alpha0; alpha1>=0; alpha1--, alpha2++)
			{
				#ifdef PRECOMP
				iAlpha += alpha2;
				
				int iAlpha1 = iAlpha;
				int iAlpha2 = iAlpha + alpha1 + alpha2 + 1;
				int iAlpha3 = iAlpha2 + 1;
				
				#else
				iAlpha += alpha1;// using position2d2( . , m-k) indexing
				
				int iAlpha1 = iAlpha + alpha0 + m-k+2; // using position2d2( . , m-k+1) indexing
				int iAlpha2 = iAlpha + alpha0 + 1;
				int iAlpha3 = iAlpha + alpha0;
				#endif
				

				for (int i=0; i < nb_Array ; i++)
					BmomentInter[iAlpha][i] = 
					(alpha0+1) * Bmoment[iAlpha1][i] 
					+ (alpha1+1) * Bmoment[iAlpha2][i] 
					+ (alpha2+1) * Bmoment[iAlpha3][i];
				
				#ifdef PRECOMP
				iAlpha -= alpha2;
				#else
				iAlpha -= alpha1;
				#endif
			}
		}
	
	
		#ifdef PRECOMP
		int mm = ((p-k+1)*(p-k+2)) / 2;
		#else
		int mm = (p-k+1)*(p-k+1);
		#endif
		for (int iAlpha=0; iAlpha<mm; iAlpha++)
		{ 
			for (int i=0; i < nb_Array; i++)
				Bmoment[iAlpha][i] = BmomentInter[iAlpha][i]/(p-k+1);
		}
  } // end moment-lowering
  

  
  #ifdef CHECK_Lower
  std::cout<<"Bmoments lowered to from order "<<p<<" to order "<<l<<":\n";
  for (int alpha0 = l; alpha0>=0; alpha0--)
	{
		int alpha2=0;
		for (int alpha1 = l-alpha0; alpha1 >=0; alpha1--, alpha2++)
		{
			#ifdef PRECOMP
			int iAlpha = position2d(alpha1,alpha2);
			#else
			int iAlpha = position2d2(alpha0,alpha1,l);
			#endif
			std::cout<<"Bmoment"<<"["<<alpha0<<","<<alpha1<<","<<alpha2<<"]: ";
			for (int k=0; k < nb_Array; k++)
				std::cout<<std::scientific<<Bmoment[iAlpha][k] << "\t";
			std::cout<<"\n";
		}
	}  
  #endif

}

void 
CRing(int n, double normalMat[][2], double **cRing)
{
  double Const = -1./2/n; // scaling between gradients and normals
  
  int Shift = (n*(n+1))/2; // shift for CRing2
  
  int iBeta = 0;
  for (int beta0=n-1; beta0>=0; beta0--)
  {
		int beta2 = 0;
		for (int beta1=n-1-beta0; beta1>=0; beta1--)
		{
			cRing[iBeta][0] = Const * (1 + beta0) * ( beta2 * normalMat[1][0] - beta1 * normalMat[2][0] );     
			cRing[Shift + iBeta][0] = Const * (1 + beta0) * ( beta2 * normalMat[1][1] - beta1 * normalMat[2][1] );
							
			cRing[iBeta][1] = Const * (1 + beta1) * ( beta0 * normalMat[2][0] - beta2 * normalMat[0][0] ); 
			cRing[Shift+iBeta][1] = Const * (1 + beta1) * ( beta0 * normalMat[2][1] - beta2 * normalMat[0][1] );
							
			cRing[iBeta][2] = Const * (1 + beta2) * ( beta1 * normalMat[0][0] - beta0 * normalMat[1][0] );
			cRing[Shift+iBeta][2] = Const * (1 + beta2) * ( beta1 * normalMat[0][1] - beta0 * normalMat[1][1] );
			
			iBeta += 1;
			beta2 += 1;	  
		}
  }
}



#ifdef PRECOMP
double 
Mass2d_Curl( int n, 
						 int q, double v1[2], double v2[2], double v3[2],
						 double **binomialMat, double normalMat[][2], 
						 double **precomp, int mp, 
						 double **Bmoment, double **BmomentInter,
						 double **Bmomentab,
						 double **massMat, double **matValNodes, 
						 double **quadraWN, double **cRing, double cputime[2])
#else
double 
Mass2d_Curl( int n, 
						 int q, double v1[2], double v2[2], double v3[2],
						 double **binomialMat, double normalMat[][2],
						 double **Bmoment, double **BmomentInter,
						 double **Bmomentab,
						 double **massMat, double **matValNodes,
						 double **quadraWN, double **cRing,
						 double cputime[2])
#endif
{
  clock_t T0, T1, t0, t1, t2, t3;
  double cputimeGrad = 0;
  
  
  
  int Len;
  if (n>1)
		Len = ( (n+1)*(n+2) ) / 2 +  ( n*(n+1) ) / 2 + 3;
  else
		Len = 3; // only Whitney elements
	
	// initialize all the mass matrix entries to zero
  for (int row=0; row<Len; row++)		
  {
		for (int col=0; col<Len; col++)
			massMat[row][col]=0;
  }   
  
  double Const;
  
  int Shift_row, Shift_col;
  
  T0 = clock();
	
	int nDash; // B-moment order
	int nb_Array = 3; // (symmetric) matrix-valued coefficients
	#ifdef PRECOMP
	
	#else
	int M; // indexing variable
  #endif
  
  if (n>1)
  {
	// have to compute M_{sigma,sigma} first, since it requires the highest order for the Bmoments:	
	
	int Shift = ((n+1)*(n+2))/ 2; 	// shift needed for storing M_{sigma,sigma} entries
	int cRing_shift = (n*(n+1))/2;
	
	/// start computing M_{sigma,sigma} ///////////
	
	nDash = 2*n; // Bmoment order
	
	#ifdef PRECOMP
	;
	#else
	//WARNING: since q might be arbitrarily chosen, careful about indexing with non-PRECOMP:
	M = MAX(nDash,q-1);
	#endif
		 
  
  // assign values to auxilliary arrays needed in B-moment computation
	#ifdef PRECOMP
	init_precomp2d(precomp, nDash, q, mp, quadraWN);
	#else
	copy_Data_at_Stroud(q, v1, v2, v3, Bmoment, matValNodes, nb_Array);
	#endif
	
	// compute Bmoments:
	#ifdef PRECOMP
	Bmoment2d (nDash, q, mp, nb_Array, v1, v2, v3, binomialMat, precomp, Bmoment, matValNodes);
	#else
	Bmoment2d_Index( nDash, q, nb_Array, Bmoment, BmomentInter, quadraWN ); // computes B-moments of order nDash = 2*n
	#endif
	
	
	int alpha[3];
	int beta[3];
	
	int iAlpha = 0 +Shift;
	for (int alpha0=n-1; alpha0>=0; alpha0--)
	{
	  int alpha2=0;
	  for (int alpha1=n-1-alpha0; alpha1>=0; alpha1--)
	  {
		alpha[0]=alpha0; alpha[1]=alpha1; alpha[2]=alpha2;
		
		int iBeta = 0 +Shift;
		for (int beta0=n-1; beta0>=0; beta0--)
		{
		  int beta2=0;
		  
		  double w0 = 1. * binomialMat[alpha0][beta0] / binomialMat[n-1][n-1];
		  
		  for (int beta1=n-1-beta0; beta1>=0; beta1--)
		  {
				beta[0]=beta0; beta[1]=beta1; beta[2]=beta2;
				
				double Sum_eta[2]={0, 0};
				
				double w1 = w0 * binomialMat[alpha1][beta1];
				double w2 = w1 * binomialMat[alpha2][beta2];
				
				// eta = [1,0,0], k=0
				double wk = (alpha0+1.+beta0 ) / (alpha0+1);
				
				#ifdef PRECOMP
				int posAlphaBetaEtaRho = position2d(alpha1+beta1, alpha2+beta2);
				#else
				int posAlphaBetaEtaRho = (alpha0 + 1 + beta0)* (M+1) + alpha1 + beta1;    //indexing of Bmoment entries w.r.t index( . , M), pos(alpha+e_k+beta)
				#endif

				// rho = [1,0,0]; ell=0, ell=k
				double w_ell =  (beta0+1.+alpha0+1) /(beta0+1) ;
				#ifdef PRECOMP
				//posAlphaBetaEtaRho += 0;
				#else
				posAlphaBetaEtaRho += M+1; //2*n+1;
				#endif

				Sum_eta[0] +=   w_ell * (Bmoment[posAlphaBetaEtaRho][0] * cRing[iBeta-Shift][0] + Bmoment[posAlphaBetaEtaRho][1] * cRing[cRing_shift+iBeta-Shift][0] ); 
				Sum_eta[1] +=   w_ell *(Bmoment[posAlphaBetaEtaRho][1] * cRing[iBeta-Shift][0] + Bmoment[posAlphaBetaEtaRho][2] * cRing[cRing_shift+iBeta-Shift][0] );


				// rho = [0,1,0]; ell=1, k=0
				w_ell =  (beta1+1.+alpha1) / (beta1+1) ;  
				#ifdef PRECOMP
				posAlphaBetaEtaRho += alpha1+beta1 + alpha2+ beta2 + 1;
				#else
				posAlphaBetaEtaRho += -(M+1) + 1; //-(2*n+1) + 1;
				#endif

				Sum_eta[0] +=  w_ell * (Bmoment[posAlphaBetaEtaRho][0] * cRing[iBeta-Shift][1] + Bmoment[posAlphaBetaEtaRho][1] * cRing[cRing_shift+iBeta-Shift][1] );
				Sum_eta[1] +=  w_ell * (Bmoment[posAlphaBetaEtaRho][1] * cRing[iBeta-Shift][1] + Bmoment[posAlphaBetaEtaRho][2] * cRing[cRing_shift+iBeta-Shift][1] );
													
													
				// rho = [0,0,1]; ell=2, k=0
				w_ell =  (beta2+1.+alpha2) / (beta2+1) ;
				#ifdef PRECOMP
				posAlphaBetaEtaRho += 1;
				#else
				posAlphaBetaEtaRho -= 1;
				#endif

				Sum_eta[0] +=  w_ell * (Bmoment[posAlphaBetaEtaRho][0] * cRing[iBeta-Shift][2] + Bmoment[posAlphaBetaEtaRho][1] * cRing[cRing_shift+iBeta-Shift][2] );
				Sum_eta[1] +=  w_ell * (Bmoment[posAlphaBetaEtaRho][1] * cRing[iBeta-Shift][2] + Bmoment[posAlphaBetaEtaRho][2] * cRing[cRing_shift+iBeta-Shift][2] );

				
				massMat[iAlpha][iBeta] += wk * w2 * ( cRing[iAlpha-Shift][0] * Sum_eta[0] + cRing[cRing_shift+iAlpha-Shift][0] * Sum_eta[1] ) * n/2./(2*n-1);     // eta=[1,0,0]


				// eta = [0,1,0], k=1

				wk = (alpha1+1.+beta1)  /(alpha1+1);
				
				#ifdef PRECOMP
				posAlphaBetaEtaRho = position2d(alpha1+1+beta1, alpha2+beta2);
				#else
				posAlphaBetaEtaRho = (alpha0+beta0)*(M+1) + alpha1+1 + beta1 ;    // indexing of Bmoment entries w.r.t index( . , M), pos(alpha+e_k+beta)
				#endif
				Sum_eta[0]=Sum_eta[1] = 0.;

				// rho = [1,0,0]; ell=0, k=1
				w_ell =  (beta0+1.+alpha0) /(beta0+1) ;
				#ifdef PRECOMP
				//posAlphaBetaEtaRho += 0;
				#else
				posAlphaBetaEtaRho += M+1; 
				#endif
				
				Sum_eta[0] +=  w_ell * (Bmoment[posAlphaBetaEtaRho][0] * cRing[iBeta-Shift][0] + Bmoment[posAlphaBetaEtaRho][1] * cRing[cRing_shift+iBeta-Shift][0] );
				Sum_eta[1] +=  w_ell * (Bmoment[posAlphaBetaEtaRho][1] * cRing[iBeta-Shift][0] + Bmoment[posAlphaBetaEtaRho][2] * cRing[cRing_shift+iBeta-Shift][0] );

													
				// rho = [0,1,0]; ell=1, ell=k
				w_ell = (beta1+1.+alpha1+1) / (beta1+1) ; 
				#ifdef PRECOMP
				posAlphaBetaEtaRho += alpha1+1 + beta1 + alpha2+beta2 + 1;
				#else
				posAlphaBetaEtaRho += -(M+1) + 1;
				#endif

				Sum_eta[0] +=  w_ell * (Bmoment[posAlphaBetaEtaRho][0] * cRing[iBeta-Shift][1] + Bmoment[posAlphaBetaEtaRho][1] * cRing[cRing_shift+iBeta-Shift][1] );
				Sum_eta[1] +=  w_ell * (Bmoment[posAlphaBetaEtaRho][1] * cRing[iBeta-Shift][1] + Bmoment[posAlphaBetaEtaRho][2] * cRing[cRing_shift+iBeta-Shift][1] );

				// rho =[0,0,1]; ell=2
				w_ell =  (beta2+1.+alpha2) /(beta2+1) ;   
				#ifdef PRECOMP
				posAlphaBetaEtaRho += 1;
				#else
				posAlphaBetaEtaRho -= 1;
				#endif

				Sum_eta[0] += w_ell * (Bmoment[posAlphaBetaEtaRho][0] * cRing[iBeta-Shift][2] + Bmoment[posAlphaBetaEtaRho][1] * cRing[cRing_shift+iBeta-Shift][2] );
				Sum_eta[1] += w_ell * (Bmoment[posAlphaBetaEtaRho][1] * cRing[iBeta-Shift][2] + Bmoment[posAlphaBetaEtaRho][2] * cRing[cRing_shift+iBeta-Shift][2] );
													
					
				massMat[iAlpha][iBeta] += wk * w2 * ( cRing[iAlpha-Shift][1] * Sum_eta[0] + cRing[cRing_shift+iAlpha-Shift][1] * Sum_eta[1] ) * n/2./(2*n-1);     //eta=[0,1,0]


				// eta = [0,0,1], k=2

				wk = (alpha2+1.+beta2) / (alpha2+1);				
				#ifdef PRECOMP
				posAlphaBetaEtaRho = position2d(alpha1+beta1, alpha2+1+beta2);
				#else
				posAlphaBetaEtaRho = (alpha0+beta0)*(M+1) + alpha1 + beta1;    // indexing of BmomentKappa entries w.r.t index( . , M), pos(alpha+e_k+beta)
				#endif
				Sum_eta[0] = Sum_eta[1] = 0.;

				// rho = [1,0,0]; ell=0, k=2
				w_ell =  (beta0+1.+alpha0) / (beta0+1) ;  
				#ifdef PRECOMP
				//posAlphaBetaEtaRho += 0;
				#else
				posAlphaBetaEtaRho += M+1;
				#endif

				Sum_eta[0] += w_ell * (Bmoment[posAlphaBetaEtaRho][0] * cRing[iBeta-Shift][0] + Bmoment[posAlphaBetaEtaRho][1] * cRing[cRing_shift+iBeta-Shift][0] );
				Sum_eta[1] += w_ell * (Bmoment[posAlphaBetaEtaRho][1] * cRing[iBeta-Shift][0] + Bmoment[posAlphaBetaEtaRho][2] * cRing[cRing_shift+iBeta-Shift][0] );

													
				// rho =[0,1,0]; ell=1, k=2
				w_ell = (beta1+1.+alpha1) / (beta1+1) ;   
				#ifdef PRECOMP
				posAlphaBetaEtaRho += alpha1+beta1 + alpha2+1+beta2 + 1;
				#else
				posAlphaBetaEtaRho += -(M+1) + 1;
				#endif

				Sum_eta[0] += w_ell * (Bmoment[posAlphaBetaEtaRho][0] * cRing[iBeta-Shift][1] + Bmoment[posAlphaBetaEtaRho][1] * cRing[cRing_shift+iBeta-Shift][1] );
				Sum_eta[1] += w_ell * (Bmoment[posAlphaBetaEtaRho][1] * cRing[iBeta-Shift][1] + Bmoment[posAlphaBetaEtaRho][2] * cRing[cRing_shift+iBeta-Shift][1] );

				// rho =[0,0,1]; ell=2, ell=k
				w_ell =  (beta2+1.+alpha2+1) / (beta2+1) ;   
				#ifdef PRECOMP
				posAlphaBetaEtaRho += 1;
				#else
				posAlphaBetaEtaRho -= 1;
				#endif

				Sum_eta[0] += w_ell * (Bmoment[posAlphaBetaEtaRho][0] * cRing[iBeta-Shift][2] + Bmoment[posAlphaBetaEtaRho][1] * cRing[cRing_shift+iBeta-Shift][2] );
				Sum_eta[1] += w_ell * (Bmoment[posAlphaBetaEtaRho][1] * cRing[iBeta-Shift][2] + Bmoment[posAlphaBetaEtaRho][2] * cRing[cRing_shift+iBeta-Shift][2] );


				massMat[iAlpha][iBeta] += wk * w2 * ( cRing[iAlpha-Shift][2] * Sum_eta[0] + cRing[cRing_shift+iAlpha-Shift][2] * Sum_eta[1] ) * n/2./(2*n-1);     //eta=[0,0,1]
				
				iBeta += 1;
				beta2 += 1;
		  }
		}
		
		iAlpha += 1;
		alpha2 += 1;
	  }
	}

		
	t0 = clock();
	
	/// start computing M_{nabla,sigma} ///
												  

	LowerMoment(2*n, q, 2*n-1, Bmoment, BmomentInter, nb_Array); // lowers Bmoment of order 2n to order 2n-1: careful, using position2d(.,2n-1) with non-PRECOMP
	
												  
	Shift_col = ((n+1)*(n+2))/ 2;
	
	double Sum[2] = {0, 0};
	
	iAlpha = 0;
	for (int alpha0=n-1; alpha0>=0; alpha0--)
	{
	  int alpha2=0;
	  for (int alpha1=n-1-alpha0; alpha1>=0; alpha1--)
	  {
		alpha[0]=alpha0; alpha[1]=alpha1; alpha[2]=alpha2;
		
		int iBeta = 0 + Shift_col;
		for (int beta0=n-1; beta0>=0; beta0--)
		{
		  int beta2=0;
		  
		  double w0 = -1. * binomialMat[alpha0][beta0] / binomialMat[n-1][n] / 2 / Area2d(v1,v2,v3);
			
			#ifdef PRECOMP
			int posAlphaBeta0 = position2d_sum(n-1-alpha0,n-1-beta0);
			#else
		  int posAlphaBeta0 = (alpha0+beta0) * (2*n);
		  #endif
		  for (int beta1=n-1-beta0; beta1>=0; beta1--)
		  {
			beta[0]=beta0; beta[1]=beta1; beta[2]=beta2;
			
			double w1 = w0 * binomialMat[alpha1][beta1];
			double w2 = w1 * binomialMat[alpha2][beta2];
			
			#ifdef PRECOMP
			int posAlphaBeta1 = posAlphaBeta0 + alpha2 + beta2; 
			//  posAlphaBeta1= position2d(alpha1+beta1,alpha2+beta2)
			#else
			int posAlphaBeta1 = posAlphaBeta0 + alpha1 + beta1;
			#endif
			
			for (int ell=0; ell<3; ell++)
			{
			  double wTilde = w2 * ( beta[ell]+1.+alpha[ell] ) / ( beta[ell]+1. ); 	// adjustment of multinomial
			  
				#ifdef PRECOMP
				int posAlphaBeta_ell = posAlphaBeta1
				+ DELTA(ell,1) * ( n-1-alpha0 + n-1-beta0 + 1 )
				+ DELTA(ell,2) * ( n-1-alpha0 + n-1-beta0 + 2 );
				
				#else
			  int posAlphaBeta_ell = posAlphaBeta1 + DELTA(ell,0)*(2*n) + DELTA(ell,1); // indexing w.r.t position2d2( . , 2n-1)
			  #endif
				
				double bMoment00 = Bmoment[posAlphaBeta_ell][0];
			  double bMoment01 = Bmoment[posAlphaBeta_ell][1];
			  double bMoment11 = Bmoment[posAlphaBeta_ell][2];
			  
				Sum[0] = n * wTilde * ( bMoment00 * cRing[iBeta-Shift_col][ell] + bMoment01 * cRing[cRing_shift+iBeta-Shift_col][ell] );
			  Sum[1] = n * wTilde * ( bMoment01 * cRing[iBeta-Shift_col][ell] + bMoment11 * cRing[cRing_shift+iBeta-Shift_col][ell] );
			  
			  for (int k=0; k<3; k++)			  
					massMat[ position2d( alpha1+DELTA(k,1), alpha2+DELTA(k,2) ) ][ iBeta ] += normalMat[k][0] * Sum[0] + normalMat[k][1] * Sum[1];			  
			  
			}
						
			iBeta += 1;
			beta2 += 1;
		  }
		}
		iAlpha += 1;
		alpha2 += 1;
	  }
	}
	


	/// start computing M_{nabla,nabla} ///
		
	LowerMoment(2*n-1, 2*n-1, 2*n-2, Bmoment, BmomentInter, nb_Array); // lowers Bmoment order to 2n-2: since LowerMoment called twice, need to put 2n-1 instead of q
	
	
	transform_BmomentC_Mass2dCurl (2*n-2, 2*n-2, Bmoment, Bmomentab, normalMat);
	
	
	Const = n*n/4./Area2d(v1,v2,v3)/Area2d(v1,v2,v3);	// scaling between normals and gradients
	
	iAlpha = 0;
	int iAlpha1 = 1; int iAlpha2 = 2;
	for (int alpha0=n-1; alpha0>=0; alpha0--)
	{
	  int alpha2=0;
	  for (int alpha1=n-1-alpha0; alpha1>=0; alpha1--)
	  {
		int iBeta = 0;
		int iBeta1 = 1; int iBeta2 = 2;
		for (int beta0=n-1; beta0>=0; beta0--)
		{
		  double w0 = 1.* binomialMat[alpha0][beta0] / binomialMat[n-1][n-1] * Const;
			#ifdef PRECOMP
			int iAlphaBeta = position2d_sum(n-1-alpha0, n-1-beta0);
			#else
		  int iAlphaBeta = (alpha0 + beta0) * (2*n-1); 	// indexing of Bmoment entries w.r.t. position2d2( . , 2n-2)
		  #endif
			
		  int beta2=0;
		  for (int beta1=n-1-beta0; beta1>=0; beta1--)
		  {
				#ifdef PRECOMP
				iAlphaBeta += alpha2 + beta2;
				#else
				iAlphaBeta += alpha1+beta1;
				#endif
				
				double w1 = w0 * binomialMat[alpha1][beta1];
				double w2 = w1 * binomialMat[alpha2][beta2];
					

				massMat[iAlpha][iBeta]   += w2 * Bmomentab[iAlphaBeta][0];   // alpha=[1,0,0], beta=[1,0,0]
				massMat[iAlpha][iBeta1]  += w2 * Bmomentab[iAlphaBeta][1];   // alpha=[1,0,0], beta=[0,1,0]
				massMat[iAlpha][iBeta2]  += w2 * Bmomentab[iAlphaBeta][2];   // alpha=[1,0,0], beta=[0,0,1]

				massMat[iAlpha1][iBeta]  += w2 * Bmomentab[iAlphaBeta][1];   // alpha=[0,1,0], beta=[1,0,0]
				massMat[iAlpha1][iBeta1] += w2 * Bmomentab[iAlphaBeta][3];   // alpha=[0,1,0], beta=[0,1,0]
				massMat[iAlpha1][iBeta2] += w2 * Bmomentab[iAlphaBeta][4];   // alpha=[0,1,0], beta=[0,0,1]

				massMat[iAlpha2][iBeta]  += w2 * Bmomentab[iAlphaBeta][2];   // alpha=[0,0,1], beta=[1,0,0]
				massMat[iAlpha2][iBeta1] += w2 * Bmomentab[iAlphaBeta][4];   // alpha=[0,0,1], beta=[0,1,0]
				massMat[iAlpha2][iBeta2] += w2 * Bmomentab[iAlphaBeta][5];   // alpha=[0,0,1], beta=[0,0,1]		
				
				
				#ifdef PRECOMP
				iAlphaBeta -= alpha2+beta2;
				#else
				iAlphaBeta -= alpha1+beta1;
				#endif
				
				iBeta += 1;
				iBeta1 += 1;
				iBeta2 += 1;
				beta2 += 1;
		  }
		  iBeta1 += 1;
		  iBeta2 += 1;
		}		
		iAlpha += 1;
		iAlpha1 += 1;
		iAlpha2 += 1;
		alpha2 += 1;
	  }
	  iAlpha1 += 1;
	  iAlpha2 += 1;
	}
	
	
	t1 = clock();
	
	
	/// start computing M_{sigma,W} ///
	
	nDash = n+1;
	// assign values to auxilliary arrays needed in B-moment computation
	#ifdef PRECOMP
	init_precomp2d(precomp, nDash, q, mp, quadraWN);
		
	#else
	copy_Data_at_Stroud(q, v1, v2, v3, Bmoment, matValNodes, nb_Array);
	#endif
	
  
  #ifdef PRECOMP
  Bmoment2d (nDash, q, mp, nb_Array, v1, v2, v3, binomialMat, precomp, Bmoment, matValNodes);
  #else
 
	Bmoment2d_Index (nDash, q, nb_Array, Bmoment, BmomentInter, quadraWN);
  M = MAX(nDash,q-1) ; // used for indexing
  #endif
  
  
	Shift_row = ((n+1)*(n+2))/ 2; 
	Shift_col = ((n+1)*(n+2))/ 2 + (n*(n+1))/2; 	// entries of M_{sigma,W} stored from (|I_n|+|I_{n-1}|)^th col and |I_n|^th row
  
  
	Const = -1./2/Area2d(v1, v2, v3); // scaling between normals and gradients
  
	double w_alpha[3] = {0, 0, 0};
	double prod[2] = {0 , 0};
  
  
	iAlpha = 0 + Shift_row;
	for (int alpha0 = n-1; alpha0>=0; alpha0--)
	{
	  int alpha2 = 0;
	  for (int alpha1=n-1-alpha0; alpha1>=0; alpha1--)
	  {
			alpha[0]=alpha0; alpha[1]=alpha1; alpha[2]=alpha2;
			w_alpha[0]= alpha0+1.; w_alpha[1]=alpha1+1.; w_alpha[2]=alpha2+1.;
			
			for (int i=0; i<3; i++)
			{
				for (int k=0; k<3; k++)
				{
					#ifdef PRECOMP
					int posAlphaEk = position2d( alpha1+DELTA(k,1), alpha2+DELTA(k,2) ); 
					#else

					int posAlphaEk = ( alpha0 +  DELTA(k,0) ) * (M+1) + alpha1 + DELTA(k,1); 	// indexing of Bmoment entries w.r.t position2d2( . , M)
					#endif
					
					for (int r=-1; r<=1; r += 2)
					{
						#ifdef PRECOMP
						int posAlphaEkEr = posAlphaEk
						+ DELTA( (i+r+3)%3, 1) * ( alpha1+DELTA(k,1)+alpha2+DELTA(k,2) + 1 )
						+ DELTA( (i+r+3)%3, 2) * ( alpha1+DELTA(k,1)+alpha2+DELTA(k,2) + 2 );
						#else

						int posAlphaEkEr = posAlphaEk + DELTA( (i+r+3)%3, 0) * (M+1) + DELTA( (i+r+3)%3, 1); 	// position2d2( alpha+e_k+e_{i+r}, M)
						#endif			
								

						prod[0] = Bmoment[posAlphaEkEr][0] * normalMat[(i-r+3)%3][0] + Bmoment[posAlphaEkEr][1] * normalMat[(i-r+3)%3][1];
						prod[1] = Bmoment[posAlphaEkEr][1] * normalMat[(i-r+3)%3][0] + Bmoment[posAlphaEkEr][2] * normalMat[(i-r+3)%3][1];

						double eps = DELTA((i+r+3)%3, k%3);
			
						massMat[iAlpha][i+Shift_col] +=  Const*r/(n+1) * (w_alpha[(i+r+3)%3] + eps)  * ( cRing[iAlpha-Shift_row][k] * prod[0] + cRing[cRing_shift+iAlpha-Shift_row][k]* prod[1] );	
					}		  
				}
			}	  	  
			iAlpha += 1;
			alpha2 += 1;
		}
	}
	
	
	t2 = clock(); 	// t0 and t1 only used for counting gradients CPU time...	
	
	/// start computing M_{nabla, W} ///
	
	
	LowerMoment(n+1, q, n, Bmoment, BmomentInter, nb_Array);// lowers Bmoment from order n+1 to n, careful: indexing w.r.t position2d2( . , n)
												  
	Shift_col =  ((n+1)*(n+2))/ 2 + (n*(n+1)) / 2; // Shift_col = |I_n| + |I_{n-1}|
	
	Const = 1./4/Area2d(v1,v2,v3)/Area2d(v1,v2,v3);
	

	int e_k[3]={0,0,0};
	
	for (int i=0; i<3; i++)
	{
	  iAlpha = 0;
	  for (int alpha0=n-1; alpha0>=0; alpha0--)
	  {
		int alpha2=0;
		for (int alpha1=n-1-alpha0; alpha1>=0; alpha1--)
		{
		  alpha[0]= alpha0; alpha[1]=alpha1; alpha[2]=alpha2;
		  w_alpha[0]= alpha0+1.; w_alpha[1]=alpha1+1.; w_alpha[2]=alpha2+1.;
		  
			#ifdef PRECOMP
			int posAlpha = position2d(alpha1,alpha2);
			#else
		  int posAlpha = alpha0 * (n+1) + alpha1; 	// Bmoment entries indexed w.r.t position2d2( . , n)
		  #endif
		  
		  for (int k=0; k<3; k++)
		  {
			e_k[0] = DELTA(k,0); e_k[1] = DELTA(k,1); e_k[2] = DELTA(k,2);
			
			for (int r=-1; r<=1; r += 2)
			{
				#ifdef PRECOMP
				int posAlphaEr = posAlpha 
				+ DELTA( (i+r+3)%3, 1 ) * ( alpha1 + alpha2 +1 )
				+ DELTA( (i+r+3)%3, 2 ) * ( alpha1 + alpha2 +2 );
				#else
			  int posAlphaEr = posAlpha + DELTA( (i+r+3)%3, 0 ) * (n+1) + DELTA( (i+r+3)%3, 1 );   // position2d2( alpha+e_{i+r}, n )
				#endif
				

				prod[0] = Bmoment[posAlphaEr][0] * normalMat[(i-r+3)%3][0] + Bmoment[posAlphaEr][1] * normalMat[(i-r+3)%3][1];
			  prod[1] = Bmoment[posAlphaEr][1] * normalMat[(i-r+3)%3][0] + Bmoment[posAlphaEr][2] * normalMat[(i-r+3)%3][1];
			  
			  massMat[ position2d(alpha1+e_k[1], alpha2+e_k[2]) ][ i+Shift_col ] += Const * r * w_alpha[(i+r+3)%3] * ( normalMat[k][0]*prod[0] + normalMat[k][1]*prod[1] );
			}
		  }
		  iAlpha += 1;
		  alpha2 += 1;
		}
	  }
	}
	
	t3 = clock();
	
	cputimeGrad = ( (double) (t1-t0)  ) / CLOCKS_PER_SEC + ( (double)   (t3-t2) )/ CLOCKS_PER_SEC;
	cputime[1] = cputimeGrad; 
	
		
  } 		// end "if n>1"
  
  
  /// start computing M_{WW} ///
  
  if (n>1)
		Shift_row = Shift_col = ((n+1)*(n+2)) / 2 + (n*(n+1)) / 2;   // Shift_col = |I_n| + |I_{n-1}|
  else
		Shift_row = Shift_col = 0;	// no shift if only Whitney elements
	
  
  Const = 1./4/Area2d(v1,v2,v3)/Area2d(v1,v2,v3);
	
	nDash = 2;
	// assign values to auxilliary arrays needed in B-moment computation
	#ifdef PRECOMP
	init_precomp2d(precomp, nDash, q, mp, quadraWN);	
	#else
	copy_Data_at_Stroud(q, v1, v2, v3, Bmoment, matValNodes, nb_Array);
	#endif
  
	#ifdef PRECOMP
	Bmoment2d (nDash, q, mp, nb_Array, v1, v2, v3, binomialMat, precomp, Bmoment, matValNodes);
	#else 
	Bmoment2d_Index (nDash, q, nb_Array, Bmoment, BmomentInter, quadraWN); // stores Bmoment of order 2, 
	M = MAX(nDash,q-1); 
	#endif											  
  
  double prod[2]={0, 0};
  
  for (int i=0; i<3; i++)
  {
		for (int r=-1; r<=1; r += 2)
		{
			#ifdef PRECOMP
			int posR = position2d( DELTA( (i+r+3)%3, 1), DELTA( (i+r+3)%3, 2) ); 
			#else
			int posR = DELTA( (i+r+3)%3, 0 ) * (M+1) + DELTA( (i+r+3)%3, 1 );
			#endif
			
			for (int j=0; j<3; j++)
			{
				for (int s=-1; s<=1; s += 2)
				{
					#ifdef PRECOMP
					int posRS = posR
					+ DELTA( (j+s+3)%3, 1 ) * ( DELTA( (i+r+3)%3, 1) + DELTA( (i+r+3)%3, 2) + 1)
					+ DELTA( (j+s+3)%3, 2 ) * ( DELTA( (i+r+3)%3, 1) + DELTA( (i+r+3)%3, 2) + 2);	 // position2d( e_{i+r}+e_{j+s})				
					
					#else
					int posRS = posR + DELTA( (j+s+3)%3, 0 ) * (M+1) + DELTA( (j+s+3)%3, 1);     // position2d2( e_{i+r}+e_{j+s}, M )
					#endif
					
					prod[0] = Bmoment[posRS][0] * normalMat[(j-s+3)%3][0] + Bmoment[posRS][1] * normalMat[(j-s+3)%3][1]; // avoid negative-valued indices...
					prod[1] = Bmoment[posRS][1] * normalMat[(j-s+3)%3][0] + Bmoment[posRS][2] * normalMat[(j-s+3)%3][1];
					
					massMat[i+Shift_row][j+Shift_col] += Const * r * s * EPS_ij( (i+r+3)%3, (j+s+3)%3 ) * ( normalMat[(i-r+3)%3][0]*prod[0] + normalMat[(i-r+3)%3][1]*prod[1] );
				}
			}
		}
  }
  
  
  T1 =clock();
  
  double cputimeTotal = ((double)(T1-T0))/CLOCKS_PER_SEC;
  
  cputime[0] = cputimeTotal;
  
  // the mass matrix is symmetric
  
  for (int row=0; row< Len; row++)
  {
	for (int col=row; col<Len; col++) // completes LOWER diagonal
	  massMat[col][row] = massMat[row][col];
  }
  
  
  #ifdef CHECK
  std::cout.precision(3); // set number of digits
	
  if (n<2) // only Whitney
  {
		std::cout<<"Mass matrix entries:\n";
		for (int row=0; row< Len; row++)
		{
			for (int col=0; col<Len; col++)	
				std::cout<<std::scientific<< massMat[row][col]<<"\t ";
			std::cout<<"\n";
			
		}
  }
  else
  {
	
		std::cout<<"Mass matrix entries:\n";
		for (int row=0; row< Len; row++)
		{
			for (int col=0; col<Len; col++)	
				std::cout<<std::scientific<< massMat[row][col]<<"\t ";
			std::cout<<"\n";	  
		}
	
// 	std::cout<<"Nabla-nabla mass matrix entries:\n";
// 	for (int row=0; row< ( ((n+1)*(n+2))/2 ); row++) 	// checking M_{nabla,nabla}
// 	{
// 	  for (int col=0; col< ((n+1)*(n+2))/2; col++)	
// 			std::cout<<std::scientific<< massMat[row][col]<<"\t ";
// 	  std::cout<<"\n";  
// 	}

// 	std::cout<<"Nabla-sigma mass matrix entries:\n";
// 	for (int row=0; row<  ((n+1)*(n+2))/2 ; row++) 	// checking M_{nabla,sigma}
// 	{
// 	  for (int col=((n+1)*(n+2))/2; col< ((n+1)*(n+2))/2 + (n*(n+1))/2; col++)	
// 			std::cout<<std::scientific<< massMat[row][col]<<"\t ";
// 	  std::cout<<"\n";
// 	}

// 	std::cout<<"Nabla-Whitney mass matrix entries:\n";
// 	for (int row=0; row<  ((n+1)*(n+2))/2 ; row++) 	// checking M_{nabla,W}
// 	{
// 	  for (int col=Len-3; col< Len; col++)	
// 			std::cout<<std::scientific<< massMat[row][col]<<"\t ";
// 	  std::cout<<"\n";
// 	}
		
// 	std::cout<<"Sigma-sigma mass matrix entries:\n";
// 	for (int row=((n+1)*(n+2))/2 ; row<  ((n+1)*(n+2))/2 + (n*(n+1))/2; row++)
// 	{
// 	  for (int col=((n+1)*(n+2))/2 ; col< ((n+1)*(n+2))/2 + (n*(n+1))/2; col++)	
// 			std::cout<<std::scientific<< massMat[row][col]<<"\t ";
// 	  std::cout<<"\n";
// 	}

// 	std::cout<<"Sigma-Whitney mass matrix entries:\n";
// 	for (int row=((n+1)*(n+2))/2 ; row<  ((n+1)*(n+2))/2 + (n*(n+1))/2; row++)
// 	{
// 	  for (int col=Len-3 ; col< Len; col++)	
// 			std::cout<<std::scientific<< massMat[row][col]<<"\t ";
// 	  std::cout<<"\n";	  
// 	}	

  }
  
  #endif
  
  
  return cputimeTotal;
  
}


// COMPUTING ELEMENT STIFFNESS MATRIX /////////////////////////////////



// store CBar coefficients into cBar
void 
CBar( int n, double v1[2], double v2[2], double v3[2] , double **cBar) 
{
  int Stencil[7][2][3]= { {{1,0,0},{0,1,0}}, {{1,0,0},{0,0,1}}, {{0,1,0},{0,0,1}}, {{0,0,1},{0,1,0}}, {{0,0,1},{1,0,0}}, {{0,1,0},{1,0,0}}, {{0,0,0},{0,0,0}} }; // note that Stencil is symmetric!!!
  
  
  int iAlpha = 0;
  for (int alpha0=n-1; alpha0>=0; alpha0--)
  {
	int alpha2=0;
	for (int alpha1=n-1-alpha0; alpha1>=0; alpha1--)
	{
	  int alpha[3]={alpha0,alpha1,alpha2};
	  for (int stenc=0; stenc<6; stenc++) //careful NOT to include last sten (otherwise get a zero on the last row of cBar!!)
	  {
			int eta[3] = { Stencil[stenc][0][0], Stencil[stenc][0][1], Stencil[stenc][0][2] };
			int rho[3] = { Stencil[stenc][1][0], Stencil[stenc][1][1], Stencil[stenc][1][2] };
			if (alpha0+rho[0]-eta[0]>=0 and alpha1+rho[1]-eta[1]>=0 and alpha2+rho[2]-eta[2]>=0) // check that valid domain point
				cBar[iAlpha][stenc] = -(  alpha[position2d(rho[1], rho[2])] +1.  ) * alpha[position2d(eta[1], eta[2])] /2.;		
	  }
	  
	  cBar[iAlpha][6] =  ( ( n+1-alpha0)*alpha0 + (n+1-alpha1)*alpha1 + (n+1-alpha2)*alpha2 ) / 2.;    // use explicit formula for c^(alpha)_alpha
	  
	  alpha2++;
	  iAlpha++;
	}
  }
}


double ** 
create_cBar(int n)
{
  double **cBar = new  double *[(n*(n+1))/2]; // the number in brackets is the number of pointers to rows
  double *cBar_array = new double [ 7 * (n*(n+1))/2 ]; 
  double *p = cBar_array;
 
  for (int i=0; i<  (n*(n+1))/2; p += 7, i++ )//cBar has SEVEN columns
		cBar[i] = p;	
  
	return cBar;
}

void 
delete_cBar(double **cBar)
{
  delete cBar[0];
	delete cBar;
}



// WARNING:this routine does not include the zero block corresponding to the gradient entries
#ifdef PRECOMP
double 
Stiff2d_Curl(int n, 
						 int q, double v1[2], double v2[2], double v3[2],
						 double **binomialMat, double **precomp, int mp, 
						 double **Bmoment, double **BmomentInter,
						 double **cBar,
						 double **stiffMat, double **matValNodes, 
						 double **quadraWN, double cputime[3])
#else
double 
Stiff2d_Curl(int n, 
						 int q, double v1[2], double v2[2], double v3[2],
						 double **binomialMat, double **Bmoment, double **BmomentInter,
						 double **cBar,
						 double **stiffMat, double **matValNodes, 
						 double **quadraWN,
						 double cputime[3])
#endif
{
  
  int Stencil[7][2][3]= { {{1,0,0},{0,1,0}}, {{1,0,0},{0,0,1}}, {{0,1,0},{0,0,1}}, {{0,0,1},{0,1,0}}, {{0,0,1},{1,0,0}}, {{0,1,0},{1,0,0}}, {{0,0,0},{0,0,0}} };
  
  int len_Stiff, Shift;
  
  clock_t t0, t1, t0Dash, t1Dash, t2Dash;
  
  
  if (n>1)
  {	
		len_Stiff = ( n*(n+1) )/2 + 3;	
  }
  
  else
		len_Stiff = 3;
		
	for (int row=0; row<len_Stiff; row++)
	{
		for (int col=0; col<len_Stiff; col++)
			stiffMat[row][col] = 0;
	}
    
  
  t0 = clock();
	
	int nb_Array = 1; // scalar-valued coefficients
  int nDash; // B-moments order
  #ifdef PRECOMP
  
  #else
  int M; // indexing variable
	#endif
  
  ///////////////////////// start if n>1 //////////////////////////////////
  
  if (n>1)
  {
		/// start computing S_{sigma,sigma} ///
		
		t0Dash = clock();
		
		nDash = 2*n-2;
		#ifdef PRECOMP
		init_precomp2d(precomp, nDash, q, mp, quadraWN);		
		#else
		copy_Data_at_Stroud(q, v1, v2, v3, Bmoment, matValNodes, nb_Array);	
		#endif
		
		#ifdef PRECOMP
		Bmoment2d (nDash, q, mp, nb_Array, v1, v2, v3, binomialMat, precomp, Bmoment, matValNodes);
		#else
		Bmoment2d_Index( nDash, q, nb_Array, Bmoment, BmomentInter, quadraWN );
		M = MAX(nDash,q-1); // indexing variable
		#endif
		
		int iAlpha=0;
		for (int alpha0=n-1; alpha0>=0; alpha0--)
		{
			int alpha2=0;
			for (int alpha1=n-1-alpha0; alpha1>=0; alpha1--)
			{			
				int iBeta=0;
				for (int beta0=n-1; beta0>=0; beta0--)
				{
					int beta2=0;
					
					double w0 = 1. * binomialMat[alpha0][beta0] / binomialMat[n-1][n-1];
					
					#ifdef PRECOMP
					int posAlphaBeta0 = position2d_sum(n-1-alpha0,n-1-beta0);
					#else
					int posAlphaBeta0 = (alpha0+beta0) * (M+1);
					#endif
					for (int beta1=n-1-beta0; beta1>=0; beta1--)
					{
						double w1 = w0 * binomialMat[alpha1][beta1];
						double w2 = w1 * binomialMat[alpha2][beta2];
						
						#ifdef PRECOMP
						int posAlphaBeta = posAlphaBeta0 + alpha2 + beta2;
						#else
						int posAlphaBeta = posAlphaBeta0 + alpha1 + beta1;
						#endif
						
						
						double BmomentA_alpha_beta = Bmoment[posAlphaBeta][0];
						
						
						for (int stenc1=0; stenc1<6; stenc1++)//careful NOT to include last stenc1 (special case)
						{
							int s1[3] = { -Stencil[stenc1][0][0]+Stencil[stenc1][1][0], -Stencil[stenc1][0][1]+Stencil[stenc1][1][1], -Stencil[stenc1][0][2]+Stencil[stenc1][1][2] };
							int alphaDash[3] = { alpha0+s1[0], alpha1+s1[1], alpha2+s1[2]};
							int posAlpha1 = position2d(alphaDash[1],alphaDash[2]);
							if (alpha0>=-s1[0] and alpha1>=-s1[1] and alpha2>=-s1[2])   // alpha= alpha'-s1: in order to avoid calling invalid entries of cBar
							{  
								double r_alphaS1 = w2 * cBar[posAlpha1][5-stenc1]; // using the symmetry of Stencil
								
								for (int stenc2=0; stenc2<6; stenc2++) // careful NOT to include last stenc2
								{
									int s2[3] = { -Stencil[stenc2][0][0]+Stencil[stenc2][1][0], -Stencil[stenc2][0][1]+Stencil[stenc2][1][1], -Stencil[stenc2][0][2]+Stencil[stenc2][1][2] };
									
									int betaDash[3] = { beta0+s2[0], beta1+s2[1], beta2+s2[2] };
									int posBeta1 = position2d(betaDash[1],betaDash[2]);
									
									if (beta0>=-s2[0] and beta1>=-s2[1] and beta2>=-s2[2])
									stiffMat[posAlpha1][posBeta1] += r_alphaS1 * BmomentA_alpha_beta * cBar[posBeta1][5-stenc2]; // using the symmetry of Stencil 
								}
							}
						}
						
						
						double r_alphaS1 = w2 * cBar[iAlpha][6];    //alphaDash=alpha
						
						
						for (int stenc2=0; stenc2<6; stenc2++)
						{
							int s2[3]= { -Stencil[stenc2][0][0]+Stencil[stenc2][1][0], -Stencil[stenc2][0][1]+Stencil[stenc2][1][1], -Stencil[stenc2][0][2]+Stencil[stenc2][1][2] };
							int betaDash[3] = {beta0+s2[0], beta1+s2[1], beta2+s2[2]};
							int posBeta2 = position2d(betaDash[1],betaDash[2]);
							
							if (beta0>=-s2[0] and beta1>=-s2[1] and beta2>=-s2[2])
							{				
								stiffMat[iAlpha][posBeta2] += r_alphaS1 * BmomentA_alpha_beta * cBar[posBeta2][5-stenc2];
							}
						}			
						
						int posBeta2 = iBeta;
						
						stiffMat[iAlpha][iBeta] += r_alphaS1 * BmomentA_alpha_beta * cBar[posBeta2][6];
						
						double r_betaS2 = w2 * cBar[iBeta][6];  //betaDash=beta
						
						for (int stenc1=0; stenc1<6; stenc1++) // careful here: case stenc1=6 already covered in previous loop...
						{
							int s1[3] = { -Stencil[stenc1][0][0]+Stencil[stenc1][1][0], -Stencil[stenc1][0][1]+Stencil[stenc1][1][1], -Stencil[stenc1][0][2]+Stencil[stenc1][1][2] };
							int alphaDash[3] = { alpha0+s1[0], alpha1+s1[1], alpha2+s1[2] };
							int posAlpha2 = position2d(alphaDash[1],alphaDash[2]);
							if (alpha0>=-s1[0] and alpha1>=-s1[1] and alpha2>=-s1[2])
								stiffMat[posAlpha2][iBeta] += cBar[posAlpha2][5-stenc1] * BmomentA_alpha_beta* r_betaS2;
						}									
						beta2++;
						iBeta++;
					}
				}			
				alpha2++;
				iAlpha++;
			}
		}
		
		t1Dash= clock();
		cputime[1] = ((double) (t1Dash-t0Dash) ) / CLOCKS_PER_SEC; // cpu time for S_sigma sigma 
		
		/// start computing S_{sigma,W} ///
		
		nDash = n-1;
		#ifdef PRECOMP
		init_precomp2d(precomp, nDash, q, mp, quadraWN);	
		#else
		copy_Data_at_Stroud(q, v1, v2, v3, Bmoment, matValNodes, nb_Array);	
		#endif
		
		#ifdef PRECOMP
		Bmoment2d (nDash, q, mp, nb_Array, v1, v2, v3, binomialMat, precomp, Bmoment, matValNodes);
		#else
		Bmoment2d_Index( nDash, q, nb_Array, Bmoment, BmomentInter, quadraWN );
		M = MAX(nDash,q-1); // indexing variable
		#endif
		
		Shift = ( n*(n+1) ) / 2;
		
		iAlpha = 0;
		for (int alpha0=n-1; alpha0>=0; alpha0--)
		{
			int alpha2=0;
			#ifdef PRECOMP
			int posAlpha0 = ( (n-1-alpha0)*(n-1-alpha0+1) )/2;
			#else
			
			int posAlpha0 = alpha0*(M+1); // indexing of BmomentA entries w.r.t. position2d2( . , M)
			#endif
			for (int alpha1=n-1-alpha0; alpha1>=0; alpha1--)
			{
			
			#ifdef PRECOMP
			int posAlpha = posAlpha0 + alpha2;
			#else
			int posAlpha = posAlpha0 + alpha1;
			#endif
	
			double BmomentA_alpha = Bmoment[ posAlpha ][0];
			
			for (int stenc=0; stenc<6; stenc++)
			{
				double s[3] = {-Stencil[stenc][0][0]+Stencil[stenc][1][0], -Stencil[stenc][0][1]+Stencil[stenc][1][1], -Stencil[stenc][0][2]+Stencil[stenc][1][2] };
				double alphaDash[3] = { alpha0+s[0], alpha1+s[1], alpha2+s[2] };
				int posAlphaS = position2d(alphaDash[1],alphaDash[2]);
				
				if (alpha0>=-s[0] and alpha1>=-s[1] and alpha2>=-s[2])  // in order to avoid calling invalid entries of cBar
				{
				for (int i=0+Shift; i<3+Shift; i++)
					stiffMat[ position2d(alpha1+s[1], alpha2+s[2]) ][ i ] += cBar[posAlphaS][5-stenc] * BmomentA_alpha / Area2d(v1, v2, v3);// using the symmetry in Stencil
				}
			}
			
			int posAlphaS = iAlpha;  // stenc=6; alpha+s = alpha; posAlphaS = iAlpha
			
			for (int i= 0 +Shift; i< 3+Shift; i++)
				stiffMat[posAlphaS][ i ] += cBar[posAlphaS][6] * BmomentA_alpha / Area2d(v1, v2, v3);
			
			
			alpha2++;
			iAlpha++;
			}
		}
		
		
		for (int row=0; row < (n*(n+1))/2; row++)
		{
			for (int col= (n*(n+1))/2; col < (n*(n+1))/2 + 3; col++)
				stiffMat[col][row] = stiffMat[row][col]; 	// the stiffness matrix is symmetric
		}
		
		t2Dash = clock();	
		cputime[2] = ((double) (t2Dash-t1Dash) ) / CLOCKS_PER_SEC; // cpu time for S_sigma W
		
	
  } // end if n>1
  
  /// start computing S_WW ///
  
  nDash = 0;
	#ifdef PRECOMP
	init_precomp2d(precomp, nDash, q, mp, quadraWN);
	#else
	copy_Data_at_Stroud(q, v1, v2, v3, Bmoment, matValNodes, nb_Array);	
	#endif
	
	#ifdef PRECOMP
	Bmoment2d (nDash, q, mp, nb_Array, v1, v2, v3, binomialMat, precomp, Bmoment, matValNodes);
	#else
	
	Bmoment2d_Index( nDash, q, nb_Array, Bmoment, BmomentInter, quadraWN );
	M = MAX(nDash,q-1); // indexing variable
	#endif
  
  if (n<2)
		Shift=0; // only Whitney elements, so no shift
	
  
  for (int i=0+Shift; i < 3 +Shift; i++)
  {
		for (int j=0+Shift; j<3+Shift; j++)
			stiffMat[i][j] = 1./Area2d(v1, v2, v3)/Area2d(v1,v2,v3) * Bmoment[0][0];
  }  
  
  t1 = clock();
  
  cputime[0] = ( (double)  (t1-t0) ) /CLOCKS_PER_SEC ; 

  #ifdef CHECK
  std::cout.precision(3); // set number of digits
	
  std::cout<<"\n";
  if (n<2)
  {
		for (int row=0; row< len_Stiff; row++)
		{
			for (int col=0; col< len_Stiff; col++)	
			std::cout<<std::scientific<< stiffMat[row][col]<<"\t ";
			std::cout<<"\n";
			
		}
  }
  else
  {

		for (int row=0; row< len_Stiff; row++)// check (non-zero) stiffness matrix entries
		{
			for (int col=0; col< len_Stiff; col++)	
				std::cout<<std::scientific<< stiffMat[row][col]<<"\t ";
			std::cout<<"\n";  
		}
		
// 	for (int row=0; row< len_Stiff-3; row++)// check S_{sigma,sigma}
// 	{
// 	  for (int col=0; col< len_Stiff-3; col++)	
// 		std::cout<<std::scientific<< stiffMat[row][col]<<"\t ";
// 	  std::cout<<"\n";
// 	  
// 	}	
		
  }
  
  #endif
  
  return (double) ( (t1-t0) ) /CLOCKS_PER_SEC ;
}


//// COMPUTING ELEMENT LOAD VECTOR ///////////////////////////////////


#ifdef PRECOMP
double 
Load2d_Curl( int n, 
						 int q, double v1[2], double v2[2], double v3[2],
						 double **binomialMat, double normalMat[][2],
						 double **precomp, int mp, 
						 double **Bmoment, double **BmomentInter,
						 double *loadVect, double **matValNodes, 
						 double **quadraWN, double **cRing, double cputime[3])
#else
double 
Load2d_Curl( int n, 
						 int q, double v1[2], double v2[2], double v3[2],
						 double **binomialMat, double normalMat[][2],
						 double **Bmoment, double **BmomentInter,
						 double *loadVect, double **matValNodes, 
						 double **quadraWN, double **cRing,
						 double cputime[3])
#endif
{
  
  int len_Load = dimCurl(n); // dimension of element load vector 

  for (int row=0; row<len_Load; row++)
		loadVect[row] = 0; // initialize load vector entries to zero
	
  clock_t t0, t1, t0_Mmt, t1_Mmt; 
	
  double Const = -1./2/Area2d(v1,v2,v3);    // scaling between normals2d and gradients
	
  int Shift=0; 
  double timing_Mmt = 0, cputimeSigma = 0, timing0 = 0;
 
	int nb_Array = 2; // vector-valued coefficients
	int nDash; // B-moment order
	
  if (n>1)
  {
		/// start computing F_sigma ///
		
		t0 = clock();		
		Shift = ((n+1)*(n+2)) / 2;  // shift needed for storing the F_sigma entries
		int cRing_shift = (n*(n+1))/2;
		
		t1 = clock();
		
		timing0 = ( (double)(t1-t0) ) / CLOCKS_PER_SEC; // cpu_timing for computing sequence CRing
		
		t0_Mmt = clock();
		
		nDash = n;	
		// assign values to auxilliary arrays needed in B-moment computation
		#ifdef PRECOMP
		init_precomp2d(precomp, nDash, q, mp, quadraWN);
		#else
		copy_Data_at_Stroud(q, v1, v2, v3, Bmoment, matValNodes, nb_Array);
		#endif
		
		// compute B-moments:
		#ifdef PRECOMP
		Bmoment2d (nDash, q, mp, nb_Array, v1, v2, v3, binomialMat, precomp, Bmoment, matValNodes);
		#else
		Bmoment2d_Index(nDash, q, nb_Array, Bmoment, BmomentInter, quadraWN ); 
		int M = MAX(nDash,q-1);
		#endif
		
		t1_Mmt = clock();
		
		timing_Mmt = ( (double)(t1_Mmt-t0_Mmt) ) / CLOCKS_PER_SEC; // cpu timing for computing Bmoments of order n
		
		
		t0 = clock();
		
		
		int iBeta=0;
		for (int beta0=n-1; beta0>=0; beta0--)
		{
			int beta2=0;
			
			#ifdef PRECOMP
			int posBeta0 = ((n-1-beta0)*(n-1-beta0+1)) / 2;
			#else
			int posBeta0 = beta0 * (M+1); 	// indexing of Bmoment entries w.r.t index( . , M)
			#endif
			
			for (int beta1=n-1-beta0; beta1>=0; beta1--)
			{
				#ifdef PRECOMP
				int posBeta = posBeta0 + beta2; // posBeta = position2d(beta1,beta2)
				#else
				int posBeta = posBeta0 + beta1;
				#endif
				
				//int beta[3] = {beta0, beta1, beta2};
				
				for (int iRho=0; iRho<3; iRho++)
				{
					#ifdef PRECOMP
					int posBetaRho = posBeta
					+ DELTA(iRho,1) * (beta1+beta2+1)
					+ DELTA(iRho,2) * (beta1+beta2+2);
					#else
					int posBetaRho = posBeta + DELTA(iRho,0)*(M+1) + DELTA(iRho,1);
					#endif
					
					loadVect[ iBeta+Shift ] += cRing[iBeta][iRho] * Bmoment[posBetaRho][0] + cRing[cRing_shift+iBeta][iRho] * Bmoment[posBetaRho][1];  // not multiplied by Const
				}
				
				beta2++;
				iBeta++;
			}
		}
		
		
		t1 = clock(); // cpu timing for computing F_sigma
		
		cputimeSigma = timing0 + ( (double)(t1-t0) ) / CLOCKS_PER_SEC;
		
		#ifdef DIV_ARTICLE // Whitney load vector is computed using B-moments of order n
		/// start computing F_W ///
		
		Shift = ((n+1)*(n+2))/2 + (n*(n+1))/2;
		
		t0 = clock();
		iBeta=0;
		for (int beta0=n-1; beta0>=0; beta0--)
		{
			#ifdef PRECOMP
			int posBeta0 = ((n-1-beta0)*(n-1-beta0+1)) / 2;
			#else
			int posBeta0 = beta0 * (M+1);
			#endif
			int beta2=0;
			for (int beta1=n-1-beta0; beta1>=0; beta1--, beta2++, iBeta++)
			{
				#ifdef PRECOMP
				int posBeta = posBeta0 + beta2; // posBeta = position2d(beta1,beta2)
				#else
				int posBeta = posBeta0 + beta1;
				#endif
				int beta[3]={beta0,beta1,beta2};
				
				for (int i=0; i<3; i++)
				{
					for (int r=-1; r<=1; r += 2)
					{
						
						#ifdef PRECOMP
						int posBetaIR = posBeta
						+ DELTA((i+r+3)%3,1) * (beta1+beta2+1)
						+ DELTA((i+r+3)%3,2) * (beta1+beta2+2);
						#else
						int posBetaIR = posBeta + DELTA((i+r+3)%3,0) *(M+1) + DELTA((i+r+3)%3,1); // pos(beta+e_{i+r})
						#endif
												
						loadVect[i + Shift] += r * Const * (beta[(i+r+3)%3]+1.) * ( normalMat[(i-r+3)%3][0] * Bmoment[posBetaIR][0] + normalMat[(i-r+3)%3][1] * Bmoment[posBetaIR][1] ) / n;
						
					}
				}
			}
		}
		
		t1 = clock(); // cpu timing for computing F_W
		
		cputime[0] = cputimeSigma + ( (double) (t1-t0) ) / CLOCKS_PER_SEC; // cpu time of NON-gradient blocks
		
		#endif
		
		
		/// start computing F_nabla ///
		
		t0_Mmt = clock();
		

		LowerMoment(n, q, n-1, Bmoment, BmomentInter, nb_Array); // lowers Bmoment of order n to order n-1: careful, using position2d(.,n-1) with non-PRECOMP	
		
		t1_Mmt = clock(); // cpu timing for lowering Bmoments to order n-1		
		timing_Mmt += ( (double)(t1_Mmt-t0_Mmt) ) / CLOCKS_PER_SEC;
		
		#ifdef DIV_ARTICLE
		cputime[2] = timing_Mmt; // cpu time for computing B-moments if n>1 with macro DIV_ARTICLE
		#endif
		
		t0 = clock();
		
		int iAlpha=0;
		for (int alpha0 = n-1; alpha0>=0; alpha0--)
		{
			int alpha2=0;
			
			#ifdef PRECOMP
			int posAlpha0 = ( (n-1-alpha0)*(n-1-alpha0+1) ) / 2;
			#else
			int posAlpha0 = alpha0 * n; // Bmoment entries w.r.t position2d2( . , n-1)
			#endif
			for (int alpha1 = n-1-alpha0; alpha1>=0; alpha1--)
			{
				#ifdef PRECOMP
				int posAlpha = posAlpha0 + alpha2; // posAlpha = position2d(alpha1,alpha2)
				#else
				int posAlpha = posAlpha0 + alpha1;
				#endif
				
				double bMoment00 = Bmoment[posAlpha][0]; 
				double bMoment11 = Bmoment[posAlpha][1];    // create temp variables (reduce memory access calls to Bmoment...)
				
				for (int iRho=0; iRho<3; iRho++)
				{
					int iAlphaRho = position2d( alpha1+ DELTA(iRho,1), alpha2+ DELTA(iRho,2) );
					
					loadVect[ iAlphaRho ] += ( normalMat[iRho][0] * bMoment00 + normalMat[iRho][1] * bMoment11 ) * n * Const;
					
				}
				
				alpha2++;
				iAlpha++;
			}
		}
		
		
		t1 =clock(); // cpu timing for computing F_nabla
		
		cputime[1] = (double) ((t1-t0)) / CLOCKS_PER_SEC; // cpu time involving the gradients
		
  } // end if n>1
  
  /// start computing F_W ///
  

	#ifdef DIV_ARTICLE
	
	if (n==1) // if n>1 with macro DIV_ARTICLE: F_W already computed above
	{
		t0_Mmt = clock();
		
		int nDash = 1; // case n=1	
		// assign values to auxilliary arrays needed in B-moment computation
		#ifdef PRECOMP
		init_precomp2d(precomp, nDash, q, mp, quadraWN);
		#else
		copy_Data_at_Stroud(q, v1, v2, v3, Bmoment, matValNodes, nb_Array);
		#endif
		
		#ifdef PRECOMP
		Bmoment2d (nDash, q, mp, nb_Array, v1, v2, v3, binomialMat, precomp, Bmoment, matValNodes);
		#else
		Bmoment2d_Index( nDash, q, nb_Array, Bmoment, BmomentInter, quadraWN );
		int M = MAX(nDash, q-1);
		#endif
		

		t1_Mmt = clock();
		timing_Mmt = ( (double)(t1_Mmt-t0_Mmt) ) / CLOCKS_PER_SEC; // if n=1, only Whitney functions are involved
		cputime[2] = timing_Mmt; // cpu time for computing B-moments
  
		t0 = clock();
		double prod[2]={0,0};
		for (int i=0; i<3; i++)
		{
			for (int r=-1; r<=1; r += 2)
			{
				#ifdef PRECOMP
				int posIR = position2d( DELTA( (i+r+3)%3, 1 ), DELTA( (i+r+3)%3, 2 ) );
				#else
				int posIR = DELTA( (i+r+3)%3, 0 ) * (M+1) + DELTA((i+r+3)%3 , 1);
				#endif
				
				loadVect[ i+Shift ] += r * Const * ( normalMat[(i-r+3)%3][0] * Bmoment[posIR][0] + normalMat[(i-r+3)%3][1] * Bmoment[posIR][1] );
			}
		}
		
  
		t1 = clock();
		//////////////////////////////////
		cputime[0] = ( (double) (t1-t0) ) / CLOCKS_PER_SEC; // cpu time of NON-gradient blocks
		
	}
	
	#else // default: same as in thesis for handling B-moments of different orders, F_W always computed LAST, whether n>1 or not
  
  if (n>1)
		Shift = ((n+1)*(n+2))/2 + (n*(n+1))/2;
  
  t0_Mmt = clock();
  
	
	nDash = 1; // case n=1	
	// assign values to auxilliary arrays needed in B-moment computation
	#ifdef PRECOMP
	init_precomp2d(precomp, nDash, q, mp, quadraWN);
	#else
	copy_Data_at_Stroud(q, v1, v2, v3, Bmoment, matValNodes, nb_Array);
	#endif
	
	
	#ifdef PRECOMP
	Bmoment2d (nDash, q, mp, nb_Array, v1, v2, v3, binomialMat, precomp, Bmoment, matValNodes);
	#else
	Bmoment2d_Index( nDash, q, nb_Array, Bmoment, BmomentInter, quadraWN );
	int M = MAX(nDash, q-1);
	#endif
  
  t1_Mmt = clock();
  
  timing_Mmt += ( (double)(t1_Mmt-t0_Mmt) ) / CLOCKS_PER_SEC;
  
  cputime[2] = timing_Mmt; // cpu time for computing B-moments
  
  
  t0 = clock();
  

  for (int i=0; i<3; i++)
  {
		for (int r=-1; r<=1; r += 2)
		{
			#ifdef PRECOMP
			int posIR = position2d( DELTA( (i+r+3)%3, 1 ), DELTA( (i+r+3)%3, 2 ) );
			#else
	  	int posIR = DELTA( (i+r+3)%3, 0 ) * (M+1) + DELTA((i+r+3)%3 , 1);
			#endif  
			
			loadVect[ i+Shift ] += r * Const * ( normalMat[(i-r+3)%3][0] * Bmoment[posIR][0] + normalMat[(i-r+3)%3][1] * Bmoment[posIR][1] );
		}
  }
  
  t1 = clock();
	
	cputime[0] = cputimeSigma + ( (double) (t1-t0) ) / CLOCKS_PER_SEC; // cpu time of NON-gradient blocks
	
	#endif // end not DIV_ARTICLE
	

  #ifdef CHECK
  std::cout.precision(3); // set number of digits
  
  std::cout<<"Load vector with n="<<n<<":\n";
  for (int row=0; row< len_Load; row++)
		std::cout<< std::scientific<<loadVect[row]<<"\n"; 
  #endif
  
  return cputimeSigma + ( (double) (t1-t0) ) / CLOCKS_PER_SEC;

}


////////// high-level routines ////////////////////////////////////////////////

// compute H(curl) mass matrix associated with matrix-valued function Kappa
// the output matrix is of dimention dimCurl(n)
// Kappa is a (symmetric) matrix-valued function which produces the mass matrix coefficients
// Cval stores the coefficients values at the quadrature points
// v1, v2, v3 are the element's vertices
// functval allows the option to use array of function values at quadrature nodes as input for the mass matrix coefficients
void
get_mass2dCurl(double **massMat, int n, void (*Kappa) (double [2], double [2][2]),
							 double *Cval, double v1[2] , double v2[2], double v3[2], int functval )
{
	
	double **binomialMat;
	double cputime[2]={0,0}; // passed as argument to Mass2d_Curl
	double normalMat[3][2] = { {0, 0}, {0, 0}, {0, 0} };  // store normals to the edges	
	normals2d(v1,v2,v3,normalMat);
	
	int len_binomial = 2*n+2;
	binomialMat = create_BinomialMat(len_binomial); //allocate memory to binomial coefficients
	
	#ifdef PRECOMP
	double **precomp;	
	#endif
	double **matValNodes; // now also used by non-PRECOMP...
	
	double **BmomentInter; // needed with LowerMoment
	
	double **Bmoment, **Bmomentab;
  double **quadraWN;
	
	double **cRing; // store cRing coefficients
	
	// initialize number of quadrature pointers, and integers needed for indexing Bmoment entries
	int q = n+1; 
  int nDash = 2*n ;  // highest Bmoment order required for mass matrix
  #ifdef PRECOMP
	int mp = MAX (nDash, q-1);  // "precomp" size
  #endif
	int nb_Array = 3;  //matrix-valued coefficients
	int len_Quadra = q + 1;     // space required for storing Jacobi nodes of order q is q, but indexing starts at 1
  quadraWN = create_quadraWN2d(len_Quadra);	
	
	// initialize auxilliary arrays		
	
	int lenMoments = len_Moments2d(nDash,q);
  Bmoment = create_Bmoment(lenMoments, nb_Array);
  Bmomentab = create_Bmoment(lenMoments, 6); // multiply normals to Bmoments and store into Bmomentab
	
	if (n>1)
	{
		cRing = create_cRing(n);
		CRing(n, normalMat,cRing);
	}
	#ifdef PRECOMP
	precomp = create_precomp2d(mp+1);	// store precomputed arrays
	#endif
	int len_matValNodes = q * q ;      // space required for 2D array with dimension q
  matValNodes = create_matValNodes2d(len_matValNodes);
	
	BmomentInter = create_Bmoment(lenMoments, nb_Array); // needed by LowerMoment
	
	
	computeBinomials(binomialMat, len_binomial);  //compute binomials
	
	//assign values to auxilliary arrays for computing matrix-valued B-moments
	assign_quadra2d(q, quadraWN);	 // initialize quadrature weights and nodes
	
	if (functval==1)
	{
		#ifdef PRECOMP
		data_at_Nodes_Cval2d (matValNodes, q, Cval, nb_Array); // read values stored in Cval
		#else
		init_Bmoment2d_Cval (Cval, q, v1, v2, v3, matValNodes, nb_Array);
		#endif
	}
	else
	{
		#ifdef PRECOMP
		data_at_Nodes_Stiff2d (Kappa, matValNodes, q, quadraWN, v1, v2, v3); // storing values of Kappa at Stroud nodes into matValNodes
		#else
		init_BmomentC_Stiff2d ( Kappa, q, v1, v2, v3, matValNodes, quadraWN );
		#endif
	}
	
	// compute mass matrix:
	#ifdef PRECOMP 
	Mass2d_Curl(n, q, v1, v2, v3, binomialMat, normalMat, precomp, mp, Bmoment, BmomentInter, Bmomentab, massMat, matValNodes, quadraWN, cRing, cputime);
	#else
	Mass2d_Curl(n, q, v1, v2, v3, binomialMat, normalMat, Bmoment, 
							BmomentInter, Bmomentab, massMat, matValNodes, quadraWN, cRing, cputime);
	#endif
	
	
	#ifdef PRECOMP
	delete_pointers_Curl(precomp, Bmoment, BmomentInter, matValNodes,quadraWN);
	delete_Bmoment(Bmomentab);
	#else
	delete_pointers_Curl(Bmoment, BmomentInter, matValNodes, quadraWN);
	delete_Bmoment(Bmomentab);
	#endif
	
	if (n>1)
		delete_cRing(cRing);
	
	delete_BinomialMat (binomialMat, len_binomial);
	
	#ifdef CHECK
	int len_Mass = dimCurl (n); // dimension of the elemental mass matrix
	std::cout<<"Mass matrix entries stored into array massMat of dimension "<<len_Mass<<"\n";
	#endif
	
}


void
get_stiffness2dCurl(double **stiffMat, int n, double (*A) (double v[2]), double *Cval,
										double v1[2], double v2[2], double v3[2], int functval)
{
	double **binomialMat;
	double cputime[3];
	
	int len_binomial = 2*n+2;
	binomialMat = create_BinomialMat(len_binomial); //allocate memory to binomial coefficients
	
	#ifdef PRECOMP
	double **precomp;	
	#endif
	double **matValNodes; // now also used by non-PRECOMP...
	
	double **BmomentInter; // needed with LowerMoment
	
	double **Bmoment;
  double **quadraWN;
	
	double **cBar; // store cBar coefficients
	
	// initialize number of quadrature pointers, and integers needed for indexing Bmoment entries
	int q = n+1; 
  int nDash = 2*n ;  // highest Bmoment order required for mass matrix
  #ifdef PRECOMP
	int mp = MAX (nDash, q-1);  // "precomp" size
  #endif
	int nb_Array = 1;  //scalar-valued coefficients
	int len_Quadra = q + 1;     // space required for storing Jacobi nodes of order q is q, but indexing starts at 1
  quadraWN = create_quadraWN2d(len_Quadra);	
	
	// initialize auxilliary arrays		
	
	int lenMoments = len_Moments2d(nDash,q);
  Bmoment = create_Bmoment(lenMoments, nb_Array);
	
	if (n>1)
	{
		cBar = create_cBar(n);
		CBar(n, v1, v2, v3, cBar);
	}
	
	#ifdef PRECOMP
	precomp = create_precomp2d(mp+1);	// store precomputed arrays
	#endif
	int len_matValNodes = q * q ;      // space required for 2D array with dimension q
  matValNodes = create_matValNodes2d(len_matValNodes);
	
	BmomentInter = create_Bmoment(lenMoments, nb_Array); // needed by LowerMoment
	
	
	computeBinomials(binomialMat, len_binomial);  //compute binomials
	
	//assign values to auxilliary arrays for computing matrix-valued B-moments
	assign_quadra2d(q, quadraWN);	 // initialize quadrature weights and nodes
	
	if (functval==1) // read values stored in Cval
	{
		#ifdef PRECOMP
		data_at_Nodes_Cval2d (matValNodes, q, Cval, nb_Array); 
		#else
		init_Bmoment2d_Cval (Cval, q, v1, v2, v3, matValNodes, nb_Array);
		#endif
	}
	else // compute values of A at Stroud nodes
	{
		#ifdef PRECOMP
		data_at_Nodes_Mass2d (A, matValNodes, q, quadraWN, v1, v2, v3); 
		#else
		init_BmomentC_Mass2d ( A, q, v1, v2, v3, matValNodes, quadraWN );
		#endif
	}
	
	// compute stiffness matrix:
	#ifdef PRECOMP
	Stiff2d_Curl( n, q, v1, v2, v3, binomialMat, precomp, mp, Bmoment,  BmomentInter, cBar, stiffMat, matValNodes, quadraWN, cputime);
	#else
	Stiff2d_Curl( n, q, v1, v2, v3, binomialMat, Bmoment, BmomentInter, cBar, stiffMat, matValNodes, quadraWN, cputime);
	#endif
	
	if (n>1)
		delete_cBar(cBar);
	
	#ifdef PRECOMP
	delete_pointers_Curl(precomp, Bmoment, BmomentInter, matValNodes,quadraWN);
	#else
	delete_pointers_Curl(Bmoment, BmomentInter, matValNodes, quadraWN);
	#endif
	
	delete_BinomialMat (binomialMat, len_binomial);
	
	#ifdef CHECK
	int len_Stiff = dim_nonGradCurl(n); // dimension of non-gradient stiffness matrix
	std::cout<<"Non-zero stiffness matrix entries stored into array stiffMat of dimension "<<len_Stiff<<"\n";
	#endif
	
}

void
get_load2dCurl(double *loadVect, int n, void (*F)( double [2], double [2]), double *Cval,
							 double v1[2], double v2[2], double v3[2], int functval)
{
	double **binomialMat;
	double cputime[3];
	double normalMat[3][2] = { {0, 0}, {0, 0}, {0, 0} };  // store normals to the edges	
	normals2d(v1,v2,v3,normalMat);
	
	
	int len_binomial = 2*n+2;
	binomialMat = create_BinomialMat(len_binomial); //allocate memory to binomial coefficients
	
	#ifdef PRECOMP
	double **precomp;	
	#endif
	double **matValNodes; // now also used by non-PRECOMP...
	
	double **BmomentInter; // needed with LowerMoment
	
	double **Bmoment;
  double **quadraWN;
	
	double **cRing; // store cRing coefficients
	
	// initialize number of quadrature pointers, and integers needed for indexing Bmoment entries
	int q = n+1; 
  int nDash = 2*n ;  // highest Bmoment order required for mass matrix
  #ifdef PRECOMP
	int mp = MAX (nDash, q-1);  // "precomp" size
  #endif
	int nb_Array = 2;  //vector-valued coefficients
	int len_Quadra = q + 1;     // space required for storing Jacobi nodes of order q is q, but indexing starts at 1
  quadraWN = create_quadraWN2d(len_Quadra);	
	
	// initialize auxilliary arrays		
	
	int lenMoments = len_Moments2d(nDash,q);
  Bmoment = create_Bmoment(lenMoments, nb_Array);
	
	if (n>1)
	{
		cRing = create_cRing(n);
		CRing(n, normalMat,cRing); 
	}
	#ifdef PRECOMP
	precomp = create_precomp2d(mp+1);	// store precomputed arrays
	#endif
	int len_matValNodes = q * q ;      // space required for 2D array with dimension q
  matValNodes = create_matValNodes2d(len_matValNodes);
	
	BmomentInter = create_Bmoment(lenMoments, nb_Array); // needed by LowerMoment
	
	
	computeBinomials(binomialMat, len_binomial);  //compute binomials
	
	//assign values to auxilliary arrays for computing matrix-valued B-moments
	assign_quadra2d(q, quadraWN);	 // initialize quadrature weights and nodes
	
	if (functval==1)
	{
		#ifdef PRECOMP // read values stored in Cval
		data_at_Nodes_Cval2d (matValNodes, q, Cval, nb_Array); 
		#else
		init_Bmoment2d_Cval (Cval, q, v1, v2, v3, matValNodes, nb_Array);
		#endif
	}
	else
	{
		#ifdef PRECOMP // compute values of F at Stroud nodes 
		data_at_Nodes_Convec2d (F, matValNodes, q, quadraWN, v1, v2, v3); 
		#else
		init_BmomentC_Convec2d ( F, q, v1, v2, v3, matValNodes, quadraWN );
		#endif
	}
	// compute load vector:
	#ifdef PRECOMP
	Load2d_Curl(n, q, v1, v2, v3, binomialMat, normalMat, precomp, mp, Bmoment, BmomentInter, loadVect, matValNodes, quadraWN, cRing, cputime);
	#else
	Load2d_Curl(n, q, v1, v2, v3, binomialMat, normalMat, Bmoment, BmomentInter, loadVect, matValNodes, quadraWN, cRing, cputime);
	#endif
	
	
	#ifdef PRECOMP
	delete_pointers_Curl(precomp, Bmoment, BmomentInter, matValNodes,quadraWN);
	#else
	delete_pointers_Curl(Bmoment, BmomentInter, matValNodes, quadraWN);
	#endif
	
	if (n>1)
		delete_cRing(cRing);
	
	delete_BinomialMat (binomialMat, len_binomial);
	
	#ifdef CHECK
	int len_Load = dimCurl (n); // length of the elemental load vector
	std::cout<<"Load vector entries stored into loadVect of length "<<len_Load<<"\n";
	#endif
	
	
}



///////// RESIDUALS COMPUTATION /////////////////////////////


// Compute non-zero residual components for constitutive equation
// Cval contains values of randomly generated data at Stroud nodes
#ifdef PRECOMP
double 
residual_Constit ( int n, int q,
							 double v1[2], double v2[2], double v3[2],
							 double **binomialMat, double **precomp, int mp,
							 double **Bmoment, double *resVect, double **matValNodes,
							 double **quadraWN, double **cBar, double cputime[2],
							 double **CVal ) 
#else
double 
residual_Constit ( int n, int q,
							 double v1[2], double v2[2], double v3[2],
							 double **Bmoment, double **BmomentInter, double *resVect, 
							 double **quadraWN, double **cBar, double cputime[2],
							 double **CVal ) 
#endif
{
	
	clock_t t0, t1, tMmt0, tMmt1;
	
	double cputime_Moment = 0, cputime_Sigma=0;
	
	int len_Res, Shift=0;
	
	if (n>1)
		len_Res = (n*(n+1))/2 + 3; // sigma and Whitney
	else
		len_Res = 3; // Whitney only
		
	for (int row=0; row<len_Res; row++)
		resVect[row] = 0; // initialize residual vector entries

		
	int nb_Array = 1; // scalar-valued coefficients
	int nDash; // B-moment order
	
	
	if (n>1)
	{
		
		int Stencil[7][2][3]= { {{1,0,0},{0,1,0}}, {{1,0,0},{0,0,1}}, {{0,1,0},{0,0,1}}, {{0,0,1},{0,1,0}}, {{0,0,1},{1,0,0}}, {{0,1,0},{1,0,0}}, {{0,0,0},{0,0,0}} }; // needed for sigma components of residual vector
		
		
		/// compute Res_sigma ///
		
		tMmt0 = clock();
		
		nDash = n-1;
		// assign values to auxilliary arrays needed in B-moment computation
		#ifdef PRECOMP
		init_precomp2d(precomp, nDash, q, mp, quadraWN);
		data_at_Nodes_Coeff(nDash, q, nb_Array, CVal, matValNodes);
		#else
		init_Bmoment_Coeff(nDash, q, nb_Array, CVal, v1, v2, v3, Bmoment);
		#endif
		
		
		// Compute B-moments associated with randomly generated data:
		#ifdef PRECOMP
		Bmoment2d (nDash, q, mp, nb_Array, v1, v2, v3, binomialMat, precomp, Bmoment, matValNodes);
		#else
		Bmoment2d_Index(nDash, q, nb_Array, Bmoment, BmomentInter, quadraWN );
		int M = MAX(nDash,q-1);
		#endif
			
		
		tMmt1 = clock();
		
		cputime_Moment += ( (double)(tMmt1-tMmt0) ) / CLOCKS_PER_SEC;
		
		t0 = clock();
		
		CBar(n, v1, v2, v3, cBar);
		
		int iBeta=0;
		for (int beta0=n-1; beta0>=0; beta0--)
		{
			#ifdef PRECOMP
			int posBeta0 = ((n-1-beta0)*(n-1-beta0+1)) / 2;
			#else
			int posBeta0 = beta0 * (M+1); // indexing of BmomentA entries w.r.t. index2( . , M)
			#endif
			
			int beta2=0;
			for (int beta1=n-1-beta0; beta1>=0; beta1--, beta2++, iBeta++)
			{
				#ifdef PRECOMP
				int posBeta = posBeta0 + beta2; // posBeta = position2d(beta1,beta2)
				#else
				int posBeta = posBeta0 + beta1;
				#endif
				
				double BmomentA_beta = Bmoment[posBeta][0];
				
				for (int stenc=0; stenc<6; stenc++)//careful NOT to include last stenc (special case)
				{
					int s[3] = { -Stencil[stenc][0][0]+Stencil[stenc][1][0], -Stencil[stenc][0][1]+Stencil[stenc][1][1], -Stencil[stenc][0][2]+Stencil[stenc][1][2] };
					
					int betaDash[3] = { beta0+s[0], beta1+s[1], beta2+s[2]};
					int iBeta1 = position2d(betaDash[1],betaDash[2]);
					
					if (beta0>=-s[0] and beta1>=-s[1] and beta2>=-s[2])   // beta= betaDash-s: in order to avoid calling invalid entries of cBar
					{
						resVect[iBeta1] += cBar[iBeta1][5-stenc] * BmomentA_beta; //using symmetry of Stencil
					}					
				}				
				// case where betaDash = beta
				resVect[iBeta] += cBar[iBeta][6] * BmomentA_beta;				
				
			}
		}
		
		t1 = clock();
		
		cputime_Sigma = ( (double)(t1-t0) ) / CLOCKS_PER_SEC;
		
	}
	
	tMmt0 = clock();
	
	
	nDash = 0;
	// assign values to auxilliary arrays needed in B-moment computation
	#ifdef PRECOMP
	init_precomp2d(precomp, nDash, q, mp, quadraWN);
	data_at_Nodes_Coeff( nDash, q, nb_Array, CVal, matValNodes);
	#else
	init_Bmoment_Coeff( nDash, q, nb_Array, CVal, v1, v2, v3, Bmoment);
	#endif
	
	
	#ifdef PRECOMP
	Bmoment2d (nDash, q, mp, nb_Array, v1, v2, v3, binomialMat, precomp, Bmoment, matValNodes);
	#else
	Bmoment2d_Index(nDash, q, nb_Array, Bmoment, BmomentInter, quadraWN );
	#endif
	
	
	tMmt1 = clock();
	cputime_Moment += ( (double)(tMmt1-tMmt0) ) / CLOCKS_PER_SEC;
	
	cputime[1] = cputime_Moment; // cpu time for computing Bmoments
	
	if (n>1)
		Shift = (n*(n+1))/2;
	
	
	#ifdef DIV_ARTICLE
	; // with DIV_ARTICLE, do not count Whitney residual cpu timing
	
	#else // default (not DIV_ARTICLE)
	
	t0 = clock();
	
	/// compute Res_W ///
	
	for (int i=0+Shift; i < 3 +Shift; i++)
		resVect[i] = 1./Area2d(v1,v2,v3) * Bmoment[0][0]; // Res_W has identical components...
	
	t1 = clock();
	
	cputime[0] = cputime_Sigma + ( (double)(t1-t0) ) / CLOCKS_PER_SEC; // cpu time for residual vector
	
	
	#endif // end not DIV_ARTICLE
	
	
	#ifdef CHECK
	#ifdef PRECOMP
	std::cout<<"\nResidual vector (PRECOMP):\n";
	#else
	std::cout<<"\nResidual vector:\n";
	#endif
	for (int row=0; row < len_Res; row++)
		std::cout<<std::scientific<<resVect[row]<<"\n";
	std::cout<<"\n";
	#endif
	
	return cputime[0]; // cpu time for residual vector
	
}


// assigns memory to a coefficient sequence of length lenCoeff
// parameter nb_Array allows for flexibility in the data structure (scalar, vector, or matrix)
double ** 
create_Coeff(int lenCoeff, int nb_Array)
{
	
	double **Coeff = new double *[lenCoeff];

  double *Coeff_array = new double[nb_Array * lenCoeff];
  double *p = Coeff_array;

  for (int i = 0; i < lenCoeff; p += nb_Array, i++)
      Coeff[i] = p;
    
  return Coeff;
}

void delete_Coeff(double **Coeff)
{
	delete Coeff[0];
	delete Coeff;
}

// random SCALAR coefficient sequence of length lenCoeff
// uses position2d indexing
void 
randomCoeff(double *random_Coeff, int len_randCoeff)
{
	srand(time(0)); // otherwise generate the same numbers
	for (int i=0; i< len_randCoeff; i++)
	{
		random_Coeff[i] = -1. + (float)(rand() )/RAND_MAX;
		//random_Coeff[i] = sin(i); // uncomment this if want residuals associated with particular B-form coefficients
	}
}

// initialize B-form coeff. associated with BB polynomials of order n with random_Coeff
// needed with residuals appearing in constitutive equations
// random_Coeff generated using routine randomCoeff
void 
init_BForm_Coeff( double *random_Coeff, int len_randCoeff,
							double **Coeff_p)
{	
	for (int i=0; i < len_randCoeff; i++)
		Coeff_p[i][0] = random_Coeff[i]; 
}


// coefficients associated with sigma basis functions
// given by randomly generated sequence random_Coeff
// sigma2Bform makes a transformation to B-form coefficients
// WARNING: only used with n>1
void 
sigma2Bform( double *random_Coeff, int n, double **Coeff_u, int lenCoeff_u,
							double **cBar)
{
	
	if (n<=1)
	{
		std::cout<<"Please choose the polynomial order at least equal to 2 with this operation.\n";
		exit(EXIT_FAILURE);
	}
	
	int Stencil[7][2][3]= { {{1,0,0},{0,1,0}}, {{1,0,0},{0,0,1}}, {{0,1,0},{0,0,1}}, {{0,0,1},{0,1,0}}, {{0,0,1},{1,0,0}}, {{0,1,0},{1,0,0}}, {{0,0,0},{0,0,0}} }; 
	
	for (int i=0; i < lenCoeff_u; i++) // initialize Coeff entries to zero
		Coeff_u[i][0] = 0;
	
	int iAlpha=0;
	for (int alpha1=n-1; alpha1>=0; alpha1--)
	{
		int alpha3=0;
		for (int alpha2=n-1-alpha1; alpha2>=0; alpha2--,alpha3++, iAlpha++)
		{
			for (int stenc=0; stenc < 6; stenc++)
			{
				int s[3] = { -Stencil[stenc][0][0]+Stencil[stenc][1][0], -Stencil[stenc][0][1]+Stencil[stenc][1][1], -Stencil[stenc][0][2]+Stencil[stenc][1][2] };
				
				int eta[3] = {alpha1+s[0], alpha2+s[1], alpha3+s[2]};
				
				if ( eta[0] >= 0 and eta[1] >= 0 and  eta[2]>= 0 )
				{
					
					int iEta = position2d(eta[1], eta[2]); // random_Coeff uses lexicographical indexing
					
					double rand_coeff_Eta = random_Coeff[iEta];
					
					Coeff_u[iAlpha][0] += rand_coeff_Eta * cBar[ iEta ][5-stenc];
				}
			}
			Coeff_u[iAlpha][0] += random_Coeff[iAlpha] * cBar[iAlpha][6]; // case eta = alpha
		}
	}
	
}


// evaluate function with B-form coeff. or order n given by Coeff at Stroud nodes of order q+1
// nb_Array indicates the structure of Coeff (scalar, vector, or matrix)
// Coeff initialized with B-form coefficients and indexed using position2d
// quadraWN contains Gauss-Jacobi quadrature rule on unit interval
double
Evaluate_at_Stroud( int n, int q, double **Coeff, double **CoeffInter, int nb_Array)
{
	int len_Quadra = q + 1; 
	double **quadraWN = create_quadraWN2d(len_Quadra);
	
	#ifdef GAUJAC	
	#else	
	if (q>80)
	{
		std::cout<<"\nThe polynomial order is too large. Activate GAUJAC option.\n";
		exit (EXIT_FAILURE);
	}
	#endif // end not GAUJAC
	
	
	gaussJacobiUnit2D (q, quadraWN); // macro GAUJAC implemented in gaussJacobiUnit2D
	
	
	clock_t t0, t1;
	
	t0 = clock();
	
	int M = MAX(n,q-1); // M is used for indexing
	
	
	//initialize CoeffInter, at this point, array Coeff has been initialized with B-form coeff.
	for (int iMu = 0; iMu < (M+1)*(M+1); iMu++)
	{
		for (int ell=0; ell < nb_Array; ell++)
			CoeffInter[ iMu ][ ell ] = 0;
	}
		
	
	double xi, wgt, s, r, B;
	double fact[nb_Array];
	
	//convert second index
	for (int j=0; j< q; j++)
	{
		#ifdef GAUJAC
		xi  = quadraWN[3][j+1];
		wgt = quadraWN[2][j+1];
		#else
		xi  = jacobi[1][q-2][j];
		wgt = jacobi[0][q-2][j];
		#endif
	
	
		s = 1 - xi;
		r = xi / (1 - xi);		
		for (int mu1 = 0; mu1 <= n ; mu1++)
		{
			B = pow(s, n-mu1);
				
			int index_mu1j = position2d2(mu1,j,M);
			
			for (int mu2=0; mu2 <= n-mu1; mu2++)
			{ 
				int i_mu1mu2 = position2d(mu2,n-mu1-mu2); 			 
				
				for (int ell=0; ell < nb_Array; ell++)
				{
					fact[ell] = B * Coeff[ i_mu1mu2 ][ell];
					
					
					CoeffInter[ index_mu1j ][ell] += fact[ell];
				}
				B *= r * (n-mu1-mu2) / (1+mu2);
			}
		}
				
	}
		

	for (int iMu = 0; iMu < (M+1)*(M+1); iMu++)
	{
		for (int ell=0; ell < nb_Array; ell++)
			Coeff[ iMu ][ ell ] = 0;
	}
	
	
	//convert first index
	for (int i=0; i< q; i++)
	{
		#ifdef GAUJAC
		xi  = quadraWN[1][i+1];
		wgt = quadraWN[0][i+1];
		#else
		xi  = legendre[1][q-2][i];
		wgt = legendre[0][q-2][i]; 
		#endif
	  
    s = 1 - xi;
    r = xi / (1 - xi);
		
		B = pow(s,n);
		for (int mu1=0; mu1 <=n; mu1++)
		{
			for (int j=0; j < q; j++)
			{
				int index_ij = position2d2(i,j,M);
				int index_mu1j = position2d2(mu1,j,M);
				
				for (int ell=0; ell < nb_Array; ell++)
				{
					fact[ell] = B * CoeffInter[index_mu1j][ell];
					Coeff[index_ij][ell] += fact[ell];
				}
			}
			B *= r * (n-mu1) / (1+mu1);
		}
	
	}
	
	t1 = clock();
	

	delete_quadraWN(quadraWN);
	
	return (double) ( (t1-t0) )/ CLOCKS_PER_SEC;

}


// CVal contains the values of the data at the Stroud nodes
// CVal initialized by means of Evaluate_at_Stroud
#ifdef PRECOMP
void
data_at_Nodes_Coeff( int n, int q, int nb_Array, double **CVal, 
										double **matValNodes)
{
		
	int M = MAX(n,q-1); // used for indexing in Evaluate_at_Stroud
			
	for (int i=0; i< q; i++)
	{
		for (int j=0; j< q; j++)
		{
			
			int index_ij = position2d2(i,j,q-1);
			int index_ij_Eval = position2d2(i,j,M); // indexing used in Evaluate_at_Stroud
			
			for (int ell = 0; ell < nb_Array; ell++)
			{	
				matValNodes[index_ij][ell] = CVal[ index_ij_Eval ][ell];
			}
		}
	}
	
}
#else


// CVal contains the values of the data at the Stroud nodes
// CVal initialized by means of Evaluate_at_Stroud
void
init_Bmoment_Coeff( int n, int q, int nb_Array, double **CVal, double v1[2], double v2[2], double v3[2], double **Bmoment)
{
	double scalingConst = 2. * Area2d(v1, v2, v3); 
	
	int M = MAX(n,q-1); // used for indexing in Evaluate_at_Stroud		
	
	for (int i=0; i< q; i++)
	{
		for (int j=0; j< q; j++)
		{
			
			int index_ij = position2d2(i,j,q-1);
			int index_ij_Eval = position2d2(i,j,M); // indexing used in Evaluate_at_Stroud
			
			for (int ell = 0; ell < nb_Array; ell++)
			{	
				Bmoment[index_ij][ell] = CVal[ index_ij_Eval ][ell] * scalingConst;
			}
		}
	}
	
}

#endif // end non-PRECOMP


// compute residuals in constitute AND conservative equation
// start with evaluation of p and curl(u) at Stroud nodes
// compute B-moments using function evaluations at Stroud nodes
// WARNING: only used with n>1
#ifdef PRECOMP
void
residual_Compute(double *random_Coeff, double **Coeff_p, 
								 double **Coeff_pInter, double **Coeff_u, 
								 double **Coeff_uInter, int lenCoeff_p, 
								 int lenCoeff_u, int n, int q, double v1[2], double v2[2], double v3[2], double cpu_time[4],
								 double **binomialMat, double **precomp, int mp,
								 double **Bmoment, double *resVect, double **matValNodes,
								 double **quadraWN, double **cBar)
#else
void
residual_Compute(double *random_Coeff, double **Coeff_p, 
								 double **Coeff_pInter, double **Coeff_u, 
								 double **Coeff_uInter, int lenCoeff_p, 
								 int lenCoeff_u, int n, int q, double v1[2], double v2[2], double v3[2], double cpu_time[4],
								 double **Bmoment, double **BmomentInter, double *resVect,
								 double **quadraWN, double **cBar)
#endif
{
	
	
	clock_t tEval0, tEval1, tMmt0, tMmt1;	
	double cpu_time_Eval=0, cpu_time_Moment_Constit=0, cpu_time_Moment_Conserv=0;
	
	
	int nb_Array=1; // by default: scalar-valued functions
	
	int len_randCoeff = (n*(n+1)) / 2; // B-form representation of order n-1
	
	randomCoeff(random_Coeff, len_randCoeff); // generates random B-form sequence of length len_randCoeff for p
	
	
	tEval0 = clock();
	init_BForm_Coeff( random_Coeff, len_randCoeff, Coeff_p); // update entries of Coeff_p accordingly (using lexicographical order)
	
	Evaluate_at_Stroud(n-1, q, Coeff_p, Coeff_pInter, nb_Array);// transform Coeff_p into values of p at Stroud nodes
	
	
	tEval1 = clock();
	
	cpu_time_Eval += ( (double) (tEval1 - tEval0) )/ CLOCKS_PER_SEC;
	
	tMmt0 = clock();
	// compute integral of p times curl(sigma)'s
	double cpu_timeRes[2]={0,0};
	#ifdef PRECOMP
	residual_Constit ( n, q, v1, v2, v3, binomialMat, precomp, mp,
								 Bmoment, resVect, matValNodes, quadraWN, cBar, cpu_timeRes,
								 Coeff_p); 
	#else 
	residual_Constit ( n, q, v1, v2, v3, Bmoment, BmomentInter, resVect,
								 quadraWN, cBar, cpu_timeRes, Coeff_p);
	#endif
	
	
	tMmt1 = clock();
	
	cpu_time_Moment_Constit += ((double) (tMmt1 - tMmt0) ) / CLOCKS_PER_SEC; 
	
	len_randCoeff = (n*(n+1)) / 2; // B-form representation of order n-1 ( for curl(u) )
	randomCoeff(random_Coeff, len_randCoeff); // generates random B-form sequence of length len_randCoeff for curl(u)
	
	
	tEval0 = clock();
	sigma2Bform( random_Coeff, n, Coeff_u, lenCoeff_u, cBar); // update entries of Coeff_u accordingly (Coeff_u = B-form representation of curl(u) )
	
	Evaluate_at_Stroud( n-1, q, Coeff_u, Coeff_uInter, nb_Array);// transform Coeff_u into values of curl(u) at Stroud nodes

	
	tEval1 = clock();	
	cpu_time_Eval += ( (double) (tEval1 - tEval0) )/ CLOCKS_PER_SEC;
	
	tMmt0 = clock();
	
	int nDash = n;
	// assign values to auxilliary arrays needed in B-moment computation
	#ifdef PRECOMP
	init_precomp2d (precomp, nDash, q, mp, quadraWN);
	data_at_Nodes_Coeff(nDash, q, nb_Array, Coeff_u, matValNodes);
	#else
	init_Bmoment_Coeff(nDash, q, nb_Array, Coeff_u, v1, v2, v3, Bmoment);
	#endif
	
	
	#ifdef PRECOMP
	Bmoment2d (nDash, q, mp, nb_Array, v1, v2, v3, binomialMat, precomp, Bmoment, matValNodes);
	#else
	Bmoment2d_Index(nDash, q, nb_Array, Bmoment, BmomentInter, quadraWN );
	#endif																						
	
	
	tMmt1 = clock();
	
	cpu_time_Moment_Conserv += ( (double) (tMmt1-tMmt0) )/ CLOCKS_PER_SEC;
	
	cpu_time[0] = cpu_time_Eval;
	cpu_time[1] = cpu_time_Moment_Constit;
	cpu_time[2] = cpu_time_Moment_Conserv;
	cpu_time[3] = cpu_time_Eval + cpu_time_Moment_Constit + cpu_time_Moment_Conserv;
	
}

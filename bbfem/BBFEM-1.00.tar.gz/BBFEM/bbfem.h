//  This file is part of BBFEM.
//  
//   Authors: Mark Ainsworth
// 				    Division of Applied Mathematics
// 				    Brown University
// 				    182 George Street
// 				    Providence, RI 02912
// 				    e-mail: Mark_Ainsworth@Brown.edu
//
//            Gaelle Andriamaro
// 	  			  University of Strathclyde
// 	  			  Department of Mathematics and Statistics
//           	26 Richmond Street
// 	  			  Glasgow G1 1XH
// 	  			  Scotland, UK
// 	          e-mail: gaelle.andriamaro@strath.ac.uk
//  
//            Oleg Davydov
// 	  			  University of Strathclyde
// 	  			  Department of Mathematics and Statistics
//           	26 Richmond Street
// 	  			  Glasgow G1 1XH
// 	  			  Scotland, UK
// 	  			  e-mail: oleg.davydov@strath.ac.uk
// 
// 
//   Copyright (C) 2013 Mark Ainsworth, Gaelle Andriamaro and Oleg Davydov
// 
// 
// This package is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2, or (at your option)
// any later version.
// 
// This package is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this package; see the file COPYING.  If not, write to
// the Free Software Foundation, 59 Temple Place - Suite 330,
// Boston, MA 02111-1307, USA.  

//// routines which are common to 2D and 3D computations ///////
// void 
// gaussJacobiUnit(int q, double **quadraWN );
double **
create_BinomialMat(int len_binomialMat);
void
delete_BinomialMat(double **binomialMat, int len_binomialMat);
void 
computeBinomials(double **binomialMat, int len_binomialMat);
double **
create_Bmoment( int lenMoments, int nb_Array );
void 
delete_Bmoment(double **Bmoment);
double **
create_Mat(int len_Mat3d);
void 
delete_Mat(double **Mat);
void
delete_pointers_functval_Bmom(double **precomp, 
															double **matValNodes, double **quadraWN);
void
delete_pointers_functval_Bmom(double **BmomentInter, 
															double **quadraWN);


void
delete_pointers_functval_Mass(double **precomp, double **Bmoment, 
															double **matValNodes, double **quadraWN);
void
delete_pointers_functval_Mass(double **Bmoment, double **BmomentInter, 
															double **quadraWN);

void
delete_pointers_functval(double **precomp, double **Bmoment,
												 double **Bmomentab, double **matValNodes, double **quadraWN);
void
delete_pointers_functval(double **Bmoment, double **BmomentInter, 
												 double **Bmomentab, double **quadraWN);
void
delete_pointers_Mass(double **precomp, double **Bmoment,
										 double **matValNodes, double **quadraWN);
void
delete_pointers_Mass(double **Bmoment, double **BmomentInter, 
										 double **quadraWN);

void
delete_pointers_Bmom(double **precomp, double **matValNodes, double **quadraWN);
void
delete_pointers_Bmom(double **BmomentInter, double **quadraWN);

void
delete_pointers(double **precomp, double **Bmoment, double **Bmomentab, double **matValNodes, double **quadraWN);
void
delete_pointers(double **Bmoment, double **BmomentInter, 
											 double **Bmomentab, double **quadraWN);	

// void
// delete_pointers_Convec(double **precomp, double **Bmoment, double **Bmomentab, double **matValNodes, double **quadraWN);
// void
// delete_pointers_Convec(double **Bmoment, double **BmomentInter, 
// 											 double **Bmomentab, double **quadraWN);	
// 	
// 
// void
// delete_pointers_Stiff (double **precomp, double **Bmoment, double **Bmomentab, double **matValNodes, double **quadraWN);
// void
// delete_pointers_Stiff (double **Bmoment, double **BmomentInter, 
// 											 double **Bmomentab, double **quadraWN);

void 
delete_matValNodes(double **matValNodes);
void 
delete_precomp(double **precomp);		
void 
delete_quadraWN (double **quadraWN);

//////////////////////////////////////////////////////////////
////////// 3D routines //////////////////////////////////////
void 
gaussJacobiUnit3D(int q, double **quadraWN );
void 
crossProd(double w1[3], double w2[3], double Cross[3]);
void 
crossProd2(double w1[3], double w2[3], double Cross[3]);
void 
subtract( double v[3], double w[3], double Sub[3]);
void 
inter( double u[3], double v[3], double w[3], double Res[3] );
int 
position3d2(int i, int j, int k, int n);
int 
position3d(int eta1, int eta2, int eta3);
void 
bary2cart3d(double b1, double b2, double b3, double b4, double v1[3], double v2[3], double v3[3], double v4[3], double v[3]);

void
transform_BmomentC_Convec3d(int n, int q, double **Bmoment, double **Bmomentab, double normalMat[4][3]);
void
transform_BmomentC_Stiff3d (int n, int q, double **Bmoment, double **Bmomentab, double normalMat[4][3]);

double 
Volume3d (double v1[3], double v2[3], double v3[3], double v4[3]) ;

double **
create_quadraWN3d (int len_quadra);

void
init_BmomentC_Bmom3d ( double (*f) (double [3]), int q, 
										 double v1[3], double v2[3], double v3[3], double v4[3], 
										 double **BmomentInter, double **quadraWN);

void
init_BmomentC_Mass3d ( double (*f) (double [3]), int q, 
										 double v1[3], double v2[3], double v3[3], double v4[3], 
										 double **BmomentInter, double **quadraWN);

void
init_BmomentC_Convec3d ( void (*b)(double[3],double[3]), int q, 
											 double v1[3], double v2[3], double v3[3], double v4[3], 
											 double **BmomentInter, double **quadraWN);
void
init_BmomentC_Stiff3d ( void (*C) (double[3], double[3][3]), int q,
											double v1[3], double v2[3], double v3[3], double v4[3], 
											double **BmomentInter, double **quadraWN);


double 
Mass3d_const (int n, double v1[3], double v2[3], double v3[3], double v4[3], double **binomialMat, double **massMat);

double 
Mass3d (int n, int q, double v1[3], double v2[3], double v3[3], double v4[3], double **binomialMat, double **precomp, double **Bmoment,
      double **massMat, double **matValNodes, double **quadraWN);
double 
Mass3d (int n, int q, double v1[3], double v2[3], double v3[3], double v4[3], double **binomialMat, double **Bmoment, double **BmomentInter,
      double **massMat, double **quadraWN);

double 
Stiff3d_const (int n, double v1[3], double v2[3], double v3[3], double v4[3], 
										double **stiffMat, double **binomialMat, double scalarMat[][4], 
										double normalMat[][3], double cpu_time[5], double Coeff[6]);

double Stiff3d 
(int n, int q, double v1[3], double v2[3], double v3[3], double v4[3], 
							double **stiffMat, double **matValNodes, double **quadraWN, double **binomialMat,
							double normalMat[][3], double **precomp, double **Bmoment, double **Bmomentab, double cpu_time[5] );
							
double Stiff3d 
(int n, int q, double v1[3], double v2[3], double v3[3], double v4[3], 
							double **stiffMat, double **quadraWN, double **binomialMat,
							double normalMat[][3], double **Bmoment, double **BmomentInter, double **Bmomentab, double cpu_time[5] );							
void 
normals3d(double v1[3], double v2[3], double v3[3], double v4[3], double normalMat[4][3]);
void 
scalarMatrix3d(double scalarMat[][4],double v1[3], double v2[3], double v3[3], 
										double v4[3] , double normalMat[][3]);
void scalarMatrix3d_Coeff(double scalarMat[][4],double v1[3], double v2[3], double v3[3], double v4[3] , double normalMat[][3],
													double Coeff[6] );
void
innerProd_Coeff3d (double normalMat[][3], double innerProdMat[4], double vectCoeff[3]);									
double 
Convec3d_const (int n, double v1[3], double v2[3], double v3[3], double v4[3], 
										 double **binomialMat, double normalMat[][3], double innerProdMat[4], double **convecMat, double vectCoeff[3] );

double
Convec3d (int n, int q, double v1[3], double v2[3], double v3[3], double v4[3], double **binomialMat, double normalMat[][3], 
		double **precomp, double **Bmoment, double **Bmomentab, double **convecMat, double **matValNodes, double **quadraWN);
double
Convec3d (int n, int q, double v1[3], double v2[3], double v3[3], double v4[3], double **binomialMat, double normalMat[][3], 
		double **Bmoment, double **BmomentInter, double **Bmomentab, double **convecMat, double **quadraWN);

void 
init_Bmoment3d_Cval (double *Cval, int q,double v1[3], double v2[3], double v3[3], 
												double v4[3], double **BmomentInter, int nb_Array);
void
Bmoment3d_const (int n, double v1[3], double v2[3], double v3[3], double v4[3], double **binomialMat, double **Bmoment);
double Bmoment3d (int n, int q, int nb_Array, double v1[3], double v2[3], double v3[3], 
								 double v4[3], double **binomialMat, double **precomp, double **Bmoment, 
								 double **matValNodes);
double 
Bmoment3d_Index( int n, int q, int nb_Array, double **Bmoment, double **BmomentInter,
											 double **quadraWN );


double **
create_matValNodes3d(int len_matValNodes);

double **
create_precomp3d(int len_precomp);

void 
init_precomp3d(double **precomp, int n, int q, int mp, double **quadraWN);

void 
data_at_Nodes_Cval3d(double **matValNodes, int q, double *Cval, int nb_Array);
void
data_at_Nodes_Bmom3d ( double (*f) (double[3]), 
										 double **matValNodes, int q, double **quadraWN,
										 double v1[3], double v2[3], double v3[3], double v4[3] ); 

void
data_at_Nodes_Mass3d ( double (*f) (double[3]),
										 double **matValNodes, int q, double **quadraWN,
										 double v1[3], double v2[3], double v3[3], double v4[3] );

void
data_at_Nodes_Convec3d ( void (*b) (double[3], double[3]), 
											 double **matValNodes, int q, double **quadraWN,
											 double v1[3], double v2[3], double v3[3], double v4[3] );

void
data_at_Nodes_Stiff3d ( void (*C)(double[3],double[3][3]), double **matValNodes, int q, double **quadraWN,
											double v1[3], double v2[3], double v3[3], double v4[3] ); 
int 
len_Mat3d(int n);
int 
len_Moments3d(int n, int q);

void
assign_pointers_Bmom3d (double v1[3], double v2[3], double v3[3], double v4[3],
											int n, int q, int nDash, int m, int nb_Array,
											double **matValNodes, double *Cval, double **quadraWN,
											double **precomp, double (*f) (double[3]), int functval );

void
assign_pointers_Bmom3d (double v1[3], double v2[3], double v3[3], double v4[3],
											int n, int q, int nDash, int m, int nb_Array,
											double *Cval, double **quadraWN,
											double **Bmoment, double (*f) (double[3]), int functval);

void
assign_pointers_Mass3d (double v1[3], double v2[3], double v3[3], double v4[3],
											int n, int q, int nDash, int m, int nb_Array,
											double **matValNodes, double *Cval, double **quadraWN,
											double **precomp, double (*f) (double[3]), int functval);
void
assign_pointers_Mass3d (double v1[3], double v2[3], double v3[3], double v4[3],
											int n, int q, int nDash, int m, int nb_Array,
											double *Cval, double **quadraWN,
											double **Bmoment, double (*f) (double[3]), int functval);

void
assign_pointers_Convec3d (double v1[3], double v2[3], double v3[3], double v4[3],
											int n, int q, int nDash, int m, int nb_Array,
											double **matValNodes, double *Cval, double **quadraWN,
											double **precomp, void (*b) (double[3], double[3]), int functval);
void
assign_pointers_Convec3d (double v1[3], double v2[3], double v3[3], double v4[3],
											int n, int q, int nDash, int m, int nb_Array,
											double *Cval, double **quadraWN,
											double **Bmoment, void (*b) (double[3], double[3]), int functval);

void
assign_pointers_Stiff3d (double v1[3], double v2[3], double v3[3], double v4[3],
											int n, int q, int nDash, int m, int nb_Array,
											double **matValNodes, double *Cval, double **quadraWN,
											double **precomp, void (*A) (double[3], double[3][3]), int functval);
void
assign_pointers_Stiff3d (double v1[3], double v2[3], double v3[3], double v4[3],
											int n, int q, int nDash, int m, int nb_Array,
											double *Cval, double **quadraWN,
											double **Bmoment, void (*A) (double[3], double[3][3]), int functval);
void
get_Bmoments3d_const (double **Bmoment, int n, double v1[3], double v2[3], double v3[3], double v4[3]);
void
get_mass3d_const(double **massMat, int n, double v1[3], double v2[3],
							 double v3[3], double v4[3]);
void
get_convec3d_const (double **convecMat, int n, double v1[3], double v2[3],
									double v3[3], double v4[3], double vectCoeff[3]);
void
get_stiffness3d_const (double **stiffMat, int n, double v1[3], double v2[3],
										 double v3[3], double v4[3], double Coeff[6]);

void 
get_Bmoments3d(double **Bmoment, int n, double (*f)(double[3]), double *Cval,
											double v1[3], double v2[3], double v3[3], double v4[3], int functval);
void 
get_mass3d(double **massMat, int n, double (*f)(double[3]), double *Cval,
									double v1[3], double v2[3], double v3[3], double v4[3], int functval);
void 
get_convec3d(double **convecMat, int n, void (*b) (double[3], double[3]), double *Cval,
										double v1[3], double v2[3], double v3[3], double v4[3], int functval);
void 
get_stiffness3d(double **stiffMat, int n, void (*C) (double [3], double [3][3]),
											 double *Cval,
											 double v1[3], double v2[3], double v3[3], double v4[3], int functval);

void 
assign_quadra3d(int q, double **quadraWN );
																
void
stroud_nodes_bary3d (int q, double *B);
void
scalar_values_at_Stroud3d(int q, double *Cval, double *B, double (*f)(double[3]),
												double v1[3], double v2[3], double v3[3], double v4[3] );
void
vector_values_at_Stroud3d(int q, double *Cval, double *B, void (*b) (double[3], double[3]),
												double v1[3], double v2[3], double v3[3], double v4[3] );
void
matrix_values_at_Stroud3d(int q, double *Cval, double *B, void (*A) (double[3], double[3][3]),
												double v1[3], double v2[3], double v3[3], double v4[3] );
												
/////////////////////////////////////////////////////////////////////
//////////////// 2D routines ////////////////////////////////////////
void 
gaussJacobiUnit2D(int q, double **quadraWN );
int
position2d2 (int i, int j, int n);
int
position2d (int eta1, int eta2);

double Area2d (double v1[2], double v2[2], double v3[2]) ;

double **create_quadraWN2d (int len_Quadra);

void normals2d (double v1[2], double v2[2], double v3[2], double normalMat[][2]);

void scalarMatrix2d (double scalarMat[][3], double v1[2], double v2[2], double v3[2], double normalMat[][2]);
void
scalarMatrix2d_Coeff (double scalarMat[][3], double v1[2], double v2[2], double v3[2], double normalMat[][2], double Coeff[3]);

void
innerProd_Coeff2d (double normalMat[][2], double innerProdMat[3], double vectCoeff[2]);
void init_Bmoment2d_Cval (double *Cval, int q,double v1[2], double v2[2], double v3[2],
				       double **Bmoment, int nb_Array);
void bary2cart2d (double b1, double b2, double b3, double v1[2], double v2[2], double v3[2], double v[2]);					 
void stroud_bary2d (int q, double *B, double **quadraWN);
void stroud_bary2dw (int q, double *B, double *W, double **quadraWN);

void
Bmoment2d_const (int n, double v1[2], double v2[2], double v3[2], double **binomialMat, double **Bmoment);
double Bmoment2d (int n, int q, int mp, int nb_Array, double v1[2], double v2[2], double v3[2],
								 double **binomialMat, double **precomp, double **Bmoment, double **matValNodes);
double Bmoment2d_Index (int n, int q, int nb_Array, double **Bmoment, 
											 double **BmomentInter, double **quadraWN);	
double ** create_matValNodes2d(int len_matValNodes);

double ** create_precomp2d( int len_precomp );

void init_precomp2d(double **precomp, int n, int q, int m,
									double **quadraWN);

void data_at_Nodes_Cval2d(double **matValNodes, int q, double *Cval, int nb_Array);									
int len_Mat2d(int n);
int len_Moments2d(int n, int q);

void assign_quadra2d(int q, double **quadraWN );
												 
void
matrixVectorMultiply2d (double Mat[2][2], double v[2], double matVectMult[2]);
int
position2d2 (int mu1, int mu2, int eta1, int eta2);
int
position2d_sum (int mu12, int eta12); 
int
position2d4 (int mu1, int mu2, int eta1, int eta2, int alfa1, int alfa2, int beta1, int beta2) ;
double
scalarProd2d (double v[2], double w[2]);

double
Mass2d_const (int n , double v1[2], double v2[2], double v3[2], double **binomialMat, 
						double **massMat);
						
double
Mass2d (int n, int q, double v1[2], double v2[2], double v3[2], double **binomialMat, double **precomp,double **Bmoment,
double **massMat, double **matValNodes, double **quadraWN);
double
Mass2d (int n, int q, double v1[2], double v2[2], double v3[2], double **binomialMat, double **Bmoment, double **BmomentInter, double **massMat, double **quadraWN);			
			
double
Stiff2d_const (int n, double v1[2], double v2[2], double v3[2], double **binomialMat,
						 double scalarMat[][3], double cputime[3], double **stiffMat,
						 double Coeff[3]);

						 
double
Convec2d_const (int n, double v1[2], double v2[2], double v3[2], double **binomialMat, 
							double normalMat[][2], double innerProdMat[3], double **convecMat,
							double vectCoeff[2]);
							
							
int 
len_Mat2d(int n);

void data_at_Nodes_Bmom2d (double (*f) (double[2]), double **matValNodes, int q, 
										double **quadraWN,
										double v1[2], double v2[2], double v3[2]);

void data_at_Nodes_Mass2d (double (*f) (double[2]), double **matValNodes, int q, 
										double **quadraWN,
										double v1[2], double v2[2], double v3[2]);

void data_at_Nodes_Convec2d (void (*b) (double[2], double[2]), double **matValNodes, int q, 
										double **quadraWN,
										double v1[2], double v2[2], double v3[2]);

void data_at_Nodes_Stiff2d (void (*C) (double[2], double[2][2]), double **matValNodes, int q, 
										double **quadraWN,
										double v1[2], double v2[2], double v3[2]);
										
void
transform_BmomentC_Convec2d (int n, int q, double **Bmoment, double **Bmomentab, double normalMat[][2]);
void
transform_BmomentC_Stiff2d (int n, int q, double **Bmoment, double **Bmomentab, double normalMat[][2]);


double
Convec2d (int n, int q, double v1[2], double v2[2], double v3[2], double **binomialMat, 
				double normalMat[][2], double **precomp, double **Bmoment, double **Bmomentab, double **convecMat, double **matValNodes, double **quadraWN);
double
Convec2d (int n, int q, double v1[2], double v2[2], double v3[2], double **binomialMat, 
				double normalMat[][2], double **Bmoment, double **BmomentInter, double **Bmomentab, double **convecMat, double **quadraWN);

double
Stiff2d (int n, int q, double v1[2], double v2[2], double v3[2], double **binomialMat, double scalarMat[][3], double normalMat[][2], double cputime[3],
	   double **precomp, 
	   double **Bmoment, double **Bmomentab, double **stiffMat, double **matValNodes,
	   double **quadraWN);
double
Stiff2d (int n, int q, double v1[2], double v2[2], double v3[2], double **binomialMat, double scalarMat[][3], double normalMat[][2], double cputime[3], 
	   double **Bmoment, double **BmomentInter, double **Bmomentab, double **stiffMat, double **quadraWN);
											 
												 
void init_BmomentC_Bmom2d (double (*f) (double[2]),
										int q, double v1[2], double v2[2], double v3[2], 
			              double **Bmoment, double **quadraWN);

void init_BmomentC_Mass2d (double (*f) (double[2]),
										int q, double v1[2], double v2[2], double v3[2], 
			              double **Bmoment, double **quadraWN);

void init_BmomentC_Convec2d (void (*b) (double[2], double[2]) ,
										int q, double v1[2], double v2[2], double v3[2], 
			              double **Bmoment, double **quadraWN);

void init_BmomentC_Stiff2d (void (*C) (double[2], double[2][2]), int q, double v1[2], 
													double v2[2], double v3[2], double **Bmoment, double **quadraWN);

double Mass2d (int n, int q, double v1[2], double v2[2], double v3[2], double **binomialMat, double **precomp,
	          double **Bmoment, double **BmomentInter,
            double **massMat, double **matValNodes, double **quadraWN);
double Mass2d_const (int n, double v1[2], double v2[2], double v3[2], double **binomialMat,
									 double **massMat);

void
get_mass2d_const(double **massMat, int n, double v1[2], double v2[2], double v3[2]);


double Stiff2d_const (int n, double v1[2], double v2[2], double v3[2], double **binomialMat,
										double scalarMat[][3], double cputime[3], double **stiffMat);
										
void
get_stiffness2d_const (double **stiffMat, int n, double v1[2], double v2[2], double v3[2],
										 double Coeff[3]);

double Convec2d_const (int n, double v1[2], double v2[2], double v3[2], double **binomialMat,
										 double normalMat[][2], double innerProdMat[3], double **convecMat,
										 double vectCoeff[2]);

void
get_convec2d_const (double **convecMat, int n, double v1[2], double v2[2], double v3[2],
									double vectCoeff[2]);



void
assign_pointers_Bmom2d (double v1[2], double v2[2], double v3[2], int n, int q, int nDash, int m, int nb_Array,
								double **matValNodes, double *Cval, double **quadraWN,
								double **precomp,
								double (*f) (double[2]), int functval);
void
assign_pointers_Bmom2d (double v1[2], double v2[2], double v3[2], int n, int q, int nDash, int m, int nb_Array,
								double *Cval, double **quadraWN,
								double **Bmoment,
								double (*f) (double[2]), int functval);


void
assign_pointers_Mass2d (double v1[2], double v2[2], double v3[2], int n, int q, int nDash, 
											int m, int nb_Array, double **matValNodes, double *Cval, double **quadraWN, double **precomp, double (*f) (double[2]), int functval);
void
assign_pointers_Mass2d (double v1[2], double v2[2], double v3[2], int n, int q, int nDash, 
											int m, int nb_Array, double *Cval, double **quadraWN, double **Bmoment, double (*f) (double[2]), int functval);
void
assign_pointers_Convec2d (double v1[2], double v2[2], double v3[2], int n, int q, int nDash, int m, int nb_Array,
								double **matValNodes, double *Cval, double **quadraWN,
								double **precomp,
								void (*b) (double[2], double[2]), int functval);
void
assign_pointers_Convec2d (double v1[2], double v2[2], double v3[2], int n, int q, int nDash, int m, int nb_Array,
								double *Cval, double **quadraWN,
								double **Bmoment,
								void (*b) (double[2], double[2]), int functval);

void
assign_pointers_Stiff2d (double v1[2], double v2[2], double v3[2], int n, int q, int nDash, 
											 int m, int nb_Array, double **matValNodes, double *Cval, 
											 double **quadraWN, double **precomp,
											 void (*C) (double[2], double[2][2]),
											 int functval);
void
assign_pointers_Stiff2d (double v1[2], double v2[2], double v3[2], int n, int q, int nDash, 
											 int m, int nb_Array, double *Cval, 
											 double **quadraWN, double **Bmoment,
											 void (*C) (double[2], double[2][2]),
											 int functval);



void get_Bmoments2d(double **Bmoment, int n, double (*f)(double[2]),
											 double *Cval, double v1[2], double v2[2], double v3[2], int functval);
void
get_Bmoments2d_const (double **Bmoment, int n, double v1[2], double v2[2], double v3[2]);
											 
void get_mass2d(double **massMat, int n, double (*f)(double[2]), double *Cval, double v1[2], double v2[2], double v3[2], int functval);

void get_convec2d(double **convecMat, int n, void (*b) (double[2], double[2]), double *Cval, double v1[2], double v2[2], double v3[2], int functval);

void
get_stiffness2d(double **stiffMat, int n, void (*C) (double [2], double [2][2]), double *Cval, double v1[2], double v2[2], double v3[2], int functval);


void
stroud_bary2d (int q, double *B, double **quadraWN );

void
stroud_nodes_bary2d (int q, double *B);
void
scalar_values_at_Stroud2d(int q, double *Cval, double *B, double (*f)(double[2]),
												double v1[2], double v2[2], double v3[2]);
void
vector_values_at_Stroud2d(int q, double *Cval, double *B, void (*b) (double[2], double[2]),
												double v1[2], double v2[2], double v3[2] );
void
matrix_values_at_Stroud2d(int q, double *Cval, double *B, void (*C) (double[2], double[2][2]),
												double v1[2], double v2[2], double v3[2] );

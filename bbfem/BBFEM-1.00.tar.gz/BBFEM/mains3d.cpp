#include <stdio.h>
#include <math.h>
#include <time.h>
#include <iostream>

#include "bbfem.h"

//declaration from GaussJacobi.cpp
void gaujac(int n, float alf, float bet, double *x, double *w);

#ifndef MAX
#define MAX(a,b) ( (a) > (b) ? (a) : (b) )
#endif

// example of coefficient function (used with mass matrix and load vector)
double 
f0(double v[3])
{
	return sin(v[0]*v[1]*v[2]);
}

// example of coefficient vector b (used with convective matrix)
void
b0 (double v[3], double res[3]) 
{
	res[0] = sin(v[0]*v[1]*v[2]);
  res[1] = 1.;
  res[2] = exp(v[0]);
}

// example of coefficient matrix A (used with stiffness matrix)
void
A0(double v[3], double matC[3][3]) 
{
// 	// identity matrix
//   matC[0][0]=1; matC[0][1]=0; matC[0][2]=0;
//   matC[1][0]=0; matC[1][1]=1; matC[1][2]=0;
//   matC[2][0]=0; matC[2][1]=0; matC[2][2]=1;
	
	// non-trivial matrix example
	matC[0][0]= sin(v[0]*v[1]); matC[0][1]=0; matC[0][2]=0;
  matC[1][0]=0; matC[1][1]=1; matC[1][2]=0;
  matC[2][0]=0; matC[2][1]=0; matC[2][2]=exp(v[2]);
}

// routines


double 
timeMomentVect(int n, int q, double v1[3], double v2[3], double v3[3], double v4[3], int nbIter, double **binomialMat)
{
	
	double (*f)(double [3]) = f0;
	
	int m = MAX(n,q-1), nDash = n;
	
	int nb_Array = 1; // Bmoments are associated with scalar-valued data
	
	#ifdef PRECOMP
	double **precomp;
	double **matValNodes;
	#else
	double **BmomentInter;
	#endif
	
  double **Bmoment;
	double *Cval;
	double **quadraWN;	

	int functval = 0; //default: using a routine (f) for B-moments' coefficients
	
	// allocate memory to quadraWN
	int len_quadra = (q + 1);     // space required for storing Jacobi nodes of order q is q, BUT indexing starts at 1
	quadraWN = create_quadraWN3d(len_quadra); // store quadrature weights and nodes of a fixed degree >> now also used with PRECOMP
	
  
	// allocate memory for Bmoment vector
	int lenMoments = len_Moments3d(n, q); // size of Bmoment vector
	Bmoment = create_Bmoment(lenMoments, nb_Array);
  
	
	#ifdef PRECOMP
	int len_matValNodes = q * q * q;
  matValNodes = create_matValNodes3d(len_matValNodes); // allocate memory to array matValNodes
	precomp = create_precomp3d(m+1); 
	#else
	BmomentInter = create_Bmoment(lenMoments, nb_Array);
	#endif
  
  #ifdef FUNCT_VAL
  functval=1; //using the values stored in Cval for B-moments' coefficients
  
  double *B; // store barycentric coordinates of Stroud nodes
	B = new double [q*q*q*4];
	stroud_nodes_bary3d (q, B);
  
  //allocate memory for Cval
  int LEN = q  * q  * q ;  // space required for 3D array with dimension q
  Cval = new double[LEN * nb_Array];    //Cval entries are stored in LINEAR memory, and used directly

	scalar_values_at_Stroud3d(q, Cval, B, f, v1, v2, v3, v4); // will put the values of f at the Stroud nodes into Cval
	#endif
	

	#ifdef PRECOMP
	assign_pointers_Bmom3d (v1, v2, v3, v4, n, q, nDash, m, nb_Array,
												matValNodes, Cval, quadraWN, precomp, f, functval);
	#else
	assign_pointers_Bmom3d (v1, v2, v3, v4, n, q, nDash, m, nb_Array,
												Cval, quadraWN, BmomentInter, f, functval);
	#endif


  double average = 0;
  for (int k=0; k<nbIter; k++)
	  {
  #ifdef PRECOMP
  average += Bmoment3d ( n, q, nb_Array, v1, v2, v3, v4, binomialMat, precomp, Bmoment, matValNodes);
  #else
  average += Bmoment3d_Index (n, q, nb_Array, Bmoment, BmomentInter, quadraWN);
  #endif
	  }
		

	#ifdef PRECOMP
	delete_pointers_Bmom(precomp, matValNodes, quadraWN);
	#else
	delete_pointers_Bmom(BmomentInter, quadraWN);
	#endif

	
	#ifdef FUNCT_VAL
	delete B;
	#endif
  
	delete_Bmoment(Bmoment);
	
	return average / nbIter;

}



void printTimeMomentVect(int n0, int n1, double v1[3], double v2[3], double v3[3], double v4[3], int nbIter)
{
  double **binomialMat;
  int len_binomialMat=300;
  binomialMat = create_BinomialMat(len_binomialMat);
  
  computeBinomials(binomialMat, len_binomialMat);
  
  #ifdef LOG
  int step = (int)(n0/1.5);
  for (int n=n0; n<=n1; n += step, step = (int)(n/1.5))
  {
	std::cout<<n<<", ";
  }
  std::cout<<"\n";

  step = (int)(n0/1.5);
  for (int n=n0; n<=n1; n += step, step = (int)(n/1.5))
	{	
		int q = n+1; // q is the number of quadrature points in each direction
		fprintf(stderr,"%f, ", timeMomentVect (n, q, v1, v2, v3, v4, nbIter, binomialMat) );
	}
	std::cout<<"\n";

  #else

	std::cout << "[";
	for (int n = n0; n < n1; n++)
	{
		int q = n+1; // q is the number of quadrature points in each direction
	  std::cout << timeMomentVect (n, q, v1, v2, v3, v4, nbIter,binomialMat) << ",";
	}
	int q = n1+1;
	std::cout << timeMomentVect (n1, q, v1, v2, v3, v4, nbIter,binomialMat)<< "]\n";

  #endif

  delete_BinomialMat(binomialMat,len_binomialMat);
  
}



double
timeMass(int n, int q, double v1[3], double v2[3], double v3[3], double v4[3], int nbIter, double **binomialMat)
{
	
	#ifdef CONSTANT
	;
	#else
	

	double (*f)(double [3]) = f0;
	
	#ifdef PRECOMP
	double **precomp;
	double **matValNodes;
	#else
	double **BmomentInter;
	#endif

  double **Bmoment; 
	double *Cval;
  double **quadraWN;
  #endif
  
	
	#ifdef CONSTANT
	;
	#else
	
	int functval = 0; //default: using a routine (f) for mass matrix coefficients
	
	int nDash = 2*n; // the Bmoment order is 2n 
  int mp = MAX(nDash,q-1); // dimension of PRECOMP
	int nb_Array = 1; // Mass needs Bmoments associated with a scalar valued function
	#endif
	
  
  #ifdef CONSTANT
  ;
	#else
  // allocate memory to quadraWN
  int len_quadra = q+1;
  quadraWN = create_quadraWN3d(len_quadra);
 
  // allocate memory for Bmoment vector
  int lenMoments = len_Moments3d(nDash, q); // size of Bmoment vector
  Bmoment = create_Bmoment(lenMoments, nb_Array);
	
	#ifdef PRECOMP
	int len_matValNodes = q * q * q ;
  matValNodes = create_matValNodes3d(len_matValNodes); // allocate memory to matValNodes
	precomp = create_precomp3d(mp+1);
	#else
	BmomentInter = create_Bmoment(lenMoments, nb_Array);
	#endif // end PRECOMP
	
	#endif // end not CONSTANT
  
  
  #ifdef CONSTANT
  ;
	#else
	
  #ifdef FUNCT_VAL
  functval=1; //using the values stored in Cval for mass matrix coefficients
  
  double *B; // store barycentric coordinates of Stroud nodes
	B = new double [q*q*q*4];
	stroud_nodes_bary3d (q, B);
  
  //allocates memory for Cval
	int LEN = q * q * q ;  // space required for 3D array with dimension q
  Cval = new double[LEN * nb_Array];    //Cval entries are stored in LINEAR memory, and used directly
	
	scalar_values_at_Stroud3d(q, Cval, B, f, v1, v2, v3, v4); // will put the values of f at the Stroud nodes into Cval
	#endif
  #endif // end not CONSTANT
  
  
  double **massMat;
	int len_Mass = len_Mat3d(n);
  massMat = create_Mat(len_Mass);
  
  #ifdef CONSTANT
  ;
	#else

	#ifdef PRECOMP
	assign_pointers_Mass3d (v1, v2, v3, v4, n, q, nDash, mp, nb_Array,matValNodes, Cval, quadraWN, precomp, f, functval);
	#else
	assign_pointers_Mass3d (v1, v2, v3, v4, n, q, nDash, mp, nb_Array, Cval, quadraWN, BmomentInter, f, functval);
	#endif

  #endif // end not CONSTANT
  
  
  double average=0;
  for (int i=0; i<nbIter; i++)
	{
		#ifdef CONSTANT
		average += Mass3d_const(n, v1, v2, v3, v4, binomialMat,massMat);
		#else
		#ifdef PRECOMP
		average += Mass3d (n, q, v1, v2, v3, v4, binomialMat, precomp,Bmoment, massMat,matValNodes, quadraWN);
		#else
		average += Mass3d (n, q, v1, v2, v3, v4, binomialMat,Bmoment, BmomentInter,massMat, quadraWN);
		#endif
		
		#endif
	}
  
  #ifdef CONSTANT
  ;
	#else
 
	#ifdef PRECOMP
	delete_pointers_Mass(precomp, Bmoment, matValNodes, quadraWN);
	#else
	delete_pointers_Mass(Bmoment, BmomentInter, quadraWN);
	#endif
	
  
	#ifdef FUNCT_VAL
	delete B;
	#endif
	
	#endif // end not CONSTANT
		
  
  delete_Mat(massMat);
	  
  return average/nbIter;
}


void
printTimeMass(int n0, int n1, double v1[3], double v2[3], double v3[3], double v4[3], int nbIter)
{
  
  double **binomialMat;
  int len_binomialMat=300;
  binomialMat = create_BinomialMat(len_binomialMat);
  
  computeBinomials(binomialMat, len_binomialMat);
  
  #ifdef LOG

  int step = (int)(n0/1.5);	//need to generate more points than 2D since only up to n=30
  for (int n=n0; n<=n1; n += step, step= (int)(n/1.5))
	  {
	  std::cout<<n<<", ";
	  }
  std::cout<<"\n";

  step = (int)(n0/1.5);
  for (int n=n0; n<=n1; n += step, step = (int)(n/1.5))
	  {
			int q = n+1;
			fprintf(stderr,"%f, ", timeMass(n,q,v1,v2,v3,v4,nbIter, binomialMat) );
	  }
  std::cout<<"\n";

  #else

  std::cout<<"[";
  for (int n=n0; n<n1; n++)
	{	
		int q=n+1;
		std::cout<< timeMass(n,q,v1,v2,v3,v4,nbIter, binomialMat)<<",";
	}
	int q=n1+1;
	std::cout<<timeMass(n1,q,v1,v2,v3,v4,nbIter,binomialMat)<<"]\n";

  #endif

  delete_BinomialMat(binomialMat,len_binomialMat);
}



double timeConvec(int n, int q, double v1[3], double v2[3], double v3[3], double v4[3], double **binomialMat,
									double normalMat[][3], int nbIter)
{
	
	double **convecMat;
	int len_Convec = len_Mat3d(n);
  convecMat = create_Mat(len_Convec);
	
	
	#ifdef CONSTANT
	double vectCoeff[3] = {1.,1.,1.}; // vector associated with constant coefficient convective matrix
	#else
	void (*b) (double[3], double[3]) = b0;
	#endif
	
	#ifdef CONSTANT
	;
	#else
	
	#ifdef PRECOMP
	double **precomp;
	double **matValNodes;
	#else
	double **BmomentInter;
	#endif
	
	double **Bmoment, **Bmomentab; // passed as arguments into Convec
	double *Cval;
  double **quadraWN;
	#endif
	
	#ifdef CONSTANT
	double innerProdMat[4];
	innerProd_Coeff3d (normalMat, innerProdMat, vectCoeff);
	
	#else
	
	int functval = 0; //default: using a routine (b) for convective matrix coefficients
	
	int nDash = 2 * n - 1;        // the Bmoment order required for the convective matrix is 2n-1
  int mp = MAX(nDash, q-1); // size allocated to precomp
  int nb_Array = 3;             //Convec needs Bmoment associated with 3D vector valued function
	
	#endif // end not CONSTANT
	
	
	#ifdef CONSTANT
	;
	#else
	// allocate memory to quadraWN
	int len_quadra = q+1;
  quadraWN = create_quadraWN3d(len_quadra);
	
	int lenMoments = len_Moments3d(nDash,q); // size of Bmoment vector
	
	Bmoment = create_Bmoment(lenMoments, nb_Array);
  Bmomentab = create_Bmoment(lenMoments, 4); // store inner products of normals and Bmoments
	
	
	#ifdef PRECOMP
	int len_matValNodes = q * q * q;
  matValNodes = create_matValNodes3d(len_matValNodes); // allocate memory to matValNodes
	precomp = create_precomp3d(mp+1);
	#else
	BmomentInter = create_Bmoment(lenMoments, nb_Array);
	#endif
	
	#endif // end not CONSTANT
	
	
	#ifdef CONSTANT
	;
	#else
	
  #ifdef FUNCT_VAL
  functval=1; //using the values stored in Cval for convective matrix coefficients
  
  double *B; // store barycentric coordinates of Stroud nodes
	B = new double [q*q*q*4];
	stroud_nodes_bary3d (q, B);
  
  //allocates memory for Cval
	int LEN = q * q * q ;  // space required for 3D array with dimension q
  Cval = new double[LEN * nb_Array];    //Cval entries are stored in LINEAR memory, and used directly

	vector_values_at_Stroud3d(q, Cval, B, b, v1, v2, v3, v4); // will put the values of b at the Stroud nodes into Cval

  #endif // end FUNCT_VAL
  #endif // end not CONSTANT

 
	#ifdef CONSTANT
	;
	#else
	  
 
	#ifdef PRECOMP
	assign_pointers_Convec3d (v1, v2, v3, v4, n, q, nDash, mp, nb_Array,matValNodes, Cval, quadraWN, precomp, b, functval);
	#else
	assign_pointers_Convec3d (v1, v2, v3, v4, n, q, nDash, mp, nb_Array, Cval, quadraWN, BmomentInter, b, functval);
	#endif
  
  #endif // end not CONSTANT
  
  double average=0;
	for (int i=0; i < nbIter; i++)
	{
		#ifdef CONSTANT
		average += Convec3d_const (n, v1, v2, v3, v4, binomialMat, normalMat, innerProdMat, convecMat, vectCoeff);
		
		#else
		
		#ifdef PRECOMP
		average += Convec3d (n, q, v1, v2, v3, v4, binomialMat, normalMat, precomp, Bmoment, Bmomentab, convecMat,matValNodes, quadraWN);  
		#else
		average += Convec3d (n, q, v1, v2, v3, v4, binomialMat, normalMat, Bmoment,
											 BmomentInter, Bmomentab, convecMat, quadraWN);  
		#endif

		#endif
	}
	
	#ifdef CONSTANT
  ;
	#else
	
	#ifdef PRECOMP
	delete_pointers(precomp, Bmoment, Bmomentab, matValNodes, quadraWN);
	#else
	delete_pointers(Bmoment, BmomentInter, Bmomentab, quadraWN);
	#endif
	
	
	#ifdef FUNCT_VAL
	delete B;
	#endif

  
  #endif // end not CONSTANT

  delete_Mat(convecMat);
	
	 return average/nbIter;
	
}

void printTimeConvec(int n0, int n1, double v1[3], double v2[3], double v3[3], double v4[3], int nbIter)
{
  double **binomialMat;
  int len_binomialMat=300;
  binomialMat = create_BinomialMat(len_binomialMat);
  
  computeBinomials(binomialMat, len_binomialMat);
  
  double normalMat[4][3]={{0,0,0},{0,0,0},{0,0,0},{0,0,0} };
	normals3d(v1,v2,v3,v4,normalMat);
  
  #ifdef LOG

  int step = (int)(n0/1.5);
  for (int n=n0; n<=n1; n += step, step = (int)(n/1.5))
	  {
	  std::cout<<n<<", ";
	  }
  std::cout<<"\n";

  step = (int)(n0/1.5);
  for (int n=n0; n<=n1; n += step, step = (int)(n/1.5))
	  {
			int q = n+1;
			fprintf(stderr, "%f\n", timeConvec(n,q,v1,v2,v3,v4,binomialMat,normalMat,nbIter) );
	  }
  std::cout<<"\n";

  #else

  std::cout<<"[";
  for (int n=n0; n<n1; n++)
	{
		int q=n+1;
		std::cout<< timeConvec(n,q,v1,v2,v3,v4,binomialMat,normalMat,nbIter)<<",";
	}
	int q=n1+1;
	std::cout<<timeConvec(n1,q,v1,v2,v3,v4,binomialMat,normalMat,nbIter)<<"]\n";	

  #endif

  delete_BinomialMat(binomialMat, len_binomialMat);
  
}


double timeStiff(int n, int q, double v1[3], double v2[3], double v3[3], double v4[3], double **binomialMat,
						double scalarMat[][4], double normalMat[][3], 
						int nbIter, double cpu_time[5])
{	
	
	#ifdef CONSTANT
	double Coeff[6] = {1., 0., 0., 1., 0., 1.}; // upper triangular entries of (symmetric) matrix associated with stiffness matrix
	#else
	void (*A) (double[3], double[3][3]) = A0;
	#endif
	
	#ifdef CONSTANT
	;
	#else
	
	#ifdef PRECOMP
	double **precomp;
	double **matValNodes;
	#else
	double **BmomentInter;
	#endif
	
  double **Bmoment, **Bmomentab; // passed as arguments into Stiff
	double *Cval;
  double **quadraWN;
	#endif
	
	#ifdef CONSTANT
	;
	#else
	
	int functval = 0; //default: using a routine (A) for stiffness matrix coefficients
	
	int nDash = 2 * n - 2;        // the Bmoment order required for the stiffness matrix is 2n-2
	int mp = MAX(nDash, q-1); // size allocated to precomp
	int nb_Array = 6;             //Stiff needs Bmoment associated with symmetric 3 by 3 matrix valued function
	#endif

	
  #ifdef CONSTANT
  scalarMatrix3d_Coeff(scalarMat, v1, v2, v3, v4, normalMat, Coeff );
	#else
	// allocate memory to quadraWN
	int len_quadra = q+1;
  quadraWN = create_quadraWN3d(len_quadra);
	
	int lenMoments = len_Moments3d(nDash,q); // size of Bmoment vector	
	Bmoment = create_Bmoment(lenMoments, nb_Array);
  Bmomentab = create_Bmoment(lenMoments, 10); // multiply normals to Bmoments and store into Bmomentab: used with Stiff
	
	#ifdef PRECOMP
	int len_matValNodes = q * q * q;
  matValNodes = create_matValNodes3d(len_matValNodes); // allocate memory to matValNodes
	precomp = create_precomp3d(mp+1);
	#else
	BmomentInter = create_Bmoment(lenMoments, nb_Array);
	#endif
  
  #endif // end not CONSTANT
  
  
  #ifdef CONSTANT
  ;
	#else
	
  #ifdef FUNCT_VAL
  functval=1; //using the values stored in Cval for stiffness matrix coefficients
  
  double *B; // store barycentric coordinates of Stroud nodes
	B = new double [q*q*q*4];
	stroud_nodes_bary3d (q, B);
  
	//allocates memory to Cval
	int LEN = q * q * q ;  // space required for 3D array with dimension q
  Cval = new double[LEN * nb_Array];    //Cval entries are stored in LINEAR memory, and used directly

	matrix_values_at_Stroud3d(q, Cval, B, A, v1, v2, v3, v4); // will put the values of A at the Stroud nodes into Cval
	
	#endif
	#endif
	
	
	double **stiffMat;
	int len_Stiff = len_Mat3d(n);
  stiffMat = create_Mat(len_Stiff);
  

  #ifdef CONSTANT
  ;
	#else

	
	#ifdef PRECOMP
	assign_pointers_Stiff3d (v1, v2, v3, v4, n, q, nDash, mp, nb_Array, matValNodes, Cval, quadraWN, precomp, A, functval);
	#else
	assign_pointers_Stiff3d (v1, v2, v3, v4, n, q, nDash, mp, nb_Array, Cval, quadraWN, BmomentInter, A, functval);
	#endif

  #endif // end not CONSTANT


  double average=0;
  for (int i=0; i<nbIter; i++)
	{
		#ifdef CONSTANT
		average+= Stiff3d_const (n, v1, v2, v3, v4, stiffMat, binomialMat, scalarMat,normalMat,
													 cpu_time, Coeff); 
		#else
	
		#ifdef PRECOMP
		average+= Stiff3d (n, q, v1, v2, v3, v4, stiffMat, matValNodes, quadraWN, binomialMat,normalMat,precomp,Bmoment, Bmomentab, cpu_time); 
		#else
		average+= Stiff3d (n, q, v1, v2, v3, v4, stiffMat, quadraWN, binomialMat,normalMat,Bmoment, BmomentInter, Bmomentab, cpu_time); 
		#endif

		#endif
	}


  #ifdef CONSTANT
  ;
	#else // not CONSTANT
	

	#ifdef PRECOMP
	delete_pointers (precomp, Bmoment, Bmomentab, matValNodes, quadraWN);
	#else
	delete_pointers (Bmoment, BmomentInter, Bmomentab, quadraWN);
	#endif
	
  
	#ifdef FUNCT_VAL
	delete B;
	#endif
	
  #endif

  delete_Mat(stiffMat);
	  
  return average/nbIter;
}


void printTimeStiff(int n0, int n1, double v1[3], double v2[3], double v3[3], double v4[3], int nbIter)
{
  
  double cpu_time[5];

  double **binomialMat;
  int len_binomialMat=300;
  binomialMat = create_BinomialMat(len_binomialMat);
  
  computeBinomials(binomialMat, len_binomialMat);
  
  double normalMat[4][3]={{0,0,0},{0,0,0},{0,0,0},{0,0,0} };
	normals3d(v1,v2,v3,v4,normalMat);
  double scalarMat[4][4];


  #ifdef LOG

  int step = (int)(n0/1.5);
  for (int n=n0; n<=n1; n += step, step = (int)(n/1.5))
	  {
	  std::cout<<n<<", ";
	  }
  std::cout<<"\n";

  step = (int)(n0/1.5);
  for (int n=n0; n<=n1; n += step, step = (int)(n/1.5))
	  {
			int q = n+1;
  #ifdef CPU_SHARE
	  timeStiff(n,q,v1,v2,v3,v4,binomialMat,scalarMat,normalMat,nbIter,cpu_time);
	  fprintf(stderr,"moments from routine Bmoment:%f, moments: %f, transform_Moments: %f, shift: %f, total cpu time: %f\n",
			  cpu_time[4], cpu_time[0], cpu_time[1], cpu_time[2], cpu_time[3]);
  #else
	  fprintf(stderr,"%f, ", timeStiff(n,q,v1,v2,v3,v4,binomialMat,scalarMat,normalMat,nbIter,cpu_time) );
  #endif
	  }
  std::cout<<"\n";

  #else

  std::cout<<"[";
  for (int n=n0; n<n1; n++)
	{
		int q=n+1;
		std::cout<< timeStiff(n,q,v1,v2,v3,v4,binomialMat,scalarMat,normalMat,nbIter,cpu_time)<<",";
	}
	int q=n1+1;
	std::cout<<timeStiff(n1,q,v1,v2,v3,v4,binomialMat,scalarMat,normalMat,nbIter,cpu_time)<<"]\n";	

  #endif

  delete_BinomialMat(binomialMat, len_binomialMat);
  
}


////////////////////////////////////////////////
/////////// mains /////////////////////////////

//// CPU TIMING /////

#ifdef TIMEMOM
int main()
{
	double v1[3]={0,0,0};
	double v2[3]={1,0,0};
	double v3[3]={0,1,0};
	double v4[3]={0,0,1};
	
				
	int n0, n1;
	
	int nbIter;
	
	std::cout<<"Enter a value for the number of iterations: ";
	std::cin>>nbIter;
	std::cout<<"Enter a value for the smallest polynomial order: ";
	std::cin>>n0;
	std::cout<<"Enter a value for the largest polynomial order: ";
	std::cin>>n1; 
	
	printTimeMomentVect(n0, n1, v1, v2, v3, v4, nbIter);
}


#elif TIMEMASS
int main()
{
	double v1[3]={0,0,0};
	double v2[3]={1,0,0};
	double v3[3]={0,1,0};
	double v4[3]={0,0,1};
	
				
	int n0, n1;
	
	int nbIter;
	
	std::cout<<"Enter a value for the number of iterations: ";
	std::cin>>nbIter;
	std::cout<<"Enter a value for the smallest polynomial order: ";
	std::cin>>n0;
	std::cout<<"Enter a value for the largest polynomial order: ";
	std::cin>>n1; 
	
	printTimeMass(n0, n1, v1, v2, v3, v4, nbIter);
}


#elif TIMECONVEC
int main()
{
	double v1[3]={0,0,0};
	double v2[3]={1,0,0};
	double v3[3]={0,1,0};
	double v4[3]={0,0,1};	
				
	int n0, n1;
	
	int nbIter;
	
	std::cout<<"Enter a value for the number of iterations: ";
	std::cin>>nbIter;
	std::cout<<"Enter a value for the smallest polynomial order: ";
	std::cin>>n0;
	std::cout<<"Enter a value for the largest polynomial order: ";
	std::cin>>n1;
	
	printTimeConvec(n0, n1, v1, v2, v3, v4, nbIter);
}

#elif TIMESTIFF


int main()
{
	double v1[3]={0,0,0};
	double v2[3]={1,0,0};
	double v3[3]={0,1,0};
	double v4[3]={0,0,1};	
				
	int n0, n1;
	
	int nbIter;
	
	std::cout<<"Enter a value for the number of iterations: ";
	std::cin>>nbIter;
	std::cout<<"Enter a value for the smallest polynomial order: ";
	std::cin>>n0;
	std::cout<<"Enter a value for the largest polynomial order: ";
	std::cin>>n1;
	
	printTimeStiff(n0, n1, v1, v2, v3, v4, nbIter); 
}


//// COMPUTATION OF THE ELEMENTAL QUANTITIES ////////////


// calling low-level routines

#elif BMOM_CONST
// Compute B-moments associated with constant coefficients
int main()
{
// 	//vertices (standard tetrahedron)
// 	double v1[3]={0,0,0};
// 	double v2[3]={1,0,0};
// 	double v3[3]={0,1,0};
// 	double v4[3]={0,0,1};
	
	//vertices (particular tetrahedron)
  double v1[3] = { 1.2  , 3.4, 0}; 
  double v2[3] = { -1.5 , 2. , 0};
  double v3[3] = { 0.1  , -1., 0};
	double v4[3] = {1. , 1., 1.};
	
	int n;
	
	std::cout<<"Enter a value for the polynomial order n: ";
	std::cin>>n;
	
	double **binomialMat;
  int len_binomialMat= 2*n+3;
  binomialMat = create_BinomialMat(len_binomialMat);
  computeBinomials(binomialMat, len_binomialMat);
	
	double **Bmoment;
	int nb_Array = 1; // Bmoments are associated with scalar-valued data
	int lenMoments = ((n+3)*(n+2)*(n+1))/6;
	Bmoment = create_Bmoment(lenMoments, nb_Array);
	
	Bmoment3d_const (n, v1, v2, v3, v4, binomialMat, Bmoment); // compute B-moments
	
	delete_BinomialMat (binomialMat, len_binomialMat); // free allocated memory
	
	// Insert your code here to make use of Bmoment. It will be destroyed in the next line!
		
	delete_Bmoment(Bmoment);
	
	#ifdef CHECK
	std::cout<<"Bmoments entries stored into array Bmoment of length"<<lenMoments<<"\n";
	#endif
}

#elif BMOM_LOW // computation of the Bmoments of order n
int main()
{
// 	//vertices (standard tetrahedron)
// 	double v1[3]={0,0,0};
// 	double v2[3]={1,0,0};
// 	double v3[3]={0,1,0};
// 	double v4[3]={0,0,1};
	
	//vertices (particular tetrahedron)
  double v1[3] = { 1.2  , 3.4, 0}; 
  double v2[3] = { -1.5 , 2. , 0};
  double v3[3] = { 0.1  , -1., 0};
	double v4[3] = {1. , 1., 1.};
	
	double (*f) (double[3]) = f0; // change here if want Bmoments associated with another function
	
	int n;
	
	std::cout<<"Enter a value for the polynomial order n: ";
	std::cin>>n;
	
	double **binomialMat;
  int len_binomialMat=2*n+2;
  binomialMat = create_BinomialMat(len_binomialMat);
  computeBinomials(binomialMat, len_binomialMat);
	
	#ifdef PRECOMP
	double **precomp;
	double **matValNodes;
	#else
	double **BmomentInter;
	#endif
	
	double **Bmoment;
	double *Cval;
	double **quadraWN;
	
	int nb_Array = 1; // Bmoments are associated with scalar-valued data
	int q= n+1; // q is the number of quadrature points
	
	int mp = MAX(n,q-1);
	
	// allocate memory to quadraWN
	int len_quadra = (q + 1);     // space required for storing Jacobi nodes of order q is q+1, BUT indexing starts at 1
  quadraWN = create_quadraWN3d(len_quadra);
	
	int functval = 0; //default: using a routine (f) for B-moments coefficients
	
	// allocate memory to Bmoment
	int nDash=n;
	int lenMoments = len_Moments3d(nDash,q); // size of Bmoment
	   
  Bmoment = create_Bmoment(lenMoments, nb_Array);
	
	#ifdef PRECOMP
	int len_matValNodes = q * q * q ;
  matValNodes = create_matValNodes3d(len_matValNodes); // allocate memory to array matValNodes
	precomp = create_precomp3d(mp+1);
	#else
	BmomentInter = create_Bmoment(lenMoments, nb_Array);
	#endif
	
  
  #ifdef FUNCT_VAL
  functval=1; //using the values stored in Cval for B-moments' coefficients
  
  double *B; // store barycentric coordinates of Stroud nodes
	B = new double [q*q*q*4];
	stroud_nodes_bary3d (q, B);
  
  //allocate memory for Cval
	int LEN = q * q  * q ;  // space required for 3D array with dimension q
  Cval = new double[LEN * nb_Array];    //Cval entries are stored in LINEAR memory, and used directly


	scalar_values_at_Stroud3d(q, Cval, B, f, v1, v2, v3, v4); // will put the values of f at the Stroud nodes into Cval
	#endif


	#ifdef PRECOMP
	assign_pointers_Bmom3d (v1, v2, v3, v4, n, q, nDash, mp, nb_Array,
												matValNodes, Cval, quadraWN, precomp, f, functval);
	#else
	assign_pointers_Bmom3d (v1, v2, v3, v4, n, q, nDash, mp, nb_Array,
												Cval, quadraWN, BmomentInter, f, functval);
	#endif
  
  // store Bmoment entries into array Bmoment
  #ifdef PRECOMP
  Bmoment3d ( n, q, nb_Array, v1, v2, v3, v4, binomialMat, precomp, Bmoment, matValNodes);
  #else
  Bmoment3d_Index (n, q, nb_Array, Bmoment, BmomentInter, quadraWN);
  #endif
    

	#ifdef PRECOMP
	delete_pointers_Bmom(precomp, matValNodes, quadraWN);
	#else
	delete_pointers_Bmom(BmomentInter, quadraWN);
	#endif
	
	
	delete_BinomialMat(binomialMat,len_binomialMat);
	
	#ifdef FUNCT_VAL
	delete B;
	#endif
	
	
	// Insert your code here to make use of Bmoment. It will be destroyed in the next line!
	
	
	delete_Bmoment(Bmoment);
	
	#ifdef CHECK
	std::cout<<"Bmoments entries stored into array Bmoment of length"<<lenMoments<<"\n";
	#endif
}

#elif MASS_CONST // Computation of the mass matrix with constant coefficients
int main()
{
// 	//vertices (standard tetrahedron)
// 	double v1[3] = { 0, 0, 0};
// 	double v2[3] = { 1, 0, 0};
// 	double v3[3] = { 0, 1, 0};
// 	double v4[3] = { 0, 0, 1};

	//vertices (particular tetrahedron)
  double v1[3] = { 1.2  , 3.4, 0}; 
  double v2[3] = { -1.5 , 2. , 0};
  double v3[3] = { 0.1  , -1., 0};
	double v4[3] = {1. , 1., 1.};
	
	
	int n;
	
	std::cout<<"Enter a value for the polynomial order n: ";
	std::cin>>n;
	
	double **binomialMat;
  int len_binomialMat=2*n+3;
  binomialMat = create_BinomialMat(len_binomialMat);
  
  computeBinomials(binomialMat, len_binomialMat);
	
	 
  double **massMat;
	int len_Mass = len_Mat3d(n);
  massMat = create_Mat(len_Mass);
	
	Mass3d_const (n, v1, v2, v3, v4, binomialMat, massMat);
	
	
	delete_BinomialMat(binomialMat,len_binomialMat);
	
	
	// Insert your code here to make use of massMat. It will be destroyed in the next line!
	
	
	delete_Mat(massMat);
	
	#ifdef CHECK
	std::cout<<"Mass matrix entries stored into array massMat of length"<<len_Mass<<"\n";
	#endif
}

#elif MASS_LOW // Computation of the mass matrix with variable coefficients
int main()
{
// 	//vertices (particular tetrahedron)
// 	double v1[3]={0,0,0};
// 	double v2[3]={1,0,0};
// 	double v3[3]={0,1,0};
// 	double v4[3]={0,0,1};
	
	//vertices (particular tetrahedron)
  double v1[3] = { 1.2  , 3.4, 0}; 
  double v2[3] = { -1.5 , 2. , 0};
  double v3[3] = { 0.1  , -1., 0};
	double v4[3] = {1. , 1., 1.};
	
	int n;
	
	std::cout<<"Enter a value for the polynomial order n: ";
	std::cin>>n;
	
	double (*f)(double [3]) = f0; // change here if want Mass associated with another function
	
	int functval = 0; //default: using a routine (f) for mass matrix coefficients
	
	double **binomialMat;
  int len_binomialMat=2*n+2;
  binomialMat = create_BinomialMat(len_binomialMat);
  
  computeBinomials(binomialMat, len_binomialMat);
		
	
	#ifdef PRECOMP
	double **precomp;
	double **matValNodes;
	#else
	double **BmomentInter;
	#endif
	
	double **Bmoment;
	double *Cval;
  double **quadraWN;
 
	
	int q = n+1; // q is the degree of the quadrature rule
  int nDash = 2*n; // the Bmoment order is 2n
  int mp = MAX(nDash,q-1); // dimension of PRECOMP
  int nb_Array = 1; // Mass needs Bmoments associated with a scalar valued function
  	
	
	int len_quadra = q+1;
  quadraWN = create_quadraWN3d(len_quadra);
	
	int lenMoments = len_Moments3d(nDash, q); // size of Bmoment
 
  Bmoment = create_Bmoment(lenMoments, nb_Array);
  
	
	#ifdef PRECOMP
	int len_matValNodes = q * q * q ;
  matValNodes = create_matValNodes3d(len_matValNodes); // allocate memory to matValNodes
	precomp = create_precomp3d(mp+1);
	#else
	BmomentInter = create_Bmoment(lenMoments, nb_Array);
	#endif
	
	
	#ifdef FUNCT_VAL
	functval = 1; //using the values stored in Cval for mass matrix coefficients
	
	double *B; // store barycentric coordinates of Stroud nodes
	B = new double [q*q*q*4];
	stroud_nodes_bary3d (q, B);
	
	int LEN = q * q * q ;  // space required for 3D array with dimension q
  Cval = new double[LEN * nb_Array];    //Cval entries are stored in LINEAR memory, and used directly

	scalar_values_at_Stroud3d(q, Cval, B, f, v1, v2, v3, v4); // will put the values of f at the Stroud nodes into Cval
	#endif
	
	double **massMat;
	int len_Mass = len_Mat3d(n);
  massMat = create_Mat(len_Mass);
	

	#ifdef PRECOMP
	assign_pointers_Mass3d (v1, v2, v3, v4, n, q, nDash, mp, nb_Array,matValNodes, Cval, quadraWN, precomp, f, functval);
	#else
	assign_pointers_Mass3d (v1, v2, v3, v4, n, q, nDash, mp, nb_Array, Cval, quadraWN, BmomentInter, f, functval);
	#endif
	
	#ifdef PRECOMP
	Mass3d (n, q, v1, v2, v3, v4, binomialMat, precomp,Bmoment,
				massMat,matValNodes, quadraWN);
	#else
	Mass3d (n, q, v1, v2, v3, v4, binomialMat,Bmoment, BmomentInter,
				massMat, quadraWN);
	#endif
		

	#ifdef PRECOMP
	delete_pointers_Mass(precomp, Bmoment, matValNodes, quadraWN);
	#else
	delete_pointers_Mass(Bmoment, BmomentInter, quadraWN);
	#endif

	
	delete_BinomialMat(binomialMat,len_binomialMat);
	
	#ifdef FUNCT_VAL
	delete B;
	#endif
	
	
	// Insert your code here to make use of massMat. It will be destroyed in the next line!
	
	
	delete_Mat(massMat);
	
	
	#ifdef CHECK
	std::cout<<"Mass matrix entries stored into array massMat of length"<<len_Mass<<"\n";
	#endif
	
}

#elif CONVEC_CONST // Computation of the convective matrix with constant coefficients
int main()
{
// 	// vertices (standard tetrahedron)
// 	double v1[3]={0,0,0};
// 	double v2[3]={1,0,0};
// 	double v3[3]={0,1,0};
// 	double v4[3]={0,0,1};
	
	//vertices (particular tetrahedron)
  double v1[3] = { 1.2  , 3.4, 0}; 
  double v2[3] = { -1.5 , 2. , 0};
  double v3[3] = { 0.1  , -1., 0};
	double v4[3] = {1. , 1., 1.};
	
	int n;
	
	std::cout<<"Enter a value for the polynomial order n: ";
	std::cin>>n;
	
	double vectCoeff[3] = {1.,1.,1.}; // vector associated with constant coefficient convective matrix
	
	double **binomialMat;
  int len_binomialMat=2*n+3;
  binomialMat = create_BinomialMat(len_binomialMat);
  
  computeBinomials(binomialMat, len_binomialMat);
	double normalMat[4][3]={{0,0,0},{0,0,0},{0,0,0},{0,0,0} };
	normals3d(v1,v2,v3,v4,normalMat);
	
	double innerProdMat[4];
	innerProd_Coeff3d (normalMat, innerProdMat, vectCoeff);
	
	
  double **convecMat;
	int len_Convec = len_Mat3d(n);
  convecMat = create_Mat(len_Convec);
	
	Convec3d_const (n, v1, v2, v3, v4, binomialMat, normalMat, innerProdMat, convecMat, vectCoeff);
	
	
	delete_BinomialMat(binomialMat, len_binomialMat);
	
	
	
	// Insert your code here to make use of convecMat. It will be destroyed in the next line!
	
	
	
	delete_Mat(convecMat);
	
	
	#ifdef CHECK
	std::cout<<"Convective matrix entries stored into array convecMat of length"<<len_Convec<<"\n";
	#endif
	
}

#elif CONVEC_LOW // Computation of the convective matrix with variable coefficients
int main()
{
// 	//vertices (standard tetrahedron)
// 	double v1[3]={0,0,0};
// 	double v2[3]={1,0,0};
// 	double v3[3]={0,1,0};
// 	double v4[3]={0,0,1};
	
	//vertices (particular tetrahedron)
  double v1[3] = { 1.2  , 3.4, 0}; 
  double v2[3] = { -1.5 , 2. , 0};
  double v3[3] = { 0.1  , -1., 0};
	double v4[3] = {1. , 1., 1.};
	
	int n;
	
	std::cout<<"Enter a value for the polynomial order n: ";
	std::cin>>n;
	
	void (*b) (double[3], double[3]) = b0; // change here if want convective matrix associated with another function
	
	int functval = 0; //default: using a routine (b) for convective matrix coefficients
	
	double **binomialMat;
  int len_binomialMat=2*n+2;
  binomialMat = create_BinomialMat(len_binomialMat);
  computeBinomials(binomialMat, len_binomialMat);
	
	double **convecMat;
	int len_Convec = len_Mat3d(n);
  convecMat = create_Mat(len_Convec);
	
	double normalMat[4][3]={{0,0,0},{0,0,0},{0,0,0},{0,0,0} };
	normals3d(v1,v2,v3,v4,normalMat);
	
	#ifdef PRECOMP
	double **precomp;
	double **matValNodes;
	#else
	double **BmomentInter;
	#endif
	
	double **Bmoment, **Bmomentab; // passed as arguments into Convec  
	double *Cval;	
  double **quadraWN;

	
	int q = n+1;                    // the number of quadrature points is n+1
  int nDash = 2 * n - 1;        // the Bmoment order required for the convective matrix is 2n-1
  int mp = MAX(nDash, q-1); // size of precomp
  int nb_Array = 3;             //Convec needs Bmoment associated with 3D vector valued function
  
  int len_quadra = q+1;
  quadraWN = create_quadraWN3d(len_quadra);
	
	int lenMoments = len_Moments3d(nDash,q); // size of Bmoment vector
	
	Bmoment = create_Bmoment(lenMoments, nb_Array);
  Bmomentab = create_Bmoment(lenMoments, 4); // store inner products of normals and Bmoments
  
	
	#ifdef PRECOMP
	int len_matValNodes = q * q * q;
  matValNodes = create_matValNodes3d(len_matValNodes); // allocate memory to matValNodes
	precomp = create_precomp3d(mp+1);
	#else
	BmomentInter = create_Bmoment(lenMoments, nb_Array);
	#endif
	
  #ifdef FUNCT_VAL
  functval = 1; //using the values stored in Cval for convective matrix coefficients
  
  double *B; // store barycentric coordinates of Stroud nodes
	B = new double [q*q*q*4];
	stroud_nodes_bary3d (q, B);
	
	
  //allocates memory for Cval
	int LEN = q * q * q;  // space required for 3D array with dimension q
  Cval = new double[LEN * nb_Array];    //Cval entries are stored in LINEAR memory, and used directly


	vector_values_at_Stroud3d(q, Cval, B, b, v1, v2, v3, v4); // will put the values of b at the Stroud nodes into Cval
  #endif
  
  		
	#ifdef PRECOMP
	assign_pointers_Convec3d (v1, v2, v3, v4, n, q, nDash, mp, nb_Array,matValNodes, Cval, quadraWN, precomp, b, functval);
	#else
	assign_pointers_Convec3d (v1, v2, v3, v4, n, q, nDash, mp, nb_Array, Cval, quadraWN, BmomentInter, b, functval);
	#endif
  
	#ifdef PRECOMP
	Convec3d (n, q, v1, v2, v3, v4, binomialMat, normalMat, precomp, Bmoment, Bmomentab, convecMat,matValNodes, quadraWN);
	#else
	Convec3d (n, q, v1, v2, v3, v4, binomialMat, normalMat, Bmoment, BmomentInter, Bmomentab, convecMat, quadraWN);
	#endif
	
	
	#ifdef PRECOMP
	delete_pointers(precomp, Bmoment, Bmomentab, matValNodes, quadraWN);
	#else
	delete_pointers(Bmoment, BmomentInter, Bmomentab, quadraWN);
	#endif
	
  delete_BinomialMat(binomialMat, len_binomialMat);
	
	
	#ifdef FUNCT_VAL
	delete B;
	#endif
	
	
	// Insert your code here to make use of convecMat. It will be destroyed in the next line!
	
	
  delete_Mat(convecMat);
	
	
	#ifdef CHECK
	std::cout<<"Convective matrix entries stored into array convecMat of length"<<len_Convec<<"\n";
	#endif
	
}

#elif STIFF_CONST // Computation of the stiffness matrix with constant coefficients
int main()
{
// 	//vertices (standard tetrahedron)
// 	double v1[3]={0,0,0};
// 	double v2[3]={1,0,0};
// 	double v3[3]={0,1,0};
// 	double v4[3]={0,0,1};
	
	//vertices (particular tetrahedron)
  double v1[3] = { 1.2  , 3.4, 0}; 
  double v2[3] = { -1.5 , 2. , 0};
  double v3[3] = { 0.1  , -1., 0};
	double v4[3] = {1. , 1., 1.};
	
	int n;
	
	std::cout<<"Enter a value for the polynomial order n: ";
	std::cin>>n;
	
	double Coeff[6] = {1., 0., 0., 1., 0., 1.}; // upper triangular entries of (symmetric) matrix associated with stiffness matrix
	
	double cpu_time[5];

  double **binomialMat;
  int len_binomialMat=2*n+2;
  binomialMat = create_BinomialMat(len_binomialMat);
  computeBinomials(binomialMat, len_binomialMat);
	
	double normalMat[4][3]={{0,0,0},{0,0,0},{0,0,0},{0,0,0} };
	normals3d (v1, v2, v3, v4, normalMat);
	
  double scalarMat[4][4];
	scalarMatrix3d_Coeff(scalarMat, v1, v2, v3, v4, normalMat, Coeff );
	
  double **stiffMat;
	int len_Stiff = len_Mat3d(n);
  stiffMat = create_Mat(len_Stiff);
	
	Stiff3d_const (n, v1, v2, v3, v4, stiffMat, binomialMat, scalarMat,normalMat, cpu_time, Coeff);
	
	delete_BinomialMat(binomialMat, len_binomialMat);
	
	
	
	// Insert your code here to make use of stiffMat. It will be destroyed in the next line!
	
	
	
	delete_Mat(stiffMat);
	
	#ifdef CHECK
	std::cout<<"Stiffness matrix entries stored into array stiffMat of dimension "<<len_Stiff<<"\n";
	#endif
	
}
#elif STIFF_LOW // Computation of the stiffness matrix entries with variable coefficients

int main()
{
// 	//vertices (standard tetrahedron)
// 	double v1[3]={0,0,0};
// 	double v2[3]={1,0,0};
// 	double v3[3]={0,1,0};
// 	double v4[3]={0,0,1};
	
	//vertices (particular tetrahedron)
  double v1[3] = { 1.2  , 3.4, 0}; 
  double v2[3] = { -1.5 , 2. , 0};
  double v3[3] = { 0.1  , -1., 0};
	double v4[3] = {1. , 1., 1.};
	
	int n;
	
	std::cout<<"Enter a value for the polynomial order n: ";
	std::cin>>n;
	
	void (*A) (double[3], double[3][3]) = A0; // change here if want the stiffness matrix associated with another function
	
	int functval = 0; //default: using a routine (A) for stiffness matrix coefficients
	
	double cpu_time[5];

  double **binomialMat;
  int len_binomialMat=2*n+2;
  binomialMat = create_BinomialMat(len_binomialMat);
  computeBinomials(binomialMat, len_binomialMat);
	
	
	double normalMat[4][3]={{0,0,0},{0,0,0},{0,0,0},{0,0,0} };
	normals3d(v1,v2,v3,v4,normalMat);
	
	#ifdef PRECOMP
	double **precomp;
	double **matValNodes;
	#else
	double **BmomentInter;
	#endif
	
	double **Bmoment, **Bmomentab; // passed as arguments into Stiff
	double *Cval;
  double **quadraWN;
  
	
	int q = n+1;                    // the number of quadrature points is n+1
  int nDash = 2 * n - 2;        // the Bmoment order required for the stiffness matrix is 2n-2
	int mp = MAX(nDash,q-1); // size of PRECOMP
  int nb_Array = 6;             //Stiff needs Bmoment associated with symmetric 3 by 3 matrix valued function
  
  int len_quadra = q+1;
  quadraWN = create_quadraWN3d(len_quadra);
	
	int lenMoments = len_Moments3d(nDash, q); // size of Bmoment 
  Bmoment = create_Bmoment(lenMoments, nb_Array);
  Bmomentab = create_Bmoment(lenMoments, 10); // multiply normals to Bmoments and store into Bmomentab: used with Stiff
	
	#ifdef PRECOMP
	int len_matValNodes = q * q * q;
  matValNodes = create_matValNodes3d(len_matValNodes); // allocate memory to matValNodes
	precomp = create_precomp3d(mp+1);
	#else
	 BmomentInter = create_Bmoment(lenMoments, nb_Array);
	#endif
  
  #ifdef FUNCT_VAL
  functval = 1; //using the values stored in Cval for stiffness matrix coefficients
  
  double *B; // store barycentric coordinates of Stroud nodes
	B = new double [q*q*q*4];
	stroud_nodes_bary3d (q, B);
  
	//allocates memory to Cval
	int LEN = q * q * q;  // space required for 3D array with dimension q
  Cval = new double[LEN * nb_Array];    //Cval entries are stored in LINEAR memory, and used directly

	matrix_values_at_Stroud3d(q, Cval, B, A, v1, v2, v3, v4); // will put the values of A at the Stroud nodes into Cval
	#endif
	
	double **stiffMat;
	int len_Stiff = len_Mat3d(n);
  stiffMat = create_Mat(len_Stiff);


	#ifdef PRECOMP
	assign_pointers_Stiff3d (v1, v2, v3, v4, n, q, nDash, mp, nb_Array, matValNodes, Cval, quadraWN, precomp, A, functval);
	#else
	assign_pointers_Stiff3d (v1, v2, v3, v4, n, q, nDash, mp, nb_Array, Cval, quadraWN, BmomentInter, A, functval);
	#endif
  

	#ifdef PRECOMP
	Stiff3d (n, q, v1, v2, v3, v4, stiffMat, matValNodes, quadraWN, binomialMat,normalMat,precomp,Bmoment, Bmomentab, cpu_time);
	#else
	Stiff3d (n, q, v1, v2, v3, v4, stiffMat, quadraWN, binomialMat,normalMat,Bmoment, BmomentInter, Bmomentab, cpu_time);
	#endif
	
	

	#ifdef PRECOMP
	delete_pointers (precomp, Bmoment, Bmomentab, matValNodes, quadraWN);
	#else
	delete_pointers (Bmoment, BmomentInter, Bmomentab, quadraWN);
	#endif
		
	
  delete_BinomialMat(binomialMat, len_binomialMat);
	
	
	#ifdef FUNCT_VAL
	delete B;
	#endif
	
	
	// Insert your code here to make use of stiffMat. It will be destroyed in the next line!
	
	
  delete_Mat(stiffMat);
	
	
	#ifdef CHECK
	std::cout<<"Stiffness matrix entries stored into array stiffMat of length"<<len_Stiff<<"\n";
	#endif
	
}

// calling high-level routines


#else // default execution: computing elemental quantities using high-level routines

#ifdef BMOM

int main()
{
// 	// vertices (standard tetrahedron)
//   double v1[3] = {0, 0, 0};
//   double v2[3] = {1, 0, 0};
//   double v3[3] = {0, 1, 0};
// 	double v4[3] = {0, 0, 1};

	//vertices (particular tetrahedron)
  double v1[3] = { 1.2  , 3.4, 0}; 
  double v2[3] = { -1.5 , 2. , 0};
  double v3[3] = { 0.1  , -1., 0};
	double v4[3] = {1. , 1., 1.};
  
  int n; // degree of the B-moments
  std::cout<<"Enter a value for the polynomial order n:";
  std::cin>>n;
	
	int q=n+1; // q stands for the number of quadrature points used
	
	double (*f) (double[3]) = f0; // change here if want Bmoments associated with another function
	
	double **Bmoment; // pointer used for Bmoment entries
	int lenMoments = len_Moments3d(n, q); // memory required for storing Bmoments depends on whether or not PRECOMP is used
	int nb_Array = 1; // the Bmoments are associated with a scalar-valued function
	
	double *Cval;// store values of coefficient at Stroud nodes
	
	int functval = 0; //default: using a routine (f) for B-moments' coefficients
	
	#ifdef FUNCT_VAL
	functval = 1;  //using the values stored in Cval for B-moments' coefficients
	
	double *B; // store barycentric coordinates of Stroud nodes
	B = new double [q*q*q*4];
	stroud_nodes_bary3d (q, B);
	
	int LEN = q * q * q;  // space required for 2D array with dimension q+1	
  Cval = new double[LEN * nb_Array];    //Cval entries are stored in LINEAR memory, and used directly
  
  scalar_values_at_Stroud3d(q, Cval, B, f, v1, v2, v3, v4); // will put the values of f at the Stroud nodes into Cval
  #endif
	
	Bmoment = create_Bmoment(lenMoments, nb_Array); //allocate memory to Bmoment	
	
	// store Bmoment entries into Bmoments
	get_Bmoments3d(Bmoment, n, f, Cval, v1, v2, v3, v4, functval);
		
	#ifdef FUNCT_VAL
	delete Cval;
	delete B;
	#endif
	
	
	
	// Insert your code here to make use of Bmoment. It will be destroyed in the next line!
		
	
	delete_Bmoment(Bmoment);
}

#elif MASS

#ifdef CONSTANT
int main()
{
// 	//vertices (standard tetrahedron)
// 	double v1[3] = { 0, 0, 0};
// 	double v2[3] = { 1, 0, 0};
// 	double v3[3] = { 0, 1, 0};
// 	double v4[3] = { 0, 0, 1};

	//vertices (particular tetrahedron)
  double v1[3] = { 1.2  , 3.4, 0}; 
  double v2[3] = { -1.5 , 2. , 0};
  double v3[3] = { 0.1  , -1., 0};
	double v4[3] = {1. , 1., 1.};

	int n; // degree of the Bernstein polynomial basis
  std::cout<<"Enter a value for the polynomial order n:";
  std::cin>>n;
	
	
	double **massMat; // used for storing mass matrix entries
	
	int len_Mass = len_Mat3d(n); // allocate memory for massMat
  massMat = create_Mat(len_Mass);
	
	get_mass3d_const(massMat, n, v1, v2, v3, v4); // compute mass matrix
	
	// Insert your code here to make use of massMat. It will be destroyed in the next line!
	
	// free allocated memory
	delete_Mat(massMat);	

}

#else // not CONSTANT

int main()
{
	//vertices (standard tetrahedron)
	double v1[3] = { 0, 0, 0};
	double v2[3] = { 1, 0, 0};
	double v3[3] = { 0, 1, 0};
	double v4[3] = { 0, 0, 1};

// 	//vertices (particular tetrahedron)
//   double v1[3] = { 1.2  , 3.4, 0}; 
//   double v2[3] = { -1.5 , 2. , 0};
//   double v3[3] = { 0.1  , -1., 0};
// 	double v4[3] = {1. , 1., 1.};

	int n; // degree of the Bernstein polynomial basis
  std::cout<<"Enter a value for the polynomial order n:";
  std::cin>>n;
	
	double (*f) (double[3]) = f0; // change here if want mass matrix associated with another function
	
	double *Cval; // store array of function values at Stroud nodes
	
	int functval = 0; //default: using a routine (f) for mass matrix coefficients
	
	#ifdef FUNCT_VAL
	functval = 1;  //using the values stored in Cval for convective matrix coefficients
	
	int q = n+1;
	int nb_Array = 1; // the mass matrix is associated with scalar-valued data
	
	double *B; // store barycentric coordinates of Stroud nodes
	B = new double [q*q*q*4];
	stroud_nodes_bary3d (q, B);
	
	int LEN = q * q * q;  // space required for 3D array with dimension q+1	
  Cval = new double[LEN * nb_Array];    //Cval entries are stored in LINEAR memory, and used directly
  
  scalar_values_at_Stroud3d(q, Cval, B, f, v1, v2, v3, v4); // will put the values of f at the Stroud nodes into Cval
  #endif
	
	double **massMat; // used for storing mass matrix entries
	
	int len_Mass = len_Mat3d(n); // allocate memory for massMat
  massMat = create_Mat(len_Mass);
	
	get_mass3d(massMat, n, f, Cval, v1, v2, v3, v4, functval); // compute mass matrix
	
	// free allocated memory
	#ifdef FUNCT_VAL
	delete Cval;
	delete B;
	#endif
	
	
	// Insert your code here to make use of massMat. It will be destroyed in the next line!
	

	delete_Mat(massMat);

}

#endif // end not CONSTANT

#elif CONVEC

#ifdef CONSTANT
int main()
{
	//vertices (standard tetrahedron)
	double v1[3] = { 0, 0, 0};
	double v2[3] = { 1, 0, 0};
	double v3[3] = { 0, 1, 0};
	double v4[3] = { 0, 0, 1};

// 	//vertices (particular tetrahedron)
//   double v1[3] = { 1.2  , 3.4, 0}; 
//   double v2[3] = { -1.5 , 2. , 0};
//   double v3[3] = { 0.1  , -1., 0};
// 	double v4[3] = {1. , 1., 1.};

	int n; // degree of the Bernstein polynomial basis
  std::cout<<"Enter a value for the polynomial order n:";
  std::cin>>n;
	
	double vectCoeff[3] = {1.,1.,1.}; // vector associated with constant coefficient convective matrix
	
	double **convecMat; // store convective matrix entries
  int len_Convec = len_Mat3d(n);
  convecMat = create_Mat(len_Convec); // allocate memory to convecMat
	
	get_convec3d_const (convecMat, n, v1, v2, v3, v4, vectCoeff);// compute convective matrix
	
	// Insert your code here to make use of convecMat. It will be destroyed in the next line!
	
	// free allocated memory
	delete_Mat(convecMat);
	
}


#else // not CONSTANT


int main()
{
	//vertices (standard tetrahedron)
	double v1[3] = { 0, 0, 0};
	double v2[3] = { 1, 0, 0};
	double v3[3] = { 0, 1, 0};
	double v4[3] = { 0, 0, 1};

// 	//vertices (particular tetrahedron)
//   double v1[3] = { 1.2  , 3.4, 0}; 
//   double v2[3] = { -1.5 , 2. , 0};
//   double v3[3] = { 0.1  , -1., 0};
// 	double v4[3] = {1. , 1., 1.};

	int n; // degree of the Bernstein polynomial basis
  std::cout<<"Enter a value for the polynomial order n:";
  std::cin>>n;
	
	double *Cval; // store array of function values at Stroud quadrature nodes, dummy argument of get_convec, unless macro FUNCT_VAL is activated
	
	void (*b) (double[3], double[3]) = b0; // change here if want convective matrix associated with another vector-valued function
	
	int functval = 0; //default: using a routine (b) for convective matrix coefficients
	
	#ifdef FUNCT_VAL
	functval = 1;  //using the values stored in Cval for convective matrix coefficients
	
	int q = n+1;
	int nb_Array = 3; // the convective matrix is associated with vector-valued data
	
	double *B; // store barycentric coordinates of Stroud nodes
	B = new double [q*q*q*4];
	stroud_nodes_bary3d (q, B);
	
	int LEN = q * q * q;  // space required for 3D array with dimension q	
  Cval = new double[LEN * nb_Array];    //Cval entries are stored in LINEAR memory, and used directly
  #endif
	
	
	#ifdef FUNCT_VAL
	vector_values_at_Stroud3d(q, Cval, B, b, v1, v2, v3, v4); // will put the values of b at the Stroud nodes into Cval
	#endif
	
	
	double **convecMat; // store convective matrix entries
  int len_Convec = len_Mat3d(n);
  convecMat = create_Mat(len_Convec); // allocate memory to convecMat
	
	get_convec3d(convecMat, n, b, Cval, v1, v2, v3, v4, functval); // compute convective matrix
	
	
	// free allocated memory
	#ifdef FUNCT_VAL
	delete Cval;
	delete B;
	#endif
	
	
	
	// Insert your code here to make use of convecMat. It will be destroyed in the next line!
	
	
	// free memory allocated to convecMat
	delete_Mat(convecMat);
}

#endif // end not CONSTANT

#else // default execution: Stiffness matrix computation

#ifdef CONSTANT

int main()
{
	//vertices (standard tetrahedron)
	double v1[3] = { 0, 0, 0};
	double v2[3] = { 1, 0, 0};
	double v3[3] = { 0, 1, 0};
	double v4[3] = { 0, 0, 1};

// 	//vertices (particular tetrahedron)
//   double v1[3] = { 1.2  , 3.4, 0}; 
//   double v2[3] = { -1.5 , 2. , 0};
//   double v3[3] = { 0.1  , -1., 0};
// 	double v4[3] = {1. , 1., 1.};

	int n; // degree of the Bernstein polynomial basis
  std::cout<<"Enter a value for the polynomial order n:";
  std::cin>>n;
	
	double Coeff[6] = {1., 0., 0., 1., 0., 1.}; // upper triangular entries of (symmetric) matrix associated with stiffness matrix
	
	
	double **stiffMat;  // store stiffness matrix entries
  int len_Stiff = len_Mat3d(n); // allocate memory to stiffMat
  stiffMat = create_Mat(len_Stiff);
	
	get_stiffness3d_const (stiffMat, n, v1, v2, v3, v4, Coeff); // compute stiffness matrix
	
	// Insert your code here to make use of stiffMat. It will be destroyed in the next line!
	
	// free allocated memory;
	delete_Mat(stiffMat);
	
}

#else // not CONSTANT

int main()
{
	//vertices (standard tetrahedron)
	double v1[3] = { 0, 0, 0};
	double v2[3] = { 1, 0, 0};
	double v3[3] = { 0, 1, 0};
	double v4[3] = { 0, 0, 1};

// 	//vertices (particular tetrahedron)
//   double v1[3] = { 1.2  , 3.4, 0}; 
//   double v2[3] = { -1.5 , 2. , 0};
//   double v3[3] = { 0.1  , -1., 0};
// 	double v4[3] = {1. , 1., 1.};

	int n; // degree of the Bernstein polynomial basis
  std::cout<<"Enter a value for the polynomial order n:";
  std::cin>>n;
	
	double *Cval; // store array of function values at Stroud quadrature nodes, dummy argument of get_stiffness unless FUNCT_VAL macro is activated
	
	#ifdef FUNCT_VAL
	int q = n+1;
	int nb_Array = 6; // the stiffness matrix is associated with (symmetric) matrix-valued data
	
	double *B; // store barycentric coordinates of Stroud nodes
	B = new double [q*q*q*4];
	stroud_nodes_bary3d (q, B);
	
	int LEN = q * q * q;  // space required for 3D array with dimension q	
  Cval = new double[LEN * nb_Array];    //Cval entries are stored in LINEAR memory, and used directly
  #endif
	
	void (*A) (double[3], double[3][3]) = A0; // change here if want stiffness matrix associated with another matrix-valued function
	
	#ifdef FUNCT_VAL
	matrix_values_at_Stroud3d(q, Cval, B, A, v1, v2, v3, v4); // will put the values of A at the Stroud nodes into Cval
	#endif
	
	double **stiffMat;  // store stiffness matrix entries
  int len_Stiff = len_Mat3d(n); // allocate memory to stiffMat
  stiffMat = create_Mat(len_Stiff);
	
	get_stiffness3d(stiffMat, n, A, Cval, v1, v2, v3, v4); // compute elemental stiffness matrix
	
	// free allocated memory
	#ifdef FUNCT_VAL
	delete Cval;
	delete B;
	#endif
	
	// Insert your code here to make use of stiffMat. It will be destroyed in the next line!
	

	delete_Mat(stiffMat);

}

#endif // end not CONSTANT

#endif // end not BMOM

#endif
#include <stdio.h>
#include <math.h>
#include <time.h>
#include <iostream>

#include "bbfem.h"


// example of coefficient vector b (used with convective matrix)
void
b0 (double v[3], double res[3]) 
{
	res[0] = sin(v[0]*v[1]*v[2]);
  res[1] = 1.;
  res[2] = exp(v[0]);
}


#ifdef CONSTANT
int main()
{
// 	//vertices (standard tetrahedron)
// 	double v1[3] = { 0, 0, 0};
// 	double v2[3] = { 1, 0, 0};
// 	double v3[3] = { 0, 1, 0};
// 	double v4[3] = { 0, 0, 1};

	//vertices (particular tetrahedron)
  double v1[3] = { 1.2  , 3.4, 0}; 
  double v2[3] = { -1.5 , 2. , 0};
  double v3[3] = { 0.1  , -1., 0};
	double v4[3] = {1. , 1., 1.};

	int n; // degree of the Bernstein polynomial basis
  std::cout<<"Enter a value for the polynomial order n:";
  std::cin>>n;
	
	double vectCoeff[3] = {1.,1.,1.}; // vector associated with constant coefficient convective matrix
	
	double **convecMat; // store convective matrix entries
  int len_Convec = len_Mat3d(n);
  convecMat = create_Mat(len_Convec); // allocate memory to convecMat
	
	get_convec3d_const (convecMat, n, v1, v2, v3, v4, vectCoeff);// compute convective matrix
	
	// Insert your code here to make use of convecMat. It will be destroyed in the next line!
	
	// free allocated memory
	delete_Mat(convecMat);
	
}


#else // not CONSTANT


int main()
{
// 	//vertices (standard tetrahedron)
// 	double v1[3] = { 0, 0, 0};
// 	double v2[3] = { 1, 0, 0};
// 	double v3[3] = { 0, 1, 0};
// 	double v4[3] = { 0, 0, 1};

	//vertices (particular tetrahedron)
  double v1[3] = { 1.2  , 3.4, 0}; 
  double v2[3] = { -1.5 , 2. , 0};
  double v3[3] = { 0.1  , -1., 0};
	double v4[3] = {1. , 1., 1.};

	int n; // degree of the Bernstein polynomial basis
  std::cout<<"Enter a value for the polynomial order n:";
  std::cin>>n;
	
	void (*b) (double[3], double[3]) = b0; // change here if want convective matrix associated with another vector-valued function
	
	double *Cval; // store array of function values at Stroud quadrature nodes, dummy argument of get_convec, unless macro FUNCT_VAL is activated
	
	int functval = 0; //default: using a routine (b) for convective matrix coefficients
	
	#ifdef FUNCT_VAL
	functval = 1;  //using the values stored in Cval for convective matrix coefficients
	
	int q = n+1;
	int nb_Array = 3; // the convective matrix is associated with vector-valued data
	
	double *B; // store barycentric coordinates of Stroud nodes
	B = new double [q*q*q*4];
	stroud_nodes_bary3d (q, B);
	
	int LEN = q * q * q;  // space required for 3D array with dimension q	
  Cval = new double[LEN * nb_Array];    //Cval entries are stored in LINEAR memory, and used directly
  #endif
	
	
	#ifdef FUNCT_VAL
	vector_values_at_Stroud3d(q, Cval, B, b, v1, v2, v3, v4); // will put the values of b at the Stroud nodes into Cval
	#endif
	
	double **convecMat; // store convective matrix entries
  int len_Convec = len_Mat3d(n);
  convecMat = create_Mat(len_Convec); // allocate memory to convecMat
	
	get_convec3d(convecMat, n, b, Cval, v1, v2, v3, v4, functval); // compute convective matrix
	
	
	// free allocated memory
	#ifdef FUNCT_VAL
	delete Cval;
	delete B;
	#endif
	
	// Insert your code here to make use of convecMat. It will be destroyed in the next line!
	

	delete_Mat(convecMat);
}

#endif // end not CONSTANT
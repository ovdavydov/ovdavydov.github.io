#include <stdio.h>
#include <math.h>
#include <time.h>
#include <iostream>

#include "bbfem.h"


//variable coefficient examples:

// example of coefficient function (used with mass matrix and load vector)
double 
f0(double v[3])
{
	return sin(v[0]*v[1]*v[2]);
}

// example of coefficient vector b (used with convective matrix)
void
b0 (double v[3], double res[3]) 
{	
	res[0] = sin(v[0]*v[1]*v[2]);
  res[1] = 1.;
  res[2] = exp(v[0]);
}

// example of coefficient matrix A (used with stiffness matrix)
void
A0(double v[3], double matC[3][3]) 
{
// 	// identity matrix
//   matC[0][0]=1; matC[0][1]=0; matC[0][2]=0;
//   matC[1][0]=0; matC[1][1]=1; matC[1][2]=0;
//   matC[2][0]=0; matC[2][1]=0; matC[2][2]=1;
	
	// non-trivial matrix example
	matC[0][0]= sin(v[0]*v[1]); matC[0][1]=0; matC[0][2]=0;
  matC[1][0]=0; matC[1][1]=1; matC[1][2]=0;
  matC[2][0]=0; matC[2][1]=0; matC[2][2]=exp(v[2]);
}




int main()
{
	int matrix;
	int variable; //Boolean
	int functval;
	
	std::cout<<"load vector: 0\n";
	std::cout<<"mass matrix: 1\n";
	std::cout<<"convective matrix: 2\n";
	std::cout<<"stiffness matrix: 3\n";
	
	std::cout<<"Choose the quantity to be computed (0/1/2/3):";
  std::cin>>matrix;
	
	std::cout<<"\nNo: 0\nYes: 1\n";
	std::cout<<"Is the data variable? (0/1)\n";
	std::cin>>variable;
	

	if (variable== 1)
	{
		std::cout<<"\nNo: 0\nYes: 1\n";
		std::cout<<"Is the data given by an array of function values? (0/1)\n";
		std::cin>>functval;

	}
	
	if (variable == 0) // constant coefficients
	{
		if (matrix == 0)
		{
// 			//vertices (standard tetrahedron)
// 			double v1[3] = { 0, 0, 0};
// 			double v2[3] = { 1, 0, 0};
// 			double v3[3] = { 0, 1, 0};
// 			double v4[3] = { 0, 0, 1};

			//vertices (particular tetrahedron)
			double v1[3] = { 1.2  , 3.4, 0}; 
			double v2[3] = { -1.5 , 2. , 0};
			double v3[3] = { 0.1  , -1., 0};
			double v4[3] = {1. , 1., 1.};

			int n; // degree of the Bernstein polynomial basis
			std::cout<<"Enter a value for the polynomial order n:";
			std::cin>>n;
			
			double **Bmoment; // pointer used for Bmoment entries
			int lenMoments = ((n+3)*(n+2)*(n+1))/6; 
			int nb_Array = 1; // the Bmoments are associated with scalar-valued coefficients equal to 1
			
			Bmoment = create_Bmoment(lenMoments, nb_Array); //allocate memory to Bmoment	
			
			get_Bmoments3d_const (Bmoment, n, v1, v2, v3, v4); // store B-moments into Bmoment array
			
			// Insert your code here to make use of Bmoment. It will be destroyed in the next line!
			
			delete_Bmoment(Bmoment);

		}
		
		else if (matrix == 1)
		{
			// 	//vertices (standard triangle)
			// 	double v1[3] = { 0, 0, 0};
			// 	double v2[3] = { 1, 0, 0};
			// 	double v3[3] = { 0, 1, 0};
			// 	double v4[3] = { 0, 0, 1};

			//vertices (particular triangle)
			double v1[3] = { 1.2  , 3.4, 0}; 
			double v2[3] = { -1.5 , 2. , 0};
			double v3[3] = { 0.1  , -1., 0};
			double v4[3] = {1. , 1., 1.};

			int n; // degree of the Bernstein polynomial basis
			std::cout<<"Enter a value for the polynomial order n:";
			std::cin>>n;
			
			
			double **massMat; // used for storing mass matrix entries
			
			int len_Mass = len_Mat3d(n); // allocate memory for massMat
			massMat = create_Mat(len_Mass);
			
			get_mass3d_const(massMat, n, v1, v2, v3, v4); // compute mass matrix
			
			// Insert your code here to make use of massMat. It will be destroyed in the next line!
			
			// free allocated memory
			delete_Mat(massMat);	
		
		}
		
		else if (matrix == 2)
		{
// 			//vertices (standard triangle)
// 			double v1[3] = { 0, 0, 0};
// 			double v2[3] = { 1, 0, 0};
// 			double v3[3] = { 0, 1, 0};
// 			double v4[3] = { 0, 0, 1};

			//vertices (particular triangle)
		  double v1[3] = { 1.2  , 3.4, 0}; 
		  double v2[3] = { -1.5 , 2. , 0};
		  double v3[3] = { 0.1  , -1., 0};
			double v4[3] = {1. , 1., 1.};

			int n; // degree of the Bernstein polynomial basis
			std::cout<<"Enter a value for the polynomial order n:";
			std::cin>>n;
			
			double vectCoeff[3] = {1.,1.,1.}; // vector associated with constant coefficient convective matrix
			
			double **convecMat; // store convective matrix entries
			int len_Convec = len_Mat3d(n);
			convecMat = create_Mat(len_Convec); // allocate memory to convecMat
			
			get_convec3d_const (convecMat, n, v1, v2, v3, v4, vectCoeff);// compute convective matrix
			
			// Insert your code here to make use of convecMat. It will be destroyed in the next line!
			
			// free allocated memory
			delete_Mat(convecMat);
		}
		
		else if (matrix == 3)
		{
// 			//vertices (standard triangle)
// 			double v1[3] = { 0, 0, 0};
// 			double v2[3] = { 1, 0, 0};
// 			double v3[3] = { 0, 1, 0};
// 			double v4[3] = { 0, 0, 1};

				//vertices (particular triangle)
			  double v1[3] = { 1.2  , 3.4, 0}; 
			  double v2[3] = { -1.5 , 2. , 0};
			  double v3[3] = { 0.1  , -1., 0};
				double v4[3] = {1. , 1., 1.};

			int n; // degree of the Bernstein polynomial basis
			std::cout<<"Enter a value for the polynomial order n:";
			std::cin>>n;
			
			double Coeff[6] = {1., 0., 0., 1., 0., 1.}; // upper triangular entries of (symmetric) matrix associated with stiffness matrix
			
			
			double **stiffMat;  // store stiffness matrix entries
			int len_Stiff = len_Mat3d(n); // allocate memory to stiffMat
			stiffMat = create_Mat(len_Stiff);
			
			get_stiffness3d_const (stiffMat, n, v1, v2, v3, v4, Coeff); // compute stiffness matrix
			
			// Insert your code here to make use of stiffMat. It will be destroyed in the next line!
			
			// free allocated memory;
			delete_Mat(stiffMat);
		}
	
	}
	
	else if (variable == 1) // variable coefficients
	{
			if (matrix == 0)
			{
// 				// vertices (standard triangle)
// 				double v1[3] = { 0, 0, 0};
// 				double v2[3] = { 1, 0, 0};
// 				double v3[3] = { 0, 1, 0};
// 				double v4[3] = { 0, 0, 1};
				
				//vertices (particular triangle)
			  double v1[3] = { 1.2  , 3.4, 0}; 
			  double v2[3] = { -1.5 , 2. , 0};
			  double v3[3] = { 0.1  , -1., 0};
				double v4[3] = {1. , 1., 1.};
				
				int n; // degree of the B-moments
				std::cout<<"Enter a value for the polynomial order n:";
				std::cin>>n;
				int q = n+1;// number of quadrature points
				
				double **Bmoment; // pointer used for Bmoment entries
				int lenMoments = len_Moments3d(n, q); // memory required for storing Bmoments depends on whether or not PRECOMP is used
				int nb_Array = 1; // the Bmoments are associated with a scalar-valued function
				double *Cval; // store array of function values at Stroud quadrature nodes
				double *B; // store barycentric coordinates of Stroud nodes
				
				Bmoment = create_Bmoment(lenMoments, nb_Array); //allocate memory to Bmoment
				

				if (functval == 1)
				{
					B = new double [q*q*q*4];
					stroud_nodes_bary3d (q, B);
					
					int LEN = q * q * q;  // space required for 3D array with dimension q+1	
					Cval = new double[LEN * nb_Array];    //Cval entries are stored in LINEAR memory, and used directly
				}
				

				double (*f) (double[3]) = f0; // change here if want Bmoments associated with another function
				
				
				if (functval == 1)
				{
					// Store your data in the array Cval. 
					// In our example we evaluate the function f0 at the Stroud nodes
				
					scalar_values_at_Stroud3d(q, Cval, B, f, v1, v2, v3, v4);
				}
				
				// store Bmoment entries into Bmoments
				get_Bmoments3d(Bmoment, n, f, Cval, v1, v2, v3, v4, functval);
								
				
				// free allocated memory
				if (functval == 1)
				{
					delete Cval;
					delete B;
				}
				
				// Insert your code here to make use of Bmoment. It will be destroyed in the next line!
				
				delete_Bmoment(Bmoment);
			}
			
			else if (matrix == 1)
			{
// 				//vertices (standard triangle)
// 				double v1[3] = { 0, 0, 0};
// 				double v2[3] = { 1, 0, 0};
// 				double v3[3] = { 0, 1, 0};
// 				double v4[3] = { 0, 0, 1};

				//vertices (particular triangle)
			  double v1[3] = { 1.2  , 3.4, 0}; 
			  double v2[3] = { -1.5 , 2. , 0};
			  double v3[3] = { 0.1  , -1., 0};
				double v4[3] = {1. , 1., 1.};
				
				int n; // degree of the Bernstein polynomial basis
				std::cout<<"Enter a value for the polynomial order n:";
				std::cin>>n;
				int q = n+1; // number of quadrature points in each direction
				
				double *Cval; // store array of function values at Stroud quadrature nodes
				
				double *B; // store barycentric coordinates of Stroud nodes
				
				double **massMat; // used for storing mass matrix entries
				
				int len_Mass = len_Mat3d(n); // allocate memory for massMat
				massMat = create_Mat(len_Mass);
				
				

				if (functval == 1)
				{
					int nb_Array = 1; // the mass matrix is associated with scalar-valued data
								
					B = new double [q*q*q*4];
					stroud_nodes_bary3d (q, B);
					
					int LEN = q * q * q;  // space required for 3D array with dimension q	
					Cval = new double[LEN * nb_Array];    //Cval entries are stored in LINEAR memory, and used directly
				}

				
		
				double (*f) (double[3]) = f0; // change here if want mass matrix associated with another function
				
				if (functval == 1)
				{				
					// Store your data in the array Cval. 
					// In our example we evaluate the function f0 at the Stroud nodes					
					scalar_values_at_Stroud3d(q, Cval, B, f, v1, v2, v3, v4);
				}

				
				get_mass3d(massMat, n, f, Cval, v1, v2, v3, v4, functval); // compute mass matrix
								
				
				// free allocated memory
				if (functval == 1)
				{
					delete Cval;
					delete B;
				}
				
				
				// Insert your code here to make use of massMat. It will be destroyed in the next line!
				
				
				delete_Mat(massMat);
			}
			
			else if (matrix == 2)
			{
// 				//vertices (standard triangle)
// 				double v1[3] = { 0, 0, 0};
// 				double v2[3] = { 1, 0, 0};
// 				double v3[3] = { 0, 1, 0};
// 				double v4[3] = { 0, 0, 1};

				//vertices (particular triangle)
			  double v1[3] = { 1.2  , 3.4, 0}; 
			  double v2[3] = { -1.5 , 2. , 0};
			  double v3[3] = { 0.1  , -1., 0};
				double v4[3] = {1. , 1., 1.};

				int n; // degree of the Bernstein polynomial basis
				std::cout<<"Enter a value for the polynomial order n:";
				std::cin>>n;
				int q=n+1;
				
				double *Cval; // store array of function values at Stroud quadrature nodes
				
				double *B; // store barycentric coordinates of Stroud nodes
				
				double **convecMat; // store convective matrix entries
				int len_Convec = len_Mat3d(n);
				convecMat = create_Mat(len_Convec); // allocate memory to convecMat
				
				
				if (functval == 1)
				{
					int nb_Array = 3; // the convective matrix is associated with vector-valued data
									
					B = new double [q*q*q*4];
					stroud_nodes_bary3d (q, B);
					
					int LEN = q * q * q;  // space required for 2D array with dimension q+1	
					Cval = new double[LEN * nb_Array];    //Cval entries are stored in LINEAR memory, and used directly
				}

				

				void (*b) (double[3], double[3]) = b0; // change here if want convective matrix associated with another function
				
				if (functval == 1)
				{
					// Store your data in the array Cval. 
					// In our example we evaluate the vector function b0 at the Stroud nodes 
					vector_values_at_Stroud3d(q, Cval, B, b, v1, v2, v3, v4);
				}
				
				get_convec3d(convecMat, n, b, Cval, v1, v2, v3, v4, functval); // compute convective matrix
				
				
				// free allocated memory
				if (functval == 1)
				{
					delete Cval;
					delete B;
				}
				
				// Insert your code here to make use of convecMat. It will be destroyed in the next line!
				
				delete_Mat(convecMat);
			}
			
			else if (matrix==3)
			{
// 				//vertices (standard triangle)
// 				double v1[3] = { 0, 0, 0};
// 				double v2[3] = { 1, 0, 0};
// 				double v3[3] = { 0, 1, 0};
// 				double v4[3] = { 0, 0, 1};

				//vertices (particular triangle)
			  double v1[3] = { 1.2  , 3.4, 0}; 
			  double v2[3] = { -1.5 , 2. , 0};
			  double v3[3] = { 0.1  , -1., 0};
				double v4[3] = {1. , 1., 1.};

				int n; // degree of the Bernstein polynomial basis
				std::cout<<"Enter a value for the polynomial order n:";
				std::cin>>n;
				int q=n+1;
				
				double *Cval; // store array of function values at Stroud quadrature nodes
				
				double *B; // store barycentric coordinates of Stroud nodes
				
				double **stiffMat;  // store stiffness matrix entries
				int len_Stiff = len_Mat3d(n); // allocate memory to stiffMat
				stiffMat = create_Mat(len_Stiff);
				
				if (functval == 1)
				{
									
					int nb_Array = 6; // the stiffness matrix is associated with a symmetric matrix-valued data
					
					B = new double [q*q*q*4];
					stroud_nodes_bary3d (q, B);
									
					int LEN = q * q * q;  // space required for 3D array with dimension q	
					Cval = new double[LEN * nb_Array];    //Cval entries are stored in LINEAR memory, and used directly
				}
				
				
				void (*A) (double[3], double[3][3]) = A0; // change here if want stiffness matrix associated with another function
				
				
				if (functval == 1)
				{
					// Store your data in the array Cval. 
					// In our example we evaluate the matrix function A0 at the Stroud nodes
					matrix_values_at_Stroud3d(q, Cval, B, A, v1, v2, v3, v4);
				}
				
				
				get_stiffness3d(stiffMat, n, A, Cval, v1, v2, v3, v4, functval); // compute stiffness matrix
								
				
				// free allocated memory
				if (functval == 1)
				{
					delete Cval;
					delete B;
				}
				
				// Insert your code here to make use of stiffMat. It will be destroyed in the next line!
				
				delete_Mat(stiffMat);
			}			
	
	} // end variable data case
	
}


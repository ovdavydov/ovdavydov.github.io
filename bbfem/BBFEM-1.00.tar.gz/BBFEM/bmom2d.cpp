#include <stdio.h>
#include <math.h>
#include <time.h>
#include <iostream>


#ifdef MEX_stroud_bary
#include <mex.h>
#endif

#ifdef MEX_stroud_baryw
#include <mex.h>
#endif


#ifdef MEX_stiff
#include <mex.h>
#endif


#include "bbfem.h"


#ifdef CONSTANT

int main()
{
// 	// vertices (standard triangle)
//   double v1[2] = { 0, 0 };
//   double v2[2] = { 1, 0 };
//   double v3[2] = { 0, 1 };
	
	// non-trivial triangle
	double v1[2] = { 1.2  , 3.4 }; 
  double v2[2] = { -1.5 , 2. };
  double v3[2] = { 0.1  , -1. };
	
	int n; // degree of the B-moments
  std::cout<<"Enter a value for the polynomial order n:";
  std::cin>>n;
	
	int nb_Array = 1; // the Bmoments are associated with  scalar-valued coefficients equal to 1
	
	double **Bmoment; // store Bmoment entries
	int lenMoments = ((n+2)*(n+1)) / 2;
	Bmoment = create_Bmoment(lenMoments, nb_Array); //allocate memory to Bmoment	
	
	get_Bmoments2d_const (Bmoment, n, v1, v2, v3); // compute B-moments
	
	// Insert your code here to make use of Bmoment. It will be destroyed in the next lines!
	
	delete_Bmoment(Bmoment);
}

#else // not CONSTANT

// example of function f: f(x,y) = 2 - sin(xy)
double
f0 (double v[2])
{
 return 2 - sin (v[0]*v[1]);
}


int main()
{
// 	// vertices (standard triangle)
//   double v1[2] = { 0, 0 };
//   double v2[2] = { 1, 0 };
//   double v3[2] = { 0, 1 };
	
	// non-trivial triangle
	double v1[2] = { 1.2  , 3.4 }; 
  double v2[2] = { -1.5 , 2. };
  double v3[2] = { 0.1  , -1. };
	
  
  int n; // degree of the B-moments
  std::cout<<"Enter a value for the polynomial order n:";
  std::cin>>n;
	
	int q=n+1; // q stands for the number of quadrature points used in each direction
	int nb_Array = 1; // the Bmoments are associated with a scalar-valued function
	
	double *Cval;
	
	int functval = 0; //default: using a routine (f) for Bmoments' coefficients
	
	double (*f) (double[2]) = f0; // change here to your routine for B-moments' coefficients
	
	#ifdef FUNCT_VAL
	functval = 1;  //using the values stored in Cval for Bmoments' coefficients
	
	double *B; // store barycentric coordinates of Stroud nodes
	B = new double [q*q*3];
	stroud_nodes_bary2d (q, B);
	
	
	int LEN = q * q ;  // space required for 2D array with dimension q+1	
  Cval = new double[LEN * nb_Array];    //Cval entries are stored in LINEAR memory, and used directly
  
  //storing your data in Cval
	scalar_values_at_Stroud2d(q, Cval, B, f, v1, v2, v3 );
	#endif
	
	double **Bmoment; // store Bmoment entries
	int lenMoments = len_Moments2d(n, q); // memory required for storing Bmoments depends on whether or not PRECOMP is used
	Bmoment = create_Bmoment(lenMoments, nb_Array); //allocate memory to Bmoment	
	

	get_Bmoments2d(Bmoment, n, f, Cval, v1, v2, v3, functval); // compute B-moments
	
		
	//free allocated memory
	#ifdef FUNCT_VAL
	delete Cval;
	delete B;
	#endif
	
	// Insert your code here to make use of Bmoment. It will be destroyed in the next lines!
	
	delete_Bmoment(Bmoment);
	
}

#endif // end not CONSTANT

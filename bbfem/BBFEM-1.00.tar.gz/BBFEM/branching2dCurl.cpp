#include <stdio.h>
#include <math.h>
#include <time.h>
#include <iostream>

#include "bbfem.h"
#include "bbfem2dCurl.h"

#ifndef MAX
#define MAX(a,b) ( (a) > (b) ? (a) : (b) )
#endif

// example of stiffness matrix coefficient
double 
A0 (double v[2])
{	
	return 2.0 - sin(v[0]*v[1]);
}

//example of matrix Kappa:
void
Kappa0 (double v[2], double matC[2][2])
{
//   // standard coefficient matrix (identity) for stiffness
//   matC[0][0] = 1;
//   matC[0][1] = 0;
//   matC[1][0] = 0;
//   matC[1][1] = 1;

// compare with Matlab's results: A=[10+x yx^2; yx^2 2-sin(xy)]
  matC[0][0] =  10.0 + v[0];
  matC[0][1] =  v[1] * v[0] * v[0];
  matC[1][0] =  v[1] * v[0] * v[0];
  matC[1][1] =  2.0 - sin(v[0]*v[1]);

}

// example of load vector coefficient
void 
F0( double v[2], double vectF[2] )
{
	
	vectF[0] = 2 - sin(v[0]*v[1]);
	vectF[1] = 1 - v[0]*v[1];
}


int main()
{
	
	int matrix;
	int functval; // Boolean
	

	std::cout<<"load vector: 0\n";
	std::cout<<"mass matrix: 1\n";
	std::cout<<"stiffness matrix: 2\n";
		
	
	std::cout<<"Choose the quantity to be computed (0/1/2/3):";
  std::cin>>matrix;
	
	std::cout<<"\nNo: 0\nYes: 1\n";
	std::cout<<"Is the data given by an array of function values? (0/1)\n";
	std::cin>>functval;
	
	
	if (matrix==0) // load vector computation
	{
//		   //vertices (standard triangle)
//   		double v1[2] = { 0, 0 };
//   		double v2[2] = { 1, 0 };
//   		double v3[2] = { 0, 1 };

		//vertices (particular triangle)
		double v1[2] = { 1.2  , 3.4 }; 
		double v2[2] = { -1.5 , 2. };
		double v3[2] = { 0.1  , -1. };
		
		int n; // degree of the Bernstein polynomial basis
		std::cout<<"Enter a value for the polynomial order n:";
		std::cin>>n;
		int q = n+1; // number of quadrature points
		
		double *Cval; // store array of function values at Stroud quadrature nodes
		double *B; // store barycentric coordinates of Stroud nodes
		
		double *loadVect;  // store load vector entries
		int len_Load = dimCurl(n); // allocate memory to stiffMat
		loadVect = new double [len_Load];
		
		if (functval == 1)
		{
			functval = 1;  //using the values stored in Cval for load vector coefficients
			int q = n+1;
			int nb_Array = 2; // the load vector is associated with vector-valued data
			
			// store barycentric coordinates of Stroud nodes
			B = new double [q*q*3];
			stroud_nodes_bary2d (q, B);
			
			int LEN = q * q ;  // space required for 2D array with dimension q x q
			Cval = new double[LEN * nb_Array];    //Cval entries are stored in LINEAR memory, and used directly		
		}
		
		void (*F) (double[2], double[2]) = F0; // change here to your routine for load vector coefficients
		
		if (functval == 1)
			vector_values_at_Stroud2d(q, Cval, B, F, v1, v2, v3 );
		
		get_load2dCurl(loadVect, n, F, Cval, v1, v2, v3, functval); // compute load vector
		
		// free allocated memory
		if (functval == 1)
		{
			delete Cval;
			delete B;
		}
		
		// Insert your code here to make use of loadVect. It will be destroyed in the next line!
		
		delete loadVect;
		
	}
	else if (matrix==1) // mass matrix computation
	{
//		   //vertices (standard triangle)
//   		double v1[2] = { 0, 0 };
//   		double v2[2] = { 1, 0 };
//   		double v3[2] = { 0, 1 };

		//vertices (particular triangle)
		double v1[2] = { 1.2  , 3.4 }; 
		double v2[2] = { -1.5 , 2. };
		double v3[2] = { 0.1  , -1. };
		
		int n; // degree of the Bernstein polynomial basis
		std::cout<<"Enter a value for the polynomial order n:";
		std::cin>>n;
		int q = n+1; // number of quadrature points
		
		double *Cval; // store array of function values at Stroud quadrature nodes
		double *B; // store barycentric coordinates of Stroud nodes
		
		double **massMat; // used for storing mass matrix entries
		int len_Mass = dimCurl(n);
		massMat = create_Mat(len_Mass);
		
		if (functval == 1)
		{
			int nb_Array = 3; // the mass matrix is associated with (symmetric) matrix-valued data
	
			// store barycentric coordinates of Stroud nodes
			B = new double [q*q*3];
			stroud_nodes_bary2d (q, B);
			
			int LEN = q * q ;  // space required for 2D array with dimension q x q
			Cval = new double[LEN * nb_Array];    //Cval entries are stored in LINEAR memory, and used directly
		}
		
		void (*Kappa) (double[2], double[2][2]) = Kappa0; // change here to your routine for mass matrix coefficients
		
		if (functval==1)
			matrix_values_at_Stroud2d(q, Cval, B, Kappa, v1, v2, v3 ); // storing your data in Cval
		
		
		get_mass2dCurl(massMat, n, Kappa, Cval, v1, v2, v3, functval); // compute elemental mass matrix
	
	
		// free allocated memory
		if (functval==1)
		{
			delete Cval;
			delete B;
		}
		
		// Insert your code here to make use of massMat. It will be destroyed in the next line!
		
		delete_Mat(massMat);		
	}
	
	else if (matrix==2) // stiffness matrix computation
	{
//		   //vertices (standard triangle)
//   		double v1[2] = { 0, 0 };
//   		double v2[2] = { 1, 0 };
//   		double v3[2] = { 0, 1 };

		//vertices (particular triangle)
		double v1[2] = { 1.2  , 3.4 }; 
		double v2[2] = { -1.5 , 2. };
		double v3[2] = { 0.1  , -1. };
		
		int n; // degree of the Bernstein polynomial basis
		std::cout<<"Enter a value for the polynomial order n:";
		std::cin>>n;
		int q = n+1; // number of quadrature points
		
		double *Cval; // store array of function values at Stroud quadrature nodes
		double *B; // store barycentric coordinates of Stroud nodes
		
		double **stiffMat;  // store (non-zero) stiffness matrix entries
		int len_Stiff = dim_nonGradCurl(n); // allocate memory to stiffMat
		stiffMat = create_Mat(len_Stiff);
		
		if (functval == 1)
		{
			functval = 1;  //using the values stored in Cval for mass matrix coefficients
			int q = n+1;
			int nb_Array = 1; // the stiffness matrix is associated with scalar-valued data
			
			// store barycentric coordinates of Stroud nodes
			B = new double [q*q*3];
			stroud_nodes_bary2d (q, B);
			
			int LEN = q * q ;  // space required for 2D array with dimension q x q
			Cval = new double[LEN * nb_Array];    //Cval entries are stored in LINEAR memory, and used directly
		}
		
		double (*A) (double[2]) = A0; // change here to your routine for stiffness matrix coefficients
		
		if (functval == 1)
			scalar_values_at_Stroud2d(q, Cval, B, A, v1, v2, v3 ); // storing your data in Cval
		
		get_stiffness2dCurl(stiffMat, n, A, Cval, v1, v2, v3, functval); // compute non-zero stiffness matrix entries
		
		// free allocated memory
		if (functval == 1)
		{
			delete Cval;
			delete B;
		}
		
		
		// Insert your code here to make use of stiffMat. It will be destroyed in the next line!
		
		
		delete_Mat(stiffMat);
		
	}

}
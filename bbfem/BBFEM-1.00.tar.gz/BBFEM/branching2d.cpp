#include <stdio.h>
#include <math.h>
#include <time.h>
#include <iostream>

#include "bbfem.h"

#ifndef MAX
#define MAX(a,b) ( (a) > (b) ? (a) : (b) )
#endif


// variable coefficient examples:

//example of matrix A: unit matrix (corresponds to constant coefficients)
void
A0 (double v[2], double matC[2][2])
{
//   // standard coefficient matrix (identity) for stiffness
//   matC[0][0] = 1;
//   matC[0][1] = 0;
//   matC[1][0] = 0;
//   matC[1][1] = 1;

// compare with Matlab's results: A=[10+x yx^2; yx^2 2-sin(xy)]
  matC[0][0] =  10.0 + v[0];
  matC[0][1] =  v[1] * v[0] * v[0];
  matC[1][0] =  v[1] * v[0] * v[0];
  matC[1][1] =  2.0 - sin(v[0]*v[1]);

}

// example of function f: f(x,y) = 2-sin(xy)
double
f0 (double v[2])
{
  return 2 - sin (v[0]*v[1]); 
}

//example of vector b(x,y) = (2-sin(xy),1-xy)^tr
void
b0 (double v[2], double vect[2])
{	
	vect[0] = 2 - sin(v[0]*v[1]);
	vect[1] = 1 - v[0]*v[1];	
}


int main()
{
	int matrix;
	int variable; // Boolean
	int functval;

	std::cout<<"load vector: 0\n";
	std::cout<<"mass matrix: 1\n";
	std::cout<<"convective matrix: 2\n";
	std::cout<<"stiffness matrix: 3\n";
	
	std::cout<<"Choose the quantity to be computed (0/1/2/3):";
  std::cin>>matrix;
	
	std::cout<<"\nNo: 0\n Yes: 1\n";
	std::cout<<"Is the data variable? (0/1)\n";
	std::cin>>variable;
	
	if (variable== 1)
	{
		std::cout<<"\nNo: 0\nYes: 1\n";
		std::cout<<"Is the data given by an array of function values? (0/1)\n";
		std::cin>>functval;

	}
	

	if (variable==0) // constant data
	{
		if (matrix==0)
		{

// 			// vertices (standard triangle)
// 			double v1[2] = { 0, 0 };
// 			double v2[2] = { 1, 0 };
// 			double v3[2] = { 0, 1 };
			
			// non-trivial triangle
			double v1[2] = { 1.2  , 3.4 }; 
			double v2[2] = { -1.5 , 2. };
			double v3[2] = { 0.1  , -1. };
			
			int n; // degree of the B-moments
			std::cout<<"Enter a value for the polynomial order n:";
			std::cin>>n;
			
			int nb_Array = 1; // the Bmoments are associated with  scalar-valued coefficients equal to 1
			
			double **Bmoment; // store Bmoment entries
			int lenMoments = ((n+2)*(n+1)) / 2;
			Bmoment = create_Bmoment(lenMoments, nb_Array); //allocate memory to Bmoment	
			
			get_Bmoments2d_const (Bmoment, n, v1, v2, v3); // compute B-moments
			
			// Insert your code here to make use of Bmoment. It will be destroyed in the next lines!
			
			delete_Bmoment(Bmoment);	

		}

		else if (matrix==1)
		{
			//   //vertices (standard triangle)
			//   double v1[2] = { 0, 0 };
			//   double v2[2] = { 1, 0 };
			//   double v3[2] = { 0, 1 };

			//vertices (particular triangle)
			double v1[2] = { 1.2  , 3.4 }; 
			double v2[2] = { -1.5 , 2. };
			double v3[2] = { 0.1  , -1. };
			
			int n; // degree of the Bernstein polynomial basis
			std::cout<<"Enter a value for the polynomial order n:";
			std::cin>>n;
			
			double **massMat; // used for storing mass matrix entries	
			int len_Mass = len_Mat2d(n); // allocate memory for massMat
			massMat = create_Mat(len_Mass);
			
			get_mass2d_const(massMat, n, v1, v2, v3);
			
			// Insert your code here to make use of massMat. It will be destroyed in the next line!
				
			// free memory allocated to massMat
			delete_Mat(massMat);
		}
		
		else if (matrix==3)
		{
			//   //vertices (standard triangle)
			//   double v1[2] = { 0, 0 };
			//   double v2[2] = { 1, 0 };
			//   double v3[2] = { 0, 1 };
			
			//vertices (particular triangle)
			double v1[2] = { 1.2  , 3.4 }; 
			double v2[2] = { -1.5 , 2. };
			double v3[2] = { 0.1  , -1. };

			int n; // degree of the Bernstein polynomial basis
			std::cout<<"Enter a value for the polynomial order n:";
			std::cin>>n;
			
			double **stiffMat;  // store stiffness matrix entries
			int len_Stiff = len_Mat2d(n); // allocate memory to stiffMat
			stiffMat = create_Mat(len_Stiff);
			
			double Coeff[3] = {1.,0.,1.}; // the constant coefficient associated with the stiffness 
																// matrix is the identity matrix
			
			get_stiffness2d_const (stiffMat, n, v1, v2, v3, Coeff);// compute stiffness matrix
			
			// Insert your code here to make use of stiffMat. It will be destroyed in the next line!
			
			// free allocated memory
			delete_Mat(stiffMat);
		}
		
		else if (matrix==2)
		{
			//   //vertices (standard triangle)
			//   double v1[2] = { 0, 0 };
			//   double v2[2] = { 1, 0 };
			//   double v3[2] = { 0, 1 };
			
			//vertices (particular triangle)
			double v1[2] = { 1.2  , 3.4 }; 
			double v2[2] = { -1.5 , 2. };
			double v3[2] = { 0.1  , -1. };

			int n; // degree of the Bernstein polynomial basis
			std::cout<<"Enter a value for the polynomial order n:";
			std::cin>>n;
			
			double vectCoeff[2] = {1.,1.}; // coefficient vector associated with convective matrix
			
			double **convecMat; // store convective matrix entries
			int len_Convec = len_Mat2d(n);
			convecMat = create_Mat(len_Convec); // allocate memory to convecMat
			
			get_convec2d_const (convecMat, n, v1, v2, v3, vectCoeff); // compute convective matrix
			
			// Insert your code here to make use of convecMat. It will be destroyed in the next line!
			
			// free allocated memory
			delete_Mat(convecMat);
		}
	
	} // end of CONSTANT data
	
	else if (variable== 1) // variable data
	{
			if (matrix== 0 )
			{
				// 	// vertices (standard triangle)
				//   double v1[2] = { 0, 0 };
				//   double v2[2] = { 1, 0 };
				//   double v3[2] = { 0, 1 };
	
				// non-trivial triangle
				double v1[2] = { 1.2  , 3.4 }; 
				double v2[2] = { -1.5 , 2. };
				double v3[2] = { 0.1  , -1. };
				
				int n; // degree of the B-moments
				std::cout<<"Enter a value for the polynomial order n:";
				std::cin>>n;
				int q = n+1;// number of quadrature points
				
				double *Cval;// store array of function values at Stroud quadrature nodes
				double *B; // store barycentric coordinates of Stroud nodes
				
				double **Bmoment; // pointer used for Bmoment entries
				int lenMoments = len_Moments2d(n, q); // memory required for storing Bmoments depends on whether or not PRECOMP is used
				int nb_Array = 1; // the Bmoments are associated with a scalar-valued function
				Bmoment = create_Bmoment(lenMoments, nb_Array); //allocate memory to Bmoment
				
			
				if (functval == 1)
				{
					B = new double [q*q*3];
					stroud_nodes_bary2d (q, B);					
					
					int LEN = q * q ;  // space required for 2D array with dimension q+1	
					Cval = new double[LEN * nb_Array];    //Cval entries are stored in LINEAR memory, and used directly
				}

				
				
				double (*f) (double[2]) = f0; // change here if want Bmoments associated with another function
				
				if (functval == 1)
				{
					// Store your data in the array Cval. 
					// In our example we evaluate the function f0 at the Stroud nodes					
					scalar_values_at_Stroud2d(q, Cval, B, f, v1, v2, v3 ); 
				}
				
				
				// store Bmoment entries into Bmoments
				get_Bmoments2d(Bmoment, n, f, Cval, v1, v2, v3, functval);
				
				
				// free allocated memory
				if (functval == 1)
				{
					delete Cval;
					delete B;
				}

								
				// Insert your code here to make use of Bmoment. It will be destroyed in the next line!
				
				delete_Bmoment(Bmoment);
			}
			

			else if (matrix==1)
			{
				//   //vertices (standard triangle)
				//   double v1[2] = { 0, 0 };
				//   double v2[2] = { 1, 0 };
				//   double v3[2] = { 0, 1 };

				//vertices (particular triangle)
				double v1[2] = { 1.2  , 3.4 }; 
				double v2[2] = { -1.5 , 2. };
				double v3[2] = { 0.1  , -1. };
				
				int n; // degree of the Bernstein polynomial basis
				std::cout<<"Enter a value for the polynomial order n:";
				std::cin>>n;
				int q = n+1; // number of quadrature points
				
				double *Cval; // store array of function values at Stroud quadrature nodes
				double *B; // store barycentric coordinates of Stroud nodes
				
				double **massMat; // used for storing mass matrix entries
				
				int len_Mass = len_Mat2d(n); // allocate memory for massMat
				massMat = create_Mat(len_Mass);
				
				if (functval == 1)
				{
									
					int nb_Array = 1; // the mass matrix is associated with scalar-valued data
					
					B = new double [q*q*3];
					stroud_nodes_bary2d (q, B);			
					
					int LEN = q * q ;  // space required for 2D array with dimension q+1	
					Cval = new double[LEN * nb_Array];    //Cval entries are stored in LINEAR memory, and used directly
				}
				
				
				double (*f) (double[2]) = f0; // change here if want mass matrix associated with another function
				

				if (functval == 1)
				{
					// Store your data in the array Cval. 
					// In our example we evaluate the function f0 at the Stroud nodes
					scalar_values_at_Stroud2d(q, Cval, B, f, v1, v2, v3 );
				}
								
				get_mass2d(massMat, n, f, Cval, v1, v2, v3, functval); // compute mass matrix
				
				
				// free allocated memory
				if (functval == 1)
				{
					delete Cval;
					delete B;
				}
				
				
				// Insert your code here to make use of massMat. It will be destroyed in the next line!
				
				delete_Mat(massMat);

			}
			
			else if (matrix==2)
			{
				//   //vertices (standard triangle)
				//   double v1[2] = { 0, 0 };
				//   double v2[2] = { 1, 0 };
				//   double v3[2] = { 0, 1 };
				
				//vertices (particular triangle)
				double v1[2] = { 1.2  , 3.4 }; 
				double v2[2] = { -1.5 , 2. };
				double v3[2] = { 0.1  , -1. };

				int n; // degree of the Bernstein polynomial basis
				std::cout<<"Enter a value for the polynomial order n:";
				std::cin>>n;
				int q=n+1;
				
				double *Cval; // store array of function values at Stroud quadrature nodes
				double *B; // store barycentric coordinates of Stroud nodes
				
				double **convecMat; // store convective matrix entries
				int len_Convec = len_Mat2d(n);
				convecMat = create_Mat(len_Convec); // allocate memory to convecMat
				
				if (functval==1)
				{
					int nb_Array = 2; // the convective matrix is associated with vector-valued data
					
					B = new double [q*q*3];
					stroud_nodes_bary2d (q, B);
					
					int LEN = q * q ;  // space required for 2D array with dimension q+1	
					Cval = new double[LEN * nb_Array];    //Cval entries are stored in LINEAR memory, and used directly
				}
				
				
				void (*b) (double[2], double[2]) = b0; // change here if want convective matrix associated with another function
				

				if (functval==1)
				{
					// Store your data in the array Cval. 
					// In our example we evaluate the vector function b0 at the Stroud nodes
						vector_values_at_Stroud2d(q, Cval, B, b, v1, v2, v3 );
				}

				get_convec2d(convecMat, n, b, Cval, v1, v2, v3, functval); // compute convective matrix
				
				
				// free allocated memory
				if (functval==1)
				{
					delete Cval;
					delete B;
				}
				
				// Insert your code here to make use of convecMat. It will be destroyed in the next line!
				
				delete_Mat(convecMat);
			}
			
			else if (matrix==3)
			{
				//   //vertices (standard triangle)
				//   double v1[2] = { 0, 0 };
				//   double v2[2] = { 1, 0 };
				//   double v3[2] = { 0, 1 };
				
				//vertices (particular triangle)
				double v1[2] = { 1.2  , 3.4 }; 
				double v2[2] = { -1.5 , 2. };
				double v3[2] = { 0.1  , -1. };

				int n; // degree of the Bernstein polynomial basis
				std::cout<<"Enter a value for the polynomial order n:";
				std::cin>>n;
				int q=n+1;
				
				
				double *Cval; // store array of function values at Stroud quadrature nodes
				double *B; // store barycentric coordinates of Stroud nodes
				
				double **stiffMat;  // store stiffness matrix entries
				int len_Stiff = len_Mat2d(n); // allocate memory to stiffMat
				stiffMat = create_Mat(len_Stiff);
				
				if (functval==1)
				{
									
					int nb_Array = 3; // the stiffness matrix is associated with a symmetric matrix-valued data
										
					B = new double [q*q*3];
					stroud_nodes_bary2d (q, B);
										
					int LEN = q * q ;  // space required for 2D array with dimension q+1	
					Cval = new double[LEN * nb_Array];    //Cval entries are stored in LINEAR memory, and used directly
				}
				
				
				void (*A) (double[2], double[2][2]) = A0; // change here if want stiffness matrix associated with another function
				

				if (functval==1)
				{
					// Store your data in the array Cval. 
					// In our example we evaluate the matrix function A0 at the Stroud nodes
					matrix_values_at_Stroud2d(q, Cval, B, A, v1, v2, v3 );
				}

				get_stiffness2d(stiffMat, n, A, Cval, v1, v2, v3, functval); // compute elemental stiffness matrix
				
				
				// free allocated memory
				if (functval==1)
				{
					delete Cval;
					delete B;
				}
				
				// Insert your code here to make use of stiffMat. It will be destroyed in the next line!
				
				delete_Mat(stiffMat);
			}			

	}  // end VARIABLE case
	
	
}


#include <stdio.h>
#include <math.h>
#include <time.h>
#include <iostream>


#ifdef MEX_stroud_bary2d
#include <mex.h>
#endif

#ifdef MEX_stroud_bary2dw
#include <mex.h>
#endif


#ifdef MEX_stiff
#include <mex.h>
#endif

#include "bbfem.h"


//declaration from GaussJacobi.cpp
void gaujac(int n, float alf, float bet, double *x, double *w);

#ifndef MAX
#define MAX(a,b) ( (a) > (b) ? (a) : (b) )
#endif


//example of matrix A
void
A0 (double v[2], double matC[2][2])
{
//   // standard coefficient matrix (identity) for stiffness
//   matC[0][0] = 1;
//   matC[0][1] = 0;
//   matC[1][0] = 0;
//   matC[1][1] = 1;

// compare with Matlab's results: A=[10+x yx^2; yx^2 2-sin(xy)]
  matC[0][0] =  10.0 + v[0];
  matC[0][1] =  v[1] * v[0] * v[0];
  matC[1][0] =  v[1] * v[0] * v[0];
  matC[1][1] =  2.0 - sin(v[0]*v[1]);

}


// example of function f: f(x) = 2 - sin(xy)
double
f0 (double v[2])
{ 
  return 2 - sin (v[0]*v[1]); 
}



//example of vector b: [2 - sin(xy) ; 1 - xy]
void
b0 (double v[2], double vect[2])
{
	
	vect[0] = 2 - sin(v[0]*v[1]);
	vect[1] = 1 - v[0]*v[1];
	
}


//routines

//// B-moment vector //////////////////


double
timeMomentVect (double (*f) (double[2]), int n, int q, double v1[2], double v2[2], double v3[2], int nbIter, double **binomialMat)
{
	
	#ifdef PRECOMP
	double **precomp;
  double **matValNodes;
	#else
	double **BmomentInter;
	#endif
	
  double **Bmoment;
	double *Cval;
	double **quadraWN;
	
	int functval = 0; //default: using a routine (f) for B-moments' coefficients
	
	int m = n, nDash = n;                   
  int nb_Array = 1;
	
	
	//allocates memory to quadraWN1 and quadraWN2;
	int len_Quadra = (q + 1);     // space required for storing Jacobi nodes of order q is q, BUT indexing starts at 1
  quadraWN = create_quadraWN2d(len_Quadra); // store quadrature weights and nodes of a fixed degree >> now also used with PRECOMP
	
	int lenMoments = len_Moments2d(n,q); // size of Bmoments
  Bmoment = create_Bmoment(lenMoments, nb_Array); // allocate memory for the Bmoment array
	
#ifdef PRECOMP
	//allocates memory to MatValNodes
	int len_matValNodes = q * q ; // space required for 2D array with dimension q
  matValNodes =create_matValNodes2d(len_matValNodes);
	precomp = create_precomp2d(m+1); // for B-moments, m=n	

#else	
	BmomentInter = create_Bmoment(lenMoments, nb_Array);
#endif

#ifdef FUNCT_VAL
	functval = 1; //using the values stored in Cval for B-moments' coefficients

	double *B; // store barycentric coordinates of Stroud nodes
	B = new double [q*q*3];
	stroud_nodes_bary2d (q, B);
	
	//allocate memory for Cval
  int LEN = q * q ;  // space required for 2D array with dimension q
	Cval = new double[LEN * nb_Array];    //Cval entries are stored in LINEAR memory, and used directly
	
	scalar_values_at_Stroud2d(q, Cval, B, f, v1, v2, v3 ); // store the values of f at the Stroud nodes into Cval
#endif

	
	#ifdef PRECOMP
	assign_pointers_Bmom2d (v1, v2, v3, n, q, nDash, m, nb_Array,matValNodes, Cval, quadraWN, precomp, f, functval);
	#else
	assign_pointers_Bmom2d (v1, v2, v3, n, q, nDash, m, nb_Array, Cval, quadraWN, Bmoment, f, functval);
	#endif


  double average = 0;
  for (int k = 0; k < nbIter; k++)
    {
#ifdef PRECOMP 
	average += Bmoment2d (n, q, m, nb_Array, v1, v2, v3, binomialMat, precomp, Bmoment, matValNodes); 
#else //not PRECOMP
	  average += Bmoment2d_Index (n, q, nb_Array, Bmoment, BmomentInter, quadraWN);
#endif
    }
    		

	#ifdef PRECOMP
	delete_pointers_Bmom(precomp, matValNodes, quadraWN);
	#else
	delete_pointers_Bmom(BmomentInter, quadraWN);
	#endif
	

	#ifdef FUNCT_VAL
  delete Cval;
	delete B;
	#endif

	delete_Bmoment(Bmoment);
	
	
  return average / nbIter;
}

void
printTimeMomentVect (double (*f) (double[2]), int n0, int n1, double v1[2], double v2[2], double v3[2], int nbIter)
{

  int len_binomial = 300;             // len_binomial is an upper bound for the dimension of binomialMat
  //allocates memory to binomialMat
  double **binomialMat = create_BinomialMat(len_binomial);

  //computes binomials
  computeBinomials(binomialMat, len_binomial);


#ifdef LOG
  int step = MAX ((int) (n0 / 1.5), 1);
  for (int n = n0; n <= n1; n += step, step = MAX ((int) (n / 1.5), 1))
    {
      std::cout << n << ", ";
    }
  std::cout << "\n";

  step = MAX ((int) (n0 / 1.5), 1);
  for (int n = n0; n <= n1; n += step, step = MAX ((int) (n / 1.5), 1))
    {
			int q = n+1;                
      fprintf (stderr, "%f, ", timeMomentVect (f, n, q, v1, v2, v3, nbIter, binomialMat));
    }
  std::cout << "\n";

#else

  std::cout << "[";
  for (int n = n0; n < n1; n++)
    {
			int q = n+1;                
      std::cout << timeMomentVect (f, n, q, v1, v2, v3, nbIter, binomialMat) << ",";
    }

	int q = n1+1;
  std::cout << timeMomentVect (f, n1, q, v1, v2, v3, nbIter, binomialMat) << "]\n";

#endif

  delete_BinomialMat (binomialMat, len_binomial);
}



///// elemental matrices //////////////

double
timeMass (int n, int q, double v1[2], double v2[2], double v3[2], int nbIter, double **binomialMat)
{

  double **massMat;     // store mass matrix entries

  int len_Mass = ((n + 1) * (n + 2)) / 2;

  massMat = create_Mat(len_Mass);
  
	#ifdef CONSTANT
	;
	#else // by default: variable case
	
	double (*f) (double[2]) = f0;
	
	#ifdef PRECOMP
	double **precomp;	// needs to be created, since passed as arguments into Mass
	double **matValNodes;
	#else
	double **BmomentInter;
	#endif
	
	double **Bmoment; 
	double *Cval;
	double **quadraWN;	// store quadrature weights and nodes of a fixed degree
	
	int functval = 0; //default: using a routine (f) for mass matrix coefficients
	
	int nDash = 2 * n;            // the Bmoment required for the mass matrix is 2n
  int m = MAX(nDash,q-1);  // m is used for indexing with non-PRECOMP, and for allowing sufficient size to "precomp"
	int nb_Array = 1;             // the Bmoment required is associated with a SCALAR function
	
  
	// allocates memory to quadraWN
	int len_Quadra = (q + 1);     // space required for storing Jacobi nodes of order q is q, BUT indexing starts at 1
  quadraWN = create_quadraWN2d(len_Quadra);
 
	int lenMoments = len_Moments2d(nDash, q);
  Bmoment = create_Bmoment(lenMoments, nb_Array);
	
	
	#ifdef PRECOMP
	int len_matValNodes = q * q;      // space required for 2D array with dimension q
  matValNodes =create_matValNodes2d(len_matValNodes);
	precomp = create_precomp2d(m+1);
	#else
	BmomentInter = create_Bmoment(lenMoments, nb_Array);
	#endif
	
	#ifdef FUNCT_VAL
	functval = 1; //using the values stored in Cval for mass matrix coefficients
	
	double *B; // store barycentric coordinates of Stroud nodes
	B = new double [q*q*3];
	stroud_nodes_bary2d (q, B);
	
  //allocates memory for Cval
  int LEN = q * q ;  // space required for 2D array with dimension q
	Cval = new double[LEN * nb_Array];    //Cval entries are stored in LINEAR memory, and used directly
	
	scalar_values_at_Stroud2d(q, Cval, B, f, v1, v2, v3 ); // store the values of f at the Stroud nodes into Cval
	#endif
	
	//assign values to auxilliary arrays
	#ifdef PRECOMP
	assign_pointers_Mass2d (v1, v2, v3, n, q, nDash, m, nb_Array,matValNodes, Cval, quadraWN, precomp, f, functval);
	#else
	assign_pointers_Mass2d (v1, v2, v3, n, q, nDash, m, nb_Array, Cval, quadraWN, Bmoment, f, functval);
	#endif
	

#endif // end not CONSTANT

  double average = 0;
  for (int i = 0; i < nbIter; i++)
	{
		#ifdef CONSTANT
		average += Mass2d_const(n, v1, v2, v3, binomialMat, massMat);
		#else
		#ifdef PRECOMP
		average += Mass2d (n, q, v1, v2, v3, binomialMat, precomp, Bmoment, massMat, matValNodes, quadraWN);
		#else
		average += Mass2d (n, q, v1, v2, v3, binomialMat, Bmoment, BmomentInter, massMat, quadraWN);
		#endif
		
		#endif
	}
	

#ifdef CONSTANT
;
#else // by default: variable case


	#ifdef PRECOMP
	delete_pointers_Mass(precomp, Bmoment, matValNodes, quadraWN);
	#else
	delete_pointers_Mass(Bmoment, BmomentInter, quadraWN);
	#endif
		

#ifdef FUNCT_VAL
  delete Cval;
	delete B;
#endif


#endif // end not CONSTANT

  delete_Mat(massMat);

  return average / nbIter;
}


void
printTimeMass (int n0, int n1, double v1[2], double v2[2], double v3[2], int nbIter)
{

  int len_binomial = 300;
	double **binomialMat;
  //allocate memory to binomialMat
  binomialMat = create_BinomialMat(len_binomial);


  //compute binomials
  computeBinomials(binomialMat, len_binomial);


#ifdef LOG

  int step = MAX ((int) (n0 / 1.5), 1);
  for (int n = n0; n <= n1; n += step, step = MAX ((int) (n / 1.5), 1))
    {
      std::cout << n << ", ";
    }
  std::cout << "\n";

  step = MAX ((int) (n0 / 1.5), 1);
  for (int n = n0; n <= n1; n += step, step = MAX ((int) (n / 1.5), 1))
	{
		int q = n+1;
    fprintf (stderr, "%f, ", timeMass (n, q, v1, v2, v3, nbIter, binomialMat));
	}
  std::cout << "\n";

#else

  std::cout << "[";
  for (int n = n0; n < n1; n++)
	{
		int q=n+1;
    std::cout << timeMass (n, q, v1, v2, v3, nbIter, binomialMat) << ",";
	}
	int q = n1+1;
  std::cout << timeMass (n1, q, v1, v2, v3, nbIter, binomialMat) << "]\n";

#endif

  delete_BinomialMat (binomialMat, len_binomial);
}


double
timeConvec(int n, int q, double v1[2], double v2[2], double v3[2], double **binomialMat, double normalMat[][2], int nbIter)
{
	
	#ifdef CONSTANT
	double vectCoeff[2] = {1.,1.}; // constant coefficient vector associated with convective matrix
	#else
	void (*b) (double[2], double[2]) = b0;
	#endif
	
  double **convecMat; // store convective matrix entries
  int len_Convec = ((n + 1) * (n + 2)) / 2;
  convecMat = create_Mat(len_Convec);
  
	#ifdef CONSTANT
	;
	#else
	
	#ifdef PRECOMP
  double **precomp;
  double **matValNodes;
  #else
  double **BmomentInter;
  #endif
  
  double **Bmoment, **Bmomentab; // need to be created, since passed as arguments into Convec
  double *Cval;
  double **quadraWN;

	#endif
	
	#ifdef CONSTANT
	double innerProdMat[3];
	innerProd_Coeff2d (normalMat, innerProdMat, vectCoeff);
	#else // by default: variable case

  int functval = 0; //default: using a routine (b) for convective matrix coefficients
  
  int nDash = 2 * n - 1;        // the Bmoment order required for the stiffness matrix is 2n-1
	int m = MAX (nDash, q-1);       // m is used for indexing with no storing algorithm, and for allowing sufficient size to "precomp"

  int nb_Array = 2;             //Convec2d needs Bmoment associated with vector-valued function
  
  // allocates memory to quadraWN
	int len_Quadra = (q + 1);     // space required for storing Jacobi nodes of order q is q, BUT indexing starts at 1
  quadraWN = create_quadraWN2d(len_Quadra);
	
	int lenMoments = len_Moments2d(nDash, q);
  
  Bmoment = create_Bmoment(lenMoments, nb_Array);
  Bmomentab = create_Bmoment(lenMoments, 3); // store inner products of normals and Bmoments: used with Convec2d
	
	#ifdef PRECOMP
	int len_matValNodes = q * q ;      // space required for 2D array with dimension q
  matValNodes =create_matValNodes2d(len_matValNodes);
	precomp = create_precomp2d(m+1);
	#else
	BmomentInter = create_Bmoment(lenMoments, nb_Array);
	#endif
	
	
	#ifdef FUNCT_VAL
	functval = 1; //using the values stored in Cval for convective matrix coefficients
	
	double *B; // store barycentric coordinates of Stroud nodes
	B = new double [q*q*3];
	stroud_nodes_bary2d (q, B);
	
  //allocates memory for Cval
  int LEN = q * q ;  // space required for 2D array with dimension q
  Cval = new double[LEN * nb_Array];    //Cval entries are stored in LINEAR memory, and used directly
  
  vector_values_at_Stroud2d(q, Cval, B, b, v1, v2, v3 ); // store the values of b at the Stroud nodes into Cval		
  #endif
	
	
	//assign values to auxilliary arrays	

	#ifdef PRECOMP
	assign_pointers_Convec2d (v1, v2, v3, n, q, nDash, m, nb_Array,matValNodes, Cval, quadraWN, precomp, b, functval);
	#else
	assign_pointers_Convec2d (v1, v2, v3, n, q, nDash, m, nb_Array, Cval, quadraWN, Bmoment, b, functval);
	#endif
	
							
  #endif // end not CONSTANT

  double average = 0;
  
  for (int i = 0; i < nbIter; i++)
    {
			#ifdef CONSTANT
			average += Convec2d_const(n, v1, v2, v3, binomialMat, normalMat, innerProdMat,
															convecMat, vectCoeff);
			#else

			#ifdef PRECOMP
			average +=
			Convec2d (n, q, v1, v2, v3, binomialMat, normalMat, precomp,
			   Bmoment, Bmomentab, convecMat, matValNodes, quadraWN); 
			#else
			average +=
			Convec2d (n, q, v1, v2, v3, binomialMat, normalMat,
			   Bmoment, BmomentInter, Bmomentab, convecMat, quadraWN); 
			#endif

			#endif
    }
    
	#ifdef CONSTANT
	;
	#else // by default: variable case
	

	//free allocated memory

	#ifdef PRECOMP
	delete_pointers(precomp, Bmoment, Bmomentab, matValNodes, quadraWN);
	#else
	delete_pointers(Bmoment, BmomentInter, Bmomentab, quadraWN);
	#endif


  #ifdef FUNCT_VAL
  delete Cval;
	delete B;
  #endif

  #endif // end not CONSTANT
  
  delete_Mat(convecMat);
  
  return average / nbIter;
}


void
printTimeConvec(int n0, int n1, double v1[2], double v2[2], double v3[2], int nbIter)
{
  int len_binomial = 300;
	double **binomialMat;
  //allocates memory to binomialMat
  binomialMat = create_BinomialMat(len_binomial);
  //compute binomials
  computeBinomials(binomialMat, len_binomial);

  double normalMat[3][2] = { {0, 0}, {0, 0}, {0, 0} };  // store normals to the edges
  normals2d (v1, v2, v3, normalMat);
  
  #ifdef LOG

  int step = MAX ((int) (n0 / 1.5), 1);
  for (int n = n0; n <= n1; n += step, step = MAX ((int) (n / 1.5), 1))
    {
      std::cout << n << ", ";
    }
  std::cout << "\n";

  step = MAX ((int) (n0 / 1.5), 1);
  for (int n = n0; n <= n1; n += step, step = MAX ((int) (n / 1.5), 1))
    {
			int q = n+1;
     
			fprintf (stderr, "%f, ", timeConvec (n, q, v1, v2, v3, binomialMat, normalMat, nbIter) );
    }
  std::cout << "\n";

  #else

  std::cout << "[";

  for (int n = n0; n < n1; n++)
    {
			int q = n+1;
      
			std::cout<<timeConvec (n, q, v1, v2, v3, binomialMat, normalMat, nbIter)<<",";
    }
  int q = n1+1;
  std::cout<<timeConvec (n1, q, v1, v2, v3, binomialMat, normalMat, nbIter)<<"]\n";

  #endif

  delete_BinomialMat (binomialMat, len_binomial);
}


double
timeStiff (int n, int q, double v1[2], double v2[2], double v3[2], double **binomialMat, double scalarMat[][3], double normalMat[][2], int nbIter, double cputime[3])
{

	#ifdef CONSTANT
	double Coeff[3] = {1.,0.,1.}; // in constant case, the coefficient is the identity matrix
	#else
	void (*A) (double[2], double[2][2]) = A0;
	#endif
	
	#ifdef CONSTANT
	scalarMatrix2d_Coeff (scalarMat, v1, v2, v3, normalMat, Coeff);
	#endif
	
  double **stiffMat; // store stiffness matrix entries


  int len_Stiff = ((n + 1) * (n + 2)) / 2;

  stiffMat = create_Mat(len_Stiff);
       
	#ifdef CONSTANT
	;
	#else
	
	#ifdef PRECOMP
  double **precomp;
  double **matValNodes;
  #else
  double **BmomentInter;
  #endif
  
  double **Bmoment, **Bmomentab; // need to be created, since passed as arguments into Stiff
	double *Cval;
  double **quadraWN;

	#endif
	
	
#ifdef CONSTANT
;
#else // by default: variable case

	int functval = 0; //default: using a routine (A) for stiffness matrix coefficients
  
  int nDash = 2 * n - 2;        // the Bmoment order required for the stiffness matrix is 2n-2
	int m = MAX (nDash, q-1);       // m is used for indexing with no storing algorithm, and for allowing sufficient size to "precomp"
  int nb_Array = 3;             //Stiff needs Bmoment associated with symmetric 2 by 2 matrix valued function
  
  
  // allocates memory to quadraWN
	int len_Quadra = (q + 1);     // space required for storing Jacobi nodes of order q is q, BUT indexing starts at 1
  quadraWN = create_quadraWN2d(len_Quadra);

	
	int lenMoments = len_Moments2d(nDash, q);
  Bmoment = create_Bmoment(lenMoments, nb_Array);
  Bmomentab = create_Bmoment(lenMoments, 6); // multiply normals to Bmoments and store into Bmomentab: used with Stiff
	
	#ifdef PRECOMP
	int len_matValNodes = q * q;      // space required for 2D array with dimension q
  matValNodes =create_matValNodes2d(len_matValNodes);
	precomp = create_precomp2d(m+1);
	#else
	BmomentInter = create_Bmoment(lenMoments, nb_Array);
	#endif
	
	#ifdef FUNCT_VAL
	functval=1; //using the values stored in Cval for stiffness matrix coefficients
	
	double *B; // store barycentric coordinates of Stroud nodes
	B = new double [q*q*3];
	stroud_nodes_bary2d (q, B);
	
	//allocates memory for Cval
  int LEN = q * q ;  // space required for 2D array with dimension q	
	Cval = new double[LEN * nb_Array];    //Cval entries are stored in LINEAR memory, and used directly
	
	matrix_values_at_Stroud2d(q, Cval, B, A, v1, v2, v3 ); // store the values of A at the Stroud nodes into Cval
	#endif
	
	//assign values to auxilliary arrays	
	#ifdef PRECOMP
	assign_pointers_Stiff2d(v1, v2, v3, n, q, nDash, m, nb_Array,matValNodes, Cval, quadraWN, precomp, A, functval);
	#else
	assign_pointers_Stiff2d(v1, v2, v3, n, q, nDash, m, nb_Array, Cval, quadraWN, Bmoment, A, functval);
	#endif
	

	#endif // end not CONSTANT

  double average = 0;
  double aver1 = 0;
  double aver2 = 0;
  double aver3 = 0;

  for (int i = 0; i < nbIter; i++)
    {
			#ifdef CONSTANT
			average += Stiff2d_const(n, v1, v2, v3, binomialMat, scalarMat, cputime, stiffMat,
														 Coeff);
			#else

			#ifdef PRECOMP
			average +=
				 Stiff2d (n, q, v1, v2, v3, binomialMat, scalarMat, normalMat, cputime, precomp,
			   Bmoment, Bmomentab, stiffMat, matValNodes, quadraWN);
			#else
			average +=
				 Stiff2d (n, q, v1, v2, v3, binomialMat, scalarMat, normalMat, cputime,
			   Bmoment, BmomentInter, Bmomentab, stiffMat, quadraWN);
			#endif

			#endif

      aver1 += cputime[0];
      aver2 += cputime[1];
      aver3 += cputime[2];

    }

  cputime[0] = aver1 / nbIter;
  cputime[1] = aver2 / nbIter;
  cputime[2] = aver3 / nbIter;

#ifdef CONSTANT
;
#else // not CONSTANT


	#ifdef PRECOMP
	delete_pointers(precomp,  Bmoment, Bmomentab, matValNodes, quadraWN)	;
	#else
	delete_pointers(Bmoment, BmomentInter, Bmomentab, quadraWN);	
	#endif

#ifdef FUNCT_VAL
	delete B;
  delete Cval;
#endif

#endif // end not CONSTANT

  delete_Mat(stiffMat);

  return average / nbIter;
}



void
printTimeStiff (int n0, int n1, double v1[2], double v2[2], double v3[2], int nbIter)
{
  double cputime[3];

  int len_binomial = 300;
	double **binomialMat;
  //allocates memory to binomialMat
  binomialMat = create_BinomialMat(len_binomial);


  //compute binomials
  computeBinomials(binomialMat, len_binomial);

  double normalMat[3][2] = { {0, 0}, {0, 0}, {0, 0} };  // store normals to the edges
  normals2d (v1, v2, v3, normalMat);

  double scalarMat[3][3];       // store normals to the edges
	

#ifdef LOG

  int step = MAX ((int) (n0 / 1.5), 1);
  for (int n = n0; n <= n1; n += step, step = MAX ((int) (n / 1.5), 1))
    {
      std::cout << n << ", ";
    }
  std::cout << "\n";

  step = MAX ((int) (n0 / 1.5), 1);
  for (int n = n0; n <= n1; n += step, step = MAX ((int) (n / 1.5), 1))
    {
			int q = n+1;
			timeStiff (n, q, v1, v2, v3, binomialMat, scalarMat, normalMat, nbIter, cputime);
      fprintf (stderr, "%f, ", cputime[1]);
    }
  std::cout << "\n";

#else

  std::cout << "[";

  for (int n = n0; n < n1; n++)
    {
			int q = n+1;
      timeStiff (n, q, v1, v2, v3, binomialMat, scalarMat, normalMat, nbIter, cputime);
      std::cout << cputime[1] << ",";
    }
  int q = n1+1;
  timeStiff (n1, q, v1, v2, v3, binomialMat, scalarMat, normalMat, nbIter, cputime);
  std::cout << cputime[1] << "]\n";

#endif

  delete_BinomialMat (binomialMat, len_binomial);
}




#ifdef STROUD_BARYW

//Computation of the weights and centres of the Stroud formulas, with storing on the disk
int main ()
{
  int q;

  std::cout << "Enter number of points:";
  std::cin >> q;

  

  double *B = new double[3 * q * q];
  double *W = new double[q * q];

  double *b = B;
  double *ww = W;

  // store quadrature weights and nodes of a fixed degree (no-storing algorithm) 


  // allocate memory to quadraWN which is called by stroud_bary2dw
  int len_Quadra = (q + 1);     // space required for storing Jacobi nodes of order m is m+1, BUT indexing starts at 1
  double **quadraWN = create_quadraWN2d (len_Quadra);

	gaussJacobiUnit (q, quadraWN);
	
  stroud_bary2dw (q, B, W, quadraWN);

  FILE *output_file = fopen ("stroud_bary2dw.txt", "w");

  fprintf (output_file, "%% Weights and barycentric coordinates of %i-point Stroud quadrature for a triangle of unit area.\n", q);
  fprintf (output_file, "%% Otherwise multiply the weights by the area of the triangle.\n", q);
  fprintf (output_file, "%% Firsts column: weights. Remaining columns: barycentric coordinates\n", q);

  for (int i = 0; i < q * q; i++)
    {
      fprintf (output_file, "%2.16f ", *ww++);

      for (int j = 0; j < 3; j++)
        fprintf (output_file, "%2.16f ", *b++);

      fprintf (output_file, "\n");
    }

  fclose (output_file);

  fprintf (stderr, "weights and barycentric coordinates have been stored in stroud_bary2dw.txt\n");
	
	//release the memory allocated to the quadrature 	 
  delete_quadraWN (quadraWN);

}


///////

#elif BMOM_CONST
// Computation of B-moments associated with constant coefficients
int main()
{
//   // vertices (standard triangle)
//   double v1[2] = { 0, 0 };
//   double v2[2] = { 1, 0 };
//   double v3[2] = { 0, 1 };
  
	
	// non-trivial triangle
	double v1[2] = { 1.2  , 3.4 }; 
  double v2[2] = { -1.5 , 2. };
  double v3[2] = { 0.1  , -1. };
	
  int n; // degree of the B-moments
  std::cout<<"Enter a value for the polynomial order n:";
  std::cin>>n;
	
	double **binomialMat; // store binomial coefficients
	int len_binomial = 2*n+2;
  binomialMat = create_BinomialMat(len_binomial); // store binomial coefficients
  computeBinomials(binomialMat, len_binomial); //compute binomials
	
	int nb_Array = 1; // B-moments are associated with scalar-valued coefficients
	 
	double **Bmoment;
	int lenMoments = ((n+2)*(n+1))/2;
	Bmoment = create_Bmoment(lenMoments, nb_Array); // allocate memory for the Bmoment array
	
	Bmoment2d_const (n, v1, v2, v3, binomialMat, Bmoment); // compute B-moments
	
	delete_BinomialMat (binomialMat, len_binomial); // free memory allocated to binomialMat
	
	// Insert your code here to make use of Bmoment. It will be destroyed in the next line!
	
	delete_Bmoment(Bmoment);
  
  #ifdef CHECK
  std::cout<<"B-moment entries stored into array Bmoment of length "<<lenMoments<<"\n";
	#endif
	
}

#elif BMOM_LOW
// Computation of the B-moments
int main ()
{
  
//   // vertices (standard triangle)
//   double v1[2] = { 0, 0 };
//   double v2[2] = { 1, 0 };
//   double v3[2] = { 0, 1 };
  
	
	// non-trivial triangle
	double v1[2] = { 1.2  , 3.4 }; 
  double v2[2] = { -1.5 , 2. };
  double v3[2] = { 0.1  , -1. };
	
  int n; // degree of the B-moments
  std::cout<<"Enter a value for the polynomial order n:";
  std::cin>>n;
	
	double (*f) (double[2]) = f0; // change here if want Bmoments associated with another function
	
	int functval = 0; //default: using a routine (f) for Bmoments' coefficients
	
	#ifdef PRECOMP
	double **precomp;
	double **matValNodes;
	#else
	double **BmomentInter;
	#endif
	
	#ifdef PRECOMP
	double **binomialMat; // needed by assign_pointers routine
	#endif
	
	double **Bmoment;
	double *Cval; // store array of function values at Stroud quadrature nodes
	double **quadraWN;
	
	#ifdef FUNCT_VAL
	functval = 1; //using the values stored in Cval for B-moments' coefficients
	
	double *B; // store barycentric coordinates of Stroud nodes
	#endif
  
  #ifdef PRECOMP
  int len_binomial = 2*n+2;
  binomialMat = create_BinomialMat(len_binomial); // store binomial coefficients
  computeBinomials(binomialMat, len_binomial); //compute binomials
  #endif
  
  
  // initialize number of quadrature pointers, and integers needed for indexing Bmoment entries
  int q = n+1; // for the B-moments, the number of quadrature points is n+1 by default
  int nDash = n; // nDash stands for the Bmoment order
  int m = MAX(n,q-1); // in case value of q is increased,
											// m is used to create sufficiently large precomp
  
  int nb_Array = 1;
   
  //allocates memory to quadraWN
	int len_Quadra = (q + 1);     // space required for storing Jacobi nodes of order q is q, BUT indexing starts at 1
  quadraWN = create_quadraWN2d(len_Quadra); // store quadrature weights and nodes of a fixed degree (no-storing algorithm)
	

	int lenMoments = len_Moments2d(nDash, q);
  
  Bmoment = create_Bmoment(lenMoments, nb_Array); // allocate memory for the Bmoment array
	
	#ifdef PRECOMP
  //allocates memory to MatValNodes
	int len_matValNodes = q * q ;      // space required for 2D array with dimension q
  matValNodes =create_matValNodes2d(len_matValNodes);
	precomp = create_precomp2d(m+1); // store precomputed arrays 
	#else
	BmomentInter = create_Bmoment(lenMoments, nb_Array);
	#endif
	
	#ifdef FUNCT_VAL
	B = new double [q*q*3];
	stroud_nodes_bary2d (q, B);
	
	int LEN = q * q ;  // space required for 2D array with dimension q+1	
  Cval = new double[LEN * nb_Array];    //Cval entries are stored in LINEAR memory, and used directly
  
	scalar_values_at_Stroud2d(q, Cval, B, f, v1, v2, v3 ); // store the values of f at the Stroud nodes into Cval
	#endif
	
	
	#ifdef PRECOMP
	assign_pointers_Bmom2d (v1, v2, v3, n, q, nDash, m, nb_Array,matValNodes, Cval, quadraWN, precomp, f, functval);
	#else
	assign_pointers_Bmom2d (v1, v2, v3, n, q, nDash, m, nb_Array, Cval, quadraWN, Bmoment, f, functval);
	#endif
	
									
  // store Bmoments into array Bmoment
  #ifdef PRECOMP
	Bmoment2d (n, q, m, nb_Array, v1, v2, v3, binomialMat, precomp, Bmoment, matValNodes); 
  #else
  Bmoment2d_Index (n, q, nb_Array, Bmoment, BmomentInter, quadraWN);
  #endif
  
      
  // free allocated memory	

	#ifdef PRECOMP
	delete_pointers_Bmom(precomp, matValNodes, quadraWN);
	#else
	delete_pointers_Bmom(BmomentInter, quadraWN);
	#endif
	
    
  #ifdef PRECOMP
  delete_BinomialMat (binomialMat, len_binomial);
  #endif
  
  #ifdef FUNCT_VAL
	delete Cval;
	delete B;
	#endif
	
	
	// Insert your code here to make use of Bmoment. It will be destroyed in the next line!
	
	delete_Bmoment(Bmoment);
  
  #ifdef CHECK
  std::cout<<"B-moment entries stored into array Bmoment of length "<<lenMoments<<"\n";
	#endif
  
}

 
#elif MASS_CONST
// Computation of the element mass matrix with piecewise constant data
int main ()
{
//   //vertices (standard triangle)
//   double v1[2] = { 0, 0 };
//   double v2[2] = { 1, 0 };
//   double v3[2] = { 0, 1 };
  
  //vertices (particular triangle)
  double v1[2] = { 1.2  , 3.4 }; 
  double v2[2] = { -1.5 , 2. };
  double v3[2] = { 0.1  , -1. };

  
  int n; // degree of the B-moments

  std::cout<<"Enter a value for the polynomial order n:";
  std::cin>>n;
  
  
  int len_binomial = 2*n+2;
  double **binomialMat = create_BinomialMat(len_binomial); // store binomial coefficients
  computeBinomials(binomialMat, len_binomial); //compute binomials
  
  double **massMat;     // store mass matrix entries
  int len_Mass = ((n + 1) * (n + 2)) / 2;
  massMat = create_Mat(len_Mass);
      
  
  // store mass matrix entries into array massMat
	Mass2d_const (n, v1, v2, v3, binomialMat, massMat);
  
  // free allocated memory
  delete_Mat(massMat);
  delete_BinomialMat (binomialMat, len_binomial);
	
	std::cout<<"Mass matrix entries stored into array massMat of dimension "<<len_Mass<<"\n";
  
}


#elif MASS_LOW

// Computation of the element mass matrix with variable coefficients
int main ()
{
//   //vertices (standard triangle)
//   double v1[2] = { 0, 0 };
//   double v2[2] = { 1, 0 };
//   double v3[2] = { 0, 1 };
  
  #ifdef PRECOMP // check if ordering has an impact on result...
  //vertices (particular triangle)
  double v1[2] = { 1.2  , 3.4 }; 
  double v2[2] = { -1.5 , 2. };
  double v3[2] = { 0.1  , -1. };
  #else
  //vertices (particular triangle)
  double v1[2] = { 1.2  , 3.4 }; 
  double v2[2] = { -1.5 , 2. };
  double v3[2] = { 0.1  , -1. };
  #endif

  int n; // degree of the Bernstein polynomial basis
  std::cout<<"Enter a value for the polynomial order n:";
  std::cin>>n;
	
	double (*f) (double[2]) = f0; // change here if want mass matrix associated with another function
	
	int functval = 0; //default: using a routine (f) for mass matrix coefficients
  
  
  int len_binomial = 2*n+2;
  double **binomialMat = create_BinomialMat(len_binomial); // store binomial coefficients
  
  double **massMat;     // store mass matrix entries
  int len_Mass = ((n + 1) * (n + 2)) / 2;
  massMat = create_Mat(len_Mass);
  
	#ifdef PRECOMP
	double **precomp;
	double **matValNodes;
	#else
	double **BmomentInter;
	#endif
	
  
  double **Bmoment;  
	double *Cval; // needed by delete_pointers routine
  double **quadraWN;	// store quadrature weights and nodes of a fixed degree (no-storing algorithm)
	
	#ifdef FUNCT_VAL
	functval = 1; //using the values stored in Cval for mass matrix coefficients
	
	double *B; // store barycentric coordinates of Stroud nodes
	#endif

	
	// initialize number of quadrature pointers, and integers needed for indexing Bmoment entries
  int q = n+1;                    // the number of quadrature points is n+1  
  int nDash = 2 * n;            // the Bmoment order required for the mass matrix is 2n
  int m = MAX(nDash,q-1);                //m = MAX(nDash, q-1); 
																// m is used for indexing only with non-PRECOMP
																// BUT m also needed with PRECOMP for allowing sufficient size to pointer "precomp"
  int nb_Array = 1;             // the Bmoment required is associated with a SCALAR function
  
	int len_Quadra = (q + 1);     // space required for storing Jacobi nodes of order q is q, BUT indexing starts at 1	
  quadraWN = create_quadraWN2d(len_Quadra);
	
	
	// initialize auxilliary arrays
	computeBinomials(binomialMat, len_binomial); //compute binomials
		

	int lenMoments = len_Moments2d(nDash, q);
  
  Bmoment = create_Bmoment(lenMoments, nb_Array);
	
	
	#ifdef PRECOMP
	int len_matValNodes = q * q ;      // space required for 2D array with dimension q	
  matValNodes =create_matValNodes2d(len_matValNodes);
	precomp = create_precomp2d(m+1); // store precomputed arrays
	
	#else	
	BmomentInter = create_Bmoment(lenMoments, nb_Array);
	#endif
	
	#ifdef FUNCT_VAL
	B = new double [q*q*3];
	stroud_nodes_bary2d (q, B);
	
	//allocates memory for Cval
  int LEN = q * q ;  // space required for 2D array with dimension q  
  Cval = new double[LEN * nb_Array];    //Cval entries are stored in LINEAR memory, and used directly
  
  scalar_values_at_Stroud2d(q, Cval, B, f, v1, v2, v3 ); // store the values of f at the Stroud nodes into Cval
	#endif
	
	//assign values to auxilliary arrays
	#ifdef PRECOMP
	assign_pointers_Mass2d (v1, v2, v3, n, q, nDash, m, nb_Array,matValNodes, Cval, quadraWN, precomp, f, functval);
	#else
	assign_pointers_Mass2d (v1, v2, v3, n, q, nDash, m, nb_Array, Cval, quadraWN, Bmoment, f, functval);
	#endif
	
  
  // store mass matrix entries into array massMat
	#ifdef PRECOMP
	Mass2d (n, q, v1, v2, v3, binomialMat, precomp, Bmoment, massMat, matValNodes, quadraWN);
	#else
	Mass2d (n, q, v1, v2, v3, binomialMat, Bmoment, BmomentInter, massMat, quadraWN);
	#endif
	
  
  //free allocated memory

	#ifdef PRECOMP
	delete_pointers_Mass(precomp, Bmoment, matValNodes, quadraWN);
	#else
	delete_pointers_Mass(Bmoment, BmomentInter, quadraWN);
	#endif

  
  
  delete_BinomialMat (binomialMat, len_binomial);
	
	#ifdef FUNCT_VAL
	delete Cval;
	delete B;
	#endif
	
	// Insert your code here to make use of massMat. It will be destroyed in the next line!
	
	delete_Mat(massMat);
	
	
	#ifdef CHECK
	std::cout<<"Mass matrix entries stored into array massMat of dimension "<<len_Mass<<"\n";
	#endif
  
}

 
#elif STIFF_CONST
// Computation of the element stiffness matrix with piecewise constant data
int main ()
{
//   //vertices (standard triangle)
//   double v1[2] = { 0, 0 };
//   double v2[2] = { 1, 0 };
//   double v3[2] = { 0, 1 };
  
  //vertices (particular triangle)
  double v1[2] = { 1.2  , 3.4 }; 
  double v2[2] = { -1.5 , 2. };
  double v3[2] = { 0.1  , -1. };

  int n; // degree of the Bernstein polynomial basis
  std::cout<<"Enter a value for the polynomial order n:";
  std::cin>>n;
	
	double Coeff[3] = {1.,0.,1.}; // the constant coefficient associated with the stiffness
	// matrix is the identity matrix

    
  int len_binomial = 2*n+2;
  double **binomialMat = create_BinomialMat(len_binomial); // store binomial coefficients
  computeBinomials(binomialMat, len_binomial); //compute binomials
  
  double cputime[3]; // needed, since passed as argument in Stiff
  
  double normalMat[3][2] = { {0, 0}, {0, 0}, {0, 0} };  // store normals to the edges
  normals2d (v1, v2, v3, normalMat);

  double scalarMat[3][3];       // store normals to the edges
 
  scalarMatrix2d_Coeff (scalarMat, v1, v2, v3, normalMat, Coeff);
  
  double **stiffMat;  // store stiffness matrix entries
  int len_Stiff = ((n + 1) * (n + 2)) / 2;
  stiffMat = create_Mat(len_Stiff);
       
	Stiff2d_const(n, v1, v2, v3, binomialMat, scalarMat, cputime, stiffMat, Coeff);
		 

  // free allocated memory
  delete_Mat(stiffMat);
  delete_BinomialMat (binomialMat, len_binomial);
	
	std::cout<<"Stiffness matrix entries stored into array stiffMat of dimension "<<len_Stiff<<"\n";
}


 
#elif STIFF_LOW
// Computation of the element stiffness matrix with variable coefficients
int main ()
{
  //   //vertices (standard triangle)
  //   double v1[2] = { 0, 0 };
  //   double v2[2] = { 1, 0 };
  //   double v3[2] = { 0, 1 };
  
  //vertices (particular triangle)
  double v1[2] = { 1.2  , 3.4 }; 
  double v2[2] = { -1.5 , 2. };
  double v3[2] = { 0.1  , -1. };

  int n; // degree of the Bernstein polynomial basis
  std::cout<<"Enter a value for the polynomial order n:";
  std::cin>>n;
	
	int functval = 0; //default: using a routine (A) for stiffness matrix coefficients
	
	void (*A) (double[2], double[2][2]) = A0; // change here if want stiffness matrix associated with another function
    
  int len_binomial = 2*n+2;
  double **binomialMat = create_BinomialMat(len_binomial); // store binomial coefficients
  
  double cputime[3]; // needed, since passed as argument in Stiff
  
  double normalMat[3][2] = { {0, 0}, {0, 0}, {0, 0} };  // store normals to the edges
  double scalarMat[3][3];       // passed as argument in Stiff (used for constant case)  
  
  double **stiffMat;  // store stiffness matrix entries
  int len_Stiff = ((n + 1) * (n + 2)) / 2;
  stiffMat = create_Mat(len_Stiff);
  
	#ifdef PRECOMP
  double **precomp;
  double **matValNodes; 
  #else
  double  **BmomentInter;
  #endif
  
  double **Bmoment,**Bmomentab; // need to be created, since passed as arguments into Stiff
  double *Cval; //delete_pointers needs this as argument
  double **quadraWN;
  
	#ifdef FUNCT_VAL
	functval = 1; //using the values stored in Cval for stiffness matrix coefficients
	
	double *B; // store barycentric coordinates of Stroud nodes
	#endif
  
  // initialize number of quadrature pointers, and integers needed for indexing Bmoment entries
  int q = n+1;                    // the number of quadrature points is n+1
  
  int nDash = 2 * n - 2;        // the Bmoment order required for the stiffness matrix is 2n-2

	int m = MAX (nDash, q-1);       // m is used for indexing: only use MAX(nDash,q-1) for indexing with no storing algorithm
								// BUT m also needed with PRECOMP for allowing sufficient size to pointer "precomp"

  int nb_Array = 3;             //Stiff needs Bmoment associated with symmetric 2 by 2 matrix valued function
	int len_Quadra = (q + 1);     // space required for storing Jacobi nodes of order q is q, BUT indexing starts at 1
	
	// allocates memory for quadraWN
  quadraWN = create_quadraWN2d(len_Quadra);
	
	// initialize auxilliary arrays
	computeBinomials(binomialMat, len_binomial); //compute binomials
	normals2d (v1, v2, v3, normalMat);
	

	int lenMoments = len_Moments2d(nDash, q);
  
  Bmoment = create_Bmoment(lenMoments, nb_Array);
  Bmomentab = create_Bmoment(lenMoments, 6); // multiply normals to Bmoments and store into Bmomentab: used with Stiff
	
	#ifdef PRECOMP
	int len_matValNodes = q * q ;      // space required for 2D array with dimension q
  matValNodes =create_matValNodes2d(len_matValNodes);
	precomp = create_precomp2d(m+1);	// store precomputed arrays
	
	#else	
	BmomentInter = create_Bmoment(lenMoments, nb_Array);
	#endif
	
	#ifdef FUNCT_VAL
	B = new double [q*q*3];
	stroud_nodes_bary2d (q, B);
	
	//allocates memory for Cval
  int LEN = q * q ;  // space required for 2D array with dimension q	
	Cval = new double[LEN * nb_Array];    //Cval entries are stored in LINEAR memory, and used directly
	
	matrix_values_at_Stroud2d(q, Cval, B, A, v1, v2, v3 ); // store the values of A at the Stroud nodes into Cval
	#endif
	

	#ifdef PRECOMP
	assign_pointers_Stiff2d(v1, v2, v3, n, q, nDash, m, nb_Array,matValNodes, Cval, quadraWN, precomp, A, functval);
	#else
	assign_pointers_Stiff2d(v1, v2, v3, n, q, nDash, m, nb_Array, Cval, quadraWN, Bmoment, A, functval);
	#endif
	
  
  // store stiffness matrix entries into array stiffMat
	#ifdef PRECOMP
	Stiff2d (n, q, v1, v2, v3, binomialMat, scalarMat, normalMat, cputime, precomp,
				 Bmoment, Bmomentab, stiffMat, matValNodes, quadraWN);
	#else
	Stiff2d (n, q, v1, v2, v3, binomialMat, scalarMat, normalMat, cputime,
				 Bmoment, BmomentInter, Bmomentab, stiffMat, quadraWN);
	#endif
				 
	
  // free allocated memory
	
	#ifdef PRECOMP
	delete_pointers (precomp, Bmoment, Bmomentab, matValNodes, quadraWN);
	#else
	delete_pointers (Bmoment, BmomentInter, Bmomentab, quadraWN);
	#endif

    
  delete_BinomialMat (binomialMat, len_binomial);
	
	#ifdef FUNCT_VAL
	delete Cval;
	delete B;
	#endif
	
	
	// Insert your code here to make use of stiffMat. It will be destroyed in the next line!		 
	
	delete_Mat(stiffMat);
	
	std::cout<<"Stiffness matrix entries stored into array stiffMat of dimension "<<len_Stiff<<"\n";
  
}


#elif CONVEC_CONST
// Computation of the element convective matrix with piecewise constant data
int main ()
{
//     //vertices (standard triangle)
//     double v1[2] = { 0, 0 };
//     double v2[2] = { 1, 0 };
//     double v3[2] = { 0, 1 };
  
  //vertices (particular triangle)
  double v1[2] = { 1.2  , 3.4 }; 
  double v2[2] = { -1.5 , 2. };
  double v3[2] = { 0.1  , -1. };

  int n; // degree of the Bernstein polynomial basis
  std::cout<<"Enter a value for the polynomial order n:";
  std::cin>>n;
	
	double vectCoeff[2] = {1.,1.}; // coefficient vector associated with convective matrix
	
	int len_binomial = 2*n+2; // dimension of binomialMat matrix
	double **binomialMat = create_BinomialMat(len_binomial); // store binomial coefficients
	double normalMat[3][2] = { {0, 0}, {0, 0}, {0, 0} };  // store normals to the edges	
	double innerProdMat[3]; // store inner products of vectCoeff with normals
	double **convecMat;  // store convective matrix entries: of dimension ((n + 1) * (n + 2)) / 2
    
	computeBinomials(binomialMat, len_binomial); //compute binomials  
  normals2d (v1, v2, v3, normalMat);
	innerProd_Coeff2d (normalMat, innerProdMat, vectCoeff);
   
  int len_Convec = ((n + 1) * (n + 2)) / 2; // dimension of convecMat matrix
  convecMat = create_Mat(len_Convec);
       
  
  // store convective matrix entries into array convecMat
	Convec2d_const (n, v1, v2, v3, binomialMat, normalMat, innerProdMat, convecMat, vectCoeff);
		 

  // free allocated memory
  delete_Mat(convecMat);
  delete_BinomialMat (binomialMat, len_binomial);
	
	std::cout<<"Convective matrix entries stored into array convecMat of dimension "<<len_Convec<<"\n";
  
}

#elif CONVEC_LOW
// Computation of the element convective matrix with variable coefficients
int main ()
{
  //   //vertices (standard triangle)
  //   double v1[2] = { 0, 0 };
  //   double v2[2] = { 1, 0 };
  //   double v3[2] = { 0, 1 };
  
  //vertices (particular triangle)
  double v1[2] = { 1.2  , 3.4 }; 
  double v2[2] = { -1.5 , 2. };
  double v3[2] = { 0.1  , -1. };

  int n; // degree of the Bernstein polynomial basis
  std::cout<<"Enter a value for the polynomial order n:";
  std::cin>>n;
	
	int functval = 0; //default: using a routine (b) for convective matrix coefficients
	
	void (*b) (double[2], double[2]) = b0; // change here if want convective matrix associated with another function
    
  int len_binomial = 2*n+2;
  double **binomialMat = create_BinomialMat(len_binomial); // store binomial coefficients
  
  double normalMat[3][2] = { {0, 0}, {0, 0}, {0, 0} };  // store normals to the edges
  
  double **convecMat;  // store convective matrix entries
  int len_Convec = ((n + 1) * (n + 2)) / 2;
  convecMat = create_Mat(len_Convec);
  
	#ifdef PRECOMP
  double **precomp;	// need to be created, since passed as arguments into Convec
  double **matValNodes;
  #else
  double **BmomentInter;
  #endif
  
  double **Bmoment, **Bmomentab; // need to be created, since passed as arguments into Convec
  double *Cval; // delete_pointers needs this as argument
  double **quadraWN;

	
	#ifdef FUNCT_VAL
	functval = 1; //using the values stored in Cval for convective matrix coefficients
	
	double *B; // store barycentric coordinates of Stroud nodes
	#endif
	
	
	// initialize number of quadrature pointers, and integers needed for indexing Bmoment entries
	int q = n+1;                    // the number of quadrature points is n+1  
  int nDash = 2 * n - 1;        // the Bmoment order required for the convective matrix is 2n-1
	int m = MAX (nDash, q-1);       // m is used for indexing: only use MAX(nDash,q-1) for indexing with no storing algorithm
																// BUT m also needed with PRECOMP for allowing sufficient size to pointer "precomp"

  int nb_Array = 2;             //Convec needs Bmoment associated with vector-valued function
    
  int len_Quadra = (q + 1);     // space required for storing Jacobi nodes of order q is q, BUT indexing starts at 1
	
	// allocates memory to quadraWN
  quadraWN = create_quadraWN2d(len_Quadra);
	
	
	// initialize auxilliary arrays
	computeBinomials(binomialMat, len_binomial); //compute binomials
	normals2d (v1, v2, v3, normalMat); // compute normals to the edges
	
	
	int lenMoments = len_Moments2d(nDash, q);
  
  Bmoment = create_Bmoment(lenMoments, nb_Array);
  Bmomentab = create_Bmoment(lenMoments, 3); // Bmomentab contains inner products of normals with Bmoments
	
	#ifdef PRECOMP
	int len_matValNodes = q * q ;      // space required for 2D array with dimension q		
  matValNodes =create_matValNodes2d(len_matValNodes);
	precomp = create_precomp2d(m+1); // store precomputed arrays
	
	#else	
	BmomentInter = create_Bmoment(lenMoments, nb_Array);
	#endif
	
	#ifdef FUNCT_VAL
	B = new double [q*q*3];
	stroud_nodes_bary2d (q, B);
	
	int LEN = q * q ;  // space required for 2D array with dimension q 
  Cval = new double[LEN * nb_Array];    //Cval entries are stored in LINEAR memory, and used directly
  
  vector_values_at_Stroud2d(q, Cval, B, b, v1, v2, v3 ); // store the values of b at the Stroud nodes into Cval
	#endif
	
	//assign values to auxilliary arrays
	#ifdef PRECOMP
	assign_pointers_Convec2d (v1, v2, v3, n, q, nDash, m, nb_Array,matValNodes, Cval, quadraWN, precomp, b, functval);
	#else
	assign_pointers_Convec2d (v1, v2, v3, n, q, nDash, m, nb_Array, Cval, quadraWN, Bmoment, b, functval);
	#endif
	  
  // store convective matrix entries into array convecMat
	#ifdef PRECOMP
	Convec2d (n, q, v1, v2, v3, binomialMat, normalMat, precomp,
		 Bmoment, Bmomentab, convecMat, matValNodes, quadraWN);
	#else
	Convec2d (n, q, v1, v2, v3, binomialMat, normalMat,
		 Bmoment, BmomentInter, Bmomentab, convecMat, quadraWN);
	#endif
		 	
		 
  // free allocated memory
	
	#ifdef PRECOMP
	delete_pointers(precomp, Bmoment, Bmomentab, matValNodes, quadraWN);
	#else
	delete_pointers(Bmoment, BmomentInter, Bmomentab, quadraWN);
	#endif
	
	delete_BinomialMat (binomialMat, len_binomial);
  
	#ifdef FUNCT_VAL
	delete Cval;
	delete B;
	#endif
  
	// Insert your code here to make use of convecMat. It will be destroyed in the next line!
	
	delete_Mat(convecMat);
  
	#ifdef CHECK
	std::cout<<"Convective matrix entries stored into array convecMat of dimension "<<len_Convec<<"\n";
	#endif
  
}


#else //debugging and timing purposes

int main ()
{
 

	#ifdef TIMEMOM
	;
	#elif TIMEMASS
	;
	#elif TIMECONVEC
	;
	#elif TIMESTIFF
	;
	#else
  int n = 5;                    //polynomial degree
	#endif // precompilers used in order to avoid compiler's warnings on "unused variable n"

//   // standard triangle
//   double v1[2] = { 0, 0 };
//   double v2[2] = { 1, 0 };
//   double v3[2] = { 0, 1 };

  // needed in order to compare with Matlab output
  double v1[2] = { 1.2  , 3.4 }; 
  double v2[2] = { -1.5 , 2. };
  double v3[2] = { 0.1  , -1. };

//check correctness
#ifdef DEB
;
//   v1[0] = v1[1] = 0;
//   v2[0] = 1;
//   v2[1] = 0;
//   v3[0] = 0;
//   v3[1] = 1;

#ifdef CHECK
  std::cout << "Enter a value for the polynomial degree n:";
  std::cin >> n;
#else
  n = 20;                       //20 or 21 
#endif
#endif


  int n0;	
	#ifdef CHECK
	;
	#else
	int n1;
	#endif // precompilers used in order to avoid compiler's warnings on "unused variable n1"
	
  int nbIter = 1;

//check timing

#ifdef TIMEMOM

	double (*f) (double[2]) = f0; // change here if want mass matrix associated with another function

#ifdef CHECK
  nbIter = 1;

  std::cout << "Enter a value for n: ";
  std::cin >> n0;
	printTimeMomentVect (f, n0, n0, v1, v2, v3, nbIter);

#else // not CHECK
  std::cout << "Enter a value for the number of iterations:";
  std::cin >> nbIter;

  std::cout << "Enter a value for the smallest polynomial order: ";
  std::cin >> n0;

  std::cout << "Enter a value for n1: ";
  std::cin >> n1;
	printTimeMomentVect (f, n0, n1, v1, v2, v3, nbIter);
#endif

#elif TIMEMASS

#ifdef CHECK
  nbIter = 1;

  std::cout << "Enter a value for n:";
  std::cin >> n0;


	printTimeMass (n0, n0, v1, v2, v3, nbIter);      

#else
  std::cout << "Enter a value for the number of iterations:";
  std::cin >> nbIter;

  std::cout << "Enter a value for the smallest polynomial order: ";
  std::cin >> n0;

  std::cout << "Enter a value for n1: ";
  std::cin >> n1;

	printTimeMass (n0, n1, v1, v2, v3, nbIter);
#endif


#elif TIMECONVEC

#ifdef CHECK
  nbIter = 1;

  std::cout << "Enter a value for n:";
  std::cin >> n0;


	printTimeConvec (n0, n0, v1, v2, v3, nbIter);      
#else
  std::cout << "Enter a value for the number of iterations:";
  std::cin >> nbIter;

  std::cout << "Enter a value for the smallest polynomial order: ";
  std::cin >> n0;

  std::cout << "Enter a value for n1: ";
  std::cin >> n1;

	printTimeConvec (n0, n1, v1, v2, v3, nbIter);
#endif

#elif TIMESTIFF

#ifdef CHECK
  nbIter = 1;

  std::cout << "Enter a value for n:";
  std::cin >> n0;


	printTimeStiff (n0, n0, v1, v2, v3, nbIter);   

#else // not CHECK
  std::cout << "Enter a value for the number of iterations:";
  std::cin >> nbIter;

  std::cout << "Enter a value for the smallest polynomial order: ";
  std::cin >> n0;

  std::cout << "Enter a value for n1: ";
  std::cin >> n1;

	printTimeStiff (n0, n1, v1, v2, v3, nbIter);

#endif // end CHECK


#endif


}

#endif /* not STROUD_BARYW */


 
////////////////////////// MEX Functions ///////////////////////////////////////////////////



#ifdef MEX_stroud_bary2d

// function B = stroud_bary2d (q)
// compute q^2 Stroud quadrature points 
//to plot points in a right triangle, use plot([0,0,1,0],[0,1,0,0],'r'), hold on, plot(B(1,:),B(2,:),'*') 
void
mexFunction (int nlhs, mxArray * plhs[], int nrhs, const mxArray * prhs[])
{
  int q;
  double *B;

  /* GET INPUT:
     Retrieve the first scalar input argument  */

  q = mxGetScalar (prhs[0]);


  /* MAKE ROOM FOR OUTPUT:
     Make space for the output argument,
     and copy the pointer to that space. */

  plhs[0] = mxCreateDoubleMatrix (3, q * q, mxREAL);

  B = mxGetPr (plhs[0]);


  /* COMPUTATION:
     Now that we have the interface set up, we can call the C routine. */

  double **quadraWN;

  // allocates memory for quadraWN1 and quadraWN2
  int len_Quadra = (q + 1);     // space required for storing q Jacobi nodes q, BUT indexing starts at 1

  quadraWN = create_quadraWN2d(len_Quadra);
  
	gaussJacobiUnit (q, quadraWN);
	
  stroud_bary2d (q, B, quadraWN);

  delete_quadraWN(quadraWN);

}
#endif



#ifdef MEX_stroud_bary2dw

// function B = stroud_bary2d (q)
// compute q^2 Stroud quadrature points 
//to plot points in a right triangle, use 
// plot([0,0,1,0],[0,1,0,0],'r'), hold on, plot(B(1,:),B(2,:),'*') 
void
mexFunction (int nlhs, mxArray * plhs[], int nrhs, const mxArray * prhs[])
{
  int q;
  double *B, *W;

  /* GET INPUT:
     Retrieve the first scalar input argument  */

  q = mxGetScalar (prhs[0]);


  /* MAKE ROOM FOR OUTPUT:
     Make space for the output argument,
     and copy the pointer to that space. */

  plhs[0] = mxCreateDoubleMatrix (3, q * q, mxREAL);

  B = mxGetPr (plhs[0]);

  plhs[1] = mxCreateDoubleMatrix (1, q * q, mxREAL);

  W = mxGetPr (plhs[1]);


  /* COMPUTATION:
     Now that we have the interface set up, we can call the C routine. */
		 
  // allocate memory to quadraWN which is called by stroud_bary2dw
  int len_Quadra = (q + 1);     // space required for storing q Jacobi nodes q, BUT indexing starts at 1
  double **quadraWN = create_quadraWN2d (len_Quadra);
 
  //gaussJacobiUnit (q-1, quadraWN);
	gaussJacobiUnit (q, quadraWN);

  stroud_bary2dw (q, B, W, quadraWN);
	
	//release the memory allocated to the quadrature 	 
  delete_quadraWN (quadraWN);


}
#endif

#ifdef MEX_stiff

// function S = stiff (n,Cval,v1,v2,v3)
// computation of stiffness matrix (VARIABLE, no PRECOMP)
// INPUT
// n -- degree, 
// Cval -- 3 x (m+1)^2 matrix of values of the 3 entries C(0,0), C(0,1), C(1,1) (in this order!)
//      at the Stroud quadrature points for the moments of degree m=2*n-2
// v1,v2,v3 -- column 2-vectors of the vertices of the triangle
// OUTPUT
// S -- stiffness matrix of size (n+2 choose 2) x (n+2 choose 2) 
// SEE routine 'Stiff' FOR THE ORDERING OF THE COLUMNS/ROWS OF S
void
mexFunction (int nlhs, mxArray * plhs[], int nrhs, const mxArray * prhs[])      /// needs to be checked...
{
  int n;
  int dimPn;
  double *Cval, *v1, *v2, *v3;
  double *S;

  /* GET INPUT:
     Retrieve the first scalar input argument  */

  n = mxGetScalar (prhs[0]);

  /* get the pointers of the remaning input arguments */
  Cval = mxGetPr (prhs[1]);
  v1 = mxGetPr (prhs[2]);
  v2 = mxGetPr (prhs[3]);
  v3 = mxGetPr (prhs[4]);


  /* MAKE ROOM FOR OUTPUT:
     Make space for the output argument,
     and copy the pointer to that space. */

  dimPn = ((n + 2) * (n + 1)) / 2;      /* compute the dimension of S */

  plhs[0] = mxCreateDoubleMatrix (dimPn, dimPn, mxREAL);

  S = mxGetPr (plhs[0]);



  /* COMPUTATION:
     Now that we have the interface set up, we can call the C routine. */


  
	double **binomialMat;
	double cputime[3];
	double normalMat[3][2] = { {0, 0}, {0, 0}, {0, 0} };  // store normals to the edges
	double scalarMat[3][3];

	
	int len_binomial = 2*n+2;
	binomialMat = create_BinomialMat(len_binomial);
	
	#ifdef PRECOMP
	double **precomp;	
	double **matValNodes;
	#else
	double **BmomentInter;
	#endif
	
	double **Bmoment, **Bmomentab;
	double *Cval;
	double **quadraWN; // store quadrature weights and nodes of a fixed degree


	int q = n+1;
  int nDash = 2 * n - 2;        // nDash is the order of the Bmoments used for the computation of the stiffness matrix
  int m = MAX (nDash, q-1);
	int nb_Array = 3;  
	int len_Quadra = (q + 1);     // space required for storing Jacobi nodes of order q is q, BUT indexing starts at 1
	
	 // allocates memory for quadraWN1 and quadraWN2
  quadraWN = create_quadraWN2d(len_Quadra);
	
	
  computeBinomials(binomialMat, len_binomial);
  normals2d (v1, v2, v3, normalMat);      // compute normals
	scalarMatrix2d (scalarMat, v1, v2, v3, normalMat);      //dummy, needed for the constant case only, but Stiff calls it


  
	int mm = MAX (nDash, q-1);          // m will be used for indexing
	
  int lenMoments = (mm + 1) * (mm + 1);
	
	Bmoment = create_Bmoment(lenMoments, nb_Array);
  Bmomentab = create_Bmoment(lenMoments, 6);
	
	#ifdef PRECOMP
	;
	#else
	BmomentInter = create_Bmoment(lenMoments, nb_Array);
	#endif
	
	
	
	// "assign_pointers" with non-PRECOMP:
	
  // initialize quadrature weights and nodes
	//gaussJacobiUnit (q, quadraWN);
	assign_quadra2d(q, quadraWN); 
	
	init_BmomentC_Stiff2d (C, q, v1, v2, v3, Bmoment, quadraWN); 
 
 
  void (*C) (double[2], double[2][2]) = A0;     //dummy, currently needed in PRECOMP case only


  int len_Stiff = ((n + 1) * (n + 2)) / 2;

  double **stiffMat = create_Mat(len_Stiff);
  


	#ifdef PRECOMP
	Stiff2d (n, q, v1, v2, v3, binomialMat, scalarMat, normalMat, cputime, precomp,
		 Bmoment, Bmomentab, stiffMat, matValNodes, quadraWN);     //compute the stiffness matrix in stiffMat
	#else
	Stiff2d (n, q, v1, v2, v3, binomialMat, scalarMat, normalMat, cputime,
		 Bmoment, BmomentInter, Bmomentab, stiffMat, quadraWN);     //compute the stiffness matrix in stiffMat
	#endif

  //store the data in S, can memcpy be used?

  for (int i = 0; i < dimPn; i++)
    for (int j = 0; j < dimPn; j++)
      *S++ = stiffMat[i][j];
  //fprintf(stderr,"\n%f ",stiffMat[i][j]);
	
#ifdef CHECKMEX
   fprintf(stderr,"\n");
   for (int i = 0; i < dimPn; i++, fprintf(stderr,"\n"))
     for (int j = 0; j < dimPn; j++)
       fprintf(stderr,"% f  ",stiffMat[i][j]);
			 
   fprintf(stderr,"\n");
	 
	 S = mxGetPr (plhs[0]); // restore S
	 
   for (int i = 0; i < dimPn; i++, fprintf(stderr,"\n"))
     for (int j = 0; j < dimPn; j++)
       fprintf(stderr,"% f  ",S[i*dimPn + j]);

   fprintf(stderr,"\n");
#endif
        
  delete_Mat(stiffMat);

  delete_quadraWN(quadraWN);
  
  delete_BinomialMat(binomialMat, len_binomial);

}
#endif

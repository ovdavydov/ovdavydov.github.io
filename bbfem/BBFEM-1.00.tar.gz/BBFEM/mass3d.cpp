#include <stdio.h>
#include <math.h>
#include <time.h>
#include <iostream>

#include "bbfem.h"


// example of coefficient function (used with mass matrix and load vector)
double 
f0(double v[3])
{
	return sin(v[0]*v[1]*v[2]);
}


#ifdef CONSTANT
int main()
{
// 	//vertices (standard tetrahedron)
// 	double v1[3] = { 0, 0, 0};
// 	double v2[3] = { 1, 0, 0};
// 	double v3[3] = { 0, 1, 0};
// 	double v4[3] = { 0, 0, 1};

	//vertices (particular tetrahedron)
  double v1[3] = { 1.2  , 3.4, 0}; 
  double v2[3] = { -1.5 , 2. , 0};
  double v3[3] = { 0.1  , -1., 0};
	double v4[3] = {1. , 1., 1.};

	int n; // degree of the Bernstein polynomial basis
  std::cout<<"Enter a value for the polynomial order n:";
  std::cin>>n;
	
	
	double **massMat; // used for storing mass matrix entries
	
	int len_Mass = len_Mat3d(n); // allocate memory for massMat
  massMat = create_Mat(len_Mass);
	
	
	
	get_mass3d_const(massMat, n, v1, v2, v3, v4); // compute mass matrix
	
	// Insert your code here to make use of massMat. It will be destroyed in the next line!
	
	// free allocated memory
	delete_Mat(massMat);	

}

#else // not CONSTANT


int main()
{
// 	//vertices (standard tetrahedron)
// 	double v1[3] = { 0, 0, 0};
// 	double v2[3] = { 1, 0, 0};
// 	double v3[3] = { 0, 1, 0};
// 	double v4[3] = { 0, 0, 1};

	//vertices (particular tetrahedron)
  double v1[3] = { 1.2  , 3.4, 0}; 
  double v2[3] = { -1.5 , 2. , 0};
  double v3[3] = { 0.1  , -1., 0};
	double v4[3] = {1. , 1., 1.};

	int n; // degree of the Bernstein polynomial basis
  std::cout<<"Enter a value for the polynomial order n:";
  std::cin>>n;
	
	double (*f) (double[3]) = f0; // change here if want mass matrix associated with another function
	
	double *Cval; // store array of function values at Stroud nodes
	
	int functval = 0; //default: using a routine (f) for mass matrix coefficients
	
	#ifdef FUNCT_VAL
	functval = 1;  //using the values stored in Cval for convective matrix coefficients
	
	int q = n+1;
	int nb_Array = 1; // the mass matrix is associated with scalar-valued data
	
	double *B; // store barycentric coordinates of Stroud nodes
	B = new double [q*q*q*4];
	stroud_nodes_bary3d (q, B);
	
	int LEN = q * q * q;  // space required for 3D array with dimension q+1	
  Cval = new double[LEN * nb_Array];    //Cval entries are stored in LINEAR memory, and used directly
  #endif
	
	
	#ifdef FUNCT_VAL
	scalar_values_at_Stroud3d(q, Cval, B, f, v1, v2, v3, v4); // storing your data in Cval
	#endif
	
	double **massMat; // used for storing mass matrix entries
	
	int len_Mass = len_Mat3d(n); // allocate memory for massMat
  massMat = create_Mat(len_Mass);
	
	get_mass3d(massMat, n, f, Cval, v1, v2, v3, v4, functval); // compute mass matrix
	
	
	// free allocated memory
	#ifdef FUNCT_VAL
	delete Cval;
	delete B;
	#endif
	
	// Insert your code here to make use of massMat. It will be destroyed in the next line!
	
	
	delete_Mat(massMat);

}
#endif // end not CONSTANT
//  This file is part of BBFEM.
//  
//   Authors: Mark Ainsworth
// 				    Division of Applied Mathematics
// 				    Brown University
// 				    182 George Street
// 				    Providence, RI 02912
// 				    e-mail: Mark_Ainsworth@Brown.edu
//
//            Gaelle Andriamaro
// 	  			  University of Strathclyde
// 	  			  Department of Mathematics and Statistics
//           	26 Richmond Street
// 	  			  Glasgow G1 1XH
// 	  			  Scotland, UK
// 	          e-mail: gaelle.andriamaro@strath.ac.uk
//  
//            Oleg Davydov
// 	  			  University of Strathclyde
// 	  			  Department of Mathematics and Statistics
//           	26 Richmond Street
// 	  			  Glasgow G1 1XH
// 	  			  Scotland, UK
// 	  			  e-mail: oleg.davydov@strath.ac.uk
// 
// 
//   Copyright (C) 2013 Mark Ainsworth, Gaelle Andriamaro and Oleg Davydov
// 
// 
// This package is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2, or (at your option)
// any later version.
// 
// This package is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this package; see the file COPYING.  If not, write to
// the Free Software Foundation, 59 Temple Place - Suite 330,
// Boston, MA 02111-1307, USA.  

int 
dimCurl(int n);
int 
dim_nonGradCurl(int n);

double **
create_cRing(int n);
void
delete_cRing(double **cRing);

void
delete_pointers_Curl(double **precomp, double **Bmoment,
										 double **BmomentInter,
										 double **matValNodes, double **quadraWN);
void
delete_pointers_Curl(double **Bmoment, double **BmomentInter, 
										 double **matValNodes,
										 double **quadraWN);										 
void 
LowerMoment( int p , int q, int l, double **Bmoment, 
						 double **BmomentInter, int nb_Array); 															
void 
CRing(int n, double normalMat[][2], double **cRing);

double 
Mass2d_Curl( int n, 
						 int q, double v1[2], double v2[2], double v3[2],
						 double **binomialMat, double normalMat[][2], 
						 double **precomp, int mp, 
						 double **Bmoment, double **BmomentInter,
						 double **Bmomentab,
						 double **massMat, double **matValNodes, 
						 double **quadraWN, double **cRing, double cputime[2]);
double 
Mass2d_Curl( int n, 
						 int q, double v1[2], double v2[2], double v3[2],
						 double **binomialMat, double normalMat[][2],
						 double **Bmoment, double **BmomentInter,
						 double **Bmomentab,
						 double **massMat, double **matValNodes, 
						 double **quadraWN, double **cRing,
						 double cputime[2]);
void 
CBar( int n, double v1[2], double v2[2], double v3[2] , double **cBar) ;
double ** 
create_cBar(int n);
void 
delete_cBar(double **cBar);
double 
Stiff2d_Curl( int n, 
						 int q, double v1[2], double v2[2], double v3[2],
						 double **binomialMat, double **precomp, int mp, 
						 double **Bmoment, double **BmomentInter,
						 double **cBar,
						 double **stiffMat, double **matValNodes, 
						 double **quadraWN, double cputime[3]);
double 
Stiff2d_Curl(int n, 
						 int q, double v1[2], double v2[2], double v3[2],
						 double **binomialMat, double **Bmoment, double **BmomentInter,
						 double **cBar,
						 double **stiffMat, double **matValNodes, 
						 double **quadraWN,
						 double cputime[3]);
void
transform_BmomentC_Mass2dCurl (int n, int q, double **Bmoment, double **Bmomentab, double normalMat[][2]);
									 										 
double 
Load2d_Curl( int n, 
						 int q, double v1[2], double v2[2], double v3[2],
						 double **binomialMat, double normalMat[][2],
						 double **precomp, int mp, 
						 double **Bmoment, double **BmomentInter,
						 double *loadVect, double **matValNodes, 
						 double **quadraWN, double **cRing, double cputime[3]);										 
double 
Load2d_Curl( int n, 
						 int q, double v1[2], double v2[2], double v3[2],
						 double **binomialMat, double normalMat[][2],
						 double **Bmoment, double **BmomentInter,
						 double *loadVect, double **matValNodes, double **quadraWN, double **cRing,
						 double cputime[3]);										 							 
void
copy_Data_at_Stroud(int q, double v1[2], double v2[2], double v3[2],
													double **Bmoment, double **matValNodes, int nb_Array);
													
													
void
get_mass2dCurl(double **massMat, int n, void (*Kappa) (double v[2], double matC[2][2]),
							 double *Cval, double v1[2] , double v2[2], double v3[2], int functval );
							 
void
get_stiffness2dCurl(double **stiffMat, int n, double (*A) (double v[2]), double *Cval,
										double v1[2], double v2[2], double v3[2], int functval);																				
void
get_load2dCurl(double *loadVect, int n, void (*F)( double v[2], double vectF[2]), double *Cval,
							 double v1[2], double v2[2], double v3[2], int functval);

					
							 
//// routines involved in residual computation: //////							 

double 
residual_Constit ( int n, int q,
							 double v1[2], double v2[2], double v3[2],
							 double **binomialMat, double **precomp, int mp,
							 double **Bmoment, double *resVect, double **matValNodes,
							 double **quadraWN, double **cBar, double cputime[2],
							 double **CVal ); 
double 
residual_Constit ( int n, int q,
							 double v1[2], double v2[2], double v3[2],
							 double **Bmoment, double **BmomentInter, double *resVect, 
							 double **quadraWN, double **cBar, double cputime[2],
							 double **CVal ); 	
double ** 
create_Coeff(int lenCoeff, int nb_Array);
void delete_Coeff(double **Coeff);
void 
randomCoeff(double *random_Coeff, int len_randCoeff);
void 
init_BForm_Coeff( double *random_Coeff, int len_randCoeff,
							int n, double **Coeff_p);
void 
sigma2Bform( double *random_Coeff, int n, double **Coeff_u, int lenCoeff_u,
							double **cBar);
double
Evaluate_at_Stroud( int n, int q, double **Coeff, double **CoeffInter, int nb_Array);

void
data_at_Nodes_Coeff( int n, int q, int nb_Array, double **CVal,
										 double **matValNodes);

void
init_Bmoment_Coeff( int n, int q, int nb_Array, double **CVal, double v1[2], double v2[2], double v3[2], double **Bmoment);

void
residual_Compute(double *random_Coeff, double **Coeff_p, 
								 double **Coeff_pInter, double **Coeff_u, 
								 double **Coeff_uInter, int lenCoeff_p, 
								 int lenCoeff_u, int n, int q, double v1[2], double v2[2], double v3[2], double cpu_time[4],
								 double **binomialMat, double **precomp, int mp,
								 double **Bmoment, double *resVect, double **matValNodes,
								 double **quadraWN, double **cBar);
void
residual_Compute(double *random_Coeff, double **Coeff_p, 
								 double **Coeff_pInter, double **Coeff_u, 
								 double **Coeff_uInter, int lenCoeff_p, 
								 int lenCoeff_u, int n, int q, double v1[2], double v2[2], double v3[2], double cpu_time[4],
								 double **Bmoment, double **BmomentInter, double *resVect,
								 double **quadraWN, double **cBar);

#include <stdio.h>
#include <math.h>
#include <time.h>
#include <iostream>

#include "bbfem.h"


#ifdef CONSTANT
int main()
{
	//   //vertices (standard triangle)
  //   double v1[2] = { 0, 0 };
  //   double v2[2] = { 1, 0 };
  //   double v3[2] = { 0, 1 };
  
  //vertices (particular triangle)
  double v1[2] = { 1.2  , 3.4 }; 
  double v2[2] = { -1.5 , 2. };
  double v3[2] = { 0.1  , -1. };

  int n; // degree of the Bernstein polynomial basis
  std::cout<<"Enter a value for the polynomial order n:";
  std::cin>>n;
	
	double vectCoeff[2] = {1.,1.}; // coefficient vector associated with convective matrix (given by vector [1,1]^tr)
	
	double **convecMat; // store convective matrix entries
  int len_Convec = len_Mat2d(n);
  convecMat = create_Mat(len_Convec); // allocate memory to convecMat
	
	get_convec2d_const (convecMat, n, v1, v2, v3, vectCoeff); // compute convective matrix
	
	// Insert your code here to make use of convecMat. It will be destroyed in the next line!
	
	// free allocated memory
	delete_Mat(convecMat);

}

#else // not CONSTANT

//example of vector b: [2-sin(xy) ; 1-xy]
void
b0 (double v[2], double vect[2])
{
	
	vect[0] = 2-sin(v[0]*v[1]);
	vect[1] = 1 - v[0]*v[1];
	
}



int main()
{
	//   //vertices (standard triangle)
  //   double v1[2] = { 0, 0 };
  //   double v2[2] = { 1, 0 };
  //   double v3[2] = { 0, 1 };
  
  //vertices (particular triangle)
  double v1[2] = { 1.2  , 3.4 }; 
  double v2[2] = { -1.5 , 2. };
  double v3[2] = { 0.1  , -1. };

  int n; // degree of the Bernstein polynomial basis
  std::cout<<"Enter a value for the polynomial order n:";
  std::cin>>n;
	
	double *Cval; // store array of function values at Stroud quadrature nodes, needed by get_convec2d
	
	int functval = 0; //default: using a routine (b) for convective matrix coefficients
	
	void (*b) (double[2], double[2]) = b0; // change here to your routine for convective matrix coefficients
	
	#ifdef FUNCT_VAL
	functval = 1;  //using the values stored in Cval for convective matrix coefficients
	int q = n+1;
	int nb_Array = 2; // the convective matrix is associated with vector-valued data
	
	double *B; // store barycentric coordinates of Stroud nodes
	B = new double [q*q*3];
	stroud_nodes_bary2d (q, B);
	
	int LEN = q * q ;  // space required for 2D array with dimension q+1	
  Cval = new double[LEN * nb_Array];    //Cval entries are stored in LINEAR memory, and used directly
  
  // storing your data in Cval
	vector_values_at_Stroud2d(q, Cval, B, b, v1, v2, v3 );
	#endif
	
	double **convecMat; // store convective matrix entries
  int len_Convec = len_Mat2d(n);
  convecMat = create_Mat(len_Convec); // allocate memory to convecMat
	
	get_convec2d(convecMat, n, b, Cval, v1, v2, v3, functval); // compute convective matrix
	
	
	// free allocated memory
	#ifdef FUNCT_VAL
	delete Cval;
	delete B;
	#endif
	
	// Insert your code here to make use of convecMat. It will be destroyed in the next line!
	
	delete_Mat(convecMat);
}


#endif // end not CONSTANT

#include <stdio.h>
#include <math.h>
#include <time.h>
#include <iostream>

#include "bbfem.h"


#ifdef CONSTANT
int main()
{
	//   //vertices (standard triangle)
	//   double v1[2] = { 0, 0 };
	//   double v2[2] = { 1, 0 };
	//   double v3[2] = { 0, 1 };

	//vertices (particular triangle)
  double v1[2] = { 1.2  , 3.4 }; 
  double v2[2] = { -1.5 , 2. };
  double v3[2] = { 0.1  , -1. };
	
	int n; // degree of the Bernstein polynomial basis
  std::cout<<"Enter a value for the polynomial order n:";
  std::cin>>n;
	
	double **massMat; // used for storing mass matrix entries	
	int len_Mass = len_Mat2d(n); // allocate memory for massMat
  massMat = create_Mat(len_Mass);
	
	get_mass2d_const(massMat, n, v1, v2, v3);
	
	// Insert your code here to make use of massMat. It will be destroyed in the next line!
		
	// free memory allocated to massMat
	delete_Mat(massMat);
	
	
}

#else // not CONSTANT

// example of function f: f(x) = 2 - sin(xy)
double
f0 (double v[2])
{
  return 2 - sin (v[0]*v[1]);
}


int main()
{
//   //vertices (standard triangle)
//   double v1[2] = { 0, 0 };
//   double v2[2] = { 1, 0 };
//   double v3[2] = { 0, 1 };

	//vertices (particular triangle)
  double v1[2] = { 1.2  , 3.4 }; 
  double v2[2] = { -1.5 , 2. };
  double v3[2] = { 0.1  , -1. };
	
  int n; // degree of the Bernstein polynomial basis
  std::cout<<"Enter a value for the polynomial order n:";
  std::cin>>n;
	
	double *Cval; // store array of function values at Stroud quadrature nodes, needed by get_mass2d
	
	int functval = 0; //default: using a routine (f) for mass matrix coefficients
	
	double (*f) (double[2]) = f0; // change here to your routine for mass matrix coefficients
	
	#ifdef FUNCT_VAL
	functval = 1;  //using the values stored in Cval for mass matrix coefficients
	int q = n+1;
	int nb_Array = 1; // the mass matrix is associated with scalar-valued data
	
	double *B; // store barycentric coordinates of Stroud nodes
	B = new double [q*q*3];
	stroud_nodes_bary2d (q, B);
	
	int LEN = q * q ;  // space required for 2D array with dimension q+1	
  Cval = new double[LEN * nb_Array];    //Cval entries are stored in LINEAR memory, and used directly

	// storing your data in Cval
	scalar_values_at_Stroud2d(q, Cval, B, f, v1, v2, v3 );
	#endif
	
	double **massMat; // used for storing mass matrix entries
	
	int len_Mass = len_Mat2d(n); // allocate memory for massMat
  massMat = create_Mat(len_Mass);
	
	get_mass2d(massMat, n, f, Cval, v1, v2, v3, functval); // compute mass matrix
		
	// free allocated memory
	#ifdef FUNCT_VAL
	delete Cval;
	delete B;
	#endif
	
	// Insert your code here to make use of massMat. It will be destroyed in the next line!
	
	delete_Mat(massMat);
}


#endif // end not CONSTANT
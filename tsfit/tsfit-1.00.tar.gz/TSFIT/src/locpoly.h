/* Local least squares polynomial approximation as described in

 O. Davydov, On the approximation power of local least squares polynomials, 
 in  "Algorithms for Approximation IV," (J.Levesley, I.J.Anderson and 
 J.C.Mason, Eds.), pp.346-353, University of Huddersfield, UK, 2002.

 O. Davydov and F. Zeilfelder, Scattered data fitting by direct extension 
 of local polynomials to bivariate splines, Advances in Comp. Math. 21 (2004), 
 223-271.
 
  Author: Oleg Davydov
	  University of Strathclyde
	  Department of Mathematics
          26 Richmond Street
	  Glasgow G1 1XH
	  Scotland, UK
	  e-mail: oleg.davydov@strath.ac.uk


  Copyright (C) 2005 Oleg Davydov

This file is part of TSFIT.

This package is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This package is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this package; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */


typedef struct
{
  char type[100];
  TRIEL *locale;		/* locale */
  int max_number;		/* maximal number of points (used for memory allocation);
				   must be at least max_number of LOCALDATA used */
  int max_degree;		/* maximal degree: used by trinom */
  int max_loc_dim;		/* maximal local dimension important for memory allocation */
  double *coefs;		/* (max_loc_dim) - vector of the local degrees of freedom */
  SVDMATR *locMatr;		/* collocation and other  matrices for least squares */
  TRINOM *trinom;		/* trinomial coefficients: needed for collocation matrices */
  LSCONTROL *lscontr;		/* pointer to the local search control */
  /* local basis */
  BBTRI *baseTri;		/* pointer to the Bernstein-Bezier triangle used for 
				   the polynomial basis */
  /* user specified parameters for degree selection */
  double min_sing_value;	/* tolerance for acceptable min sing value (polynomials) */
  int starting_degree;		/* starting polynomial degree */
  /* info */
  int *degree_stat;		/* the numbers of loc polynomials of degrees 0...starting_degree */
  double max_cond;		/* maximum condition number of the collocation matrix over 
				   all local approximations */
  /* pointer to any auxiliary data */
  void *aux;
} LACONTROL;


/* routines for the external use */


void compute_poly_loc_appr (void *data, void *lcontr);
void adapt_poly_degree (LOCALDATA * locPoints, LACONTROL * lacontr);

void init_poly_loc_appr (void *lcontr);
void free_poly_loc_appr (void *lcontr);

/* C^1 spline of degree 3 on the four-directional mesh computed by the 
extension method as described in
 O. Davydov and F. Zeilfelder, Scattered data fitting by direct extension 
 of local polynomials to bivariate splines, Advances in Comp. Math. 21 (2004), 
 223-271.
 
  Author: Oleg Davydov
	  University of Strathclyde
	  Department of Mathematics
          26 Richmond Street
	  Glasgow G1 1XH
	  Scotland, UK
	  e-mail: oleg.davydov@strath.ac.uk


  Copyright (C) 2005 Oleg Davydov

This file is part of TSFIT.

This package is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This package is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this package; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */


/* running window for averaging and local update */

/*
 *  y
 *  |
 *  |
 *  ----------------------------------------- |
 *  |                                         |
 *  |                                         |
 *  |        yborder                          |
 *  |------------------------                 |
 *  |------------------------                 |
 *  |          |           || x               |
 *  |          |           || b               |
 *  |          |           || o               |
 *  |          |   window  || r  -->          |
 *  |          |           || d               |
 *  |          |           || e               |
 *  |          |           || r    yborder    |
 *  |          |           ||-----------------|
 *  |          ------------||-----------------|
 *  |                                         |
 *  |                                         |
 *  |-----------------------------------------| --> x
 */

typedef struct
{
  int ntri;			/* the number of triangles we allocate memory
				   for each of the 'wcoefs*' */
  int wn, wm;			/* current window sizes in x, resp. y direction */
  double *wcoefs0;		/* 8 arrays of coefficients of local approximations */
  double *wcoefs1;		/* (correspond to the numbering of triangles in loc_extension) */
  double *wcoefs2;
  double *wcoefs3;
  double *wcoefs4;
  double *wcoefs5;
  double *wcoefs6;
  double *wcoefs7;
  double gg[10];		/* dummy array of BB coefs needed sometimes at the boundary */

  double *xborder, *yborder;	/* intended for a buffer to store local
				   approximations used by more than one window;
				   NOT USED SOFAR */
} WINDOW_SpC1d3D2;


typedef struct
{
  int n;			/* number of true spline cells (ie, without border cells) in x direction */
  int m;			/* number of true spline cells (ie, without border cells) in y direction */
  double **f;                   /* values at the vertices, including border cells; (n+3)x(m+3)-array */
  double **fx;                   /* x-derivatives at the vertices, including border cells; (n+3)x(m+3)-array */
  double **fy;                   /* y-derivatives at the vertices, including border cells; (n+3)x(m+3)-array */
  double **fnx;                   /* normal x-derivatives, including border cells; (n+3)x(m+2)-array */
  double **fny;                   /* normal y-derivatives, including border cells; (n+2)x(m+3)-array */
} FVSBASIS;

/* spline via coefficients w.r.t. our basis */

/* coefs are split in groups of 10, each corresponding to a Bezier
triangle; the numbering of the triangles is shown below: they are 
the _west_ triangles in each numbered (i.e. 'black') cell; 
the stars indicate the bounding box */
/* 
*  Numbering of 'black' cells: 
*
*       y
*       | 
*       | 
*  |----|----|----|----|
*  |    | 6  |    | 7  |
*  |----***********----|
*  | 4  *    | 5  *    |
*  |----*----|----*----|
*  |    * 2  |    * 3  |
*  |----***********----|--> x
*  | 0  |    | 1  |    |
*  |----|----|----|----|
*
*
*
* Ordering of the vertices of the triangle: 
* clockwise with the central vertex being the last
*  
*  2
*   |---------|
*   | *       |
*   |   * 3   |
*   | *       |
*   |---------|
*  1
*  
* ordering of BB coefs in 'coefs':
*   
*   1--->2
*    -->
*    ->
*    3
*/

typedef struct
{
  int n;			/* number of true spline cells (ie, without border cells) in x direction */
  int m;			/* number of true spline cells (ie, without border cells) in y direction */
  double hx;			/* length of the x side of the cell */
  double hy;			/* length of the y side of the cell */
  int num;			/* number of coefs: the size of the array 'coefs'; 
                                  NOTE: exceeds the dimension of the spline space */
  double *coefs;		/* see the above description */
  TRIEL *locale;                /* locale */
  BBTRI *bbtri;			/* preallocated BB triangle for evaluation */
  int av;			/* averaging flag: if av = 1, the "window" field below is activated  */
  int ws;			/* window size (number of cells in x and y direction) */
  WINDOW_SpC1d3D2 *window;	/* see the description above */
  /* info */
  int dim;			/* the dimension of the spline space */
  int nontriv;			/* number of significant nonzero coefs: needed for
				   compression with multilevel splines */
  /* optional FVS basis */
  int fvs_state;                /* 0: fvsbasis is not allocated; 1: allocated but either not used or outdated;
                                   2: represents the same spline as 'coefs'; 3: represents the correct spline
				   while 'coefs' is outdated */
  FVSBASIS *fvsbasis;           /* coefficients of the same spline w.r.t. FVS finite element basis */
} SpC1d3D2;






/* routines for external use */


void init_SpC1d3D2 (void * spline);

void free_SpC1d3D2 (void * spline);

void compute_SpC1d3D2 (void * data_void, void * spline_void,
                       TSFIT_LOCAL_METHOD *local_method,
	      	       TSFIT_CONVERTER *converter);

double eval_SpC1d3D2 (double x, double y, void *spline_void);

void compute_bbcoefs_SpC1d3D2 (double *coefs, int i, int j, int ind,
		      SpC1d3D2 * spline);

void store_bbcoefs_SpC1d3D2 (SpC1d3D2 * spline, char *filename);


void init_fvsbasis_SpC1d3D2 (SpC1d3D2 * spline);

void free_fvsbasis_SpC1d3D2 (SpC1d3D2 * spline);

void transform_to_fvs_SpC1d3D2 (SpC1d3D2 * spline);

void transform_from_fvs_SpC1d3D2 (SpC1d3D2 * spline);

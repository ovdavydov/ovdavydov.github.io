/* C^2 spline of degree 6 on the four-directional mesh computed by the 
extension method as described in
 O. Davydov and F. Zeilfelder, Scattered data fitting by direct extension 
 of local polynomials to bivariate splines, Advances in Comp. Math. 21 (2004), 
 223-271.
 
  Authors: Frank Zeilfelder
           Universit\"at Mannheim 
           Fakult\"at f\"ur Mathematik und Infomatik
           Lehrstuhl Mathematik IV
           68131 Mannheim, Germany 
           e-mail: zeilfeld@euklid.math.uni-mannheim.de
 
           Oleg Davydov
	  			 University of Strathclyde
	  			 Department of Mathematics
          			 26 Richmond Street
	  			 Glasgow G1 1XH
	  			 Scotland, UK
	  			 e-mail: oleg.davydov@strath.ac.uk


  Copyright (C) 2005, 2012  Frank Zeilfelder and Oleg Davydov

This file is part of TSFIT.

This package is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This package is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this package; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

#include <stdio.h>
#include <stdlib.h>
#include <string.h> 
#include <math.h>



#include "datamng.h"
#include "lmethod.h"
#include "convert.h"

#include "bezier.h"
#include "SpC2d6D2.h"




/***********************************************************************/
/*                    Static function declarations                     */
/***********************************************************************/

static void compute_rst_ijx (double x, double y, double *rr, double *ss,
			     double *tt, int *ii_arg, int *jj_arg,
			     int *index_arg, D2SPLINE * spline);
static double deCast6 (double r, double s, double t, double *tri);
static void extend2 (D2SPLINE * spline);
static void add_to_average2 (D2SPLINE * spline);
static void loc_appr2 (void *data_void, void *spline_void,
		       TSFIT_LOCAL_METHOD * local_method,
		       TSFIT_CONVERTER * converter);



/***********************************************************************/
/*                             Macros                                  */
/***********************************************************************/
/*
 * EVAL_LOC_POLY (evaluation of local approximations)
 * COMPUTATION_MESSAGES (messages about computation of average spline)
 */


/***********************************************************************/
/*                             Routines                                */
/***********************************************************************/
void
set_C2_Delta2spline (D2SPLINE * spline)
{
  spline->loc_dim = 28;
  spline->deCast = &deCast6;
  spline->loc_appr = &loc_appr2;
  spline->extend = &extend2;
  spline->add_to_average = &add_to_average2;

}

void
compute_Delta2spline (void *data_void, void *spline_void,
		      TSFIT_LOCAL_METHOD * local_method,
		      TSFIT_CONVERTER * converter)
{
  TSFIT_DATA *data = (TSFIT_DATA *) data_void;
  D2SPLINE *tspline = (D2SPLINE *) spline_void;
  int i, j, k, l;
  void (*loc_appr) (void *data_void, void *spline_void,
		       TSFIT_LOCAL_METHOD * local_method,
		       TSFIT_CONVERTER * converter) = tspline->loc_appr;
  void (*extend) (D2SPLINE * spline) = tspline->extend;
  void (*add_to_average) (D2SPLINE * spline) = tspline->add_to_average;



  tspline->shift = 0;

  if (!tspline->av)
    {

      tspline->control = 1;

#ifdef COMPUTATION_MESSAGES
      fprintf (stderr, "Compute spline (x,y) non-shifted \n");
#endif

      loc_appr (data, tspline, local_method, converter);
      extend (tspline);


    }
  else
    {				/* averaging */

      for (tspline->control = 1; tspline->control < 9; tspline->control++)
	{

#ifdef COMPUTATION_MESSAGES
	  if (tspline->control == 1)
	    fprintf (stderr, "\n\n1) Compute spline (x,y) non-shifted \n");
	  if (tspline->control == 2)
	    fprintf (stderr,
		     "\nCompute 7 additional splines:\n2) (x,y) shifted; ");
	  if (tspline->control == 3)
	    fprintf (stderr, "3) (1-x,y) non-shifted; ");
	  if (tspline->control == 4)
	    fprintf (stderr, "4) (1-x,y) shifted;\n");
	  if (tspline->control == 5)
	    fprintf (stderr, "5) (y,x) non-shifted; ");
	  if (tspline->control == 6)
	    fprintf (stderr, "6) (y,x) shifted;  ");
	  if (tspline->control == 7)
	    fprintf (stderr, "7) (1-y,x) non-shifted;\n");
	  if (tspline->control == 8)
	    fprintf (stderr, "8) (1-y,x) shifted. ");
#endif

	  if (tspline->control == 5)
	    {

	      /* store original gridsizes for computation of tri5 -- tri8 */

	      tspline->gridXSize1 = tspline->gridXSize;
	      tspline->gridYSize1 = tspline->gridYSize;
	      tspline->wGrid1 = tspline->wGrid;
	      tspline->hGrid1 = tspline->hGrid;

	      /* change gridsizes */


	      tspline->gridXSize = tspline->gridYSize1;
	      tspline->gridYSize = tspline->gridXSize1;
	      tspline->wGrid = tspline->hGrid1;
	      tspline->hGrid = tspline->wGrid1;


	    }



	  /* compute the local least squares polynomials
	     and extend them to a spline by smoothness conditions */

	  loc_appr (data, tspline, local_method, converter);
	  extend (tspline);





	  /*  add the coefficients to the averaged spline */


	  add_to_average (tspline);


	  /* switch between shifted and non-shifted */

	  tspline->shift = !tspline->shift;


	}


      /* back to original gridXSize,gridYSize */


      tspline->gridXSize = tspline->gridXSize1;
      tspline->gridYSize = tspline->gridYSize1;
      tspline->wGrid = tspline->wGrid1;
      tspline->hGrid = tspline->hGrid1;



      /* Compute the coefficients of the averaged spline */

      for (i = -1; i <= tspline->gridXSize; i++)
	for (j = -1; j <= tspline->gridYSize; j++)
	  for (k = 0; k <= 3; k++)
	    for (l = 0; l < tspline->loc_dim; l++)
	      (tspline->tri)[getTriIndex_Delta2spline (i, j, tspline) +
			     k][l] =
		1 / 8.0 *
		(tspline->tri_av)[getTriIndex_Delta2spline (i, j, tspline) +
				  k][l];



    }





}






  /* Initialize the D2SPLINE structure */


void
init_Delta2spline (void *spline_void)
{
  D2SPLINE *spline = (D2SPLINE *) spline_void;
  int i;
  int numTri;


  /* compute reflectX, reflectY: bounding box of the spline grid on
     the scaled data */

  spline->reflectX = spline->wGrid * (double) spline->gridXSize;
  spline->reflectY = spline->hGrid * (double) spline->gridYSize;

  /* initialize the arrays that depend on gridXSize, gridYsize */

  numTri = (spline->gridXSize + 2) * (spline->gridYSize + 2) * 4;


  /* memory needed for the polynomial pieces of the 
     current spline of computation and average spline */

  spline->tri = (double **) malloc (numTri * sizeof (double *));

  if (spline->tri == NULL)
    {
      fprintf (stderr, "error: memory allocation failure [tri]\n");
      exit (-1);
    }




  for (i = 0; i < numTri; i++)
    {
      spline->tri[i] = (double *) malloc (spline->loc_dim * sizeof (double));
      if (spline->tri[i] == NULL)
	{
	  fprintf (stderr, "error: memory allocation failure [tri]\n");
	  exit (-1);
	}
    }

  if (spline->av)
    {
      spline->tri_av = (double **) malloc (numTri * sizeof (double *));

      if (spline->tri_av == NULL)
	{
	  fprintf (stderr, "error: memory allocation failure [tri_av]\n");
	  exit (-1);
	}

      for (i = 0; i < numTri; i++)
	{

	  spline->tri_av[i] =
	    (double *) malloc (spline->loc_dim * sizeof (double));

	  if (spline->tri_av[i] == NULL)
	    {
	      fprintf (stderr, "error: memory allocation failure [tri_av]\n");
	      exit (-1);
	    }
	}
    }


}


void
free_Delta2spline (void *spline_void)
{

  D2SPLINE *spline = (D2SPLINE *) spline_void;
  int i;
  int numTri = (spline->gridXSize + 2) * (spline->gridYSize + 2) * 4;

  if (spline->av)
    {

      for (i = 0; i < numTri; i++)
	free ((spline->tri_av)[i]);

      free (spline->tri_av);

    }

  for (i = 0; i < numTri; i++)
    free ((spline->tri)[i]);

  free (spline->tri);

}




/* evaluation at one point */

double
eval_Delta2spline (double x, double y, void *spline_void)
{
  D2SPLINE *spline = (D2SPLINE *) spline_void;
  int ii, jj, idx;
  double r, s, t;

  compute_rst_ijx (x, y, &r, &s, &t, &ii, &jj, &idx, spline);

  return spline->deCast (r, s, t,
			 (spline->
			  tri)[getTriIndex_Delta2spline (ii, jj,
							 spline) + idx]);

}



static void
compute_rst_ijx (double x, double y, double *rr, double *ss, double *tt,
		 int *ii_arg, int *jj_arg, int *index_arg, D2SPLINE * spline)
{
  int ii, jj, idx;
  double r, s, t, d;
  double m1, m2, mgrid;
  double z1[2], z2[2], z3[2], ll[2];
  int gridXSize = spline->gridXSize;
  int gridYSize = spline->gridYSize;
  double wGrid = spline->wGrid;
  double hGrid = spline->hGrid;


  mgrid = hGrid / wGrid;

  ii = (int) (x / wGrid);
  if (ii < 0)
    ii = 0;
  if (ii >= gridXSize)
    ii = gridXSize - 1;
  jj = (int) (y / hGrid);
  if (jj < 0)
    jj = 0;
  if (jj >= gridYSize)
    jj = gridYSize - 1;

  ll[0] = (double) ii *wGrid;
  ll[1] = (double) jj *hGrid;

  if (x < ll[0])
    x = ll[0];
  if (x > ll[0] + wGrid)
    x = ll[0] + wGrid;
  if (y < ll[1])
    y = ll[1];
  if (y > ll[1] + hGrid)
    y = ll[1] + hGrid;

  if (x == ll[0])
    {
      idx = 0;
      z1[0] = ll[0];
      z1[1] = ll[1];
      z2[0] = ll[0];
      z2[1] = ll[1] + hGrid;
    }
  else
    {
      m1 = (y - ll[1]) / (x - ll[0]);
      m2 = (hGrid - (y - ll[1])) / (x - ll[0]);

      if (m1 >= mgrid)
	{			/* idx = 0 or 1 */
	  if (m2 >= mgrid)
	    {
	      idx = 0;
	      z1[0] = ll[0];
	      z1[1] = ll[1];
	      z2[0] = ll[0];
	      z2[1] = ll[1] + hGrid;
	    }
	  else
	    {
	      idx = 1;
	      z1[0] = ll[0];
	      z1[1] = ll[1] + hGrid;
	      z2[0] = ll[0] + wGrid;
	      z2[1] = ll[1] + hGrid;
	    }
	}
      else
	{			/* idx = 2 or 3 */
	  if (m2 >= mgrid)
	    {
	      idx = 3;
	      z1[0] = ll[0] + wGrid;
	      z1[1] = ll[1];
	      z2[0] = ll[0];
	      z2[1] = ll[1];
	    }
	  else
	    {
	      idx = 2;
	      z1[0] = ll[0] + wGrid;
	      z1[1] = ll[1] + hGrid;
	      z2[0] = ll[0] + wGrid;
	      z2[1] = ll[1];
	    }
	}
    }
  z3[0] = ll[0] + 0.5 * wGrid;
  z3[1] = ll[1] + 0.5 * hGrid;

  d = z2[0] * z3[1] + z1[1] * z3[0] + z1[0] * z2[1];
  d -= z1[1] * z2[0] + z1[0] * z3[1] + z2[1] * z3[0];

  r = z2[0] * z3[1] + y * z3[0] + x * z2[1];
  r -= y * z2[0] + x * z3[1] + z2[1] * z3[0];
  r /= d;

  s = x * z3[1] + z1[1] * z3[0] + z1[0] * y;
  s -= z1[1] * x + z1[0] * z3[1] + y * z3[0];
  s /= d;

  t = z2[0] * y + z1[1] * x + z1[0] * z2[1];
  t -= z1[1] * z2[0] + z1[0] * y + z2[1] * x;
  t /= d;

  if (fabs (r + s + t - 1.0) > 1.e-6)
    fprintf (stderr, "r = %f, s = %f, t = %f\n", r, s, t);

  *rr = r;
  *ss = s;
  *tt = t;

  *ii_arg = ii;
  *jj_arg = jj;
  *index_arg = idx;



}


/* Computes the index of the squares,
the squares are organized in rows, from
the bottom to the top */


int
getTriIndex_Delta2spline (int x, int y, D2SPLINE * spline)
{
  int idx;

  /* -1 <= x <= gridXSize, -1 <= y <= gridYSize */

  idx = ((y + 1) * (spline->gridXSize + 2) + (x + 1)) * 4;

#ifdef COMPUTATION_MESSAGES
  if (idx < 0
      || idx >= ((spline->gridXSize + 2) * (spline->gridYSize + 2) * 4))
    fprintf (stderr, "error: getTriIndex(%d,%d) = %d\n", x, y, idx);
#endif

  return idx;
}


/* computes the index of quad(i,j) in the original grid
   (gridXSize1 is the original x-size of grid)
*/

int
getTriIndex1_Delta2spline (int x, int y, D2SPLINE * spline)
{
  int idx;

  idx = ((y + 1) * (spline->gridXSize1 + 2) + (x + 1)) * 4;

#ifdef COMPUTATION_MESSAGES
  if (idx < 0
      || idx >= ((spline->gridXSize1 + 2) * (spline->gridYSize1 + 2) * 4))
    fprintf (stderr, "error: getTriIndex1_Delta2spline ! (%d,%d) = %d\n", x,
	     y, idx);
#endif

  return idx;
}




void
reflect_xy_Delta2spline (double *x, double *y, D2SPLINE * spline)
{
  double h;
  int control = spline->control;
  double reflectX = spline->reflectX;
  double reflectY = spline->reflectY;


  if (control == 3 || control == 4)
    *x = reflectX - *x;
  if (control == 5 || control == 6)
    {
      h = *y;
      *y = *x;
      *x = h;
    }
  if (control == 7 || control == 8)
    {
      h = *y;
      *y = reflectY - *x;
      *x = h;

    }

}






/***********************************************************************/
/*                             C2 method                               */
/***********************************************************************/

/* de Casteljau algorithm for the evaluation  of
a polynomial of degree six at the point (r,s,t)
*/

static double
deCast6 (double r, double s, double t, double *tri)
{
  double b5[21], b4[15], b3[10], b2[6], b1[3], d;

  b5[0] = r * tri[0] + s * tri[1] + t * tri[7];
  b5[1] = r * tri[1] + s * tri[2] + t * tri[8];
  b5[2] = r * tri[2] + s * tri[3] + t * tri[9];
  b5[3] = r * tri[3] + s * tri[4] + t * tri[10];
  b5[4] = r * tri[4] + s * tri[5] + t * tri[11];
  b5[5] = r * tri[5] + s * tri[6] + t * tri[12];

  b5[6] = r * tri[7] + s * tri[8] + t * tri[13];
  b5[7] = r * tri[8] + s * tri[9] + t * tri[14];
  b5[8] = r * tri[9] + s * tri[10] + t * tri[15];
  b5[9] = r * tri[10] + s * tri[11] + t * tri[16];
  b5[10] = r * tri[11] + s * tri[12] + t * tri[17];

  b5[11] = r * tri[13] + s * tri[14] + t * tri[18];
  b5[12] = r * tri[14] + s * tri[15] + t * tri[19];
  b5[13] = r * tri[15] + s * tri[16] + t * tri[20];
  b5[14] = r * tri[16] + s * tri[17] + t * tri[21];

  b5[15] = r * tri[18] + s * tri[19] + t * tri[22];
  b5[16] = r * tri[19] + s * tri[20] + t * tri[23];
  b5[17] = r * tri[20] + s * tri[21] + t * tri[24];

  b5[18] = r * tri[22] + s * tri[23] + t * tri[25];
  b5[19] = r * tri[23] + s * tri[24] + t * tri[26];

  b5[20] = r * tri[25] + s * tri[26] + t * tri[27];




  b4[0] = r * b5[0] + s * b5[1] + t * b5[6];
  b4[1] = r * b5[1] + s * b5[2] + t * b5[7];
  b4[2] = r * b5[2] + s * b5[3] + t * b5[8];
  b4[3] = r * b5[3] + s * b5[4] + t * b5[9];
  b4[4] = r * b5[4] + s * b5[5] + t * b5[10];

  b4[5] = r * b5[6] + s * b5[7] + t * b5[11];
  b4[6] = r * b5[7] + s * b5[8] + t * b5[12];
  b4[7] = r * b5[8] + s * b5[9] + t * b5[13];
  b4[8] = r * b5[9] + s * b5[10] + t * b5[14];

  b4[9] = r * b5[11] + s * b5[12] + t * b5[15];
  b4[10] = r * b5[12] + s * b5[13] + t * b5[16];
  b4[11] = r * b5[13] + s * b5[14] + t * b5[17];

  b4[12] = r * b5[15] + s * b5[16] + t * b5[18];
  b4[13] = r * b5[16] + s * b5[17] + t * b5[19];

  b4[14] = r * b5[18] + s * b5[19] + t * b5[20];


  b3[0] = r * b4[0] + s * b4[1] + t * b4[5];
  b3[1] = r * b4[1] + s * b4[2] + t * b4[6];
  b3[2] = r * b4[2] + s * b4[3] + t * b4[7];
  b3[3] = r * b4[3] + s * b4[4] + t * b4[8];

  b3[4] = r * b4[5] + s * b4[6] + t * b4[9];
  b3[5] = r * b4[6] + s * b4[7] + t * b4[10];
  b3[6] = r * b4[7] + s * b4[8] + t * b4[11];

  b3[7] = r * b4[9] + s * b4[10] + t * b4[12];
  b3[8] = r * b4[10] + s * b4[11] + t * b4[13];

  b3[9] = r * b4[12] + s * b4[13] + t * b4[14];


  b2[0] = r * b3[0] + s * b3[1] + t * b3[4];
  b2[1] = r * b3[1] + s * b3[2] + t * b3[5];
  b2[2] = r * b3[2] + s * b3[3] + t * b3[6];
  b2[3] = r * b3[4] + s * b3[5] + t * b3[7];
  b2[4] = r * b3[5] + s * b3[6] + t * b3[8];
  b2[5] = r * b3[7] + s * b3[8] + t * b3[9];

  b1[0] = r * b2[0] + s * b2[1] + t * b2[3];
  b1[1] = r * b2[1] + s * b2[2] + t * b2[4];
  b1[2] = r * b2[3] + s * b2[4] + t * b2[5];

  d = r * b1[0] + s * b1[1] + t * b1[2];

  return d;
}

static void
extend2 (D2SPLINE * spline)
{
  int i, j;
  double *base, *coeff;
  double tmp1, tmp2, tmp3, b[10];





  /* duplicate all Bezier points which are already known
     and compute 'ring' of Bezier points around each base tri
   */

  for (j = -1; j <= spline->gridYSize; j++)
    {
      for (i = -1; i <= spline->gridXSize; i++)
	{

	  /*if (abs(i+j) & 0x1)
	     continue; */

	  if ((abs (i + j) & 0x1) & !spline->shift)
	    continue;
	  if (!(abs (i + j) & 0x1) & spline->shift)
	    continue;


	  /* fprintf(stderr, "initial square: %d,%d\n", i,j);  */




	  base = (spline->tri)[getTriIndex_Delta2spline (i, j, spline)];

	  coeff = (spline->tri)[getTriIndex_Delta2spline (i, j, spline) + 1];

	  /* C^0-conditions */


	  coeff[0] = base[6];
	  coeff[7] = base[12];
	  coeff[13] = base[17];
	  coeff[18] = base[21];
	  coeff[22] = base[24];
	  coeff[25] = base[26];
	  coeff[27] = base[27];


	  /* C^1-conditions */

	  coeff[1] = 2.0 * base[12] - base[5];
	  coeff[8] = 2.0 * base[17] - base[11];
	  coeff[14] = 2.0 * base[21] - base[16];
	  coeff[19] = 2.0 * base[24] - base[20];
	  coeff[23] = 2.0 * base[26] - base[23];
	  coeff[26] = 2.0 * base[27] - base[25];


	  /* C^2-conditions */

	  coeff[2] = 4.0 * base[17] - 4.0 * base[11] + base[4];
	  coeff[9] = 4.0 * base[21] - 4.0 * base[16] + base[10];
	  coeff[15] = 4.0 * base[24] - 4.0 * base[20] + base[15];
	  coeff[20] = 4.0 * base[26] - 4.0 * base[23] + base[19];
	  coeff[24] = 4.0 * base[27] - 4.0 * base[25] + base[22];


	  coeff = (spline->tri)[getTriIndex_Delta2spline (i, j, spline) + 3];

	  /* C^0-conditions */


	  coeff[6] = base[0];
	  coeff[12] = base[7];
	  coeff[17] = base[13];
	  coeff[21] = base[18];
	  coeff[24] = base[22];
	  coeff[26] = base[25];
	  coeff[27] = base[27];


	  /* C^1-conditions */

	  coeff[5] = 2.0 * base[7] - base[1];
	  coeff[11] = 2.0 * base[13] - base[8];
	  coeff[16] = 2.0 * base[18] - base[14];
	  coeff[20] = 2.0 * base[22] - base[19];
	  coeff[23] = 2.0 * base[25] - base[23];
	  coeff[25] = 2.0 * base[27] - base[26];


	  /* C^2-conditions */

	  coeff[4] = 4.0 * base[13] - 4.0 * base[8] + base[2];
	  coeff[10] = 4.0 * base[18] - 4.0 * base[14] + base[9];
	  coeff[15] = 4.0 * base[22] - 4.0 * base[19] + base[15];
	  coeff[19] = 4.0 * base[25] - 4.0 * base[23] + base[20];
	  coeff[22] = 4.0 * base[27] - 4.0 * base[26] + base[24];



	  coeff = (spline->tri)[getTriIndex_Delta2spline (i, j, spline) + 2];

	  coeff[27] = base[27];
	  coeff[25] =
	    (spline->tri)[getTriIndex_Delta2spline (i, j, spline) + 1][26];
	  coeff[22] =
	    (spline->tri)[getTriIndex_Delta2spline (i, j, spline) + 1][24];
	  coeff[26] =
	    (spline->tri)[getTriIndex_Delta2spline (i, j, spline) + 3][25];
	  coeff[24] =
	    (spline->tri)[getTriIndex_Delta2spline (i, j, spline) + 3][22];

	  coeff[23] =
	    2.0 * (spline->tri)[getTriIndex_Delta2spline (i, j, spline) +
				1][26] -
	    (spline->tri)[getTriIndex_Delta2spline (i, j, spline) + 1][23];
	  coeff[19] =
	    2.0 * (spline->tri)[getTriIndex_Delta2spline (i, j, spline) +
				1][24] -
	    (spline->tri)[getTriIndex_Delta2spline (i, j, spline) + 1][20];
	  coeff[20] =
	    2.0 * (spline->tri)[getTriIndex_Delta2spline (i, j, spline) +
				3][22] -
	    (spline->tri)[getTriIndex_Delta2spline (i, j, spline) + 3][19];
	  coeff[15] =
	    4.0 * (spline->tri)[getTriIndex_Delta2spline (i, j, spline) +
				1][24] -
	    4.0 * (spline->tri)[getTriIndex_Delta2spline (i, j, spline) +
				1][20] +
	    (spline->tri)[getTriIndex_Delta2spline (i, j, spline) + 1][15];







	  if (i > -1)
	    {
	      coeff =
		(spline->tri)[getTriIndex_Delta2spline (i - 1, j, spline) +
			      2];

	      coeff[0] = base[6];
	      coeff[1] = base[5];
	      coeff[2] = base[4];
	      coeff[3] = base[3];
	      coeff[4] = base[2];
	      coeff[5] = base[1];
	      coeff[6] = base[0];

	      coeff[7] = base[6] + base[5] - base[12];
	      coeff[8] = base[5] + base[4] - base[11];
	      coeff[9] = base[4] + base[3] - base[10];
	      coeff[10] = base[3] + base[2] - base[9];
	      coeff[11] = base[2] + base[1] - base[8];
	      coeff[12] = base[1] + base[0] - base[7];

	      coeff[13] = base[6] + 2.0 * base[5] + base[4]
		- 2.0 * base[12] - 2.0 * base[11] + base[17];
	      coeff[14] = base[5] + 2.0 * base[4] + base[3]
		- 2.0 * base[11] - 2.0 * base[10] + base[16];
	      coeff[15] = base[4] + 2.0 * base[3] + base[2]
		- 2.0 * base[10] - 2.0 * base[9] + base[15];
	      coeff[16] = base[3] + 2.0 * base[2] + base[1]
		- 2.0 * base[9] - 2.0 * base[8] + base[14];
	      coeff[17] = base[2] + 2.0 * base[1] + base[0]
		- 2.0 * base[8] - 2.0 * base[7] + base[13];





	      coeff =
		(spline->tri)[getTriIndex_Delta2spline (i - 1, j, spline) +
			      1];

	      coeff[6] = base[6];

	      coeff[12] =
		(spline->tri)[getTriIndex_Delta2spline (i - 1, j, spline) +
			      2][7];
	      coeff[17] =
		(spline->tri)[getTriIndex_Delta2spline (i - 1, j, spline) +
			      2][13];


	      coeff[5] =
		2.0 * coeff[12] -
		(spline->tri)[getTriIndex_Delta2spline (i - 1, j, spline) +
			      2][1];
	      coeff[11] =
		2.0 * coeff[17] -
		(spline->tri)[getTriIndex_Delta2spline (i - 1, j, spline) +
			      2][8];

	      coeff[4] =
		4.0 * coeff[17] -
		4.0 *
		(spline->tri)[getTriIndex_Delta2spline (i - 1, j, spline) +
			      2][8] +
		(spline->tri)[getTriIndex_Delta2spline (i - 1, j, spline) +
			      2][2];



	      coeff =
		(spline->tri)[getTriIndex_Delta2spline (i - 1, j, spline) +
			      3];


	      coeff[0] = base[0];

	      coeff[7] =
		(spline->tri)[getTriIndex_Delta2spline (i - 1, j, spline) +
			      2][12];
	      coeff[13] =
		(spline->tri)[getTriIndex_Delta2spline (i - 1, j, spline) +
			      2][17];

	      coeff[1] =
		2.0 * coeff[7] -
		(spline->tri)[getTriIndex_Delta2spline (i - 1, j, spline) +
			      2][5];
	      coeff[8] =
		2.0 * coeff[13] -
		(spline->tri)[getTriIndex_Delta2spline (i - 1, j, spline) +
			      2][11];

	      coeff[2] =
		4.0 * coeff[13] -
		4.0 *
		(spline->tri)[getTriIndex_Delta2spline (i - 1, j, spline) +
			      2][11] +
		(spline->tri)[getTriIndex_Delta2spline (i - 1, j, spline) +
			      2][4];





	      if (j > -1)
		{

		  coeff =
		    (spline->
		     tri)[getTriIndex_Delta2spline (i - 1, j - 1,
						    spline) + 1];


		  coeff[6] = base[0];

		  coeff[5] =
		    (spline->
		     tri)[getTriIndex_Delta2spline (i - 1, j, spline) + 3][1];
		  coeff[4] =
		    (spline->
		     tri)[getTriIndex_Delta2spline (i - 1, j, spline) + 3][2];

		  coeff[12] = base[0] +
		    (spline->
		     tri)[getTriIndex_Delta2spline (i - 1, j,
						    spline) + 3][1] -
		    (spline->
		     tri)[getTriIndex_Delta2spline (i - 1, j, spline) + 3][7];
		  coeff[11] =
		    (spline->
		     tri)[getTriIndex_Delta2spline (i - 1, j,
						    spline) + 3][1] +
		    (spline->
		     tri)[getTriIndex_Delta2spline (i - 1, j,
						    spline) + 3][2] -
		    (spline->
		     tri)[getTriIndex_Delta2spline (i - 1, j, spline) + 3][8];

		  coeff[17] = base[0] +
		    2.0 *
		    (spline->
		     tri)[getTriIndex_Delta2spline (i - 1, j,
						    spline) + 3][1] +
		    (spline->
		     tri)[getTriIndex_Delta2spline (i - 1, j,
						    spline) + 3][2] -
		    2.0 *
		    (spline->
		     tri)[getTriIndex_Delta2spline (i - 1, j,
						    spline) + 3][7] -
		    2.0 *
		    (spline->
		     tri)[getTriIndex_Delta2spline (i - 1, j,
						    spline) + 3][8] +
		    (spline->
		     tri)[getTriIndex_Delta2spline (i - 1, j,
						    spline) + 3][13];


		  coeff =
		    (spline->
		     tri)[getTriIndex_Delta2spline (i - 1, j - 1,
						    spline) + 2];


		  coeff[0] = base[0];

		  coeff[7] =
		    (spline->
		     tri)[getTriIndex_Delta2spline (i - 1, j - 1,
						    spline) + 1][12];
		  coeff[13] =
		    (spline->
		     tri)[getTriIndex_Delta2spline (i - 1, j - 1,
						    spline) + 1][17];

		  coeff[1] =
		    2.0 * coeff[7] -
		    (spline->
		     tri)[getTriIndex_Delta2spline (i - 1, j - 1,
						    spline) + 1][5];
		  coeff[8] =
		    2.0 * coeff[13] -
		    (spline->
		     tri)[getTriIndex_Delta2spline (i - 1, j - 1,
						    spline) + 1][11];

		  coeff[2] = 4.0 * coeff[13] -
		    4.0 *
		    (spline->
		     tri)[getTriIndex_Delta2spline (i - 1, j - 1,
						    spline) + 1][11] +
		    (spline->
		     tri)[getTriIndex_Delta2spline (i - 1, j - 1,
						    spline) + 1][4];


		}

	      if (j < spline->gridYSize)
		{

		  coeff =
		    (spline->
		     tri)[getTriIndex_Delta2spline (i - 1, j + 1,
						    spline) + 3];

		  coeff[0] = base[6];

		  coeff[1] =
		    (spline->
		     tri)[getTriIndex_Delta2spline (i - 1, j, spline) + 1][5];
		  coeff[2] =
		    (spline->
		     tri)[getTriIndex_Delta2spline (i - 1, j, spline) + 1][4];

		  coeff[7] = base[6] + coeff[1] -
		    (spline->
		     tri)[getTriIndex_Delta2spline (i - 1, j,
						    spline) + 1][12];
		  coeff[8] =
		    coeff[1] + coeff[2] -
		    (spline->
		     tri)[getTriIndex_Delta2spline (i - 1, j,
						    spline) + 1][11];

		  coeff[13] = base[6] +
		    2.0 * coeff[1] +
		    coeff[2] -
		    2.0 *
		    (spline->
		     tri)[getTriIndex_Delta2spline (i - 1, j,
						    spline) + 1][12] -
		    2.0 *
		    (spline->
		     tri)[getTriIndex_Delta2spline (i - 1, j,
						    spline) + 1][11] +
		    (spline->
		     tri)[getTriIndex_Delta2spline (i - 1, j,
						    spline) + 1][17];


		  coeff =
		    (spline->
		     tri)[getTriIndex_Delta2spline (i - 1, j + 1,
						    spline) + 2];

		  coeff[6] = base[6];

		  coeff[12] =
		    (spline->
		     tri)[getTriIndex_Delta2spline (i - 1, j + 1,
						    spline) + 3][7];
		  coeff[17] =
		    (spline->
		     tri)[getTriIndex_Delta2spline (i - 1, j + 1,
						    spline) + 3][13];

		  coeff[5] =
		    2.0 * coeff[12] -
		    (spline->
		     tri)[getTriIndex_Delta2spline (i - 1, j + 1,
						    spline) + 3][1];
		  coeff[11] =
		    2.0 * coeff[17] -
		    (spline->
		     tri)[getTriIndex_Delta2spline (i - 1, j + 1,
						    spline) + 3][8];

		  coeff[4] = 4.0 * coeff[17] -
		    4.0 *
		    (spline->
		     tri)[getTriIndex_Delta2spline (i - 1, j + 1,
						    spline) + 3][8] +
		    (spline->
		     tri)[getTriIndex_Delta2spline (i - 1, j + 1,
						    spline) + 3][2];

		}
	    }

	  if (j > -1)
	    {



	      coeff =
		(spline->tri)[getTriIndex_Delta2spline (i, j - 1, spline) +
			      1];

	      coeff[0] = base[0];

	      coeff[1] =
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline) + 3][5];
	      coeff[2] =
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline) + 3][4];

	      coeff[7] = base[0] + coeff[1] -
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline) +
			      3][12];
	      coeff[8] =
		coeff[1] + coeff[2] -
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline) +
			      3][11];

	      coeff[13] = base[0] +
		2.0 * coeff[1] +
		coeff[2] -
		2.0 * (spline->tri)[getTriIndex_Delta2spline (i, j, spline) +
				    3][12] -
		2.0 * (spline->tri)[getTriIndex_Delta2spline (i, j, spline) +
				    3][11] +
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline) +
			      3][17];



	      coeff =
		(spline->tri)[getTriIndex_Delta2spline (i, j - 1, spline)];

	      coeff[6] = base[0];

	      coeff[12] =
		(spline->tri)[getTriIndex_Delta2spline (i, j - 1, spline) +
			      1][7];
	      coeff[17] =
		(spline->tri)[getTriIndex_Delta2spline (i, j - 1, spline) +
			      1][13];

	      coeff[5] =
		2.0 * coeff[12] -
		(spline->tri)[getTriIndex_Delta2spline (i, j - 1, spline) +
			      1][1];
	      coeff[11] =
		2.0 * coeff[17] -
		(spline->tri)[getTriIndex_Delta2spline (i, j - 1, spline) +
			      1][8];

	      coeff[4] = 4.0 * coeff[17] -
		4.0 *
		(spline->tri)[getTriIndex_Delta2spline (i, j - 1, spline) +
			      1][8] +
		(spline->tri)[getTriIndex_Delta2spline (i, j - 1, spline) +
			      1][2];

	    }

	  if (j < spline->gridYSize)
	    {



	      coeff =
		(spline->tri)[getTriIndex_Delta2spline (i, j + 1, spline) +
			      3];

	      coeff[6] = base[6];

	      coeff[5] =
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline) + 1][1];
	      coeff[4] =
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline) + 1][2];

	      coeff[12] = base[6] + coeff[5] -
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline) + 1][7];
	      coeff[11] = coeff[5] + coeff[4] -
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline) + 1][8];

	      coeff[17] = base[6] +
		2.0 * coeff[5] +
		coeff[4] -
		2.0 * (spline->tri)[getTriIndex_Delta2spline (i, j, spline) +
				    1][7] -
		2.0 * (spline->tri)[getTriIndex_Delta2spline (i, j, spline) +
				    1][8] +
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline) +
			      1][13];



	      coeff =
		(spline->tri)[getTriIndex_Delta2spline (i, j + 1, spline)];

	      coeff[0] = base[6];

	      coeff[7] =
		(spline->tri)[getTriIndex_Delta2spline (i, j + 1, spline) +
			      3][12];
	      coeff[13] =
		(spline->tri)[getTriIndex_Delta2spline (i, j + 1, spline) +
			      3][17];

	      coeff[1] =
		2.0 * coeff[7] -
		(spline->tri)[getTriIndex_Delta2spline (i, j + 1, spline) +
			      3][5];
	      coeff[8] =
		2.0 * coeff[13] -
		(spline->tri)[getTriIndex_Delta2spline (i, j + 1, spline) +
			      3][11];

	      coeff[2] = 4.0 * coeff[13] -
		4.0 *
		(spline->tri)[getTriIndex_Delta2spline (i, j + 1, spline) +
			      3][11] +
		(spline->tri)[getTriIndex_Delta2spline (i, j + 1, spline) +
			      3][4];

	    }

	  
	}
    }

  /* by the method, we assume that the degree is five on five 
     edges of the square with index (i,j), this is done next,
     at the boundary we assume a C3 property instead */


  for (j = -1; j <= spline->gridYSize; j++)
    {
      for (i = -1; i <= spline->gridXSize; i++)
	{



	  if ((abs (i + j) & 0x1) & !spline->shift)
	    continue;
	  if (!(abs (i + j) & 0x1) & spline->shift)
	    continue;


	  if ((i < spline->gridXSize) && (j < spline->gridYSize))
	    {

	      coeff =
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline) + 1];

	      if (spline->super)
		{

		  coeff[3] =
		    8.0 *
		    (spline->
		     tri)[getTriIndex_Delta2spline (i, j,
						    spline)][21] -
		    12.0 *
		    (spline->
		     tri)[getTriIndex_Delta2spline (i, j,
						    spline)][16] +
		    6.0 *
		    (spline->
		     tri)[getTriIndex_Delta2spline (i, j,
						    spline)][10] -
		    (spline->tri)[getTriIndex_Delta2spline (i, j, spline)][3];

		  tmp1 = coeff[3];

		  coeff[21] =
		    8.0 *
		    (spline->
		     tri)[getTriIndex_Delta2spline (i, j,
						    spline)][27] -
		    12.0 *
		    (spline->
		     tri)[getTriIndex_Delta2spline (i, j,
						    spline)][25] +
		    6.0 *
		    (spline->
		     tri)[getTriIndex_Delta2spline (i, j,
						    spline)][22] -
		    (spline->
		     tri)[getTriIndex_Delta2spline (i, j, spline)][18];

		  tmp2 = coeff[21];

		}
	      else
		{


		  coeff[3] = (coeff[0] - 6.0 * coeff[1] + 15.0 * coeff[2] +
			      15.0 * coeff[4] - 6.0 * coeff[5] +
			      coeff[6]) / 20.0;

		  tmp1 = coeff[3];

		  coeff[21] =
		    (coeff[27] - 6.0 * coeff[26] + 15.0 * coeff[24] +
		     15.0 * coeff[17] - 6.0 * coeff[12] + coeff[6]) / 20.0;

		  tmp2 = coeff[21];

		}

	    }

	  else
	    {

	      /* at the boundary, we determine the middle coefficients
	         by some C3-smoothness condition */


	      coeff =
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline) + 1];

	      coeff[3] =
		8.0 *
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline)][21] -
		12.0 *
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline)][16] +
		6.0 *
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline)][10] -
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline)][3];

	      tmp1 = coeff[3];

	      coeff[21] =
		8.0 *
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline)][27] -
		12.0 *
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline)][25] +
		6.0 *
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline)][22] -
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline)][18];

	      tmp2 = coeff[21];

	    }

	  if (j < spline->gridYSize)
	    {
	      coeff =
		(spline->tri)[getTriIndex_Delta2spline (i, j + 1, spline) +
			      3];
	      coeff[3] = tmp1;
	    }



	  if ((i < spline->gridXSize) && (j > -1))
	    {

	      coeff =
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline) + 3];



	      if (spline->super)
		{

		  coeff[3] =
		    8.0 *
		    (spline->
		     tri)[getTriIndex_Delta2spline (i, j,
						    spline)][18] -
		    12.0 *
		    (spline->
		     tri)[getTriIndex_Delta2spline (i, j,
						    spline)][14] +
		    6.0 *
		    (spline->
		     tri)[getTriIndex_Delta2spline (i, j,
						    spline)][9] -
		    (spline->tri)[getTriIndex_Delta2spline (i, j, spline)][3];

		  tmp1 = coeff[3];

		  coeff[18] =
		    8.0 *
		    (spline->
		     tri)[getTriIndex_Delta2spline (i, j,
						    spline)][27] -
		    12.0 *
		    (spline->
		     tri)[getTriIndex_Delta2spline (i, j,
						    spline)][26] +
		    6.0 *
		    (spline->
		     tri)[getTriIndex_Delta2spline (i, j,
						    spline)][24] -
		    (spline->
		     tri)[getTriIndex_Delta2spline (i, j, spline)][21];
		  tmp3 = coeff[18];

		}
	      else
		{


		  coeff[3] = (coeff[6] - 6.0 * coeff[5] + 15.0 * coeff[4] +
			      15.0 * coeff[2] - 6.0 * coeff[1] +
			      coeff[0]) / 20.0;

		  tmp1 = coeff[3];


		  coeff[18] = (coeff[0] - 6.0 * coeff[7] + 15.0 * coeff[13] +
			       15.0 * coeff[22] - 6.0 * coeff[25] +
			       coeff[27]) / 20.0;

		  tmp3 = coeff[18];

		}





	    }
	  else
	    {

	      /* at the boundary, we determine the middle coefficients
	         by some C3-smoothness condition */


	      coeff =
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline) + 3];

	      coeff[3] =
		8.0 *
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline)][18] -
		12.0 *
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline)][14] +
		6.0 *
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline)][9] -
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline)][3];

	      tmp1 = coeff[3];

	      coeff[18] =
		8.0 *
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline)][27] -
		12.0 *
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline)][26] +
		6.0 *
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline)][24] -
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline)][21];
	      tmp3 = coeff[18];
	    }


	  if (j > -1)
	    {
	      coeff =
		(spline->tri)[getTriIndex_Delta2spline (i, j - 1, spline) +
			      1];
	      coeff[3] = tmp1;
	    }

	  coeff = (spline->tri)[getTriIndex_Delta2spline (i, j, spline) + 2];

	  coeff[18] = tmp2;
	  coeff[21] = tmp3;

	  if (i < spline->gridXSize)
	    {
	      if ((j < spline->gridYSize) && (j > -1))
		{
		  if (spline->super)
		    coeff[3] =
		      8.0 *
		      (spline->
		       tri)[getTriIndex_Delta2spline (i + 1, j + 1,
						      spline)][0] -
		      12.0 *
		      (spline->
		       tri)[getTriIndex_Delta2spline (i + 1, j + 1,
						      spline)][1] +
		      6.0 *
		      (spline->
		       tri)[getTriIndex_Delta2spline (i + 1, j + 1,
						      spline)][2] -
		      (spline->
		       tri)[getTriIndex_Delta2spline (i + 1, j + 1,
						      spline)][3];
		  else
		    coeff[3] = (coeff[6] - 6.0 * coeff[5] + 15.0 * coeff[4] +
				15.0 * coeff[2] - 6.0 * coeff[1] +
				coeff[0]) / 20.0;
		}
	      /* at the boundary, we determine the middle coefficients
	         by some C3-smoothness condition */

	      if (j == -1)

		coeff[3] =
		  8.0 *
		  (spline->
		   tri)[getTriIndex_Delta2spline (i + 1, j + 1,
						  spline)][0] -
		  12.0 *
		  (spline->
		   tri)[getTriIndex_Delta2spline (i + 1, j + 1,
						  spline)][1] +
		  6.0 *
		  (spline->
		   tri)[getTriIndex_Delta2spline (i + 1, j + 1,
						  spline)][2] -
		  (spline->
		   tri)[getTriIndex_Delta2spline (i + 1, j + 1, spline)][3];


	      if (j == spline->gridYSize)

		coeff[3] =
		  8.0 *
		  (spline->
		   tri)[getTriIndex_Delta2spline (i + 1, j - 1,
						  spline)][6] -
		  12.0 *
		  (spline->
		   tri)[getTriIndex_Delta2spline (i + 1, j - 1,
						  spline)][5] +
		  6.0 *
		  (spline->
		   tri)[getTriIndex_Delta2spline (i + 1, j - 1,
						  spline)][4] -
		  (spline->
		   tri)[getTriIndex_Delta2spline (i + 1, j - 1, spline)][3];


	      tmp1 = coeff[3];

	      coeff =
		(spline->tri)[getTriIndex_Delta2spline (i + 1, j, spline)];
	      coeff[3] = tmp1;
	    }


	}
    }


/* two additional coefficients are determined now ,this happens
   at the top and at the bottom */


  for (j = 0; j <= spline->gridYSize; j++)
    {
      for (i = -1; i <= spline->gridXSize; i++)
	{


	  if ((abs (i + j) & 0x1) & !spline->shift)
	    continue;
	  if (!(abs (i + j) & 0x1) & spline->shift)
	    continue;

	  coeff =
	    (spline->tri)[getTriIndex_Delta2spline (i, j - 1, spline) + 1];

	  coeff[9] = coeff[2] + coeff[3] -
	    (spline->tri)[getTriIndex_Delta2spline (i, j, spline) + 3][10];

	  coeff[14] = coeff[1] +
	    2.0 * coeff[2] +
	    coeff[3] -
	    2.0 * (spline->tri)[getTriIndex_Delta2spline (i, j, spline) +
				3][11] -
	    2.0 * (spline->tri)[getTriIndex_Delta2spline (i, j, spline) +
				3][10] +
	    (spline->tri)[getTriIndex_Delta2spline (i, j, spline) + 3][16];




	}
    }



  for (j = -1; j < spline->gridYSize; j++)
    {
      for (i = -1; i <= spline->gridXSize; i++)
	{


	  if ((abs (i + j) & 0x1) & !spline->shift)
	    continue;
	  if (!(abs (i + j) & 0x1) & spline->shift)
	    continue;

	  coeff =
	    (spline->tri)[getTriIndex_Delta2spline (i, j + 1, spline) + 3];

	  coeff[10] = coeff[4] + coeff[3] -
	    (spline->tri)[getTriIndex_Delta2spline (i, j, spline) + 1][9];

	  coeff[16] = coeff[5] +
	    2.0 * coeff[4] +
	    coeff[3] -
	    2.0 * (spline->tri)[getTriIndex_Delta2spline (i, j, spline) +
				1][8] -
	    2.0 * (spline->tri)[getTriIndex_Delta2spline (i, j, spline) +
				1][9] +
	    (spline->tri)[getTriIndex_Delta2spline (i, j, spline) + 1][14];




	}
    }


  /* Now we determine the remaining coefficients on the c3-rings
     by defining them as the solution of the linear system,
     again, we do this at the bottom and at the top */



  for (j = 0; j <= spline->gridYSize; j++)
    {
      for (i = 0; i <= spline->gridXSize; i++)
	{


	  if ((abs (i + j) & 0x1) & !spline->shift)
	    continue;
	  if (!(abs (i + j) & 0x1) & spline->shift)
	    continue;


	  b[0] =
	    (spline->tri)[getTriIndex_Delta2spline (i - 1, j, spline) +
			  2][16];
	  b[1] =
	    (spline->tri)[getTriIndex_Delta2spline (i - 1, j, spline) +
			  2][10];
	  b[2] =
	    (spline->tri)[getTriIndex_Delta2spline (i - 1, j, spline) +
			  3][3] + (spline->tri)[getTriIndex_Delta2spline (i -
									  1,
									  j,
									  spline)
						+ 3][2];
	  b[3] =
	    -2.0 * (spline->tri)[getTriIndex_Delta2spline (i - 1, j, spline) +
				 3][8] +
	    (spline->tri)[getTriIndex_Delta2spline (i - 1, j, spline) +
			  3][3] +
	    2.0 * (spline->tri)[getTriIndex_Delta2spline (i - 1, j, spline) +
				3][2] +
	    (spline->tri)[getTriIndex_Delta2spline (i - 1, j, spline) + 3][1];
	  b[4] =
	    2.0 *
	    (spline->tri)[getTriIndex_Delta2spline (i - 1, j - 1, spline) +
			  2][18];
	  b[5] =
	    4.0 *
	    (spline->tri)[getTriIndex_Delta2spline (i - 1, j - 1, spline) +
			  2][18];
	  b[6] =
	    (spline->tri)[getTriIndex_Delta2spline (i, j - 1, spline)][3] +
	    (spline->tri)[getTriIndex_Delta2spline (i, j - 1, spline)][4];
	  b[7] =
	    -2.0 *
	    (spline->tri)[getTriIndex_Delta2spline (i - 1, j - 1, spline) +
			  2][8] + (spline->tri)[getTriIndex_Delta2spline (i -
									  1,
									  j -
									  1,
									  spline)
						+ 2][3] +
	    2.0 *
	    (spline->tri)[getTriIndex_Delta2spline (i - 1, j - 1, spline) +
			  2][2] + (spline->tri)[getTriIndex_Delta2spline (i -
									  1,
									  j -
									  1,
									  spline)
						+ 2][1];
	  b[8] =
	    (spline->tri)[getTriIndex_Delta2spline (i, j - 1, spline) +
			  1][14];
	  b[9] =
	    (spline->tri)[getTriIndex_Delta2spline (i, j - 1, spline) + 1][9];


	  (spline->tri)[getTriIndex_Delta2spline (i - 1, j, spline) + 2][21] =
	    (58.0 * b[0] -
	     17.0 * b[1] -
	     3.0 * b[2] +
	     10.0 * b[3] +
	     2.0 * b[4] -
	     3.0 * b[5] - b[6] + 2.0 * b[7] - 2.0 * b[8] + b[9]) / 48.0;


	  (spline->tri)[getTriIndex_Delta2spline (i - 1, j, spline) + 3][18] =
	    (spline->tri)[getTriIndex_Delta2spline (i - 1, j, spline) +
			  2][21];


	  (spline->tri)[getTriIndex_Delta2spline (i - 1, j, spline) + 3][14] =
	    (68.0 * b[0] -
	     34.0 * b[1] -
	     6.0 * b[2] +
	     20.0 * b[3] +
	     4.0 * b[4] -
	     6.0 * b[5] -
	     2.0 * b[6] + 4.0 * b[7] - 4.0 * b[8] + 2.0 * b[9]) / 48.0;

	  (spline->tri)[getTriIndex_Delta2spline (i - 1, j, spline) + 3][9] =
	    (40.0 * b[0] -
	     20.0 * b[1] -
	     12.0 * b[2] +
	     40.0 * b[3] +
	     8.0 * b[4] -
	     12.0 * b[5] -
	     4.0 * b[6] + 8.0 * b[7] - 8.0 * b[8] + 4.0 * b[9]) / 48.0;

	  (spline->tri)[getTriIndex_Delta2spline (i - 1, j - 1, spline) +
			1][10] =
	    ((-40.0) * b[0] + 20.0 * b[1] + 60.0 * b[2] - 40.0 * b[3] -
	     8.0 * b[4] + 12.0 * b[5] + 4.0 * b[6] - 8.0 * b[7] + 8.0 * b[8] -
	     4.0 * b[9]) / 48.0;

	  (spline->tri)[getTriIndex_Delta2spline (i - 1, j - 1, spline) +
			1][16] =
	    ((-12.0) * b[0] + 6.0 * b[1] + 18.0 * b[2] - 12.0 * b[3] -
	     12.0 * b[4] + 18.0 * b[5] + 6.0 * b[6] - 12.0 * b[7] +
	     12.0 * b[8] - 6.0 * b[9]) / 48.0;


	  (spline->tri)[getTriIndex_Delta2spline (i - 1, j - 1, spline) +
			2][14] =
	    (12.0 * b[0] - 6.0 * b[1] - 18.0 * b[2] + 12.0 * b[3] +
	     60.0 * b[4] - 18.0 * b[5] - 6.0 * b[6] + 12.0 * b[7] -
	     12.0 * b[8] + 6.0 * b[9]) / 48.0;

	  (spline->tri)[getTriIndex_Delta2spline (i - 1, j - 1, spline) +
			2][9] =
	    (8.0 * b[0] - 4.0 * b[1] - 12.0 * b[2] + 8.0 * b[3] +
	     40.0 * b[4] - 12.0 * b[5] - 20.0 * b[6] + 40.0 * b[7] -
	     40.0 * b[8] + 20.0 * b[9]) / 48.0;


	  (spline->tri)[getTriIndex_Delta2spline (i, j - 1, spline)][10] =
	    ((-8.0) * b[0] +
	     4.0 * b[1] +
	     12.0 * b[2] -
	     8.0 * b[3] -
	     40.0 * b[4] +
	     12.0 * b[5] +
	     68.0 * b[6] - 40.0 * b[7] + 40.0 * b[8] - 20.0 * b[9]) / 48.0;

	  (spline->tri)[getTriIndex_Delta2spline (i, j - 1, spline)][16] =
	    ((-4.0) * b[0] +
	     2.0 * b[1] +
	     6.0 * b[2] -
	     4.0 * b[3] -
	     20.0 * b[4] +
	     6.0 * b[5] +
	     34.0 * b[6] - 20.0 * b[7] + 68.0 * b[8] - 34.0 * b[9]) / 48.0;

	  (spline->tri)[getTriIndex_Delta2spline (i, j - 1, spline)][21] =
	    ((-2.0) * b[0] +
	     b[1] +
	     3.0 * b[2] -
	     2.0 * b[3] -
	     10.0 * b[4] +
	     3.0 * b[5] +
	     17.0 * b[6] - 10.0 * b[7] + 58.0 * b[8] - 17.0 * b[9]) / 48.0;


	  (spline->tri)[getTriIndex_Delta2spline (i, j - 1, spline) + 1][18] =
	    (spline->tri)[getTriIndex_Delta2spline (i, j - 1, spline)][21];
	}
    }





  for (j = -1; j < spline->gridYSize; j++)
    {
      for (i = 0; i <= spline->gridXSize; i++)
	{



	  if ((abs (i + j) & 0x1) & !spline->shift)
	    continue;
	  if (!(abs (i + j) & 0x1) & spline->shift)
	    continue;


	  b[0] =
	    (spline->tri)[getTriIndex_Delta2spline (i - 1, j, spline) +
			  2][14];
	  b[1] =
	    (spline->tri)[getTriIndex_Delta2spline (i - 1, j, spline) + 2][9];
	  b[2] =
	    (spline->tri)[getTriIndex_Delta2spline (i - 1, j, spline) +
			  1][3] + (spline->tri)[getTriIndex_Delta2spline (i -
									  1,
									  j,
									  spline)
						+ 1][4];
	  b[3] =
	    -2.0 * (spline->tri)[getTriIndex_Delta2spline (i - 1, j, spline) +
				 1][11] +
	    (spline->tri)[getTriIndex_Delta2spline (i - 1, j, spline) +
			  1][3] +
	    2.0 * (spline->tri)[getTriIndex_Delta2spline (i - 1, j, spline) +
				1][4] +
	    (spline->tri)[getTriIndex_Delta2spline (i - 1, j, spline) + 1][5];
	  b[4] =
	    2.0 *
	    (spline->tri)[getTriIndex_Delta2spline (i - 1, j + 1, spline) +
			  2][21];
	  b[5] =
	    4.0 *
	    (spline->tri)[getTriIndex_Delta2spline (i - 1, j + 1, spline) +
			  2][21];
	  b[6] =
	    (spline->tri)[getTriIndex_Delta2spline (i, j + 1, spline)][2] +
	    (spline->tri)[getTriIndex_Delta2spline (i, j + 1, spline)][3];
	  b[7] =
	    -2.0 *
	    (spline->tri)[getTriIndex_Delta2spline (i - 1, j + 1, spline) +
			  2][11] + (spline->tri)[getTriIndex_Delta2spline (i -
									   1,
									   j +
									   1,
									   spline)
						 + 2][5] +
	    2.0 *
	    (spline->tri)[getTriIndex_Delta2spline (i - 1, j + 1, spline) +
			  2][4] + (spline->tri)[getTriIndex_Delta2spline (i -
									  1,
									  j +
									  1,
									  spline)
						+ 2][3];
	  b[8] =
	    (spline->tri)[getTriIndex_Delta2spline (i, j + 1, spline) +
			  3][16];
	  b[9] =
	    (spline->tri)[getTriIndex_Delta2spline (i, j + 1, spline) +
			  3][10];


	  (spline->tri)[getTriIndex_Delta2spline (i - 1, j, spline) + 2][18] =
	    (58.0 * b[0] -
	     17.0 * b[1] -
	     3.0 * b[2] +
	     10.0 * b[3] +
	     2.0 * b[4] -
	     3.0 * b[5] - b[6] + 2.0 * b[7] - 2.0 * b[8] + b[9]) / 48.0;


	  (spline->tri)[getTriIndex_Delta2spline (i - 1, j, spline) + 1][21] =
	    (spline->tri)[getTriIndex_Delta2spline (i - 1, j, spline) +
			  2][18];


	  (spline->tri)[getTriIndex_Delta2spline (i - 1, j, spline) + 1][16] =
	    (68.0 * b[0] -
	     34.0 * b[1] -
	     6.0 * b[2] +
	     20.0 * b[3] +
	     4.0 * b[4] -
	     6.0 * b[5] -
	     2.0 * b[6] + 4.0 * b[7] - 4.0 * b[8] + 2.0 * b[9]) / 48.0;

	  (spline->tri)[getTriIndex_Delta2spline (i - 1, j, spline) + 1][10] =
	    (40.0 * b[0] -
	     20.0 * b[1] -
	     12.0 * b[2] +
	     40.0 * b[3] +
	     8.0 * b[4] -
	     12.0 * b[5] -
	     4.0 * b[6] + 8.0 * b[7] - 8.0 * b[8] + 4.0 * b[9]) / 48.0;

	  (spline->tri)[getTriIndex_Delta2spline (i - 1, j + 1, spline) +
			3][9] =
	    ((-40.0) * b[0] + 20.0 * b[1] + 60.0 * b[2] - 40.0 * b[3] -
	     8.0 * b[4] + 12.0 * b[5] + 4.0 * b[6] - 8.0 * b[7] + 8.0 * b[8] -
	     4.0 * b[9]) / 48.0;

	  (spline->tri)[getTriIndex_Delta2spline (i - 1, j + 1, spline) +
			3][14] =
	    ((-12.0) * b[0] + 6.0 * b[1] + 18.0 * b[2] - 12.0 * b[3] -
	     12.0 * b[4] + 18.0 * b[5] + 6.0 * b[6] - 12.0 * b[7] +
	     12.0 * b[8] - 6.0 * b[9]) / 48.0;


	  (spline->tri)[getTriIndex_Delta2spline (i - 1, j + 1, spline) +
			2][16] =
	    (12.0 * b[0] - 6.0 * b[1] - 18.0 * b[2] + 12.0 * b[3] +
	     60.0 * b[4] - 18.0 * b[5] - 6.0 * b[6] + 12.0 * b[7] -
	     12.0 * b[8] + 6.0 * b[9]) / 48.0;

	  (spline->tri)[getTriIndex_Delta2spline (i - 1, j + 1, spline) +
			2][10] =
	    (8.0 * b[0] - 4.0 * b[1] - 12.0 * b[2] + 8.0 * b[3] +
	     40.0 * b[4] - 12.0 * b[5] - 20.0 * b[6] + 40.0 * b[7] -
	     40.0 * b[8] + 20.0 * b[9]) / 48.0;


	  (spline->tri)[getTriIndex_Delta2spline (i, j + 1, spline)][9] =
	    ((-8.0) * b[0] +
	     4.0 * b[1] +
	     12.0 * b[2] -
	     8.0 * b[3] -
	     40.0 * b[4] +
	     12.0 * b[5] +
	     68.0 * b[6] - 40.0 * b[7] + 40.0 * b[8] - 20.0 * b[9]) / 48.0;

	  (spline->tri)[getTriIndex_Delta2spline (i, j + 1, spline)][14] =
	    ((-4.0) * b[0] +
	     2.0 * b[1] +
	     6.0 * b[2] -
	     4.0 * b[3] -
	     20.0 * b[4] +
	     6.0 * b[5] +
	     34.0 * b[6] - 20.0 * b[7] + 68.0 * b[8] - 34.0 * b[9]) / 48.0;

	  (spline->tri)[getTriIndex_Delta2spline (i, j + 1, spline)][18] =
	    ((-2.0) * b[0] +
	     b[1] +
	     3.0 * b[2] -
	     2.0 * b[3] -
	     10.0 * b[4] +
	     3.0 * b[5] +
	     17.0 * b[6] - 10.0 * b[7] + 58.0 * b[8] - 17.0 * b[9]) / 48.0;


	  (spline->tri)[getTriIndex_Delta2spline (i, j + 1, spline) + 3][21] =
	    (spline->tri)[getTriIndex_Delta2spline (i, j + 1, spline)][18];
	}
    }

  /* now loop over all remaining cells (without border cells) */

  for (j = -1; j <= spline->gridYSize; j++)
    {
      for (i = -1; i <= spline->gridXSize; i++)
	{


	  if (!(abs (i + j) & 0x1) & !spline->shift)
	    continue;
	  if ((abs (i + j) & 0x1) & spline->shift)
	    continue;

	  /* we have 3 C2 conditions across horizontal and
	     vertical lines */



	  if (i > -1)
	    {


	      coeff = (spline->tri)[getTriIndex_Delta2spline (i, j, spline)];

	      /*  if (i>0){ */


	      coeff[15] = coeff[2] + 2.0 * coeff[3] + coeff[4] -
		2.0 *
		(spline->tri)[getTriIndex_Delta2spline (i - 1, j, spline) +
			      2][10] -
		2.0 *
		(spline->tri)[getTriIndex_Delta2spline (i - 1, j, spline) +
			      2][9] +
		(spline->tri)[getTriIndex_Delta2spline (i - 1, j, spline) +
			      2][15];
	      /*   }

	         else{ */

	      /* in the first column we determine this
	         coefficient by degree raising, since we 
	         do not trust in information of a least squares 
	         at the boundary lieing far away */
	      /*

	         coeff[15] =(4.0*coeff[16]+4.0*coeff[14]-
	         coeff[17]-coeff[13])/6.0;

	         }
	       */
	    }
	  if (j < spline->gridYSize)
	    {
	      coeff =
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline) + 1];
	      coeff[15] =
		coeff[2] + 2.0 * coeff[3] + coeff[4] -
		2.0 *
		(spline->tri)[getTriIndex_Delta2spline (i, j + 1, spline) +
			      3][10] -
		2.0 *
		(spline->tri)[getTriIndex_Delta2spline (i, j + 1, spline) +
			      3][9] +
		(spline->tri)[getTriIndex_Delta2spline (i, j + 1, spline) +
			      3][15];
	    }
	  if (j > -1)
	    {
	      coeff =
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline) + 3];
	      coeff[15] =
		coeff[2] + 2.0 * coeff[3] + coeff[4] -
		2.0 *
		(spline->tri)[getTriIndex_Delta2spline (i, j - 1, spline) +
			      1][10] -
		2.0 *
		(spline->tri)[getTriIndex_Delta2spline (i, j - 1, spline) +
			      1][9] +
		(spline->tri)[getTriIndex_Delta2spline (i, j - 1, spline) +
			      1][15];
	    }

	  /* we use 5 c3 supersmoothness conditions at the
	     singular vertex for the interior remaining squares */


	  if ((i > -1) && (i < spline->gridXSize) && (j > -1)
	      && (j < spline->gridYSize))
	    {

	      b[0] = 0.0;
	      b[1] =
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline) +
			      1][15] -
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline)][15];
	      b[2] =
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline) +
			      1][10] -
		6.0 *
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline)][15] +
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline)][9];



	      (spline->tri)[getTriIndex_Delta2spline (i, j, spline) + 1][19] =
		((-4.0) * b[0] + 4.0 * b[1] - b[2]) / 4.0;

	      (spline->tri)[getTriIndex_Delta2spline (i, j, spline) + 1][22] =
		(3.0 * b[1] - b[2]) / 4.0;

	      (spline->tri)[getTriIndex_Delta2spline (i, j, spline)][24] =
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline) +
			      1][22];

	      (spline->tri)[getTriIndex_Delta2spline (i, j, spline)][20] =
		(2.0 * b[1] - b[2]) / 4.0;





	      b[0] = 0.0;
	      b[1] =
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline) +
			      1][15] -
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline) +
			      2][15];
	      b[2] =
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline) +
			      1][9] -
		6.0 * (spline->tri)[getTriIndex_Delta2spline (i, j, spline) +
				    2][15] +
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline) +
			      2][10];



	      (spline->tri)[getTriIndex_Delta2spline (i, j, spline) + 1][20] =
		((-4.0) * b[0] + 4.0 * b[1] - b[2]) / 4.0;

	      (spline->tri)[getTriIndex_Delta2spline (i, j, spline) + 1][24] =
		(3.0 * b[1] - b[2]) / 4.0;

	      (spline->tri)[getTriIndex_Delta2spline (i, j, spline) + 2][22] =
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline) +
			      1][24];

	      (spline->tri)[getTriIndex_Delta2spline (i, j, spline) + 2][19] =
		(2.0 * b[1] - b[2]) / 4.0;



	      b[0] = 0.0;
	      b[1] =
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline) +
			      2][15] -
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline) +
			      3][15];
	      b[2] =
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline) +
			      2][9] -
		6.0 * (spline->tri)[getTriIndex_Delta2spline (i, j, spline) +
				    3][15] +
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline) +
			      3][10];



	      (spline->tri)[getTriIndex_Delta2spline (i, j, spline) + 2][20] =
		((-4.0) * b[0] + 4.0 * b[1] - b[2]) / 4.0;

	      (spline->tri)[getTriIndex_Delta2spline (i, j, spline) + 2][24] =
		(3.0 * b[1] - b[2]) / 4.0;

	      (spline->tri)[getTriIndex_Delta2spline (i, j, spline) + 3][22] =
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline) +
			      2][24];

	      (spline->tri)[getTriIndex_Delta2spline (i, j, spline) + 3][19] =
		(2.0 * b[1] - b[2]) / 4.0;



	      b[0] = 0.0;
	      b[1] =
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline)][15] -
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline) +
			      3][15];
	      b[2] =
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline)][10] -
		6.0 * (spline->tri)[getTriIndex_Delta2spline (i, j, spline) +
				    3][15] +
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline) + 3][9];



	      (spline->tri)[getTriIndex_Delta2spline (i, j, spline)][19] =
		((-4.0) * b[0] + 4.0 * b[1] - b[2]) / 4.0;

	      (spline->tri)[getTriIndex_Delta2spline (i, j, spline)][22] =
		(3.0 * b[1] - b[2]) / 4.0;

	      (spline->tri)[getTriIndex_Delta2spline (i, j, spline) + 3][24] =
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline)][22];

	      (spline->tri)[getTriIndex_Delta2spline (i, j, spline) + 3][20] =
		(2.0 * b[1] - b[2]) / 4.0;



	      b[0] = 0.0;
	      b[1] =
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline) +
			      1][24] -
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline)][22];
	      b[2] =
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline) +
			      1][21] -
		6.0 *
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline)][22] +
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline)][18];



	      (spline->tri)[getTriIndex_Delta2spline (i, j, spline) + 1][26] =
		((-4.0) * b[0] + 4.0 * b[1] - b[2]) / 4.0;

	      (spline->tri)[getTriIndex_Delta2spline (i, j, spline) + 2][25] =
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline) +
			      1][26];


	      (spline->tri)[getTriIndex_Delta2spline (i, j, spline) + 1][27] =
		(3.0 * b[1] - b[2]) / 4.0;

	      (spline->tri)[getTriIndex_Delta2spline (i, j, spline)][27] =
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline) +
			      1][27];

	      (spline->tri)[getTriIndex_Delta2spline (i, j, spline) + 2][27] =
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline) +
			      1][27];

	      (spline->tri)[getTriIndex_Delta2spline (i, j, spline) + 3][27] =
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline) +
			      1][27];


	      (spline->tri)[getTriIndex_Delta2spline (i, j, spline)][25] =
		(2.0 * b[1] - b[2]) / 4.0;

	      (spline->tri)[getTriIndex_Delta2spline (i, j, spline) + 3][26] =
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline)][25];


	      /* we finally use 3 C2-conditions at the singular 
	         vertex */


	      (spline->tri)[getTriIndex_Delta2spline (i, j, spline) + 2][26] =
		(4.0 *
		 (spline->tri)[getTriIndex_Delta2spline (i, j, spline) +
			       2][27] -
		 (spline->tri)[getTriIndex_Delta2spline (i, j, spline)][24] +
		 (spline->tri)[getTriIndex_Delta2spline (i, j, spline) +
			       2][24]) / 4.0;

	      (spline->tri)[getTriIndex_Delta2spline (i, j, spline) + 3][25] =
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline) +
			      2][26];

	      (spline->tri)[getTriIndex_Delta2spline (i, j, spline)][26] =
		2.0 *
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline)][27] -
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline) +
			      2][26];

	      (spline->tri)[getTriIndex_Delta2spline (i, j, spline) + 1][25] =
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline)][26];




	      (spline->tri)[getTriIndex_Delta2spline (i, j, spline) + 2][23] =
		(4.0 *
		 (spline->tri)[getTriIndex_Delta2spline (i, j, spline) +
			       2][25] -
		 (spline->tri)[getTriIndex_Delta2spline (i, j, spline) +
			       1][19] +
		 (spline->tri)[getTriIndex_Delta2spline (i, j, spline) +
			       2][20]) / 4.0;


	      (spline->tri)[getTriIndex_Delta2spline (i, j, spline) + 1][23] =
		2.0 * (spline->tri)[getTriIndex_Delta2spline (i, j, spline) +
				    1][26] -
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline) +
			      2][23];


	      (spline->tri)[getTriIndex_Delta2spline (i, j, spline) + 3][23] =
		(4.0 *
		 (spline->tri)[getTriIndex_Delta2spline (i, j, spline) +
			       3][26] -
		 (spline->tri)[getTriIndex_Delta2spline (i, j, spline)][20] +
		 (spline->tri)[getTriIndex_Delta2spline (i, j, spline) +
			       3][19]) / 4.0;


	      (spline->tri)[getTriIndex_Delta2spline (i, j, spline)][23] =
		2.0 * (spline->tri)[getTriIndex_Delta2spline (i, j, spline) +
				    3][26] -
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline) +
			      3][23];
	    }
	}
    }


}


static void
add_to_average2 (D2SPLINE * spline)
{
  int i, j, k, l;

  if (spline->control == 1)
    {
      for (i = -1; i <= spline->gridXSize; i++)
	for (j = -1; j <= spline->gridYSize; j++)
	  for (k = 0; k <= 3; k++)
	    for (l = 0; l <= 27; l++)
	      (spline->tri_av)[getTriIndex_Delta2spline (i, j, spline) +
			       k][l] =
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline) + k][l];
    }



  if (spline->control == 2)
    {
      for (i = -1; i <= spline->gridXSize; i++)
	for (j = -1; j <= spline->gridYSize; j++)
	  for (k = 0; k <= 3; k++)
	    for (l = 0; l <= 27; l++)
	      (spline->tri_av)[getTriIndex_Delta2spline (i, j, spline) +
			       k][l] +=
		(spline->tri)[getTriIndex_Delta2spline (i, j, spline) + k][l];
    }


  if (spline->control == 3)
    {
      for (i = -1; i <= spline->gridXSize; i++)
	for (j = -1; j <= spline->gridYSize; j++)
	  {
	    for (l = 0; l <= 6; l++)
	      {
		(spline->
		 tri_av)[getTriIndex_Delta2spline (i, j, spline)][l] +=
	  (spline->
	   tri)[getTriIndex_Delta2spline (spline->gridXSize - i - 1, j,
					  spline) + 2][6 - l];
		(spline->tri_av)[getTriIndex_Delta2spline (i, j, spline) +
				 1][l] +=
		  (spline->
		   tri)[getTriIndex_Delta2spline (spline->gridXSize - i - 1,
						  j, spline) + 1][6 - l];
		(spline->tri_av)[getTriIndex_Delta2spline (i, j, spline) +
				 2][l] +=
		  (spline->
		   tri)[getTriIndex_Delta2spline (spline->gridXSize - i - 1,
						  j, spline)][6 - l];
		(spline->tri_av)[getTriIndex_Delta2spline (i, j, spline) +
				 3][l] +=
		  (spline->
		   tri)[getTriIndex_Delta2spline (spline->gridXSize - i - 1,
						  j, spline) + 3][6 - l];
	      }
	    for (l = 0; l <= 5; l++)
	      {
		(spline->tri_av)[getTriIndex_Delta2spline (i, j, spline)][7 +
									  l]
		  +=
		  (spline->
		   tri)[getTriIndex_Delta2spline (spline->gridXSize - i - 1,
						  j, spline) + 2][12 - l];
		(spline->tri_av)[getTriIndex_Delta2spline (i, j, spline) +
				 1][7 + l] +=
		  (spline->
		   tri)[getTriIndex_Delta2spline (spline->gridXSize - i - 1,
						  j, spline) + 1][12 - l];
		(spline->tri_av)[getTriIndex_Delta2spline (i, j, spline) +
				 2][7 + l] +=
		  (spline->
		   tri)[getTriIndex_Delta2spline (spline->gridXSize - i - 1,
						  j, spline)][12 - l];
		(spline->tri_av)[getTriIndex_Delta2spline (i, j, spline) +
				 3][7 + l] +=
		  (spline->
		   tri)[getTriIndex_Delta2spline (spline->gridXSize - i - 1,
						  j, spline) + 3][12 - l];
	      }
	    for (l = 0; l <= 4; l++)
	      {
		(spline->tri_av)[getTriIndex_Delta2spline (i, j, spline)][13 +
									  l]
		  +=
		  (spline->
		   tri)[getTriIndex_Delta2spline (spline->gridXSize - i - 1,
						  j, spline) + 2][17 - l];
		(spline->tri_av)[getTriIndex_Delta2spline (i, j, spline) +
				 1][13 + l] +=
		  (spline->
		   tri)[getTriIndex_Delta2spline (spline->gridXSize - i - 1,
						  j, spline) + 1][17 - l];
		(spline->tri_av)[getTriIndex_Delta2spline (i, j, spline) +
				 2][13 + l] +=
		  (spline->
		   tri)[getTriIndex_Delta2spline (spline->gridXSize - i - 1,
						  j, spline)][17 - l];
		(spline->tri_av)[getTriIndex_Delta2spline (i, j, spline) +
				 3][13 + l] +=
		  (spline->
		   tri)[getTriIndex_Delta2spline (spline->gridXSize - i - 1,
						  j, spline) + 3][17 - l];
	      }
	    for (l = 0; l <= 3; l++)
	      {
		(spline->tri_av)[getTriIndex_Delta2spline (i, j, spline)][18 +
									  l]
		  +=
		  (spline->
		   tri)[getTriIndex_Delta2spline (spline->gridXSize - i - 1,
						  j, spline) + 2][21 - l];
		(spline->tri_av)[getTriIndex_Delta2spline (i, j, spline) +
				 1][18 + l] +=
		  (spline->
		   tri)[getTriIndex_Delta2spline (spline->gridXSize - i - 1,
						  j, spline) + 1][21 - l];
		(spline->tri_av)[getTriIndex_Delta2spline (i, j, spline) +
				 2][18 + l] +=
		  (spline->
		   tri)[getTriIndex_Delta2spline (spline->gridXSize - i - 1,
						  j, spline)][21 - l];
		(spline->tri_av)[getTriIndex_Delta2spline (i, j, spline) +
				 3][18 + l] +=
		  (spline->
		   tri)[getTriIndex_Delta2spline (spline->gridXSize - i - 1,
						  j, spline) + 3][21 - l];
	      }
	    for (l = 0; l <= 2; l++)
	      {
		(spline->tri_av)[getTriIndex_Delta2spline (i, j, spline)][22 +
									  l]
		  +=
		  (spline->
		   tri)[getTriIndex_Delta2spline (spline->gridXSize - i - 1,
						  j, spline) + 2][24 - l];
		(spline->tri_av)[getTriIndex_Delta2spline (i, j, spline) +
				 1][22 + l] +=
		  (spline->
		   tri)[getTriIndex_Delta2spline (spline->gridXSize - i - 1,
						  j, spline) + 1][24 - l];
		(spline->tri_av)[getTriIndex_Delta2spline (i, j, spline) +
				 2][22 + l] +=
		  (spline->
		   tri)[getTriIndex_Delta2spline (spline->gridXSize - i - 1,
						  j, spline)][24 - l];
		(spline->tri_av)[getTriIndex_Delta2spline (i, j, spline) +
				 3][22 + l] +=
		  (spline->
		   tri)[getTriIndex_Delta2spline (spline->gridXSize - i - 1,
						  j, spline) + 3][24 - l];
	      }
	    for (l = 0; l <= 1; l++)
	      {
		(spline->tri_av)[getTriIndex_Delta2spline (i, j, spline)][25 +
									  l]
		  +=
		  (spline->
		   tri)[getTriIndex_Delta2spline (spline->gridXSize - i - 1,
						  j, spline) + 2][26 - l];
		(spline->tri_av)[getTriIndex_Delta2spline (i, j, spline) +
				 1][25 + l] +=
		  (spline->
		   tri)[getTriIndex_Delta2spline (spline->gridXSize - i - 1,
						  j, spline) + 1][26 - l];
		(spline->tri_av)[getTriIndex_Delta2spline (i, j, spline) +
				 2][25 + l] +=
		  (spline->
		   tri)[getTriIndex_Delta2spline (spline->gridXSize - i - 1,
						  j, spline)][26 - l];
		(spline->tri_av)[getTriIndex_Delta2spline (i, j, spline) +
				 3][25 + l] +=
		  (spline->
		   tri)[getTriIndex_Delta2spline (spline->gridXSize - i - 1,
						  j, spline) + 3][26 - l];
	      }
	    for (k = 0; k <= 3; k++)

	      (spline->tri_av)[getTriIndex_Delta2spline (i, j, spline) +
			       k][27] +=
		(spline->
		 tri)[getTriIndex_Delta2spline (spline->gridXSize - i - 1, j,
						spline) + 2][27];

	  }

    }

  if (spline->control == 4)
    {
      for (i = -1; i <= spline->gridXSize; i++)
	for (j = -1; j <= spline->gridYSize; j++)
	  {
	    for (l = 0; l <= 6; l++)
	      {
		(spline->
		 tri_av)[getTriIndex_Delta2spline (i, j, spline)][l] +=
	  (spline->
	   tri)[getTriIndex_Delta2spline (spline->gridXSize - i - 1, j,
					  spline) + 2][6 - l];
		(spline->tri_av)[getTriIndex_Delta2spline (i, j, spline) +
				 1][l] +=
		  (spline->
		   tri)[getTriIndex_Delta2spline (spline->gridXSize - i - 1,
						  j, spline) + 1][6 - l];
		(spline->tri_av)[getTriIndex_Delta2spline (i, j, spline) +
				 2][l] +=
		  (spline->
		   tri)[getTriIndex_Delta2spline (spline->gridXSize - i - 1,
						  j, spline)][6 - l];
		(spline->tri_av)[getTriIndex_Delta2spline (i, j, spline) +
				 3][l] +=
		  (spline->
		   tri)[getTriIndex_Delta2spline (spline->gridXSize - i - 1,
						  j, spline) + 3][6 - l];
	      }
	    for (l = 0; l <= 5; l++)
	      {
		(spline->tri_av)[getTriIndex_Delta2spline (i, j, spline)][7 +
									  l]
		  +=
		  (spline->
		   tri)[getTriIndex_Delta2spline (spline->gridXSize - i - 1,
						  j, spline) + 2][12 - l];
		(spline->tri_av)[getTriIndex_Delta2spline (i, j, spline) +
				 1][7 + l] +=
		  (spline->
		   tri)[getTriIndex_Delta2spline (spline->gridXSize - i - 1,
						  j, spline) + 1][12 - l];
		(spline->tri_av)[getTriIndex_Delta2spline (i, j, spline) +
				 2][7 + l] +=
		  (spline->
		   tri)[getTriIndex_Delta2spline (spline->gridXSize - i - 1,
						  j, spline)][12 - l];
		(spline->tri_av)[getTriIndex_Delta2spline (i, j, spline) +
				 3][7 + l] +=
		  (spline->
		   tri)[getTriIndex_Delta2spline (spline->gridXSize - i - 1,
						  j, spline) + 3][12 - l];
	      }
	    for (l = 0; l <= 4; l++)
	      {
		(spline->tri_av)[getTriIndex_Delta2spline (i, j, spline)][13 +
									  l]
		  +=
		  (spline->
		   tri)[getTriIndex_Delta2spline (spline->gridXSize - i - 1,
						  j, spline) + 2][17 - l];
		(spline->tri_av)[getTriIndex_Delta2spline (i, j, spline) +
				 1][13 + l] +=
		  (spline->
		   tri)[getTriIndex_Delta2spline (spline->gridXSize - i - 1,
						  j, spline) + 1][17 - l];
		(spline->tri_av)[getTriIndex_Delta2spline (i, j, spline) +
				 2][13 + l] +=
		  (spline->
		   tri)[getTriIndex_Delta2spline (spline->gridXSize - i - 1,
						  j, spline)][17 - l];
		(spline->tri_av)[getTriIndex_Delta2spline (i, j, spline) +
				 3][13 + l] +=
		  (spline->
		   tri)[getTriIndex_Delta2spline (spline->gridXSize - i - 1,
						  j, spline) + 3][17 - l];
	      }
	    for (l = 0; l <= 3; l++)
	      {
		(spline->tri_av)[getTriIndex_Delta2spline (i, j, spline)][18 +
									  l]
		  +=
		  (spline->
		   tri)[getTriIndex_Delta2spline (spline->gridXSize - i - 1,
						  j, spline) + 2][21 - l];
		(spline->tri_av)[getTriIndex_Delta2spline (i, j, spline) +
				 1][18 + l] +=
		  (spline->
		   tri)[getTriIndex_Delta2spline (spline->gridXSize - i - 1,
						  j, spline) + 1][21 - l];
		(spline->tri_av)[getTriIndex_Delta2spline (i, j, spline) +
				 2][18 + l] +=
		  (spline->
		   tri)[getTriIndex_Delta2spline (spline->gridXSize - i - 1,
						  j, spline)][21 - l];
		(spline->tri_av)[getTriIndex_Delta2spline (i, j, spline) +
				 3][18 + l] +=
		  (spline->
		   tri)[getTriIndex_Delta2spline (spline->gridXSize - i - 1,
						  j, spline) + 3][21 - l];
	      }
	    for (l = 0; l <= 2; l++)
	      {
		(spline->tri_av)[getTriIndex_Delta2spline (i, j, spline)][22 +
									  l]
		  +=
		  (spline->
		   tri)[getTriIndex_Delta2spline (spline->gridXSize - i - 1,
						  j, spline) + 2][24 - l];
		(spline->tri_av)[getTriIndex_Delta2spline (i, j, spline) +
				 1][22 + l] +=
		  (spline->
		   tri)[getTriIndex_Delta2spline (spline->gridXSize - i - 1,
						  j, spline) + 1][24 - l];
		(spline->tri_av)[getTriIndex_Delta2spline (i, j, spline) +
				 2][22 + l] +=
		  (spline->
		   tri)[getTriIndex_Delta2spline (spline->gridXSize - i - 1,
						  j, spline)][24 - l];
		(spline->tri_av)[getTriIndex_Delta2spline (i, j, spline) +
				 3][22 + l] +=
		  (spline->
		   tri)[getTriIndex_Delta2spline (spline->gridXSize - i - 1,
						  j, spline) + 3][24 - l];
	      }
	    for (l = 0; l <= 1; l++)
	      {
		(spline->tri_av)[getTriIndex_Delta2spline (i, j, spline)][25 +
									  l]
		  +=
		  (spline->
		   tri)[getTriIndex_Delta2spline (spline->gridXSize - i - 1,
						  j, spline) + 2][26 - l];
		(spline->tri_av)[getTriIndex_Delta2spline (i, j, spline) +
				 1][25 + l] +=
		  (spline->
		   tri)[getTriIndex_Delta2spline (spline->gridXSize - i - 1,
						  j, spline) + 1][26 - l];
		(spline->tri_av)[getTriIndex_Delta2spline (i, j, spline) +
				 2][25 + l] +=
		  (spline->
		   tri)[getTriIndex_Delta2spline (spline->gridXSize - i - 1,
						  j, spline)][26 - l];
		(spline->tri_av)[getTriIndex_Delta2spline (i, j, spline) +
				 3][25 + l] +=
		  (spline->
		   tri)[getTriIndex_Delta2spline (spline->gridXSize - i - 1,
						  j, spline) + 3][26 - l];
	      }
	    for (k = 0; k <= 3; k++)

	      (spline->tri_av)[getTriIndex_Delta2spline (i, j, spline) +
			       k][27] +=
		(spline->
		 tri)[getTriIndex_Delta2spline (spline->gridXSize - i - 1, j,
						spline) + 2][27];

	  }

    }


  if (spline->control == 5)
    {
      for (i = -1; i <= spline->gridXSize1; i++)
	for (j = -1; j <= spline->gridYSize1; j++)
	  {

	    for (l = 0; l <= 6; l++)
	      {
		for (k = 0; k <= 3; k++)
		  (spline->tri_av)[getTriIndex1_Delta2spline (i, j, spline) +
				   k][l] +=
		    (spline->tri)[getTriIndex_Delta2spline (j, i, spline) +
				  3 - k][6 - l];
	      }

	    for (l = 0; l <= 5; l++)
	      {
		for (k = 0; k <= 3; k++)
		  (spline->tri_av)[getTriIndex1_Delta2spline (i, j, spline) +
				   k][7 + l] +=
		    (spline->tri)[getTriIndex_Delta2spline (j, i, spline) +
				  3 - k][12 - l];
	      }

	    for (l = 0; l <= 4; l++)
	      {
		for (k = 0; k <= 3; k++)
		  (spline->tri_av)[getTriIndex1_Delta2spline (i, j, spline) +
				   k][13 + l] +=
		    (spline->tri)[getTriIndex_Delta2spline (j, i, spline) +
				  3 - k][17 - l];
	      }


	    for (l = 0; l <= 3; l++)
	      {
		for (k = 0; k <= 3; k++)
		  (spline->tri_av)[getTriIndex1_Delta2spline (i, j, spline) +
				   k][18 + l] +=
		    (spline->tri)[getTriIndex_Delta2spline (j, i, spline) +
				  3 - k][21 - l];
	      }

	    for (l = 0; l <= 2; l++)
	      {
		for (k = 0; k <= 3; k++)
		  (spline->tri_av)[getTriIndex1_Delta2spline (i, j, spline) +
				   k][22 + l] +=
		    (spline->tri)[getTriIndex_Delta2spline (j, i, spline) +
				  3 - k][24 - l];
	      }
	    for (l = 0; l <= 1; l++)
	      {
		for (k = 0; k <= 3; k++)
		  (spline->tri_av)[getTriIndex1_Delta2spline (i, j, spline) +
				   k][25 + l] +=
		    (spline->tri)[getTriIndex_Delta2spline (j, i, spline) +
				  3 - k][26 - l];
	      }
	    for (k = 0; k <= 3; k++)

	      (spline->tri_av)[getTriIndex1_Delta2spline (i, j, spline) +
			       k][27] +=
		(spline->tri)[getTriIndex_Delta2spline (j, i, spline) +
			      2][27];

	  }

    }

  if (spline->control == 6)
    {
      for (i = -1; i <= spline->gridXSize1; i++)
	for (j = -1; j <= spline->gridYSize1; j++)
	  {

	    for (l = 0; l <= 6; l++)
	      {
		for (k = 0; k <= 3; k++)
		  (spline->tri_av)[getTriIndex1_Delta2spline (i, j, spline) +
				   k][l] +=
		    (spline->tri)[getTriIndex_Delta2spline (j, i, spline) +
				  3 - k][6 - l];
	      }

	    for (l = 0; l <= 5; l++)
	      {
		for (k = 0; k <= 3; k++)
		  (spline->tri_av)[getTriIndex1_Delta2spline (i, j, spline) +
				   k][7 + l] +=
		    (spline->tri)[getTriIndex_Delta2spline (j, i, spline) +
				  3 - k][12 - l];
	      }

	    for (l = 0; l <= 4; l++)
	      {
		for (k = 0; k <= 3; k++)
		  (spline->tri_av)[getTriIndex1_Delta2spline (i, j, spline) +
				   k][13 + l] +=
		    (spline->tri)[getTriIndex_Delta2spline (j, i, spline) +
				  3 - k][17 - l];
	      }


	    for (l = 0; l <= 3; l++)
	      {
		for (k = 0; k <= 3; k++)
		  (spline->tri_av)[getTriIndex1_Delta2spline (i, j, spline) +
				   k][18 + l] +=
		    (spline->tri)[getTriIndex_Delta2spline (j, i, spline) +
				  3 - k][21 - l];
	      }

	    for (l = 0; l <= 2; l++)
	      {
		for (k = 0; k <= 3; k++)
		  (spline->tri_av)[getTriIndex1_Delta2spline (i, j, spline) +
				   k][22 + l] +=
		    (spline->tri)[getTriIndex_Delta2spline (j, i, spline) +
				  3 - k][24 - l];
	      }
	    for (l = 0; l <= 1; l++)
	      {
		for (k = 0; k <= 3; k++)
		  (spline->tri_av)[getTriIndex1_Delta2spline (i, j, spline) +
				   k][25 + l] +=
		    (spline->tri)[getTriIndex_Delta2spline (j, i, spline) +
				  3 - k][26 - l];
	      }
	    for (k = 0; k <= 3; k++)

	      (spline->tri_av)[getTriIndex1_Delta2spline (i, j, spline) +
			       k][27] +=
		(spline->tri)[getTriIndex_Delta2spline (j, i, spline) +
			      2][27];


	  }

    }

  if (spline->control == 7)
    {
      for (i = -1; i <= spline->gridXSize1; i++)
	for (j = -1; j <= spline->gridYSize1; j++)
	  {
	    for (l = 0; l <= 27; l++)
	      {

		(spline->
		 tri_av)[getTriIndex1_Delta2spline (i, j, spline)][l] +=
	  (spline->
	   tri)[getTriIndex_Delta2spline (spline->gridYSize1 - j - 1, i,
					  spline) + 3][l];
		(spline->tri_av)[getTriIndex1_Delta2spline (i, j, spline) +
				 1][l] +=
		  (spline->
		   tri)[getTriIndex_Delta2spline (spline->gridYSize1 - j - 1,
						  i, spline)][l];
		(spline->tri_av)[getTriIndex1_Delta2spline (i, j, spline) +
				 2][l] +=
		  (spline->
		   tri)[getTriIndex_Delta2spline (spline->gridYSize1 - j - 1,
						  i, spline) + 1][l];
		(spline->tri_av)[getTriIndex1_Delta2spline (i, j, spline) +
				 3][l] +=
		  (spline->
		   tri)[getTriIndex_Delta2spline (spline->gridYSize1 - j - 1,
						  i, spline) + 2][l];
	      }
	  }

    }


  if (spline->control == 8)
    {
      for (i = -1; i <= spline->gridXSize1; i++)
	for (j = -1; j <= spline->gridYSize1; j++)
	  {
	    for (l = 0; l <= 27; l++)
	      {


		(spline->
		 tri_av)[getTriIndex1_Delta2spline (i, j, spline)][l] +=
	  (spline->
	   tri)[getTriIndex_Delta2spline (spline->gridYSize1 - j - 1, i,
					  spline) + 3][l];
		(spline->tri_av)[getTriIndex1_Delta2spline (i, j, spline) +
				 1][l] +=
		  (spline->
		   tri)[getTriIndex_Delta2spline (spline->gridYSize1 - j - 1,
						  i, spline)][l];
		(spline->tri_av)[getTriIndex1_Delta2spline (i, j, spline) +
				 2][l] +=
		  (spline->
		   tri)[getTriIndex_Delta2spline (spline->gridYSize1 - j - 1,
						  i, spline) + 1][l];
		(spline->tri_av)[getTriIndex1_Delta2spline (i, j, spline) +
				 3][l] +=
		  (spline->
		   tri)[getTriIndex_Delta2spline (spline->gridYSize1 - j - 1,
						  i, spline) + 2][l];

	      }
	  }

    }



}






static void
loc_appr2 (void *data_void, void *spline_void,
	   TSFIT_LOCAL_METHOD * local_method, TSFIT_CONVERTER * converter)
{
  TSFIT_DATA *data = (TSFIT_DATA *) data_void;
  D2SPLINE *spline = (D2SPLINE *) spline_void;
  int i, j;
  double llx, lly;
  double Rx, Ry, Sx, Sy, Tx, Ty;
  TRIEL *element = spline->locale;

#ifdef EVAL_LOC_POLY
  FILE *f;

  f = fopen ("locpol.txt", "a");

  if (f == NULL)
    {
      fprintf (stderr, "error: file opening failure \'locpol.txt\' [loc_appr2]\n");
      exit (-1);
    }
#endif


  /* radius = spline->wGrid * lcontr->init_rad_factor; */


  /* use least squares approx to fit data to each initial triangle */


  for (j = -1; j <= spline->gridYSize; j++)
    {
      lly = j * spline->hGrid;
      for (i = -1; i <= spline->gridXSize; i++)
	{

	  /* use every second grid cell, loop interrupted, if 
	     i+j is an odd number and non-spline->shifted scheme or
	     i+j is even and spline->shifted scheme  */

	  if ((abs (i + j) & 0x1) & !spline->shift)
	    continue;
	  if (!(abs (i + j) & 0x1) & spline->shift)
	    continue;

	  /*
	     if (abs(i+j) & 0x1) continue;
	   */

	  llx = i * spline->wGrid;

	  /* vertices of the triangle */

	  Rx = llx;
	  Ry = lly;
	  Sx = llx;
	  Sy = lly + spline->hGrid;
	  Tx = llx + 0.5 * spline->wGrid;
	  Ty = lly + 0.5 * spline->hGrid;



	  /* reflect the point if averaging is used 
	     (nothing happens if spline->control=1 or 2) */

	  reflect_xy_Delta2spline (&Rx, &Ry, spline);
	  reflect_xy_Delta2spline (&Sx, &Sy, spline);
	  reflect_xy_Delta2spline (&Tx, &Ty, spline);


	  element->triangle.x1 = Rx;
	  element->triangle.y1 = Ry;
	  element->triangle.x2 = Sx;
	  element->triangle.y2 = Sy;
	  element->triangle.x3 = Tx;
	  element->triangle.y3 = Ty;

	  find_tri_center (&element->triangle);

	  element->triangle.diam = spline->wGrid;
	  element->coefs =
	    (spline->tri)[getTriIndex_Delta2spline (i, j, spline)];




	  /* compute local polynomial approximations of appropriate degree 
	     using the local data in 'locPoints' */


	  converter->call_local_method (element, converter->body,
					local_method, data);



#ifdef EVAL_LOC_POLY
	  if (j > -1 && j < spline->gridYSize && i > -1
	      && i < spline->gridXSize)
	    {
	      int ii, jj, kk, N;
	      double r, s, t, x, y, z, dN;

	      N = 4;
	      dN = (double) N;

	      for (ii = 0; ii <= N; ii++)
		for (jj = 0; jj <= N - ii; jj++)
		  {

		    kk = N - ii - jj;
		    r = (double) ii / dN;
		    s = (double) jj / dN;
		    t = (double) kk / dN;

		    x = Rx * r + Sx * s + Tx * t;
		    y = Ry * r + Sy * s + Ty * t;
		    z =
		      deCast6 (r, s, t,
			       (spline->
				tri)[getTriIndex_Delta2spline (i, j,
							       spline)]);

		    fprintf (f, "%f %f %f\n", x, y, z);

		  }
	      fprintf (f, "\n");
	    }
#endif


	  

	}
    }





#ifdef EVAL_LOC_POLY
  fclose (f);
#endif
}

/* C^2 spline of degree 6 on the four-directional mesh computed by the 
extension method as described in
 O. Davydov and F. Zeilfelder, Scattered data fitting by direct extension 
 of local polynomials to bivariate splines, Advances in Comp. Math. 21 (2004), 
 223-271.
 
  Authors: Frank Zeilfelder
           Universit\"at Mannheim 
           Fakult\"at f\"ur Mathematik und Infomatik
           Lehrstuhl Mathematik IV
           68131 Mannheim, Germany 
           e-mail: zeilfeld@euklid.math.uni-mannheim.de
 
           Oleg Davydov
	   University of Strathclyde
	   Department of Mathematics
           26 Richmond Street
	   Glasgow G1 1XH
	   Scotland, UK
	   e-mail: oleg.davydov@strath.ac.uk


  Copyright (C) 2005, 2012  Frank Zeilfelder and Oleg Davydov

This file is part of TSFIT.

This package is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This package is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this package; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */


/* spline structure */

typedef struct d2spline
{
  double **tri;
  int gridXSize;
  int gridYSize;
  double wGrid;
  double hGrid;
  int smoothness;
  int loc_dim;
  int super;
  int av;			/* averaging flag: if av = 1, averaging is used */
  double **tri_av;
  void (*loc_appr) (void *data_void, void *spline_void,
		       TSFIT_LOCAL_METHOD * local_method,
		       TSFIT_CONVERTER * converter);
  void (*extend) (struct d2spline * spline);
  void (*add_to_average) (struct d2spline * spline);
  double (*deCast) (double r, double s, double t, double *tri);
  int gridXSize1;
  int gridYSize1;
  double wGrid1;
  double hGrid1;
  int shift;
  int control;
  double reflectX;
  double reflectY;
  TRIEL *locale;		/* locale */
} D2SPLINE;



/* routines for external use */

void init_Delta2spline (void *spline);

void free_Delta2spline (void *spline);

void compute_Delta2spline (void *data_void, void *spline_void,
			   TSFIT_LOCAL_METHOD * local_method,
			   TSFIT_CONVERTER * converter);

double eval_Delta2spline (double x, double y, void *spline_void);


void set_C2_Delta2spline (D2SPLINE * spline);

int getTriIndex_Delta2spline (int x, int y, D2SPLINE * spline);
int getTriIndex1_Delta2spline (int x, int y, D2SPLINE * spline);
void reflect_xy_Delta2spline (double *x, double *y, D2SPLINE * spline);

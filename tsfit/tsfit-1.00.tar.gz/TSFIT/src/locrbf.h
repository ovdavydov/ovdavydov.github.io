/* Local RBF approximation as described in

 O. Davydov, R. Morandi and A. Sestini, Local hybrid approximation for 
 scattered data fitting with bivariate splines, Comput. Aided Geom. Design 23 (2006), 703-721. 
 
 O. Davydov, A. Sestini and R. Morandi, Local RBF approximation for
 scattered data fitting with bivarite splines, in "Trends and Applications 
 in Constructive Approximation," (M. G. de Bruin, D. H. Mache, and J. Szabados, Eds.),
 ISNM Vol. 151, Birkhauser, 2005, pp. 91-102. 
 
  Author: Oleg Davydov
	  University of Strathclyde
	  Department of Mathematics
          26 Richmond Street
	  Glasgow G1 1XH
	  Scotland, UK
	  e-mail: oleg.davydov@strath.ac.uk


  Copyright (C) 2005, 2012 Oleg Davydov

This file is part of TSFIT.

This package is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This package is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this package; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

/*** locale for rfb methods: triangle and evaluation routine ***/

typedef struct
{
  TRIANGLE *triangle;		/* triangle geometry */
  double (*eval) (double b1, double b2, double b3, void *lcontr_void);
} TRIEVAL;


/*** hybrid approximation ***/

typedef struct
{
  LSCONTROL *lscontr;		/* pointer to the loc. search control */
  LACONTROL *lacontr;		/* pointer to the polynomial loc. appr. control */
  TRIEVAL *locale;
  double (*basis_function) (double rx, double ry, double delta);
  /* parameters of the method */
  double min_sing_value;	/* tolerance for acceptable min sing value of
				   extended systems */
  double delta_coef;		/* scaling parameter for the RBF function */
  int max_loc_dim;		/* maximal number of basis functions used locally  */
  int max_knotnum;		/* (no parameter!) = max_loc_dim - dim of polynomials */
  /* current approximation */
  double delta;			/* delta = delta_coef * maximum distance between points */
  int knotnum;			/* actual number of rbf knots */
  int *knotidx;			/* knot indices; allocated size max_knotnum */
  double *knotx;		/* x coordinates of the knots */
  double *knoty;		/* y coordinates of the knots */
  /* info */
  double max_delta;
  double min_delta;
  int *knotnum_stat;
  double max_cond;
} LHACONTROL;


/**** rbf approximation ****/

/*
 *    structure for the linear equality-constrained least squares
 *    problem (LSE): min_x ||Ax-c|| subject to B^T x=d; since we have d=0 
 *    and c is the vector of input z-values, we do not need these two 
 *    in the structure. We have A = [P_Xi C_{K,Xi}] and
 *     B = [  0  ]
 *         [ P_K ]
 *    where P_Xi and P_K are the polynomial collocation matrices at
 *    all local points Xi and knots K, respectively, and C_{K,Xi}
 *    is the RBF collocation matrix.
 *    ATTN: We use the _transpose_ B^T for easy implementation
 *    COMMENT: This structure is only used if USE_LAPACK_LSE is defined in 'locrbf.c'
 */

typedef struct
{
  /* local polynomial basis */
  BBTRI *baseTri;		/* pointer to the Bernstein-Bezier triangle used for 
				   the polynomial basis */
  /* matrices */
  double **A;			/* hybrid (polynomial-RBF) collocation matrix */
  double **B;			/* matrix of constraints */
  /* coefficient vector x */
  double *coefs;
  /* constraint vector d; it is zero for our application, but
     it is better to allocate it in advance if the LSE subroutine requires it */
  double *d;
} LSE;


/* main control structure for the rbf method */

typedef struct
{
  LSCONTROL *lscontr;		/* pointer to the loc. search control */
  LACONTROL *lacontr;		/* pointer to the polynomial loc. appr. control */
  TRIEVAL *locale;
  double (*basis_function) (double rx, double ry, double delta);
  LOCALDATA *locKnots;		/* RBF knots */
  double delta;			/* actual delta = delta_coef * maximum distance between points */
  double *coefs;		/* coefficients of the hybrid function */
  /* parameters */
  int interp_only;		/* if set to a nonzero value, enforces using locally
				   interpolation on the knots (otherwise the set of
				   knots is only part of the local points -- in general
				   -- and we do least squares) */
  int max_loc_dim;		/* maximal number of RBFs used locally;
				   the same as maximal number of RBF knots  */
  double delta_coef;		/* scaling parameter for the RBF function */
  double separ_par;		/* maximal allowed factor delta/separ.dist */
  /* structure for constrained least squares  (used with USE_LAPACK_LSE) */
  LSE *lse;
  /* auxiliary array for sing value decomposition method of solving LSE */
  double *c;
  /* arrays for thinning */
  double **squared_distance;	/* squared distances between local points */
  int **bad_dist;		/* bad_dist(i,j) = 1 iff the distance
				   between i-th and j-th local points (i\ne j)
				   is smaller than the tolerance value */
  int *bad_point_index;		/* the number of too close neighbors */
  int *permute;			/* the permutation of the local point indices, according
				   to their "quality" w.r.t. separation distance: 
				   permute[0] is the "best" point */
  /* info */
  double max_delta;
  double min_delta;
  int max_knotnum;
  int *knotnum_stat;
  double max_cond;
} LRBFACONTROL;




/*** routines for external use ***/

void compute_hybrid_loc_appr (void *data, void *lhacontr);
void compute_rbf_loc_appr (void *data, void *lrbfacontr);

void init_hybrid_loc_appr (void *lhacontr);
void free_hybrid_loc_appr (void *lhacontr);

void init_rbf_loc_appr (void *lrbfacontr);
void free_rbf_loc_appr (void *lrbfacontr);

/* radial basis functions */

double rbf_MQ (double rx, double ry, double delta);
double rbf_MQ1_5 (double rx, double ry, double delta);
double rbf_MQ2 (double rx, double ry, double delta);
double rbf_MQ3 (double rx, double ry, double delta);
double rbf_IMQ (double rx, double ry, double delta);
double rbf_IMQ2 (double rx, double ry, double delta);
double rbf_IMQ3 (double rx, double ry, double delta);
double rbf_IMQ0_5 (double rx, double ry, double delta);
double rbf_TPS (double rx, double ry, double delta);
double rbf_TPS4 (double rx, double ry, double delta);
double rbf_TPS6 (double rx, double ry, double delta);
double rbf_polyharmonic1_5 (double rx, double ry, double delta);
double rbf_polyharmonic1_75 (double rx, double ry, double delta);
double rbf_polyharmonic3 (double rx, double ry, double delta);
double rbf_polyharmonic5 (double rx, double ry, double delta);
double rbf_polyharmonic7 (double rx, double ry, double delta);
double rbf_polyharmonic9 (double rx, double ry, double delta);
double rbf_Gauss (double rx, double ry, double delta);
double rbf_Wendland31 (double rx, double ry, double delta);
double rbf_Wendland32 (double rx, double ry, double delta);
double rbf_Wendland33 (double rx, double ry, double delta);
double rbf_BuhmannC3 (double rx, double ry, double delta);


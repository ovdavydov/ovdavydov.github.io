/* Management of the first stage ("local") methods.
 
  Author: Oleg Davydov
	  University of Strathclyde
	  Department of Mathematics
          26 Richmond Street
	  Glasgow G1 1XH
	  Scotland, UK
	  e-mail: oleg.davydov@strath.ac.uk


  Copyright (C) 2005 Oleg Davydov

This file is part of TSFIT.

This package is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This package is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this package; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#include "datamng.h"
#include "lmethod.h"

#include "locsearch.h"
#include "bezier.h"
#include "linalg.h"
#include "locpoly.h"
#include "locrbf.h"



void
set_local_method_type (TSFIT_LOCAL_METHOD * method, char *type)
{




  if (!strcmp (type, "polynomial"))
    {
      LACONTROL *lacontr;

      strcpy (method->type, type);
      
      method->body = malloc (sizeof (LACONTROL));
      if (method->body == NULL)
	{
	  fprintf (stderr,
		   "\nerror: memory allocation failure [set_local_method_type]\n");
	  exit (-1);
	}
	
      lacontr = (LACONTROL *) method->body;

      /* lacontr->lscontr is allocated here in order to allow setting
         its parameters before calling method->init */

      lacontr->lscontr = (LSCONTROL *) malloc (sizeof (LSCONTROL));
      if (lacontr->lscontr == NULL)
	{
	  fprintf (stderr,
		   "\nerror: memory allocation failure [set_local_method_type]\n");
	  exit (-1);
	}

      method->init = &init_poly_loc_appr;
      method->free = &free_poly_loc_appr;
      method->compute = &compute_poly_loc_appr;

      /* set default parameter values */

      lacontr->lscontr->init_rad_factor = 1.0;
      lacontr->min_sing_value = 1e-15;
      lacontr->max_loc_dim = 28;	/* sufficient for polynomials of
					   degree up to 6 currently in use */
      lacontr->max_degree = 6;

      /* set the type of locale */

      strcpy (method->locale_type, "TRIEL");
      method->locale = lacontr->locale = (TRIEL *) malloc (sizeof (TRIEL));
      if (lacontr->locale == NULL)
	{
	  fprintf (stderr,
		   "\nerror: memory allocation failure [set_local_method_type]\n");
	  exit (-1);
	}

    }
  else if (!strcmp (type, "Hybrid"))
    {
      LHACONTROL *lhacontr;

      strcpy (method->type, type);
      
      method->body = malloc (sizeof (LHACONTROL));
      if (method->body == NULL)
	{
	  fprintf (stderr,
		   "\nerror: memory allocation failure [set_local_method_type]\n");
	  exit (-1);
	}
	
      lhacontr = (LHACONTROL *) method->body;

      lhacontr->lscontr = (LSCONTROL *) malloc (sizeof (LSCONTROL));
      if (lhacontr->lscontr == NULL)
	{
	  fprintf (stderr,
		   "\nerror: memory allocation failure [set_local_method_type]\n");
	  exit (-1);
	}

      lhacontr->lacontr = (LACONTROL *) malloc (sizeof (LACONTROL));
      if (lhacontr->lacontr == NULL)
	{
	  fprintf (stderr,
		   "\nerror: memory allocation failure [set_local_method_type]\n");
	  exit (-1);
	}

      method->init = &init_hybrid_loc_appr;
      method->free = &free_hybrid_loc_appr;
      method->compute = &compute_hybrid_loc_appr;

      /* set default parameter values */

      lhacontr->lscontr->init_rad_factor = 1.0;
      lhacontr->lacontr->min_sing_value = 1e-15;
      lhacontr->lacontr->max_degree = 6;
      lhacontr->max_loc_dim = 400;

      /* set the type of locale */

      strcpy (method->locale_type, "TRIEVAL");

      method->locale = lhacontr->locale =
	(TRIEVAL *) malloc (sizeof (TRIEVAL));
      if (lhacontr->locale == NULL)
	{
	  fprintf (stderr,
		   "\nerror: memory allocation failure [set_local_method_type]\n");
	  exit (-1);
	}

      lhacontr->lacontr->locale = (TRIEL *) malloc (sizeof (TRIEL));
      if (lhacontr->lacontr->locale == NULL)
	{
	  fprintf (stderr,
		   "\nerror: memory allocation failure [set_local_method_type]\n");
	  exit (-1);
	}

    }
#ifndef HYBRID_ONLY
  else if (!strcmp (type, "RBF"))
    {
      LRBFACONTROL *lrbfacontr;

      strcpy (method->type, type);
      
      method->body = malloc (sizeof (LRBFACONTROL));
      if (method->body == NULL)
	{
	  fprintf (stderr,
		   "\nerror: memory allocation failure [set_local_method_type]\n");
	  exit (-1);
	}
	
      lrbfacontr = (LRBFACONTROL *) method->body;

      lrbfacontr->lscontr = (LSCONTROL *) malloc (sizeof (LSCONTROL));
      if (lrbfacontr->lscontr == NULL)
	{
	  fprintf (stderr,
		   "\nerror: memory allocation failure [set_local_method_type]\n");
	  exit (-1);
	}

      lrbfacontr->lacontr = (LACONTROL *) malloc (sizeof (LACONTROL));
      if (lrbfacontr->lacontr == NULL)
	{
	  fprintf (stderr,
		   "\nerror: memory allocation failure [set_local_method_type]\n");
	  exit (-1);
	}

      method->init = &init_rbf_loc_appr;
      method->free = &free_rbf_loc_appr;
      method->compute = &compute_rbf_loc_appr;

      /* set default parameter values */

      lrbfacontr->lscontr->init_rad_factor = 1.0;
      lrbfacontr->lacontr->min_sing_value = 1e-15;
      lrbfacontr->lacontr->max_degree = 6;
      lrbfacontr->max_loc_dim = 400;
      lrbfacontr->interp_only = 0;

      /* set the type of locale */

      strcpy (method->locale_type, "TRIEVAL");

      method->locale = lrbfacontr->locale =
	(TRIEVAL *) malloc (sizeof (TRIEVAL));
      if (lrbfacontr->locale == NULL)
	{
	  fprintf (stderr,
		   "\nerror: memory allocation failure [set_local_method_type]\n");
	  exit (-1);
	}

      lrbfacontr->lacontr->locale = (TRIEL *) malloc (sizeof (TRIEL));
      if (lrbfacontr->lacontr->locale == NULL)
	{
	  fprintf (stderr,
		   "\nerror: memory allocation failure [set_local_method_type]\n");
	  exit (-1);
	}


    }
#endif
  else
    {
      fprintf (stderr,
	       "\nerror: Invalid method type \"%s\"! [set_local_method_type]\n",
	       type);
      exit (-1);
    }


}

/* change the type of the method; 
assumes that  method->body is _allocated_ (see set_local_method_type)
and _initialized_ (i.e. method->init has been called, see tsfit_compute);
if called with type=NULL, then the memory allocated to method->body will be freed 
 and the method type will be set to "NULL"  */
void
reset_local_method_type (TSFIT_LOCAL_METHOD * method, char *type)
{

  method->free (method->body);

  /* the following memory has been allocated by set_local_method_type */

  if (!strcmp (method->type, "polynomial"))
    free (((LACONTROL *) method->body)->lscontr);
  else if (!strcmp (method->type, "Hybrid"))
    {
      free (((LHACONTROL *) method->body)->lscontr);
      free (((LHACONTROL *) method->body)->lacontr->locale);
      free (((LHACONTROL *) method->body)->lacontr);
    }
#ifndef HYBRID_ONLY
  else if (!strcmp (method->type, "RBF"))
    {
      free (((LRBFACONTROL *) method->body)->lscontr);
      free (((LRBFACONTROL *) method->body)->lacontr->locale);
      free (((LRBFACONTROL *) method->body)->lacontr);
    }
#endif

  free (method->locale);

  free (method->body);

  if (type != NULL)
    set_local_method_type (method, type);
  else
    strcpy (method->type, "NULL");

}


/* set the minimum number of points used locally */
void
set_min_points (TSFIT_LOCAL_METHOD * method, int number)
{
  LSCONTROL *lscontr;

  if (!strcmp (method->type, "polynomial"))
    lscontr = ((LACONTROL *) method->body)->lscontr;
  else if (!strcmp (method->type, "Hybrid"))
    lscontr = ((LHACONTROL *) method->body)->lscontr;
  else if (!strcmp (method->type, "RBF"))
    lscontr = ((LRBFACONTROL *) method->body)->lscontr;
  else
    {
      fprintf (stderr,
	       "\nerror: Invalid local method type \"%s\"! [set_min_points]\n",
	       method->type);
      exit (-1);
    }


  lscontr->minPoints = number;

}


/* set the maximum number of points used locally */
void
set_max_points (TSFIT_LOCAL_METHOD * method, int number)
{
  LSCONTROL *lscontr;

  if (!strcmp (method->type, "polynomial"))
    lscontr = ((LACONTROL *) method->body)->lscontr;
  else if (!strcmp (method->type, "Hybrid"))
    lscontr = ((LHACONTROL *) method->body)->lscontr;
  else if (!strcmp (method->type, "RBF"))
    lscontr = ((LRBFACONTROL *) method->body)->lscontr;
  else
    {
      fprintf (stderr,
	       "\nerror: Invalid local method type \"%s\"! [set_max_points]\n",
	       method->type);
      exit (-1);
    }


  lscontr->maxPoints = number;

}

/* set the starting polynomial degree */
void
set_starting_degree (TSFIT_LOCAL_METHOD * method, int degree)
{
  LACONTROL *lacontr;

  if (!strcmp (method->type, "polynomial"))
    lacontr = (LACONTROL *) method->body;
  else if (!strcmp (method->type, "Hybrid") || !strcmp (method->type, "RBF"))
    {
      fprintf (stderr,
	       "\nerror: Do not use this function with hybrid or rbf method! [set_starting_degree]\n");
      fprintf (stderr,
	       "Set the ploynomial degree with set_radial_basis_function instead\n");
      exit (-1);
    }
  else
    {
      fprintf (stderr,
	       "\nerror: Invalid local method type \"%s\"! [set_starting_degree]\n",
	       method->type);
      exit (-1);
    }


  lacontr->starting_degree = degree;

}

/* set the minimum singular value for the polynomial part */
void
set_min_sing_value_poly (TSFIT_LOCAL_METHOD * method, double min_sing_value)
{
  LACONTROL *lacontr;

  if (!strcmp (method->type, "polynomial"))
    lacontr = (LACONTROL *) method->body;
  else if (!strcmp (method->type, "Hybrid"))
    lacontr = ((LHACONTROL *) method->body)->lacontr;
  else if (!strcmp (method->type, "RBF"))
    lacontr = ((LRBFACONTROL *) method->body)->lacontr;
  else
    {
      fprintf (stderr,
	       "\nerror: Invalid local method type \"%s\"! [set_min_sing_value_poly]\n",
	       method->type);
      exit (-1);
    }


  lacontr->min_sing_value = min_sing_value;

}

/* set the radial basis function and polynomial degree */
void
set_radial_basis_function (TSFIT_LOCAL_METHOD * method, int degree,
			   double (*basis_function) (double rx, double ry, double delta))
{

  if (!strcmp (method->type, "polynomial"))
    {
      fprintf (stderr,
	       "\nerror: rbf is not used with this method \"%s\"! [set_radial_basis_function]\n",
	       method->type);
      exit (-1);
    }
  else if (!strcmp (method->type, "Hybrid"))
    {
      if ((basis_function == &rbf_MQ2 ||
	   basis_function == &rbf_MQ3 ||
	   basis_function == &rbf_TPS ||
	   basis_function == &rbf_polyharmonic3) && degree < 1)
	{
	  fprintf (stderr,
		   "\nerror: degree = %i [set_radial_basis_function]\n",
		   degree);
	  fprintf (stderr,
		   "The radial basis function selected requires polynomial degree at least 1.\n");
	  exit (-1);
	}
      if ((basis_function == &rbf_TPS4 ||
	   basis_function == &rbf_polyharmonic5) && degree < 2)
	{
	  fprintf (stderr,
		   "\nerror: degree = %i [set_radial_basis_function]\n",
		   degree);
	  fprintf (stderr,
		   "The radial basis function selected requires polynomial degree at least 2.\n");
	  exit (-1);
	}
      if ((basis_function == &rbf_TPS6 ||
	   basis_function == &rbf_polyharmonic7) && degree < 3)
	{
	  fprintf (stderr,
		   "\nerror: degree = %i [set_radial_basis_function]\n",
		   degree);
	  fprintf (stderr,
		   "The radial basis function selected requires polynomial degree at least 3.\n");
	  exit (-1);
	}
      if ((basis_function == &rbf_polyharmonic9) && degree < 4)
	{
	  fprintf (stderr,
		   "\nerror: degree = %i [set_radial_basis_function]\n",
		   degree);
	  fprintf (stderr,
		   "The radial basis function selected requires polynomial degree at least 4.\n");
	  exit (-1);
	}
      ((LHACONTROL *) method->body)->basis_function = basis_function;
      ((LHACONTROL *) method->body)->lacontr->starting_degree = degree;
    }
  else if (!strcmp (method->type, "RBF"))
    {
      if (basis_function == &rbf_MQ2 ||
	  basis_function == &rbf_MQ3 ||
	  basis_function == &rbf_TPS ||
	  basis_function == &rbf_polyharmonic3 ||
	  basis_function == &rbf_TPS4 ||
	  basis_function == &rbf_polyharmonic5 ||
	  basis_function == &rbf_TPS6 ||
	  basis_function == &rbf_polyharmonic7 ||
	  basis_function == &rbf_polyharmonic9)
	{
	  fprintf (stderr, "\nerror: The radial basis function selected ");
	  fprintf (stderr,
		   "cannot currently be used with the \"rbf\" method.\n");
	  exit (-1);
	}
      ((LRBFACONTROL *) method->body)->basis_function = basis_function;
      ((LRBFACONTROL *) method->body)->lacontr->starting_degree = degree;
    }
  else
    {
      fprintf (stderr,
	       "\nerror: Invalid local method type \"%s\"! [set_radial_basis_function]\n",
	       method->type);
      exit (-1);
    }


}

/* set the scaling coefficient for radial basis function methods */
void
set_scaling_coef (TSFIT_LOCAL_METHOD * method, double scaling_coef)
{
  if (!strcmp (method->type, "polynomial"))
    {
      fprintf (stderr,
	       "\nerror: rbf scaling is not relevant for this method \"%s\"! [set_scaling_coef]\n",
	       method->type);
      exit (-1);
    }
  else if (!strcmp (method->type, "Hybrid"))
    ((LHACONTROL *) method->body)->delta_coef = scaling_coef;
  else if (!strcmp (method->type, "RBF"))
    ((LRBFACONTROL *) method->body)->delta_coef = scaling_coef;
  else
    {
      fprintf (stderr,
	       "\nerror: Invalid local method type \"%s\"! [set_scaling_coef]\n",
	       method->type);
      exit (-1);
    }
}

/* set the minimum singular value for the hybrid method */
void
set_min_sing_value_hybrid (TSFIT_LOCAL_METHOD * method,
			   double min_sing_value_hybrid)
{
  if (!strcmp (method->type, "polynomial") || !strcmp (method->type, "RBF"))
    {
      fprintf (stderr,
	       "\nerror: min_sing_value_hybrid is not relevant for this method \"%s\"! [set_min_sing_value_hybrid]\n",
	       method->type);
      exit (-1);
    }
  else if (!strcmp (method->type, "Hybrid"))
    ((LHACONTROL *) method->body)->min_sing_value = min_sing_value_hybrid;
  else
    {
      fprintf (stderr,
	       "\nerror: Invalid local method type \"%s\"! [set_min_sing_value_hybrid]\n",
	       method->type);
      exit (-1);
    }
}

/* set the separation parameter for the rbf method */
void
set_separation_rbf (TSFIT_LOCAL_METHOD * method, double separ_par)
{
  if (!strcmp (method->type, "polynomial")
      || !strcmp (method->type, "Hybrid"))
    {
      fprintf (stderr,
	       "\nerror: separation parameter is not relevant for this method \"%s\"! [set_separation_rbf]\n",
	       method->type);
      exit (-1);
    }
  else if (!strcmp (method->type, "RBF"))
    ((LRBFACONTROL *) method->body)->separ_par = separ_par;
  else
    {
      fprintf (stderr,
	       "\nerror: Invalid local method type \"%s\"! [set_separation_rbf]\n",
	       method->type);
      exit (-1);
    }
}


/* set the option "interpolation only" for the rbf method */
void
set_interpolation_only_rbf (TSFIT_LOCAL_METHOD * method, char *TRUE_or_FALSE)
{
  if (!strcmp (method->type, "polynomial")
      || !strcmp (method->type, "Hybrid"))
    {
      fprintf (stderr,
	       "\nerror: \"interpolation only\" is not relevant for this method \"%s\"! [set_interpolation_only_rbf]\n",
	       method->type);
      exit (-1);
    }
  else if (!strcmp (method->type, "RBF"))
    {
      if (!strcmp (TRUE_or_FALSE, "TRUE"))
	((LRBFACONTROL *) method->body)->interp_only = 1;
      else if (!strcmp (TRUE_or_FALSE, "FALSE"))
	((LRBFACONTROL *) method->body)->interp_only = 0;
      else
	{
	  fprintf (stderr,
		   "\nerror: Invalid value \"%s\" for TRUE_or_FALSE! [set_set_interpolation_only_rbf]\n",
		   TRUE_or_FALSE);
	  exit (-1);
	}
    }
  else
    {
      fprintf (stderr,
	       "\nerror: Invalid local method type \"%s\"! [set_interpolation_only_rbf]\n",
	       method->type);
      exit (-1);
    }
}

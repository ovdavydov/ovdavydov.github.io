/* Local least squares polynomial approximation as described in

 O. Davydov, On the approximation power of local least squares polynomials, 
 in  "Algorithms for Approximation IV," (J.Levesley, I.J.Anderson and 
 J.C.Mason, Eds.), pp.346-353, University of Huddersfield, UK, 2002.

 O. Davydov and F. Zeilfelder, Scattered data fitting by direct extension 
 of local polynomials to bivariate splines, Advances in Comp. Math. 21 (2004), 
 223-271.
 
  Author: Oleg Davydov
	  University of Strathclyde
	  Department of Mathematics
          26 Richmond Street
	  Glasgow G1 1XH
	  Scotland, UK
	  e-mail: oleg.davydov@strath.ac.uk


  Copyright (C) 2005, 2012 Oleg Davydov

This file is part of TSFIT.

This package is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This package is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this package; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>


#include "datamng.h"

#include "locsearch.h"
#include "bezier.h"
#include "linalg.h"
#include "locpoly.h"


#ifndef MAXDOUBLE
#define MAXDOUBLE 1.79769313486231570e+308
#endif


/* #define CHECK_NUM_STABILITY */



/* procedure for degree adaptation.
Note that singular value decomposition is not
computed in case of degree 0.  */
void
adapt_poly_degree (LOCALDATA * locPoints, LACONTROL * lacontr)
{
  BBTRI *baseTri = lacontr->baseTri;
  double minsv;
  int i, nsuit;


  /*  choose the initial degree of the local polynomial depending
     on the parameters and the number of local points */

  baseTri->degree = (int) (sqrt (2 * locPoints->number + .25) - 1.5);

  if (baseTri->degree > lacontr->starting_degree)
    baseTri->degree = lacontr->starting_degree;


  baseTri->dim = (baseTri->degree + 1) * (baseTri->degree + 2) / 2;


  /* determine a suitable degree */

  while (baseTri->degree > 0)
    {

      fill_BBbasis_matr (lacontr->locMatr->A, baseTri->degree,
			 baseTri->triangle, locPoints->number,
			 locPoints->x, locPoints->y, lacontr->trinom);

      /* compute the singular value decomposition  */

      lacontr->locMatr->m = locPoints->number;
      lacontr->locMatr->n = baseTri->dim;

      compute_svd (lacontr->locMatr);


      /* count suitable singular values */

      minsv = lacontr->min_sing_value;

      nsuit = 0;

      for (i = 0; i < baseTri->dim; i++)
	if (lacontr->locMatr->sv[i] > minsv)
	  nsuit++;

      if (nsuit == baseTri->dim)	/* leave the loop */
	break;

      /* new suitable degree */

      baseTri->degree = (int) (sqrt (2 * nsuit + .25) - 1.5);

      /* update baseTri->dim */

      baseTri->dim = (baseTri->degree + 1) * (baseTri->degree + 2) / 2;

    }

#ifdef CHECK_NUM_STABILITY
#ifndef min
#define min(a,b) ( (a) < (b) ? (a) : (b) )
#endif

#ifndef max
#define max(a,b) ( (a) > (b) ? (a) : (b) )
#endif

  if (baseTri->degree == 0)
    lacontr->max_cond = max (lacontr->max_cond, 1.0);
  else
    {
      double sv_max = -MAXDOUBLE;
      double sv_min = MAXDOUBLE;

      for (i = 0; i < baseTri->dim; i++)
	{
	  sv_max = max (sv_max, lacontr->locMatr->sv[i]);
	  sv_min = min (sv_min, lacontr->locMatr->sv[i]);
	}

      lacontr->max_cond = max (lacontr->max_cond, sv_max / sv_min);


    }


#endif /* CHECK_NUM_STABILITY */


}


/* local polynomial approximations */


void
compute_poly_loc_appr (void *data_void, void *lcontr_void)
{
  TSFIT_DATA *data = (TSFIT_DATA *) data_void;
  LACONTROL *lacontr = (LACONTROL *) lcontr_void;
  LOCALDATA *locPoints = (lacontr->lscontr)->locPoints;
  TRIEL *element = lacontr->locale;
  TRIANGLE *triangle = &(element->triangle);
  BBTRI *baseTri = lacontr->baseTri;
  int i;

  /* choose points for local approximation */

  choose_loc_points (data, lacontr->lscontr, triangle->xc, triangle->yc,
		     triangle->diam);

  /* set the vertices of baseTri */

  baseTri->triangle = triangle;

  /* find suitable polynomial degree */

  adapt_poly_degree (locPoints, lacontr);

  /* Compute the BB coefs of the solution */

  if (baseTri->degree == 0)
    {

      /* least squares constant is the average of the z-values
         of local points */
      double *zz = locPoints->z;

      (baseTri->coefs)[0] = 0.0;

      for (i = 0; i < locPoints->number; i++)
	(baseTri->coefs)[0] += zz[i];

      (baseTri->coefs)[0] /= locPoints->number;


    }
  else
    LS_using_svd (lacontr->locMatr, locPoints->z, baseTri->coefs);


  element->degree = baseTri->degree;

  element->coefs = baseTri->coefs;	/* this cannot be done once and for all
					   when initializing the local method since
					   degree raising converter changes
					   element->coefs */


  /* local degree info */

  (lacontr->degree_stat)[baseTri->degree]++;

}







/* Allocate memory for data structures used for local approximation;
 max_number is the maximal possible number of local points for
 memory allocation */

void
init_poly_loc_appr (void *lcontr_void)
{
  LACONTROL *lacontr = (LACONTROL *) lcontr_void;
  int max_number;
  int i;
  BBTRI *baseTri;
  int max_loc_dim = lacontr->max_loc_dim;


  init_loc_search (lacontr->lscontr);

  lacontr->max_number = max_number = lacontr->lscontr->locPoints->max_number;


  lacontr->coefs = (double *) malloc (max_loc_dim * sizeof (double));

  if (lacontr->coefs == NULL)
    {
      fprintf (stderr, "error: memory allocation failure [init_poly_loc_appr]\n");
      exit (-1);
    }





  /* allocate memory for the field 'locMatr' */

  lacontr->locMatr = init_svdmatr (max_number, max_loc_dim);

  /* set the type of the SVD to 'S' since it is faster than 'A' when
     using LAPACK. Note that Numerical Recipes provide no analogue of 'A'
     since their SVD routine never compute the full matrix U */

  lacontr->locMatr->type = 'S';

  /* initialize lacontr->trinom */

  lacontr->trinom = (TRINOM *) malloc (sizeof (TRINOM));
  if (lacontr->trinom == NULL)
    {
      fprintf (stderr, "error: memory allocation failure [init_poly_loc_appr]\n");
      exit (-1);
    }

  init_trinom (lacontr->trinom, lacontr->max_degree);

  /* initialize the field 'baseTri' */

  baseTri = lacontr->baseTri =
    init_baseTri (lacontr->starting_degree, lacontr->coefs);



  baseTri->max_dim =
    (lacontr->starting_degree + 1) * (lacontr->starting_degree + 2) / 2;


  /* memory for the degree info */

  lacontr->degree_stat =
    (int *) malloc ((lacontr->starting_degree + 1) * sizeof (int));
  if (lacontr->degree_stat == NULL)
    {
      fprintf (stderr, "error: memory allocation failure [lacontr]\n");
      exit (-1);
    }

  for (i = 0; i <= lacontr->starting_degree; i++)
    (lacontr->degree_stat)[i] = 0;

  lacontr->max_cond = -MAXDOUBLE;



}



/* free the memory used for local structures  */

void
free_poly_loc_appr (void *lcontr_void)
{
  LACONTROL *lacontr = (LACONTROL *) lcontr_void;






  free_loc_search (lacontr->lscontr);

  free_trinom (lacontr->trinom);
  free (lacontr->trinom);

  free_svdmatr (lacontr->locMatr);
  free (lacontr->locMatr);

  free (lacontr->coefs);



  free_baseTri (lacontr->baseTri);
  free (lacontr->baseTri);

  free (lacontr->degree_stat);
}

/* Interface to a third party linear algebra package: CLAPACK.
 
  Author: Oleg Davydov
	  University of Strathclyde
	  Department of Mathematics
          26 Richmond Street
	  Glasgow G1 1XH
	  Scotland, UK
	  e-mail: oleg.davydov@strath.ac.uk


  Copyright (C) 2005, 2012 Oleg Davydov

This file is part of TSFIT.

This package is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This package is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this package; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

/* WARNINGS: 1) We assume that matrices used are small and therefore we do not
try to save memory or exploit any sparse structure of the matrices. 
2) The matrices are stored according to C standard: row by row. 
3) Ua, Ut and Vt entries in the structure SVDMATR are used sometimes instead of U, V.
It should be OK to allocate them even if they are not always needed -- since our matrices 
are small, see above. */



typedef struct
{
  /* used for computing SVD: A = U S V^T, where S=diag(sv) */
  char type;                    /* Info on what has been actually computed: only sv or
                                (some) singular vectors, etc. We use the same
				letters as 'jobz' in the routine SGESDD/DGESDD of LAPACK. */
  int m;			/* actual number of rows */
  int n;			/* actual number of columns */
  int max_m;			/* maximal number of rows (for memory allocation) */
  int max_n;			/* maximal number of columns (for memory allocation) */
  double **A;			/* the main (max_m) x (max_n) - matrix (to be decomposed) */
  double *a;			/* points to the same matrix as **A, but as 1D array (used for 
				   contiguous allocation) */
  double **At;			/* (max_n) x (max_m) - matrix: the transpose of A */
  double *at;			/* points to the same matrix as **At, but as 1D array (used for 
				   contiguous allocation) */
  double **V;			/* (max_n) x (max_n) - matrix of right singular vectors */
  double *v;			/* points to the same matrix as **V, but as 1D array (used for 
				   contiguous allocation) */
  double **U;			/* (max_m) x (max_m) - matrix of left singular vectors */
  double *u;			/* points to the same matrix as **U, but as 1D array (used for 
				   contiguous allocation) */
  double *sv;			/* min{max_m, max_n} - vector of singular values */
  double **Ua;			/* abridged (max_m) x (max_n) - matrix of first (max_n)
                                   left singular vectors; makes sense only if max_n < max_m;
				   remaining singular vectors (those _not_ in Ua) build an orthogonal
				   basis for the null space of A */
  double *ua;			/* points to the same matrix as **Ua, but as 1D array (used for 
				   contiguous allocation) */
  double **Ut;			/* (max_m) x (max_m) - matrix: the transpose of U */
  double *ut;			/* points to the same matrix as **Ut, but as 1D array (used for 
				   contiguous allocation) */
  double **Vt;			/* (max_n) x (max_n) - matrix: the transpose of V */
  double *vt;			/* points to the same matrix as **Vt, but as 1D array (used for 
				   contiguous allocation) */
  double *xx;                   /* max_n-vector used with 'LS_using_svd' */
} SVDMATR;


SVDMATR *init_svdmatr (int max_m, int max_n);
void free_svdmatr (SVDMATR * matr);


/* compute the SVD of the collocation matrix */
void compute_svd (SVDMATR * locMatr);

/* compute least squares approximation using precomputed svd of the
full rank collocation matrix */
void LS_using_svd (SVDMATR * locMatr, double b[], double x[]);


void LSE_solver (double *x, int m, int n, int q,
		 double **A, double **B, double *c, double *d);
void
m_times_v (int m, int n, 
            double *a, int lda, 
	    double *x, double *y);
		 
void
mt_times_v (int m, int n, 
            double *a, int lda, 
	    double *x, double *y);
	    
void
m_times_mt (int m, int n, int k, 
            double *a, int lda, 
	    double *b, int ldb, 
	    double *c, int ldc);


#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "tsfit.h"

int
main ()
{
  TSFIT_DATA data;
  TSFIT_LOCAL_METHOD local_method;
  TSFIT_GLOBAL_METHOD global_method;

  FILE *fp;
  int num, n;
  double *px, *py, *pz, *xx, *yy, *zz;
  double comp_cputime;
  int cl;

  fprintf (stderr, "\n\nTests with Franke's function f1 evaluated at 100 points ds3.\n\n");

  fprintf (stderr, "\n\nTSFIT Example 3: local polynomials with C1 and C2 splines\n");
  fprintf (stderr, "\nMethods described in ");
  fprintf (stderr, "\nDavydov & Zeilfelder, Scattered data fitting by direct extension\
        \nof local polynomials to bivariate splines, Advances in Comp. Math. 21 (2004), 223-271.");
  fprintf (stderr, "\n(See numerical results in Section 6.3.)");

  /*** read the data ***/


  /* open the file containing data points */

  fp = fopen ("f1_ds3", "r");

  if (fp == NULL)
    {
      fprintf (stderr, "error: file opening failure\n");
      exit (-1);
    }

  /* read the number of data points from the first line of the data file fp */

  fscanf (fp, "%d", &num);

  /* allocate memory for x, y, z arrays */


  if ((px = xx =
       (double *) malloc (num * sizeof (double))) == NULL)
    {
      fprintf (stderr, "error: memory allocation failure [x]\n");
      exit (-1);
    }
  if ((py = yy =
       (double *) malloc (num * sizeof (double))) == NULL)
    {
      fprintf (stderr, "error: memory allocation failure [y]\n");
      exit (-1);
    }
  if ((pz = zz =
       (double *) malloc (num * sizeof (double))) == NULL)
    {
      fprintf (stderr, "error: memory allocation failure [z]\n");
      exit (-1);
    }


  /* fill in the x, y, z arrays */


  for (n = 0; n < num; n++)
    fscanf (fp, "%lf %lf %lf", px++, py++, pz++);

  fclose (fp);

  /*** set up the data management structure ***/
  
  init_tsfit_data (&data, num, xx, yy, zz);


  fprintf (stderr, "\n\n(a) 6x6 C1 spline Q_1^av\n\n");

  /*** determine the local method ***/


  /** choose the type of the local method **/ 

  set_local_method_type (&local_method, "polynomial");
  

  /** set parameters of the local method **/

  /* local search parameters */
  
  set_min_points (&local_method, 3);
  set_max_points (&local_method, 100);

  /* local polynomial approximation parameters */
  
  set_starting_degree (&local_method, 3);
  set_min_sing_value_poly (&local_method, 1.0 / 32.0);


  /*** determine the global method ***/


  /** choose the type of the global method **/

  set_global_method_type (&global_method, "SpC1d3D2");
  
  /** set parameters of the global method **/
  
  set_D2mesh (&global_method, &data, 6, 6);
  
  

  /*** compute the spline ***/

  cl = clock();    /* reset clock */ 

  tsfit_compute (&data, &global_method, &local_method);
  
  comp_cputime = (double) (clock()-cl) / CLOCKS_PER_SEC;

  fprintf(stderr, "\n\nCOMPUTATION CPUTIME: %1.2e sec\n\n",comp_cputime);


  /*** Evaluation  ***/

  evaluate_grid (0.0, 1.0, 100, 0.0, 1.0, 100, "output3a.txt", &data, &global_method);



  fprintf (stderr, "\n\n(b) 5x5 C2 spline RQ_2^av\n\n");

  /*** determine the local method ***/


  /** reset the local method **/ 

  reset_local_method_type (&local_method, "polynomial");
  

  /** set parameters of the local method **/

  /* local searching parameters */
  
  set_min_points (&local_method, 16);
  set_max_points (&local_method, 100);

 
  /* local polynomial approximation parameters */
  
  set_starting_degree (&local_method, 6);
  set_min_sing_value_poly (&local_method, 1.0 / 32.0);



  /*** determine the global method ***/

  /** reset the global method **/

  reset_global_method_type (&global_method, "SpC2d6D2");
  
  /** set parameters of the global method **/
  
  set_D2mesh (&global_method, &data, 5, 5);

  /*** compute the spline ***/

  cl = clock();    /* reset clock */ 

  tsfit_compute (&data, &global_method, &local_method);
  
  comp_cputime = (double) (clock()-cl) / CLOCKS_PER_SEC;

  fprintf(stderr, "\n\nCOMPUTATION CPUTIME: %1.2e sec\n\n",comp_cputime);


  /*** Evaluation  ***/

  evaluate_grid (0.0, 1.0, 100, 0.0, 1.0, 100, "output3b.txt", &data, &global_method);




  /*** Release the memory ***/

  reset_global_method_type (&global_method, NULL);

  reset_local_method_type (&local_method, NULL);

  free_tsfit_data (&data);
  
  free (xx);
  free (yy);
  free (zz);
  

  return 0;
}

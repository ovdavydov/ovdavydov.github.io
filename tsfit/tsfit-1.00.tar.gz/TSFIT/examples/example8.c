#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>

#include "tsfit.h"

int
main ()
{
  TSFIT_DATA data;
  TSFIT_DATA cleaned_data;
  TSFIT_GLOBAL_METHOD global_method;
  TSFIT_LOCAL_METHOD local_method;

  FILE *fp;
  int n, num, cnum;
  double *orig_x, *orig_y, *orig_z;
  double *px, *py, *pz, *xx, *yy, *zz, *cxx, *cyy, *czz;
  double *errors;
  double d,rms;
  int k;
  double comp_cputime;
  int cl;


  fprintf (stderr, "\n\nTSFIT example 8: Test with Rotterdam Port data\n");
  fprintf (stderr, "Davydov & Zeilfelder, Scattered data fitting by direct extension\
        \n   of local polynomials to bivariate splines, Section 6.6\n\n");


  fprintf (stderr, "\
  \n  (a) data cleaning using local polynomials and 40x109 C1-spline\
  \n  (b) final approximation using local polynomials and 100x281 C1-spline\n\n");

  /*** read the data ***/


  /* open the file containing data points */

  fp = fopen ("data_sets/RotterdamPort_raw", "r"); 

  if (fp == NULL)
    {
      fprintf (stderr, "error: file opening failure\n");
      exit (-1);
    }

  /* read the number of data points from the first line of the data file fp */

  fscanf (fp, "%d", &num);

  /* allocate memory for original x, y, z arrays */


  if ((px = orig_x =
       (double *) malloc (num * sizeof (double))) == NULL)
    {
      fprintf (stderr, "error: memory allocation failure [x]\n");
      exit (-1);
    }
  if ((py = orig_y =
       (double *) malloc (num * sizeof (double))) == NULL)
    {
      fprintf (stderr, "error: memory allocation failure [y]\n");
      exit (-1);
    }
  if ((pz = orig_z =
       (double *) malloc (num * sizeof (double))) == NULL)
    {
      fprintf (stderr, "error: memory allocation failure [z]\n");
      exit (-1);
    }


  /* fill in the orig_x, orig_y, orig_z arrays */


  for (n = 0; n < num; n++)
    fscanf (fp, "%lf %lf %lf", px++, py++, pz++);

  fclose (fp);

  /*** set up the data management structure ***/


  /* allocate memory for auxiliary xx, yy, zz arrays */


  if ((xx =
       (double *) malloc (num * sizeof (double))) == NULL)
    {
      fprintf (stderr, "error: memory allocation failure [x]\n");
      exit (-1);
    }
  if ((yy =
       (double *) malloc (num * sizeof (double))) == NULL)
    {
      fprintf (stderr, "error: memory allocation failure [y]\n");
      exit (-1);
    }
  if ((zz =
       (double *) malloc (num * sizeof (double))) == NULL)
    {
      fprintf (stderr, "error: memory allocation failure [z]\n");
      exit (-1);
    }

  /* copy the data to xx, yy, zz to keep orig_x, etc. unchanged */

  memcpy (xx, orig_x, num * sizeof (double));
  memcpy (yy, orig_y, num * sizeof (double));
  memcpy (zz, orig_z, num * sizeof (double));

  init_tsfit_data (&data, num, xx, yy, zz);

  
  /****  COARSE APPROXIMATION ****/

  fprintf (stderr, "\n\nCOARSE APPROXIMATION\n\n");


  /*** determine the local method ***/


  /** choose the type of the local method **/ 

  set_local_method_type (&local_method, "polynomial");
  

  /** set parameters of the local method **/

  /** set parameters of the local method **/

  /* local search parameters */
  
  set_min_points (&local_method, 300);
  set_max_points (&local_method, 100);

  /* local polynomial approximation parameters */
  
  set_starting_degree (&local_method, 1);
  set_min_sing_value_poly (&local_method, 1.0 / 0.5);



  /*** determine the global method ***/


  /** choose the type of the global method **/

  set_global_method_type (&global_method, "SpC1d3D2");
  
  /** set parameters of the global method **/
  
  set_D2mesh (&global_method, &data, 40, 109);

 
  /*** compute the spline ***/

  cl = clock();    /* reset clock */ 

  tsfit_compute (&data, &global_method, &local_method);

  comp_cputime = (double) (clock()-cl) / CLOCKS_PER_SEC;

  fprintf(stderr, "\n\nCOMPUTATION CPUTIME: %1.2e sec\n\n",comp_cputime);



  /*** Data cleaning ***/
  
  /* compute the error vector (scaled!) and rms */

  if ((errors =
       (double *) malloc (num * sizeof (double))) == NULL)
    {
      fprintf (stderr, "error: memory allocation failure [errors]\n");
      exit (-1);
    }
  
  rms = 0.0;
  
  for (n=0; n < num; n++)
    {
      d = errors[n] =  orig_z[n] 
                       - evaluate_point(orig_x[n], orig_y[n], &data, &global_method);
      rms += d * d;
    
    }
 
  rms /= num;
  rms = sqrt(rms);
  

  /* clean the data */


  if ((cxx =
       (double *) malloc (num * sizeof (double))) == NULL)
    {
      fprintf (stderr, "error: memory allocation failure [cleaned_data->x]\n");
      exit (-1);
    }
  if ((cyy =
       (double *) malloc (num * sizeof (double))) == NULL)
    {
      fprintf (stderr, "error: memory allocation failure [cleaned_data->y]\n");
      exit (-1);
    }
  if ((czz =
       (double *) malloc (num * sizeof (double))) == NULL)
    {
      fprintf (stderr, "error: memory allocation failure [cleaned_data->z]\n");
      exit (-1);
    }


  k = 0;
  

  for (n=0; n < num; n++) 
    if (fabs(errors[n])  < rms) 
      {
	cxx[k] = orig_x[n];
	cyy[k] = orig_y[n];
	czz[k] = orig_z[n];
	k++;
      }


  cnum = k;

  fprintf (stderr, "\n\nData cleaning completed (%i points removed)\n\n",
                  num - cnum);
  
  /*** free memory used for cleaning ***/

  free (errors);
  
  free_tsfit_data (&data);
  free (xx);
  free (yy);
  free (zz);
  
  
  
  /****  FINE APPROXIMATION ****/
  
  fprintf (stderr, "\n\nFINE APPROXIMATION\n\n");
  
  init_tsfit_data (&cleaned_data, cnum, cxx, cyy, czz);

  
  /** reset the local method **/ 

  reset_local_method_type (&local_method, "polynomial");
  
  /** set parameters of the local method **/

  /* local search parameters */
  
  set_min_points (&local_method, 3);
  set_max_points (&local_method, 49);

  /* local polynomial approximation parameters */
  
  set_starting_degree (&local_method, 3);
  set_min_sing_value_poly (&local_method, 1.0 / 5.0);


  /** reset the global method **/

  reset_global_method_type (&global_method, "SpC1d3D2");
  
  /** set parameters of the global method **/
  
  set_D2mesh (&global_method, &cleaned_data, 100, 281);




  /*** compute the spline ***/

  cl = clock();    /* reset clock */ 


  tsfit_compute (&cleaned_data, &global_method, &local_method);

  comp_cputime = (double) (clock()-cl) / CLOCKS_PER_SEC;

  fprintf(stderr, "\n\nCOMPUTATION CPUTIME: %1.2e sec\n\n",comp_cputime);



 
  /*** Evaluation  ***/

  evaluate_grid (40.0, 270.0, 400, 
                 40.0, 970.0, 1617, 
		 "output8.txt", &cleaned_data, &global_method);


 
  /*** Release the memory ***/


  reset_global_method_type (&global_method, NULL);

  reset_local_method_type (&local_method, NULL);

  free_tsfit_data (&cleaned_data);

  free (cxx);
  free (cyy);
  free (czz);

  free (orig_x);
  free (orig_y);
  free (orig_z);

  return 0;
}

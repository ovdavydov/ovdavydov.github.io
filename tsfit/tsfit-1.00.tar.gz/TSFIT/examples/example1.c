#include <stdio.h>
#include <stdlib.h>

#include "tsfit.h"

int
main ()
{
  TSFIT_DATA data;
  TSFIT_LOCAL_METHOD local_method;
  TSFIT_GLOBAL_METHOD global_method;

  FILE *fp;
  int num, n;
  double *px, *py, *pz, *xx, *yy, *zz;

  fprintf (stderr, "\n\nTest with Franke's function f1 evaluated at 100 points ds3.\n\n");

  fprintf (stderr, "\n\nTSFIT Example 1: local rbf (multiquadric, interpolating) and 5x5 C2-spline RQ_2^av\n");
  fprintf (stderr, "\nLocal rbf method described in ");
  fprintf (stderr, "\nDavydov, Sestini & Morandi,  Local RBF approximation for scattered \
         \ndata fitting with bivariate splines, Proceedings of IDoMAT 2004, to appear.\n");
  fprintf (stderr, "\nC2 spline method described in ");
  fprintf (stderr, "\nDavydov & Zeilfelder, Scattered data fitting by direct extension\
        \nof local polynomials to bivariate splines, Advances in Comp. Math. 21 (2004), 223-271.\n\n");


  /*** read the data ***/


  /* open the file containing data points */

  fp = fopen ("f1_ds3", "r");

  if (fp == NULL)
    {
      fprintf (stderr, "error: file opening failure\n");
      exit (-1);
    }

  /* read the number of data points from the first line of the data file fp */

  fscanf (fp, "%d", &num);

  /* allocate memory for x, y, z arrays */


  if ((px = xx =
       (double *) malloc (num * sizeof (double))) == NULL)
    {
      fprintf (stderr, "error: memory allocation failure [x]\n");
      exit (-1);
    }
  if ((py = yy =
       (double *) malloc (num * sizeof (double))) == NULL)
    {
      fprintf (stderr, "error: memory allocation failure [y]\n");
      exit (-1);
    }
  if ((pz = zz =
       (double *) malloc (num * sizeof (double))) == NULL)
    {
      fprintf (stderr, "error: memory allocation failure [z]\n");
      exit (-1);
    }


  /* fill in the x, y, z arrays */


  for (n = 0; n < num; n++)
    fscanf (fp, "%lf %lf %lf", px++, py++, pz++);

  fclose (fp);

  /*** set up the data management structure ***/
  
  init_tsfit_data (&data, num, xx, yy, zz);


  /*** determine the local method ***/


  /** choose the type of the local method **/ 

  set_local_method_type (&local_method, "RBF");
  

  /** set parameters of the local method **/

  /* local searching parameters */
  
  set_min_points (&local_method, 20);
  set_max_points (&local_method, 100);

  /* local rbf approximation parameters */
 
  set_radial_basis_function (&local_method, 0, &rbf_MQ);
  set_scaling_coef (&local_method, 0.5);
  set_separation_rbf (&local_method, 25.0);
  set_interpolation_only_rbf (&local_method, "TRUE");


  /*** determine the global method ***/

  /** choose the type of the global method **/

  set_global_method_type (&global_method, "SpC2d6D2");
  
  /** set parameters of the global method **/
  
  set_D2mesh (&global_method, &data, 5, 5);
  

  /*** compute the spline ***/


  tsfit_compute (&data, &global_method, &local_method);


  /*** Evaluation  ***/

  evaluate_grid (0.0, 1.0, 100, 0.0, 1.0, 100, "output1.txt", &data, &global_method);



  /*** Release the memory ***/

  reset_global_method_type (&global_method, NULL);

  reset_local_method_type (&local_method, NULL);

  free_tsfit_data (&data);
  
  free (xx);
  free (yy);
  free (zz);
  

  return 0;
}

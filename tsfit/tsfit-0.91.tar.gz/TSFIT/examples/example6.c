#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "tsfit.h"

int
main ()
{
  TSFIT_DATA data;
  TSFIT_LOCAL_METHOD local_method;
  TSFIT_GLOBAL_METHOD global_method;

  FILE *fp;
  int num, n;
  double *px, *py, *pz, *xx, *yy, *zz;
  double comp_cputime;
  int cl;


  fprintf (stderr, "\n\nTSFIT Example 6: Test with glacier"); 

  fprintf (stderr, "\n(using local hybrid approximation and 20x24 C2-spline RQ_2^av)");
  fprintf (stderr, "\nLocal hybrid method described in ");
  fprintf (stderr, "\nDavydov, Morandi & Sestini,  Local hybrid approximation for scattered \
         \ndata fitting with bivariate splines, preprint, August 2004.");
  fprintf (stderr, "\n(See numerical results in Section 5.3.)");
  fprintf (stderr, "\nC2 spline method described in ");
  fprintf (stderr, "\nDavydov & Zeilfelder, Scattered data fitting by direct extension\
        \nof local polynomials to bivariate splines, Advances in Comp. Math. 21 (2004), 223-271.");

  /*** read the data ***/


  /* open the file containing data points */

  fp = fopen ("data_sets/glacier", "r");

  if (fp == NULL)
    {
      fprintf (stderr, "error: file opening failure\n");
      exit (-1);
    }

  /* read the number of data points from the first line of the data file fp */

  fscanf (fp, "%d", &num);

  /* allocate memory for x, y, z arrays */


  if ((px = xx =
       (double *) malloc (num * sizeof (double))) == NULL)
    {
      fprintf (stderr, "error: memory allocation failure [x]\n");
      exit (-1);
    }
  if ((py = yy =
       (double *) malloc (num * sizeof (double))) == NULL)
    {
      fprintf (stderr, "error: memory allocation failure [y]\n");
      exit (-1);
    }
  if ((pz = zz =
       (double *) malloc (num * sizeof (double))) == NULL)
    {
      fprintf (stderr, "error: memory allocation failure [z]\n");
      exit (-1);
    }


  /* fill in the x, y, z arrays */


  for (n = 0; n < num; n++)
    fscanf (fp, "%lf %lf %lf", px++, py++, pz++);

  fclose (fp);

  /*** set up the data management structure ***/
  
  init_tsfit_data (&data, num, xx, yy, zz);


  /*** determine the local method ***/


  /** choose the type of the local method **/ 

  set_local_method_type (&local_method, "Hybrid");
  

  /** set parameters of the local method **/

  /* local search parameters */
  
  set_min_points (&local_method, 60);
  set_max_points (&local_method, 160);

 /* local hybrid approximation parameters */
 
  set_radial_basis_function (&local_method, 0, &rbf_MQ);
  set_scaling_coef (&local_method, 0.4);
  set_min_sing_value_hybrid (&local_method, 1.0 / 100000.0);


  /*** determine the global method ***/


  /** choose the type of the global method **/

  set_global_method_type (&global_method, "SpC2d6D2");
  
  /** set parameters of the global method **/
  
  set_D2mesh (&global_method, &data, 20, 24);
  
  

  /*** compute the spline ***/

  cl = clock();    /* reset clock */ 

  tsfit_compute (&data, &global_method, &local_method);
  
  comp_cputime = (double) (clock()-cl) / CLOCKS_PER_SEC;

  fprintf(stderr, "\n\nCOMPUTATION CPUTIME: %1.2e sec\n\n",comp_cputime);


  /*** Evaluation  ***/

  evaluate_grid (9.0, 16.5, 300, 
                 4.0, 13.5, 380, 
		 "output6.txt", &data, &global_method);




  /*** Release the memory ***/

  reset_global_method_type (&global_method, NULL);

  reset_local_method_type (&local_method, NULL);

  free_tsfit_data (&data);
  
  free (xx);
  free (yy);
  free (zz);
  

  return 0;
}

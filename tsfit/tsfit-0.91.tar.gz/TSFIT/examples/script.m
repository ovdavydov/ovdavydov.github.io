% Matlab/Octave script: will display the Franke function and approximation
% using evaluations on a 101x101 grid (f1.txt and output1.txt).
% Replace 'output1' with 'output2a' to display output2a.txt, etc.
% Note: mesh(Y,X,.. is used rather than mesh(X,Y,.. to ensure that
% Octave produces the standard view of the Franke function. 
clear
spline = 'output1'

% 3D plot of Franke function and spline 
% (rotated to get the standard view of f1)
[X,Y]=meshgrid(0:.01:1); load f1.txt, figure(1);  mesh(Y,X,f1(:,101:-1:1)), title('Franke function')
load([spline,'.txt']), SP=eval(spline); figure(2); mesh(Y,X,SP(:,101:-1:1)), title('spline')
% contor plots
c=min(min(f1)):.04:max(max(f1));
figure(4); contour(0:.01:1,0:.01:1,f1,c), title('Franke function')
figure(5); contour(0:.01:1,0:.01:1,SP,c), title('spline'), 
% 3D plot of the error
figure(3);  mesh(Y,X,f1(:,101:-1:1)-SP(:,101:-1:1)), title('error')
% max, rms and mean errors on the grid
max=norm(reshape(f1-SP,1,10201),Inf)
rms=norm(reshape(f1-SP,1,10201),2)/101
mean=norm(reshape(f1-SP,1,10201),1)/10201

/* Routines for triangle Bezier patches: de Casteljau algorithm, 
degree raising, etc. as described e.g. in 
 G. Farin, Curves and Surfaces for CAGD: a practical guide, 5th edition,
 Morgan Kaufmann Publishers Inc., San Francisco, CA, USA, 2001.
 
  Author: Oleg Davydov
	  University of Strathclyde
	  Department of Mathematics
          26 Richmond Street
	  Glasgow G1 1XH
	  Scotland, UK
	  e-mail: oleg.davydov@strath.ac.uk


  Copyright (C) 2005 Oleg Davydov

This file is part of TSFIT.

This package is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This package is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this package; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

/** routines for Bernstein-Bezier techniques **/


/* triangle */

typedef struct
{
  double x1, y1, x2, y2, x3, y3;	/* vertices of the triangle */
  double xc, yc;		/* center */
  double diam;			/* diameter */
} TRIANGLE;



/* Bezier triangle, especially for evaluation */

typedef struct
{
  int max_degree;		/* maximal degree for memory allocation */
  int max_dim;			/* maximal length of the 'coefs' array for memory allocation */
  TRIANGLE *triangle;		/* triangle geometry */
  int degree;			/* actual degree of the basis */
  int dim;			/* actual number of coefficients */
  double *coefs;		/* array of Bernstein-Bezier coefficients */
  double *c;			/* auxiliary array for the de Casteljau 
				   algorithm */
/*
 * ordering of BB coefs in 'coefs':
 *   
 *   1--->2
 *    -->
 *    ->
 *    3
 */
} BBTRI;


/* triangle locpoly/spline-interface element; degrees of freedom are BB
coefficients ordered as in the diagram above */

typedef struct
{
  TRIANGLE triangle;		/* triangle geometry */
  int degree;			/* polynomial degree of the element */
  double *coefs;		/* pointer to where coefficients must be written */
  int i, j, k;			/* "coordinates" of the current triangle in the triangulation: useful for uniform
				   and "structured" triangulations like checkerboard */
} TRIEL;

/* trinomial coefficients in a "Pascal pyramid";
used by 'eval_BB_basis_functions' */

typedef struct
{
  int max_degree;		/* maximum degree for which the coefs are computed */
  double **coefs;
} TRINOM;



/* routines for external use */


void find_tri_center (TRIANGLE * triangle);
void find_tri_diam (TRIANGLE * triangle);
void tri_desc2bary (double x, double y,
		double *b1, double *b2, double *b3, TRIANGLE * tri);
void tri_bary2desc (double b1, double b2, double b3,
		double *x, double *y, TRIANGLE * tri);

		
double bbtri_deCast (double b1, double b2, double b3, BBTRI * tri);
void bbtri_raise_degree (int degree_in, double *coefs_in,
		   int degree_out, double *coefs_out);
		   
BBTRI *init_baseTri (int max_degree, double *coefs);
void free_baseTri (BBTRI * baseTri);

/* functions for the evaluation of BB basis functions */
void init_trinom (TRINOM * trinom, int max_degree);
void free_trinom (TRINOM * trinom);
void eval_BB_basis_functions (int degree, double b1, double b2, double b3,
			      double *values, TRINOM * trinom);
void fill_BBbasis_matr (double **A,
			int degree, TRIANGLE * triangle,
			int num, double *x, double *y, TRINOM * trinom);

/* Management of the second stage ("global") methods.
 
  Author: Oleg Davydov
	  University of Strathclyde
	  Department of Mathematics
          26 Richmond Street
	  Glasgow G1 1XH
	  Scotland, UK
	  e-mail: oleg.davydov@strath.ac.uk


  Copyright (C) 2005 Oleg Davydov

This file is part of TSFIT.

This package is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This package is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this package; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

typedef struct
{
  char type[1000];
  char locale_type[1000];
  void *body;
  void *locale;
  void (*init) (void *body);
  void (*free) (void *body);
  void (*compute) (void *data, void *body,
		   TSFIT_LOCAL_METHOD * local_method,
		   TSFIT_CONVERTER * converter);
  double (*eval) (double x, double y, void *body);
} TSFIT_GLOBAL_METHOD;

void set_global_method_type (TSFIT_GLOBAL_METHOD * method, char *type);
void reset_global_method_type (TSFIT_GLOBAL_METHOD * method, char *type);

void tsfit_compute (TSFIT_DATA * data, TSFIT_GLOBAL_METHOD * global_method,
		    TSFIT_LOCAL_METHOD * local_method);

void set_D2mesh (TSFIT_GLOBAL_METHOD * method, TSFIT_DATA * data, int n, int m);
void set_averaging (TSFIT_GLOBAL_METHOD * method, char *TRUE_or_FALSE);
void set_supersmooth (TSFIT_GLOBAL_METHOD * method, char *TRUE_or_FALSE);
double evaluate_point (double x, double y, TSFIT_DATA * data,
                       TSFIT_GLOBAL_METHOD * method);
void evaluate_grid (double xl, double xr, int n, 
        	    double yl, double yr, int m, 
        	    char *filename,
		    TSFIT_DATA * data, TSFIT_GLOBAL_METHOD * method);

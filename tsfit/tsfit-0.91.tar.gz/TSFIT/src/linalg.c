/* Interface to a third party linear algebra package: CLAPACK.
 
  Author: Oleg Davydov
	  University of Strathclyde
	  Department of Mathematics
          26 Richmond Street
	  Glasgow G1 1XH
	  Scotland, UK
	  e-mail: oleg.davydov@strath.ac.uk


  Copyright (C) 2005 Oleg Davydov

This file is part of TSFIT.

This package is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This package is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this package; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "linalg.h"

/***********************************************************************/
/*          functions and headers from linear algebra packages         */
/***********************************************************************/






#ifndef min
#define min(a,b) ( (a) < (b) ? (a) : (b) )
#endif

#ifndef max
#define max(a,b) ( (a) > (b) ? (a) : (b) )
#endif


/***********************************************************************/
/*                          Functions                                  */
/***********************************************************************/
SVDMATR *
init_svdmatr (int max_m, int max_n)
{
  int i;
  SVDMATR *matr = (SVDMATR *) malloc (sizeof (SVDMATR));

  if (matr == NULL)
    {
      fprintf (stderr, "error: not enough memory! [init_svdmatr]\n");
      exit (-1);
    }


  matr->max_n = max_n;

  matr->max_m = max_m;

  /* the main matrix */

  matr->a = (double *) malloc (max_m * max_n * sizeof (double));

  if (matr->a == NULL)
    {
      fprintf (stderr, "error: not enough memory! [init_svdmatr]\n");
      exit (-1);
    }

  matr->A = (double **) malloc (max_m * sizeof (double *));

  if (matr->A == NULL)
    {
      fprintf (stderr, "error: not enough memory! [init_svdmatr]\n");
      exit (-1);
    }

  (matr->A)[0] = matr->a;
  for (i = 1; i < max_m; i++)
    (matr->A)[i] = (matr->A)[i - 1] + max_n;

  /* the transpose of A */

  matr->at = (double *) malloc (max_m * max_n * sizeof (double));

  if (matr->at == NULL)
    {
      fprintf (stderr, "error: not enough memory! [init_svdmatr]\n");
      exit (-1);
    }

  matr->At = (double **) malloc (max_n * sizeof (double *));

  if (matr->At == NULL)
    {
      fprintf (stderr, "error: not enough memory! [init_svdmatr]\n");
      exit (-1);
    }

  (matr->At)[0] = matr->at;
  for (i = 1; i < max_n; i++)
    (matr->At)[i] = (matr->At)[i - 1] + max_m;
    

  /* the matrix of right singular vectors */

  matr->v = (double *) malloc (max_n * max_n * sizeof (double));

  if (matr->v == NULL)
    {
      fprintf (stderr, "error: not enough memory! [init_svdmatr]\n");
      exit (-1);
    }

  matr->V = (double **) malloc (max_n * sizeof (double *));

  if (matr->V == NULL)
    {
      fprintf (stderr, "error: not enough memory! [init_svdmatr]\n");
      exit (-1);
    }

  (matr->V)[0] = matr->v;
  for (i = 1; i < max_n; i++)
    (matr->V)[i] = (matr->V)[i - 1] + max_n;

  /* the transpose of V */

  matr->vt = (double *) malloc (max_n * max_n * sizeof (double));

  if (matr->vt == NULL)
    {
      fprintf (stderr, "error: not enough memory! [init_svdmatr]\n");
      exit (-1);
    }

  matr->Vt = (double **) malloc (max_n * sizeof (double *));

  if (matr->Vt == NULL)
    {
      fprintf (stderr, "error: not enough memory! [init_svdmatr]\n");
      exit (-1);
    }

  (matr->Vt)[0] = matr->vt;
  for (i = 1; i < max_n; i++)
    (matr->Vt)[i] = (matr->Vt)[i - 1] + max_n;


  /* the matrix of left singular vectors */

  matr->u = (double *) malloc (max_m * max_m * sizeof (double));

  if (matr->u == NULL)
    {
      fprintf (stderr, "error: not enough memory! [init_svdmatr]\n");
      exit (-1);
    }

  matr->U = (double **) malloc (max_m * sizeof (double *));

  if (matr->U == NULL)
    {
      fprintf (stderr, "error: not enough memory! [init_svdmatr]\n");
      exit (-1);
    }

  (matr->U)[0] = matr->u;
  for (i = 1; i < max_m; i++)
    (matr->U)[i] = (matr->U)[i - 1] + max_m;

  /* the transpose of U */

  matr->ut = (double *) malloc (max_m * max_m * sizeof (double));

  if (matr->ut == NULL)
    {
      fprintf (stderr, "error: not enough memory! [init_svdmatr]\n");
      exit (-1);
    }

  matr->Ut = (double **) malloc (max_m * sizeof (double *));

  if (matr->Ut == NULL)
    {
      fprintf (stderr, "error: not enough memory! [init_svdmatr]\n");
      exit (-1);
    }

  (matr->Ut)[0] = matr->ut;
  for (i = 1; i < max_m; i++)
    (matr->Ut)[i] = (matr->Ut)[i - 1] + max_m;

  /* the abridged matrix of left singular vectors */

  matr->ua = (double *) malloc (max_m * max_n * sizeof (double));

  if (matr->ua == NULL)
    {
      fprintf (stderr, "error: not enough memory! [init_svdmatr]\n");
      exit (-1);
    }

  matr->Ua = (double **) malloc (max_m * sizeof (double *));

  if (matr->Ua == NULL)
    {
      fprintf (stderr, "error: not enough memory! [init_svdmatr]\n");
      exit (-1);
    }

  (matr->Ua)[0] = matr->ua;
  for (i = 1; i < max_m; i++)
    (matr->Ua)[i] = (matr->Ua)[i - 1] + max_n;


  /* the vector of singular values */

  matr->sv = (double *) malloc (min (max_n, max_m) * sizeof (double));

  if (matr->sv == NULL)
    {
      fprintf (stderr, "error: not enough memory! [init_svdmatr]\n");
      exit (-1);
    }

  return matr;
}

void
free_svdmatr (SVDMATR * matr)
{

  /* we do not need to free (matr->A)[i] fields
     since they are just pointers to corresponding sites
     in matr->a allocated contiguously;
     the same applies to other matrices */

  free (matr->A);

  free (matr->a);

  free (matr->At);

  free (matr->at);

  free (matr->V);

  free (matr->v);

  free (matr->U);

  free (matr->u);

  free (matr->Ua);

  free (matr->ua);

  free (matr->Ut);

  free (matr->ut);

  free (matr->Vt);

  free (matr->vt);

  free (matr->sv);



  /* free(matr); */



}




/******************************************************************/
/**************************** LAPACK ******************************/
/******************************************************************/



#ifdef LAPACK



extern void dgesdd_ (char *jobz, int *m, int *n, double *a, int *lda, 
        	     double *s, double *u, int *ldu, double *vt, int *ldvt, 
		     double *work, int *lwork, int *iwork, int *info);

extern void dgglse_ (int *m, int *n, int *p, double *a, int *lda, double *b, 
                    int *ldb, double *c, double *d, double *x, double *work, 
		    int *lwork, int *info);
		    
extern void dgemv_ (char *trans, int *m, int *n, double *alpha, double *a, 
                   int *lda, double *x, int *incx, double *beta, double *y, 
		   int *incy);
		   
extern void dgemm_ (char *transa, char *transb, int *m, int *n, int *k, 
                    double *alpha, double *a, int *lda, double *b, int *ldb, 
		    double *beta, double *c, int *ldc);


/**************************** Compute SVD ******************************/

void
LS_using_svd (SVDMATR * locMatr, double b[], double x[])
/* Works with both locMatr->type == 'S' and  locMatr->type == 'A'.
WARNING: Cannot be applied to degenerate least squares.
In particular only applicable when m \ge n. */
{

  int m = locMatr->m;
  int n = locMatr->n;

  int i;

  double xx[n];
  double *ut;
  
  

  if (locMatr->type == 'S' || locMatr->type == 'A')
    ut = locMatr->ut;
  else if (locMatr->type == 'O')
    ut = locMatr->at;
  else
    {
      fprintf(stderr,"error: no legitimate locMatr->type [LS_using_svd]");
      exit(-1);
    }    

  /* 1) xx = Ut * b */


  m_times_v (n, m, ut, locMatr->max_m, b, xx);


  /* divide by singular values: we only use this routine with non-degenerate
     least squares!! */

  for (i = 0; i < n; i++)
    xx[i] /= locMatr->sv[i];


  /* 2) x = V * xx */

	       
  m_times_v (n, n, locMatr->v, locMatr->max_n, xx, x);
  
}


void
compute_svd (SVDMATR * locMatr)
/* We use LAPACK "divide and conquer" SVD routine DGESDD (dgesdd_ in CLAPACK).
1) If m >= n, then A is transformed to FORTRAN format by transposition (locMatr->At),
and U and V are returned in FORTRAN format, too, that is they are transposed in 
C format: locMatr->ut and locMatr->v.
2) If m < n, then we use locMatr->a directly in C format which de facto means 
that dgesdd_ understands it as the _transpose_ of A -- because of the 
fortran format it uses. Therefore we get as output locMatr->vt and locMatr->u. 
Note that we in this way always apply dgesdd_ to a matrix with m >= n, which 
perfectly makes sense since dgesdd_ seems to work slower if  m < n. 
DESCRIPTION OF TYPES (locMatr->type -- it is assumed to have been set before
a call to this routine):
'S' -- returns only part of locMatr->ut or locMatr->vt of the size of A, depending 
       on whether m >= n or m < n.
'A' -- returns full matrices.
'O' -- part of U^T (if m >= n) or V^T (if m < n) is overwritten on At or A, respectively,
locMatr->ut (locMatr->vt) remain unchanged. WARNING: thus, with this option the original 
matrix A is lost in case m < n.
Note that according to our experience 'S' is somewhat faster than 'A', and 'O' is a bit 
slower than 'S'. */
{
  double **A = locMatr->A;
  int m = locMatr->m;
  int n = locMatr->n;

  int mindir = min (m, n);
  int maxdir = max (m, n);

  char jobz;

  int *max_m = &(locMatr->max_m);
  int *max_n = &(locMatr->max_n);

  int lwork = 5 * mindir * mindir + 9 * mindir + maxdir;
  double *work;
  int *iwork;
  int info;

  work = (double*) malloc (lwork * sizeof(double));
  if (work == NULL)
    {
      fprintf (stderr, "error: not enough memory! [compute_svd]\n");
      exit (-1);
    }

  iwork = (int*) malloc (8 * mindir * sizeof(int));
  if (iwork == NULL)
    {
      fprintf (stderr, "error: not enough memory! [compute_svd]\n");
      exit (-1);
    }


  if (locMatr->type == 'S' || locMatr->type == 'A' || locMatr->type == 'O')
    jobz = locMatr->type;
  else
    {
      fprintf(stderr,"error: no legitimate locMatr->type [compute_svd]");
      exit(-1);
    }    

  if (m >= n)
    {

      int i, j;

      /* transpose A to convert it to FORTRAN format */

      for (i = 0; i < m; i++)
	for (j = 0; j < n; j++)
	  (locMatr->At)[j][i] = A[i][j];
	  

      dgesdd_ (&jobz, &m, &n,
	        locMatr->at, max_m,
	        locMatr->sv,
	        locMatr->ut, max_m,
	        locMatr->v, max_n, work, &lwork, iwork, &info);

    }
  else  /* m < n */
    dgesdd_ (&jobz, &n, &m,
	      locMatr->a, max_n,
	      locMatr->sv,
	      locMatr->vt, max_n,
	      locMatr->u, max_m, work, &lwork, iwork, &info);
    
  free (work);
  free (iwork);

}





/************************** Solve LSE problem ******************************/


/* 
 * Solve linear equality-constrained least squares
 * problem (LSE) using routine DGGLSE: 
 * min_x ||Ax-c|| subject to B^T x=d. 
 * A is an (m x n)-matrix 
 * B is an (n x q)-matrix 
 * c is an m-vector
 * d is a  q-vector
 * x is an n-vector
 * (q\le n\le m+q)
 * ATTN: We use the _transpose_ B^T !! (This seems easier to apply
 * with collocation matrices.)
 * 
 */

void
LSE_solver (double *x, int m, int n, int q,
	    double **A, double **B, double *c, double *d)
{
  int i, j;
  
  int info;
  
  double a[m * n];
  double bt[q * n];
  
  
  int lwork = q + (n + m) * 50;
  double *work;
  
    
  
  work = (double*) malloc (lwork * sizeof(double));
  if (work == NULL)
    {
      fprintf (stderr, "error: not enough memory! [LSE_solver]\n");
      exit (-1);
    }

  /* convert A to FORTRAN format */

  for (i = 0; i < m; i++)
    for (j = 0; j < n; j++)
      a[j * m + i] = A[i][j];

  /* build 'bt' (the transpose of 'B') in FORTRAN format */

  for (i = 0; i < n; i++)
    memcpy (&bt[i * q], B[i], q * sizeof (double));


  dgglse_ (&m, &n, &q, a, &m, bt, &q, c, d, x, work, &lwork, &info);

  free (work);

}


/************** Matrix-vector and matrix-matrix multiplication ************/

/* y = A * x
product of A and x is computed and stored in y.
A is (m x n)
x is (n)
y is (m)
a, is a contiguous array corresponding to A in row major (i.e. C-type) order,
lda -- its leading dimension, i.e. allocated length of rows.
Since the fortran routine requires a matrix in column major, we do the usual
trick of swapping dimentions and passing 'T' as if we needed transpose.  */

void
m_times_v (int m, int n, double *a, int lda, double *x, double *y)
{


  char trans = 'T';
  double alpha = 1.0;
  int incx = 1;
  double beta = 0.0;
  int incy = 1;

  dgemv_(&trans, &n, &m, &alpha, a, &lda,
         x, &incx, &beta, y, &incy);
	 

  /* cblas_dgemv (CblasRowMajor, CblasNoTrans, m, n, 1.0,
               a, lda, x, 1, 0.0, y, 1); */

}


/* y = A^T * x
product of A^T and x is computed and stored in y.
A is (m x n)
x is (n)
y is (m)
a, is a contiguous array corresponding to A in row major (i.e. C-type) order,
lda -- its leading dimension, i.e. allocated length of rows.
Here we say trans = 'N' because row major is the same as transposed column major. */

void
mt_times_v (int m, int n, 
            double *a, int lda, 
	    double *x, double *y)
{

  char trans = 'N';
  double alpha = 1.0;
  int incx = 1;
  double beta = 0.0;
  int incy = 1;

  dgemv_(&trans, &n, &m, &alpha, a, &lda,
         x, &incx, &beta, y, &incy);
	 
  /* cblas_dgemv (CblasRowMajor, CblasTrans, m, n, 1.0,
               a, lda, x, 1, 0.0, y, 1); */
		 
}

/* C = A * B^T
product of matrices A and B^T is computed and stored in C. 
C is (m x n)
A is (m x k)
B is (n x k)
a, b, c are contiguous arrays corresponding to A, B, C in row major (i.e. C-type) order,
lda, ldb, ldc -- their leading dimensions, i.e. allocated lengths of rows.
See the above comments on  m_times_v and mt_times_v. Since C^T = B * A^T and we want 
C in row major, we have to multiply in the reverse order. */

void
m_times_mt (int m, int n, int k, 
            double *a, int lda, 
	    double *b, int ldb, 
	    double *c, int ldc)
{
  char transa = 'T'; 
  char transb = 'N'; 
  double alpha = 1.0;
  double beta = 0.0;


  dgemm_ (&transa, &transb, &n, &m, &k, 
                    &alpha, b, &ldb, a, &lda, 
		    &beta, c, &ldc);


  /* cblas_dgemm (CblasRowMajor, CblasNoTrans, CblasTrans, m, n, k, 1.0,
        	 a, lda, b, ldb, 0.0, c, ldc); */
}


#endif /* LAPACK */




/******************************************************************/
/**************************** CLAPACK *****************************/
/******************************************************************/


#ifdef CLAPACK


#include <g2c.h>


#include <cblas.h>


#include <clapack.h>



/**************************** Compute SVD ******************************/

void
LS_using_svd (SVDMATR * locMatr, double b[], double x[])
/* Works with both locMatr->type == 'S' and  locMatr->type == 'A'.
WARNING: Cannot be applied to degenerate least squares.
In particular only applicable when m \ge n. */
{

  int m = locMatr->m;
  int n = locMatr->n;

  int i;

  double xx[n];
  double *ut;


  if (locMatr->type == 'S' || locMatr->type == 'A')
    ut = locMatr->ut;
  else if (locMatr->type == 'O')
    ut = locMatr->at;
  else
    {
      fprintf(stderr,"error: no legitimate locMatr->type [LS_using_svd]");
      exit(-1);
    }    

  /* 1) xx = Ut * b */

  cblas_dgemv (CblasRowMajor, CblasNoTrans, n, m, 1.0, ut, locMatr->max_m,
	       b, 1, 0.0, xx, 1);


  /* divide by singular values: we only use this routine with non-degenerate
     least squares!! */

  for (i = 0; i < n; i++)
    xx[i] /= locMatr->sv[i];


  /* 2) x = V * xx */

  cblas_dgemv (CblasRowMajor, CblasNoTrans, n, n, 1.0, locMatr->v, locMatr->max_n,
	       xx, 1, 0.0, x, 1);
  
}


void
compute_svd (SVDMATR * locMatr)
/* We use LAPACK "divide and conquer" SVD routine DGESDD (dgesdd_ in CLAPACK).
1) If m >= n, then A is transformed to FORTRAN format by transposition (locMatr->At),
and U and V are returned in FORTRAN format, too, that is they are transposed in 
C format: locMatr->ut and locMatr->v.
2) If m < n, then we use locMatr->a directly in C format which de facto means 
that dgesdd_ understands it as the _transpose_ of A -- because of the 
fortran format it uses. Therefore we get as output locMatr->vt and locMatr->u. 
Note that we in this way always apply dgesdd_ to a matrix with m >= n, which 
perfectly makes sense since dgesdd_ seems to work slower if  m < n. 
DESCRIPTION OF TYPES (locMatr->type -- it is assumed to have been set before
a call to this routine):
'S' -- returns only part of locMatr->ut or locMatr->vt of the size of A, depending 
       on whether m >= n or m < n.
'A' -- returns full matrices.
'O' -- part of U^T (if m >= n) or V^T (if m < n) is overwritten on At or A, respectively,
locMatr->ut (locMatr->vt) remain unchanged. WARNING: thus, with this option the original 
matrix A is lost in case m < n.
Note that according to our experience 'S' is somewhat faster than 'A', and 'O' is a bit 
slower than 'S'. */
{
  double **A = locMatr->A;
  int m = locMatr->m;
  int n = locMatr->n;

  int mindir = min (m, n);
  int maxdir = max (m, n);

  char jobz;

  integer *mm = (integer *) & m;
  integer *nn = (integer *) & n;
  integer *max_m = (integer *) & (locMatr->max_m);
  integer *max_n = (integer *) & (locMatr->max_n);

  integer lwork = 5 * mindir * mindir + 9 * mindir + maxdir;
  doublereal *work;
  integer *iwork;
  integer info;

  work = (doublereal*) malloc (lwork * sizeof(doublereal));
  if (work == NULL)
    {
      fprintf (stderr, "error: not enough memory! [compute_svd]\n");
      exit (-1);
    }

  iwork = (integer*) malloc (8 * mindir * sizeof(integer));
  if (iwork == NULL)
    {
      fprintf (stderr, "error: not enough memory! [compute_svd]\n");
      exit (-1);
    }


  if (locMatr->type == 'S' || locMatr->type == 'A' || locMatr->type == 'O')
    jobz = locMatr->type;
  else
    {
      fprintf(stderr,"error: no legitimate locMatr->type [compute_svd]");
      exit(-1);
    }    

  if (m >= n)
    {

      int i, j;

      /* transpose A to convert it to FORTRAN format */

      for (i = 0; i < m; i++)
	for (j = 0; j < n; j++)
	  (locMatr->At)[j][i] = A[i][j];
	  

      dgesdd_ (&jobz, mm, nn,
	       (doublereal *) locMatr->at, max_m,
	       (doublereal *) locMatr->sv,
	       (doublereal *) locMatr->ut, max_m,
	       (doublereal *) locMatr->v, max_n, work, &lwork, iwork, &info);

    }
  else  /* m < n */
    dgesdd_ (&jobz, nn, mm,
	     (doublereal *) locMatr->a, max_n,
	     (doublereal *) locMatr->sv,
	     (doublereal *) locMatr->vt, max_n,
	     (doublereal *) locMatr->u, max_m, work, &lwork, iwork, &info);
    
  free (work);
  free (iwork);

}





/************************** Solve LSE problem ******************************/


/* 
 * Solve linear equality-constrained least squares
 * problem (LSE) using routine DGGLSE: 
 * min_x ||Ax-c|| subject to B^T x=d. 
 * A is an (m x n)-matrix 
 * B is an (n x q)-matrix 
 * c is an m-vector
 * d is a  q-vector
 * x is an n-vector
 * (q\le n\le m+q)
 * ATTN: We use the _transpose_ B^T !! (This seems easier to apply
 * with collocation matrices.)
 * 
 */

void
LSE_solver (double *x, int m, int n, int q,
	    double **A, double **B, double *c, double *d)
{
  int i, j;
  
  integer info;
  
  double a[m * n];
  double bt[q * n];
  
  doublereal *aa = (doublereal*) a;
  doublereal *bbt= (doublereal*) bt;
  
  integer *mm = (integer *) & m;
  integer *nn = (integer *) & n;
  integer *qq = (integer *) & q;
  doublereal *cc = (doublereal *) c;
  doublereal *dd = (doublereal *) d;
  doublereal *xx = (doublereal *) x;
  integer lwork = q + (n + m) * 50;
  doublereal *work;
  
    
  
  work = (doublereal*) malloc (lwork * sizeof(doublereal));
  if (work == NULL)
    {
      fprintf (stderr, "error: not enough memory! [LSE_solver]\n");
      exit (-1);
    }

  /* convert A to FORTRAN format */

  for (i = 0; i < m; i++)
    for (j = 0; j < n; j++)
      a[j * m + i] = A[i][j];

  /* build 'bt' (the transpose of 'B') in FORTRAN format */

  for (i = 0; i < n; i++)
    memcpy (&bt[i * q], B[i], q * sizeof (double));


  dgglse_ (mm, nn, qq, aa, mm, bbt, qq, cc, dd, xx, work, &lwork, &info);

  free (work);

}


/************** Matrix-matrix and matrix-vector multiplication ************/


/* product of A^T and x is computed and stored in y.
A is (m x n)
x is (n)
y is (m)
a, is a contiguous array corresponding to A in row major (i.e. C-type) order,
lda -- its leading dimension, i.e. allocated lengths of rows.
Calls a CBLAS routine */

void
mt_times_v (int m, int n, 
            double *a, int lda, 
	    double *x, double *y)
{
    cblas_dgemv (CblasRowMajor, CblasTrans, m, n, 1.0,
        	 a, lda, x, 1, 0.0, y, 1);
}

/* product of A and B^T is computed and stored in C.
C is (m x n)
A is (m x k)
B is (n x k)
a, b, c are contiguous arrays corresponding to A, B, C in row major (i.e. C-type) order,
lda, ldb, ldc -- their leading dimensions, i.e. allocated lengths of rows.
Calls a CBLAS routine  */

void
m_times_mt (int m, int n, int k, 
            double *a, int lda, 
	    double *b, int ldb, 
	    double *c, int ldc)
{
    cblas_dgemm (CblasRowMajor, CblasNoTrans, CblasTrans, m, n, k, 1.0,
        	 a, lda, b, ldb, 0.0, c, ldc);
}


#endif /* CLAPACK */



/* Management of the second stage ("global") methods.
 
  Author: Oleg Davydov
	  University of Strathclyde
	  Department of Mathematics
          26 Richmond Street
	  Glasgow G1 1XH
	  Scotland, UK
	  e-mail: oleg.davydov@strath.ac.uk


  Copyright (C) 2005 Oleg Davydov

This file is part of TSFIT.

This package is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This package is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this package; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <values.h>


#include "datamng.h"
#include "lmethod.h"
#include "convert.h"
#include "gmethod.h"

#include "bezier.h"
#include "SpC1d3D2.h"
#include "SpC2d6D2.h"


/* main computation routine */
void
tsfit_compute (TSFIT_DATA *data, TSFIT_GLOBAL_METHOD * global_method,
	       TSFIT_LOCAL_METHOD * local_method)
{
  TSFIT_CONVERTER *converter;

  /*** determine the converter ***/

  converter = (TSFIT_CONVERTER *) calloc (1, sizeof (TSFIT_CONVERTER));
  if (converter == NULL)
    {
      fprintf (stderr, "error: not enough memory: [converter]!\n");
      exit (-1);
    }

  set_tsfit_converter (converter, local_method, global_method);


  fprintf (stderr, "\nConverter has been set\n");


  /*** initialization ***/


  local_method->init (local_method->body);


  fprintf (stderr, "\nLocal method initialized\n");

  global_method->init (global_method->body);


  fprintf (stderr, "\nGlobal method initialized\n");

  converter->init (converter->body);

  fprintf (stderr, "\nConverter initialized\n\nComputation starts now...\n");


  /*** compute the spline ***/



  global_method->compute (data, global_method->body, local_method, converter);

  fprintf (stderr, "\n...Spline computed\n");


  /*** Free the memory allocated to the converter ***/

  converter->free (converter->body);
  free (converter);


}


void
set_global_method_type (TSFIT_GLOBAL_METHOD * method, char *type)
{


  if (!strcmp (type, "SpC1d3D2"))
    {
      SpC1d3D2 *spline;

      strcpy (method->type, type);

      method->body = calloc (1, sizeof (SpC1d3D2));
      if (method->body == NULL)
	{
	  fprintf (stderr,
		   "\nerror: memory allocation failure [set_global_method_type]\n");
	  exit (-1);
	}
	
      spline = (SpC1d3D2 *) method->body;
      
      method->init = &init_SpC1d3D2;
      method->free = &free_SpC1d3D2;
      method->compute = &compute_SpC1d3D2;
      method->eval = &eval_SpC1d3D2;

      /* default parameters */

      spline->av = 1;
      spline->ws = 20;		/* ws is only relevant if av == 1 */

      /* set the type of locale */

      strcpy (method->locale_type, "TRIEL");

      method->locale = spline->locale = (TRIEL *) calloc (1, sizeof (TRIEL));
      if (spline->locale == NULL)
	{
	  fprintf (stderr,
		   "\nerror: memory allocation failure [set_global_method_type]\n");
	  exit (-1);
	}
      spline->locale->degree = 3;

    }
  else if (!strcmp (type, "SpC2d6D2"))
    {
      D2SPLINE *spline;

      strcpy (method->type, type);

      method->body = calloc (1, sizeof (D2SPLINE));
      if (method->body == NULL)
	{
	  fprintf (stderr,
		   "\nerror: memory allocation failure [set_global_method_type]\n");
	  exit (-1);
	}
      spline = (D2SPLINE *) method->body;
      
      method->init = &init_Delta2spline;
      method->free = &free_Delta2spline;
      method->compute = &compute_Delta2spline;
      method->eval = &eval_Delta2spline;

      /* the following call sets some parameters related to smoothness */

      set_C2_Delta2spline (spline);

      /* default parameters */

      spline->av = 1;
      spline->super = 0;


      /* set the type of locale */

      strcpy (method->locale_type, "TRIEL");

      method->locale = spline->locale = (TRIEL *) calloc (1, sizeof (TRIEL));
      if (spline->locale == NULL)
	{
	  fprintf (stderr,
		   "\nerror: memory allocation failure [set_global_method_type]\n");
	  exit (-1);
	}
      spline->locale->degree = 6;
    }
  else
    {
      fprintf (stderr,
	       "\nerror: Invalid method type \"%s\"! [set_global_method_type]\n",
	       type);
      exit (-1);
    }



}


/* change the type of the method; 
assumes that  method->body is _allocated_ (see set_global_method_type)
and _initialized_ (i.e. method->init has been called, see tsfit_compute);
if called with type=NULL, then just method->body will be freed and the method type
will be set to "NULL"  */
void
reset_global_method_type (TSFIT_GLOBAL_METHOD * method, char *type)
{


  method->free (method->body);

  free (method->body);

  if (type != NULL)
    set_global_method_type (method, type);
  else
    strcpy (method->type, "NULL");

}

/* set the parameters n (number of cells in x direction) and 
m (number of cells in y direction) of the D2 mesh. The mesh is adjusted
to the bounded box of the data. */

void
set_D2mesh (TSFIT_GLOBAL_METHOD * method, TSFIT_DATA *data, int n, int m)
{

  double scaled_x_side = (data->xmax - data->xmin) / data->scaling_factor;
  double scaled_y_side = (data->ymax - data->ymin) / data->scaling_factor;

  if (!strcmp (method->type, "SpC1d3D2"))
    {
      SpC1d3D2 *spline = (SpC1d3D2 *) method->body;

      spline->n = n;
      spline->m = m;
      spline->hx = scaled_x_side / n;
      spline->hy = scaled_y_side / m;

    }
  else if (!strcmp (method->type, "SpC2d6D2"))
    {
      D2SPLINE *spline = (D2SPLINE *) method->body;

      spline->gridXSize = n;
      spline->gridYSize = m;
      spline->wGrid = scaled_x_side / n;
      spline->hGrid = scaled_y_side / m;
    }
  else
    {
      fprintf (stderr,
	       "\nerror: Invalid method type \"%s\"! [set_D2mesh]\n",
	       method->type);
      exit (-1);
    }
}

/* determine whether averaged spline will be used */
void
set_averaging (TSFIT_GLOBAL_METHOD * method, char *TRUE_or_FALSE)
{
  if (!strcmp (method->type, "SpC1d3D2"))
    {
      SpC1d3D2 *spline = (SpC1d3D2 *) method->body;

      if (!strcmp (TRUE_or_FALSE, "TRUE"))
	spline->av = 1;
      else if (!strcmp (TRUE_or_FALSE, "FALSE"))
	spline->av = 0;
      else
	{
	  fprintf (stderr,
		   "\nerror: Invalid value \"%s\" for TRUE_or_FALSE! [set_averaging]\n",
		   TRUE_or_FALSE);
	  exit (-1);
	}

    }
  else if (!strcmp (method->type, "SpC2d6D2"))
    {
      D2SPLINE *spline = (D2SPLINE *) method->body;

      if (!strcmp (TRUE_or_FALSE, "TRUE"))
	spline->av = 1;
      else if (!strcmp (TRUE_or_FALSE, "FALSE"))
	spline->av = 0;
      else
	{
	  fprintf (stderr,
		   "\nerror: Invalid value \"%s\" for TRUE_or_FALSE! [set_averaging]\n",
		   TRUE_or_FALSE);
	  exit (-1);
	}

    }
  else
    {
      fprintf (stderr,
	       "\nerror: Invalid method type \"%s\"! [set_averaging]\n",
	       method->type);
      exit (-1);
    }
}


/* determine whether C^2 spline with "supersmoothness" 
 (SQ_2, SQ_2^av) will be used; applies only to  SpC2d6D2 spline */
void
set_supersmooth (TSFIT_GLOBAL_METHOD * method, char *TRUE_or_FALSE)
{
  if (!strcmp (method->type, "SpC2d6D2"))
    {
      D2SPLINE *spline = (D2SPLINE *) method->body;

      if (!strcmp (TRUE_or_FALSE, "TRUE"))
	spline->super = 1;
      else if (!strcmp (TRUE_or_FALSE, "FALSE"))
	spline->super = 0;
      else
	{
	  fprintf (stderr,
		   "\nerror: Invalid value \"%s\" for TRUE_or_FALSE! [set_super]\n",
		   TRUE_or_FALSE);
	  exit (-1);
	}

    }
  else
    {
      fprintf (stderr,
	       "\nerror: Invalid method type \"%s\"! [set_super]\n",
	       method->type);
      exit (-1);
    }
}

/* evaluation of the approximation at a single point */
double 
evaluate_point (double x, double y, TSFIT_DATA * data,
                       TSFIT_GLOBAL_METHOD * method)	
{

  return unscale_z (method->eval (scale_x (x, data), scale_y (y, data), method->body), 
                    data);
}


/* evaluation of the approximation on a grid */
void
evaluate_grid (double xl, double xr, int n, 
               double yl, double yr, int m, 
               char *filename,
	       TSFIT_DATA * data, TSFIT_GLOBAL_METHOD * method)
{
  FILE *fp;
  int ix, iy;
  double x, y, hx, hy, xls, xrs, yls, yrs;
  
  
  
  fp = fopen (filename, "w");

  if (fp == NULL)
    {
      fprintf (stderr, "error: file opening failure \'%s\' [evaluate_grid]\n",filename);
      exit (-1);
    }

  /* hx = (xr - xl) / n;
  hy = (yr - yl) / m;

  for (iy = 0, y = yl; iy <= m; iy++, y += hy, fprintf (fp, "\n"))
    for (ix = 0, x = xl; ix <= n; ix++, x += hx)
      fprintf (fp, "%f ", evaluate_point (x, y, data, method)); */	
      
      
  /* scale grid bounds */
  
  xls = scale_x (xl, data);
  xrs = scale_x (xr, data);
  yls = scale_y (yl, data);
  yrs = scale_y (yr, data);
  
  hx = (xrs - xls) / n;
  hy = (yrs - yls) / m;

  for (iy = 0, y = yls; iy <= m; iy++, y += hy, fprintf (fp, "\n"))
    for (ix = 0, x = xls; ix <= n; ix++, x += hx)
      fprintf (fp, "%f ", unscale_z (method->eval (x, y, method->body), data));	

  fclose (fp);
  
  fprintf (stderr, "\nGrid evaluations written to \'%s\'\n\n",filename);
  
} 




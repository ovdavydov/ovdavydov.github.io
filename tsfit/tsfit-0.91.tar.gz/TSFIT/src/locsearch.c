/* Range searching according to the the grid method as described e.g. in 
 J. L. Bentley and J. H. Friedman, Data structures for range searching,
 ACM Computing Surveys, 11 (1079), 397-409.
 
  Author: Oleg Davydov
	  University of Strathclyde
	  Department of Mathematics
          26 Richmond Street
	  Glasgow G1 1XH
	  Scotland, UK
	  e-mail: oleg.davydov@strath.ac.uk


  Copyright (C) 2005 Oleg Davydov

This file is part of TSFIT.

This package is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This package is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this package; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */


#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <values.h>

#include "datamng.h"

#include "locsearch.h"

static int count_points (TSFIT_DATA * data, double mx, double my, double radius,
		  int *cell_xmin, int *cell_xmax, int *cell_ymin, int *cell_ymax);

static void collect_points (TSFIT_DATA * data, LOCALDATA * locPoints,
		     double mx, double my, double radius,
		     int cell_xmin, int cell_xmax, int cell_ymin, int cell_ymax,
		     int number);

static int thin_points (TSFIT_DATA * data, LOCALDATA * locPoints,
		 double mx, double my, double radius,
		 int cell_xmin, int cell_xmax, int cell_ymin, int cell_ymax);



/* chooses local points starting from a circle 
with midpoint (mx,my) and initial radius
determined by loc_size */

void
choose_loc_points (TSFIT_DATA * data, LSCONTROL * lscontr, double mx, double my,
		   double loc_size)
{

  int cell_xmin, cell_xmax, cell_ymin, cell_ymax;
  int minPoints, max_number, number;
  LOCALDATA *locPoints;
  double radius = loc_size * lscontr->init_rad_factor;


  minPoints = lscontr->minPoints;
  locPoints = lscontr->locPoints;
  max_number = locPoints->max_number;

  /* find the disk with at least 'minPoints' points 
     by enlarging the radius if needed */

  number = count_points (data, mx, my, radius,
			 &cell_xmin, &cell_xmax, &cell_ymin, &cell_ymax);

  while (number < minPoints)
    {

      radius *= 1.5;
      number = count_points (data, mx, my, radius,
			     &cell_xmin, &cell_xmax, &cell_ymin, &cell_ymax);
    }

  lscontr->diam = radius * 2.0;


  if (number > max_number)
    {				/* thinning */


      locPoints->number = thin_points (data, locPoints, mx, my, radius,
				       cell_xmin, cell_xmax, cell_ymin, cell_ymax);




    }
  else
    {				/* the case when number <= max_number */

      locPoints->number = number;

      collect_points (data, locPoints, mx, my, radius,
		      cell_xmin, cell_xmax, cell_ymin, cell_ymax, number);


    }
}


/* compute the number of data points in the disk 
with center '(mx,my)' and radius 'radius';
as a by-product we store the "cell bounding box" of the disk:
'cell_xmin', 'cell_xmax', 'cell_ymin', 'cell_ymax' */

static int
count_points (TSFIT_DATA * data, double mx, double my, double radius,
	      int *cell_xmin, int *cell_xmax, int *cell_ymin, int *cell_ymax)
{

  int m, cell_x, cell_y, num, n, ind, number;
  double d, dx, dy;
  double *xx = data->x;
  double *yy = data->y;
  int *cell_number = data->cell_number;
  int **cell_index = data->cell_index;
  int *index;


  find_data_cell (data, mx - radius, my - radius, cell_xmin, cell_ymin);
  find_data_cell (data, mx + radius, my + radius, cell_xmax, cell_ymax);



  num = 0;

  for (cell_y = *cell_ymin; cell_y <= *cell_ymax; cell_y++)
    {
      for (cell_x = *cell_xmin; cell_x <= *cell_xmax; cell_x++)
	{

	  m = cell_y * data->grid_size + cell_x;

	  number = cell_number[m];
	  index = cell_index[m];

	  for (n = 0; n < number; n++)
	    {
	      ind = index[n];

	      dx = xx[ind] - mx;
	      dy = yy[ind] - my;

	      d = sqrt (dx * dx + dy * dy);

	      if (d <= radius)
		num++;
	    }

	}
    }

  return num;
}

/* Collect ALL data points inside the disk defined by mx, my, radius.
It is assumed that the number of points 'num', and the bounding box 'cell_xmin',
etc. are known -- e.g. they have been computed using 'count_points'.
The indices of the points are stored in 'sampleIndex'. 
WARNING: the memory allocated to 'sampleIndex' must allow at least 'num+1'
points, and locPoints->max_number must be at least num */


static void
collect_points (TSFIT_DATA * data, LOCALDATA * locPoints, double mx, double my,
		double radius, int cell_xmin, int cell_xmax, int cell_ymin,
		int cell_ymax, int num)
{
  int m, n, ind;
  int cell_x, cell_y;
  double x, y, d, dx, dy;
  double *xx = data->x;
  double *yy = data->y;
  double *zz = data->z;
  int *cell_number = data->cell_number;
  int **cell_index = data->cell_index;
  int number, *index;
  double *lx = locPoints->x;
  double *ly = locPoints->y;
  double *lz = locPoints->z;



  for (cell_y = cell_ymin; cell_y <= cell_ymax; cell_y++)
    {
      for (cell_x = cell_xmin; cell_x <= cell_xmax; cell_x++)
	{

	  m = cell_y * data->grid_size + cell_x;
	  number = cell_number[m];
	  index = cell_index[m];

	  for (n = 0; n < number; n++)
	    {
	      ind = index[n];
	      x = xx[ind];
	      y = yy[ind];
	      dx = x - mx;
	      dy = y - my;
	      d = sqrt (dx * dx + dy * dy);

	      /* store the current point if it is in the circle */
	      if (d <= radius)
		{
		  *(lx++) = x;
		  *(ly++) = y;
		  *(lz++) = zz[ind];

		}

	    }

	}
    }


}

/* Thin the points inside the disk defined by mx, my, radius, 
by a "most central"  method. 
It is assumed that the the bounding box defined by 'cell_xmin',
etc. is known -- e.g. they have been computed using 'count_points'.
The indices of the points are stored in 'sampleIndex' 
WARNIG: only works correctly if 'locPoints->max_number' is a square number (e.g has been 
increased up to the nearest square number, see the function 'init_loc_search') */


static int
thin_points (TSFIT_DATA * data, LOCALDATA * locPoints, double mx, double my,
	     double radius, int cell_xmin, int cell_xmax, int cell_ymin,
	     int cell_ymax)
{
  int k, m, n, ind, indl;
  int cell_x, cell_y, num, loc_grid_X, loc_grid_Y, loc_grid_index;
  double x, y, d, dx, dy, llx, lly;
  double loc_grid_len;
  int loc_grid_size = locPoints->max_number;
  int loc_grid_sizeX = locPoints->loc_grid_sizeX;
  int *loc_grid = locPoints->loc_grid;
  double *loc_grid_dist = locPoints->loc_grid_dist;
  double *xx = data->x;
  double *yy = data->y;
  double *zz = data->z;
  int *cell_number = data->cell_number;
  int **cell_index = data->cell_index;
  int number, *index;
  double *lx = locPoints->x;
  double *ly = locPoints->y;
  double *lz = locPoints->z;




  for (k = 0; k < loc_grid_size; k++)
    loc_grid_dist[k] = MAXDOUBLE;


  loc_grid_len = 2.0 * radius / (double) loc_grid_sizeX;
  llx = mx - radius;
  lly = my - radius;




  for (cell_y = cell_ymin; cell_y <= cell_ymax; cell_y++)
    {
      for (cell_x = cell_xmin; cell_x <= cell_xmax; cell_x++)
	{

	  m = cell_y * data->grid_size + cell_x;
	  number = cell_number[m];
	  index = cell_index[m];


	  for (n = 0; n < number; n++)
	    {
	      ind = index[n];

	      x = xx[ind];
	      y = yy[ind];

	      /* compute distance to the center of the disk */

	      dx = x - mx;
	      dy = y - my;
	      d = sqrt (dx * dx + dy * dy);

	      /* leave out the point if it is not in the circle */

	      if (d > radius)
		continue;

	      /* get coordinates of loc_grid cell */

	      x -= llx;
	      y -= lly;

	      loc_grid_X = (int) (x / loc_grid_len);
	      loc_grid_Y = (int) (y / loc_grid_len);
	      loc_grid_index = loc_grid_Y * loc_grid_sizeX + loc_grid_X;


	      /* distance to the center of the local cell */

	      dx = x - (loc_grid_X + 0.5) * loc_grid_len;
	      dy = y - (loc_grid_Y + 0.5) * loc_grid_len;
	      d = sqrt (dx * dx + dy * dy);

	      /* store the index of the current point and its distance
	         if the distance to the center is smaller */

	      if (d < loc_grid_dist[loc_grid_index])
		{
		  loc_grid[loc_grid_index] = ind;
		  loc_grid_dist[loc_grid_index] = d;
		}


	    }

	}
    }

  /* update 'locPoints' */

  num = 0;

  for (n = 0; n < loc_grid_size; n++)
    {

      if (loc_grid_dist[n] <= radius)
	{
	  indl = loc_grid[n];
	  *(lx++) = xx[indl];
	  *(ly++) = yy[indl];
	  *(lz++) = zz[indl];
	  num++;
	}
    }


  return num;

}




/* Allocate memory for data structures used for local search;  
'lscontr->minPoints' and 'lscontr->maxPoints' must be specified
before calling this function */

void
init_loc_search (LSCONTROL * lscontr)
{
  int max_number;
  int loc_grid_sizeX;
  LOCALDATA *locPoints;




  /* allocate memory for the field 'locPoints' */

  locPoints = lscontr->locPoints = (LOCALDATA *) malloc (sizeof (LOCALDATA));

  if (locPoints == NULL)
    {
      fprintf (stderr, "error: memory allocation failure [locPoints]\n");
      exit (-1);
    }


  loc_grid_sizeX = locPoints->loc_grid_sizeX =
    (int) ceil (sqrt (lscontr->maxPoints));


  /* 'locPoints->max_number' is 'maxPoints' rounded up to the nearest
     SQUARE number (needed for the "most central" thinning) */

  max_number = locPoints->max_number = loc_grid_sizeX * loc_grid_sizeX;

  locPoints->x = (double *) malloc (max_number * sizeof (double));

  if (locPoints->x == NULL)
    {
      fprintf (stderr, "error: memory allocation failure [locPoints]\n");
      exit (-1);
    }

  locPoints->y = (double *) malloc (max_number * sizeof (double));

  if (locPoints->y == NULL)
    {
      fprintf (stderr, "error: memory allocation failure [locPoints]\n");
      exit (-1);
    }

  locPoints->z = (double *) malloc (max_number * sizeof (double));

  if (locPoints->z == NULL)
    {
      fprintf (stderr, "error: memory allocation failure [locPoints]\n");
      exit (-1);
    }


  /* allocate auxiliary arrays for thinning */


  /* array for the indices of the "most central" points */

  locPoints->loc_grid = (int *) malloc (max_number * sizeof (int));

  if (locPoints->loc_grid == NULL)
    {
      fprintf (stderr, "error: memory allocation failure [loc_grid] \n");
      exit (-1);
    }

  /* array for the distances of the "most central" points to the centers
     of local cells */

  locPoints->loc_grid_dist = (double *) malloc (max_number * sizeof (double));

  if (locPoints->loc_grid_dist == NULL)
    {
      fprintf (stderr, "error: memory allocation failure [loc_grid_dist] \n");
      exit (-1);
    }


}



/* free the memory used for local search  */

void
free_loc_search (LSCONTROL * lscontr)
{
  LOCALDATA *locPoints = lscontr->locPoints;

  free (locPoints->loc_grid_dist);
  free (locPoints->loc_grid);


  free (locPoints->x);
  free (locPoints->y);
  free (locPoints->z);

  free (locPoints);

}

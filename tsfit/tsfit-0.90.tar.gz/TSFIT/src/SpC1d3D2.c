/* C^1 spline of degree 3 on the four-directional mesh computed by the 
extension method as described in
 O. Davydov and F. Zeilfelder, Scattered data fitting by direct extension 
 of local polynomials to bivariate splines, Advances in Comp. Math. 21 (2004), 
 223-271.
 
  Author: Oleg Davydov
	  University of Strathclyde
	  Department of Mathematics
          26 Richmond Street
	  Glasgow G1 1XH
	  Scotland, UK
	  e-mail: oleg.davydov@strath.ac.uk


  Copyright (C) 2005 Oleg Davydov

This file is part of TSFIT.

This package is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This package is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this package; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "datamng.h"
#include "lmethod.h"
#include "convert.h"

#include "bezier.h"
#include "SpC1d3D2.h"




static void loc_extension (double *coefs, int type,
			   double *g0, double *g1, double *g2, double *g3);

static void add_loc_extension (double *coefs, int type,
			       double *g0, double *g1, double *g2,
			       double *g3);

static int update_window (int wli, int wri, int wlj, int wrj,
			  TSFIT_DATA * data, SpC1d3D2 * spline,
			  TSFIT_LOCAL_METHOD * local_method,
			  TSFIT_CONVERTER * converter);

static void locate_point_D2 (double x, double y, int n, int m, double hx,
			     double hy, int *i, int *j, int *ind);

void
init_SpC1d3D2 (void *spline_void)
{
  SpC1d3D2 *spline = (SpC1d3D2 *) spline_void;
  int i, ntri;
  double *bbtri_coefs;

  spline->fvs_state = 0;	/* we do not allocate fvsbasis in 'init_SpC1d3D2'!! */


  spline->num = (((spline->n + 2) * (spline->m + 2) + 1) / 2) * 10;

  spline->coefs = (double *) malloc (spline->num * sizeof (double));

  if (spline->coefs == NULL)
    {
      fprintf (stderr, "error: memory allocation failure [init_SpC1d3D2]\n");
      exit (-1);
    }

  /* initialize spline->bbtri for evaluation */

  bbtri_coefs = (double *) malloc (10 * sizeof (double));

  if (bbtri_coefs == NULL)
    {
      fprintf (stderr, "error: memory allocation failure [spline]\n");
      exit (-1);
    }

  spline->bbtri = init_baseTri (3, bbtri_coefs);

  /* allocate bbtri->triangle since this is not done in init_baseTri
     (for BBTRI used locally we link triangle using converter, therefore
     init_baseTri cannot allocate it) */

  spline->bbtri->triangle = (TRIANGLE *) malloc (sizeof (TRIANGLE));

  if (spline->bbtri->triangle == NULL)
    {
      fprintf (stderr, "error: memory allocation failure [init_SpC1d3D2]\n");
      exit (-1);
    }



  /* initialize window for averaging */

  if (spline->av)
    {
      if (spline->ws < 1)
	spline->ws = 1;

      spline->window = (WINDOW_SpC1d3D2 *) malloc (sizeof (WINDOW_SpC1d3D2));

      if (spline->window == NULL)
	{
	  fprintf (stderr, "error: memory allocation failure [spline]\n");
	  exit (-1);
	}

      /* we allocate initially memory for a small window, which will be dinamically
         reallocated if it turns out too small */


      ntri = (spline->window)->ntri = 80;

      spline->window->wcoefs0 = (double *) calloc (ntri, sizeof (double));

      if (spline->window->wcoefs0 == NULL)
	{
	  fprintf (stderr, "error: memory allocation failure [spline]\n");
	  exit (-1);
	}

      spline->window->wcoefs1 = (double *) calloc (ntri, sizeof (double));

      if (spline->window->wcoefs1 == NULL)
	{
	  fprintf (stderr, "error: memory allocation failure [spline]\n");
	  exit (-1);
	}

      spline->window->wcoefs2 = (double *) calloc (ntri, sizeof (double));

      if (spline->window->wcoefs2 == NULL)
	{
	  fprintf (stderr, "error: memory allocation failure [spline]\n");
	  exit (-1);
	}

      spline->window->wcoefs3 = (double *) calloc (ntri, sizeof (double));

      if (spline->window->wcoefs3 == NULL)
	{
	  fprintf (stderr, "error: memory allocation failure [spline]\n");
	  exit (-1);
	}

      spline->window->wcoefs4 = (double *) calloc (ntri, sizeof (double));

      if (spline->window->wcoefs4 == NULL)
	{
	  fprintf (stderr, "error: memory allocation failure [spline]\n");
	  exit (-1);
	}

      spline->window->wcoefs5 = (double *) calloc (ntri, sizeof (double));

      if (spline->window->wcoefs5 == NULL)
	{
	  fprintf (stderr, "error: memory allocation failure [spline]\n");
	  exit (-1);
	}

      spline->window->wcoefs6 = (double *) calloc (ntri, sizeof (double));

      if (spline->window->wcoefs6 == NULL)
	{
	  fprintf (stderr, "error: memory allocation failure [spline]\n");
	  exit (-1);
	}

      spline->window->wcoefs7 = (double *) calloc (ntri, sizeof (double));

      if (spline->window->wcoefs7 == NULL)
	{
	  fprintf (stderr, "error: memory allocation failure [spline]\n");
	  exit (-1);
	}


      for (i = 0; i < 10; i++)
	(spline->window)->gg[i] = 0.0;



    }


  spline->nontriv = spline->dim =
    5 * spline->n * spline->m + 4 * (spline->n + spline->m) + 3;



  /*  init_fvsbasis_SpC1d3D2 (spline);
     transform_to_fvs_SpC1d3D2 (spline);
     spline->fvs_state = 3;
     transform_from_fvs_SpC1d3D2 (spline);
     free_fvsbasis_SpC1d3D2 (spline); */



  /* fprintf (stderr, "\nParameters of SpC1d3D2\n");
     fprintf (stderr, "Dimension: %i\n", spline->dim);
     fprintf (stderr, "Spline grid: %i x %i \n", spline->n, spline->m);
     fprintf (stderr, "Meshsize: %f x %f \n", spline->hx, spline->hy);
     if (spline->av)
     fprintf (stderr, "Averaging used\n\n");
     else
     fprintf (stderr, "No averaging\n\n"); */

}

void
free_SpC1d3D2 (void *spline_void)
{
  SpC1d3D2 *spline = (SpC1d3D2 *) spline_void;

  free (spline->coefs);

  free (spline->bbtri->coefs);

  free (spline->bbtri->triangle);

  free_baseTri (spline->bbtri);


  free (spline->bbtri);



  if (spline->av)
    {

      free ((spline->window)->wcoefs0);
      free ((spline->window)->wcoefs1);
      free ((spline->window)->wcoefs2);
      free ((spline->window)->wcoefs3);
      free ((spline->window)->wcoefs4);
      free ((spline->window)->wcoefs5);
      free ((spline->window)->wcoefs6);
      free ((spline->window)->wcoefs7);
      free (spline->window);


    }

  /* free(spline); */


}

static void
loc_extension (double *coefs, int type,
	       double *g0, double *g1, double *g2, double *g3)
/* 'coefs':  pointer to the first coef of the BB triangle to be computed;
   'type':    type 0-7 of the triangle according to the diagram below;
   'g0...g3': pointers to the first coef of the respective "grey" triangle */
/* 
 *
 *  |----|------|------|------|
 *  |    |      |      |      |
 *  |    |      |g1    |      |
 *  |    |      |      |      |
 *  |----|------|------|------|
 *  |    |   1  |  5   |      |
 *  |    |g0   2|4    6|g2    |     g0 = 0 !!!!
 *  |    |   3  |  7   |      |
 *  |----/------|------/------|
 *  |    |      |      |      |
 *  |    |      |g3    |      |
 *  |    |      |      |      |
 *  |----/------|------/------|
 *
 *  Numeration of the vertices, and of the BB coefs in the triangles: 
 *
 *
 *           *-------*  
 *           |\1   2/|
 *           |2\   /1| 
 *           |  \3/  |
 *           |  3*3  |
 *           |  /3\  |
 *           |1/   \2|   
 *           |/2   1\|                 \ 0  1   2  3 /
 *   *-------*-------*-------*        3  \ 4  5   6/ 0
 *   |\1   2/|\1   2/|\1   2/|          6  \ 7  8/ 4
 *   |2\   /1|2\   /1|2\   /1|        2   8  \9/ 7   1
 *   |  \3/  |  \3/  |  \3/  |          5   9 * 9  5
 *   |  3*3  |  3*3  |  3*3  |        1   7 / 9 \8   2 
 *   |  /3\  |  /3\  |  /3\  |          4 / 8  7  \6 
 *   |1/   \2|1/   \2|1/   \2|        0 / 6   5  4 \ 3
 *   |/2   1\|/2   1\|/2   1\|        / 3   2   1  0 \
 *   *-------*-------*-------*
 *           |\1   2/|
 *           |2\   /1| 
 *           |  \3/  |
 *           |  3*3  |
 *           |  /3\  |
 *           |1/   \2|   
 *           |/2   1\|  
 *           *-------*  
 *      
 *      
 */
{
  int k;
  double tmp;
  double a0, b0, c0, a1, b1, c1, a2, b2, c2, a3, b3, c3;

  if (type < 4)
    {

      switch (type)
	{
	case 0:
	  for (k = 0; k < 10; k++)
	    *(coefs + k) = *(g0 + k);
	  break;
	case 1:
	  *coefs = *(g0 + 3);
	  *(coefs + 4) = *(g0 + 6);
	  *(coefs + 7) = *(g0 + 8);
	  *(coefs + 9) = *(g0 + 9);
	  *(coefs + 1) = *(g0 + 6) * 2.0 - *(g0 + 2);
	  *(coefs + 5) = *(g0 + 8) * 2.0 - *(g0 + 5);
	  *(coefs + 8) = *(g0 + 9) * 2.0 - *(g0 + 7);
	  *(coefs + 3) = *g1;
	  *(coefs + 6) = *g1 * 2.0 - *(g1 + 4);
	  *(coefs + 2) = (*g1 - *(g1 + 4)) * 2.0 + *(g1 + 1);
	  break;
	case 2:
	  *(coefs + 9) = *(g0 + 9);
	  *(coefs + 7) = tmp = *(g0 + 9) * 2.0 - *(g0 + 7);
	  *(coefs + 8) = *(g0 + 9) * 2.0 - *(g0 + 8);
	  *(coefs + 5) = (tmp - *(g0 + 8)) * 2.0 + *(g0 + 5);
	  *coefs = *g1;
	  *(coefs + 1) = *g1 * 2.0 - *(g1 + 1);
	  *(coefs + 4) = *g1 * 2.0 - *(g1 + 4);
	  *(coefs + 3) = *(g3 + 3);
	  *(coefs + 2) = *(g3 + 3) * 2.0 - *(g3 + 2);
	  *(coefs + 6) = *(g3 + 3) * 2.0 - *(g3 + 6);
	  break;
	case 3:
	  *(coefs + 3) = *g0;
	  *(coefs + 6) = *(g0 + 4);
	  *(coefs + 8) = *(g0 + 7);
	  *(coefs + 9) = *(g0 + 9);
	  *(coefs + 2) = *(g0 + 4) * 2.0 - *(g0 + 1);
	  *(coefs + 5) = *(g0 + 7) * 2.0 - *(g0 + 5);
	  *(coefs + 7) = *(g0 + 9) * 2.0 - *(g0 + 8);
	  *coefs = *(g3 + 3);
	  *(coefs + 4) = *(g3 + 3) * 2.0 - *(g3 + 6);
	  *(coefs + 1) = (*(g3 + 3) - *(g3 + 6)) * 2.0 + *(g3 + 2);
	  break;

	default:
	  fprintf (stderr, "error: unrecognized type '%i'! [loc_extension]\n",
		   type);
	  exit (-1);
	}
    }
  else
    {

      /*  domain points of the white cell used here: 
       *
       *
       *  **  a1  b1  ** 
       *    **  c1  a2
       *  b0  **  **  **
       *    c0  **  c2
       *  a0  **  **  **
       *    **  c3  b2
       *  **  b3  a3  **
       */
      a0 = *(g3 + 3) * 2.0 - *(g3 + 2);
      b0 = *g1 * 2.0 - *(g1 + 1);
      c0 =
	a0 + b0 - *(g0 + 9) * 4.0 + (*(g0 + 7) + *(g0 + 8)) * 2.0 - *(g0 + 5);
      a1 = *(g1 + 4) * 2.0 - *(g1 + 1);
      a2 = (*(g2 + 2) + *(g2 + 3)) - *(g2 + 6);
      b1 = a2 * 2.0 - *(g2 + 2);
      c1 = a1 + b1 - *(g1 + 7) * 2.0 + *(g1 + 5);
      b2 = (*g2 + *(g2 + 1)) - *(g2 + 4);
      c2 = (*(g2 + 1) + *(g2 + 2)) - *(g2 + 5);
      a3 = b2 * 2.0 - *(g2 + 1);
      b3 = *(g3 + 6) * 2.0 - *(g3 + 2);
      c3 = a3 + b3 - *(g3 + 8) * 2.0 + *(g3 + 5);

      switch (type)
	{
	case 4:
	  *coefs = *(g3 + 3);
	  *(coefs + 1) = a0;
	  *(coefs + 2) = b0;
	  *(coefs + 3) = *g1;
	  *(coefs + 4) = (a0 + b3) / 2.0;
	  *(coefs + 5) = c0;
	  *(coefs + 6) = (b0 + a1) / 2.0;
	  *(coefs + 7) = (c0 + c3) / 2.0;
	  *(coefs + 8) = (c0 + c1) / 2.0;
	  *(coefs + 9) = (c0 + c1 + c2 + c3) / 4.0;
	  break;
	case 5:
	  *coefs = *g1;
	  *(coefs + 1) = a1;
	  *(coefs + 2) = b1;
	  *(coefs + 3) = *(g2 + 3);
	  *(coefs + 4) = (b0 + a1) / 2.0;
	  *(coefs + 5) = c1;
	  *(coefs + 6) = a2;
	  *(coefs + 7) = (c0 + c1) / 2.0;
	  *(coefs + 8) = (c1 + c2) / 2.0;
	  *(coefs + 9) = (c0 + c1 + c2 + c3) / 4.0;
	  break;
	case 6:
	  *coefs = *(g2 + 3);
	  *(coefs + 1) = *(g2 + 2);
	  *(coefs + 2) = *(g2 + 1);
	  *(coefs + 3) = *g2;
	  *(coefs + 4) = a2;
	  *(coefs + 5) = c2;
	  *(coefs + 6) = b2;
	  *(coefs + 7) = (c1 + c2) / 2.0;
	  *(coefs + 8) = (c2 + c3) / 2.0;
	  *(coefs + 9) = (c0 + c1 + c2 + c3) / 4.0;
	  break;
	case 7:
	  *coefs = *g2;
	  *(coefs + 1) = a3;
	  *(coefs + 2) = b3;
	  *(coefs + 3) = *(g3 + 3);
	  *(coefs + 4) = b2;
	  *(coefs + 5) = c3;
	  *(coefs + 6) = (a0 + b3) / 2.0;
	  *(coefs + 7) = (c2 + c3) / 2.0;
	  *(coefs + 8) = (c0 + c3) / 2.0;
	  *(coefs + 9) = (c0 + c1 + c2 + c3) / 4.0;
	  break;
	default:
	  fprintf (stderr, "error: unrecognized type '%i'! [loc_extension]\n",
		   type);
	  exit (-1);
	}
    }
}

static void
add_loc_extension (double *coefs, int type,
		   double *g0, double *g1, double *g2, double *g3)
/* the same as 'loc_extension', but coefficients are _added_ to coefs;
the main difference in the program is that some '=' signs are replaced with '+=';
however, watch 'tmp =' ! */
{
  int k;
  double tmp;
  double a0, b0, c0, a1, b1, c1, a2, b2, c2, a3, b3, c3;

  if (type < 4)
    {

      switch (type)
	{
	case 0:
	  for (k = 0; k < 10; k++)
	    *(coefs + k) += *(g0 + k);
	  break;
	case 1:
	  *coefs += *(g0 + 3);
	  *(coefs + 4) += *(g0 + 6);
	  *(coefs + 7) += *(g0 + 8);
	  *(coefs + 9) += *(g0 + 9);
	  *(coefs + 1) += *(g0 + 6) * 2.0 - *(g0 + 2);
	  *(coefs + 5) += *(g0 + 8) * 2.0 - *(g0 + 5);
	  *(coefs + 8) += *(g0 + 9) * 2.0 - *(g0 + 7);
	  *(coefs + 3) += *g1;
	  *(coefs + 6) += *g1 * 2.0 - *(g1 + 4);
	  *(coefs + 2) += (*g1 - *(g1 + 4)) * 2.0 + *(g1 + 1);
	  break;
	case 2:
	  *(coefs + 9) += *(g0 + 9);
	  *(coefs + 7) += tmp = *(g0 + 9) * 2.0 - *(g0 + 7);
	  *(coefs + 8) += *(g0 + 9) * 2.0 - *(g0 + 8);
	  *(coefs + 5) += (tmp - *(g0 + 8)) * 2.0 + *(g0 + 5);
	  *coefs += *g1;
	  *(coefs + 1) += *g1 * 2.0 - *(g1 + 1);
	  *(coefs + 4) += *g1 * 2.0 - *(g1 + 4);
	  *(coefs + 3) += *(g3 + 3);
	  *(coefs + 2) += *(g3 + 3) * 2.0 - *(g3 + 2);
	  *(coefs + 6) += *(g3 + 3) * 2.0 - *(g3 + 6);
	  break;
	case 3:
	  *(coefs + 3) += *g0;
	  *(coefs + 6) += *(g0 + 4);
	  *(coefs + 8) += *(g0 + 7);
	  *(coefs + 9) += *(g0 + 9);
	  *(coefs + 2) += *(g0 + 4) * 2.0 - *(g0 + 1);
	  *(coefs + 5) += *(g0 + 7) * 2.0 - *(g0 + 5);
	  *(coefs + 7) += *(g0 + 9) * 2.0 - *(g0 + 8);
	  *coefs += *(g3 + 3);
	  *(coefs + 4) += *(g3 + 3) * 2.0 - *(g3 + 6);
	  *(coefs + 1) += (*(g3 + 3) - *(g3 + 6)) * 2.0 + *(g3 + 2);
	  break;
	default:
	  fprintf (stderr, "error: unrecognized type '%i'! [loc_extension]\n",
		   type);
	  exit (-1);
	}
    }
  else
    {

      a0 = *(g3 + 3) * 2.0 - *(g3 + 2);
      b0 = *g1 * 2.0 - *(g1 + 1);
      c0 =
	a0 + b0 - *(g0 + 9) * 4.0 + (*(g0 + 7) + *(g0 + 8)) * 2.0 - *(g0 + 5);
      a1 = *(g1 + 4) * 2.0 - *(g1 + 1);
      a2 = (*(g2 + 2) + *(g2 + 3)) - *(g2 + 6);
      b1 = a2 * 2.0 - *(g2 + 2);
      c1 = a1 + b1 - *(g1 + 7) * 2.0 + *(g1 + 5);
      b2 = (*g2 + *(g2 + 1)) - *(g2 + 4);
      c2 = (*(g2 + 1) + *(g2 + 2)) - *(g2 + 5);
      a3 = b2 * 2.0 - *(g2 + 1);
      b3 = *(g3 + 6) * 2.0 - *(g3 + 2);
      c3 = a3 + b3 - *(g3 + 8) * 2.0 + *(g3 + 5);


      switch (type)
	{
	case 4:
	  *coefs += *(g3 + 3);
	  *(coefs + 1) += a0;
	  *(coefs + 2) += b0;
	  *(coefs + 3) += *g1;
	  *(coefs + 4) += (a0 + b3) / 2.0;
	  *(coefs + 5) += c0;
	  *(coefs + 6) += (b0 + a1) / 2.0;
	  *(coefs + 7) += (c0 + c3) / 2.0;
	  *(coefs + 8) += (c0 + c1) / 2.0;
	  *(coefs + 9) += (c0 + c1 + c2 + c3) / 4.0;
	  break;
	case 5:
	  *coefs += *g1;
	  *(coefs + 1) += a1;
	  *(coefs + 2) += b1;
	  *(coefs + 3) += *(g2 + 3);
	  *(coefs + 4) += (b0 + a1) / 2.0;
	  *(coefs + 5) += c1;
	  *(coefs + 6) += a2;
	  *(coefs + 7) += (c0 + c1) / 2.0;
	  *(coefs + 8) += (c1 + c2) / 2.0;
	  *(coefs + 9) += (c0 + c1 + c2 + c3) / 4.0;
	  break;
	case 6:
	  *coefs += *(g2 + 3);
	  *(coefs + 1) += *(g2 + 2);
	  *(coefs + 2) += *(g2 + 1);
	  *(coefs + 3) += *g2;
	  *(coefs + 4) += a2;
	  *(coefs + 5) += c2;
	  *(coefs + 6) += b2;
	  *(coefs + 7) += (c1 + c2) / 2.0;
	  *(coefs + 8) += (c2 + c3) / 2.0;
	  *(coefs + 9) += (c0 + c1 + c2 + c3) / 4.0;
	  break;
	case 7:
	  *coefs += *g2;
	  *(coefs + 1) += a3;
	  *(coefs + 2) += b3;
	  *(coefs + 3) += *(g3 + 3);
	  *(coefs + 4) += b2;
	  *(coefs + 5) += c3;
	  *(coefs + 6) += (a0 + b3) / 2.0;
	  *(coefs + 7) += (c2 + c3) / 2.0;
	  *(coefs + 8) += (c0 + c3) / 2.0;
	  *(coefs + 9) += (c0 + c1 + c2 + c3) / 4.0;
	  break;
	default:
	  fprintf (stderr, "error: unrecognized type '%i'! [loc_extension]\n",
		   type);
	  exit (-1);
	}
    }
}

int
get_location_of_triangle_SpC1d3D2 (int i, int j, int n)
/* computes the starting index into coefs of the grey triangle (i,j,0)
in the 'coefs' field of spline and 'wcoefs*' fields of the window;
it thus makes sense only if i+j is an even number */
{

  return 10 * (((n + 2) * (j + 1) + i + 1) / 2);
}




void
compute_bbcoefs_SpC1d3D2 (double *coefs, int i, int j, int ind,
			  SpC1d3D2 * spline)
/* we assume that -1\le i\le spline->n and -1\le j\le spline->m */
/* compute the BB coefficients of the spline in the (i,j,ind)-triangle,
 * where (i,j) are the coordinates of the square [i,i+1]x[j,j+1], and ind is the
 * index of the subtriangle as in the following diagram: 
 *   |---------|
 *   |    1    |
 *   | 0     2 |
 *   |    3    |
 *   |---------| 
*/
{
  int type;
  double *g0, *g1, *g2, *g3;
  int ind0, ind1, ind2, ind3;



  /* determine the type of the triangle according to 'loc_extension' */

  if ((i + j) % 2)
    type = ind + 4;
  else
    type = ind;


  if (type > 3)
    i--;			/* i.e. in this case i is replaced with i-1 */

  /* find the locations in the array "spline->coefs" 
     of the four grey triangles needed for the computation;
     if we get to the second strip outside the domain, we just set
     the index to zero since the values are irrelevant */

  ind0 = get_location_of_triangle_SpC1d3D2 (i, j, spline->n);
  if (ind0 < 0)
    ind0 = 0;
  ind1 = get_location_of_triangle_SpC1d3D2 (i + 1, j + 1, spline->n);
  if (j == spline->m)
    ind1 = 0;
  ind2 = get_location_of_triangle_SpC1d3D2 (i + 2, j, spline->n);
  ind3 = get_location_of_triangle_SpC1d3D2 (i + 1, j - 1, spline->n);
  if (ind3 < 0)
    ind3 = 0;

  g0 = spline->coefs + ind0;
  g1 = spline->coefs + ind1;
  g2 = spline->coefs + ind2;
  g3 = spline->coefs + ind3;



  /* call the function */

  loc_extension (coefs, type, g0, g1, g2, g3);


}



static int
update_window (int wli, int wri, int wlj, int wrj,
	       TSFIT_DATA * data, SpC1d3D2 * spline,
	       TSFIT_LOCAL_METHOD * local_method, TSFIT_CONVERTER * converter)
/* wli is the i index of the first  cell  */
/* wri is the i index of the last  cell  */
/* wlj is the j index of the first  cell  */
/* wrj is the j index of the last  cell  */
/* returns the number of updated grey triangles: zero if nothing has been done,
in particular when e.g. wli > wri */
/*  local polynomials are updated for all spline cells in the window plus 
one more strip around; grey triangles are updated in the window plus the first 
strip if window is at the boundary of the domain */
/* the window shrinks if it is not completely in the domain and is enlarged
if needed to ensure that the starting cell is black */
{

  double hx = spline->hx;
  /* = (data->xmax - data->xmin) / data->scaling_factor / (double)spline->n; */
  double hy = spline->hy;
  /* = (data->ymax - data->ymin) / data->scaling_factor / (double)spline->m; */
  int n = spline->n;
  int m = spline->m;
  int indb, indw;
  int i, j, k;
  double llx, llx_fixed, lly;
  TRIEL *element = spline->locale;
  int wm, wn, ntri;
  WINDOW_SpC1d3D2 *window = spline->window;
  double *gg = window->gg;
  double *g0 = gg, *g1 = gg, *g2 = gg, *g3 = gg;	/* pointers to BB coefs needed for
							   local computations; we initialize 
							   them arbitrarily for the case that
							   their values for the first use 
							   are irrelevant -- for the (virtual)
							   triangles of the _second_ strip */
  int ind, ind0, ind1, ind2, ind3, ind4, ind5, ind6, sh;
  int nUpdated = 0;






  /* since we have a uniform triangulation, diameters of all triangles
     are the same, and we take hx as a good approxiamation 
     -- instead of calling find_tri_diam */

  element->triangle.diam = hx;


  /*** compute the local polynomial approximations ***/


  /* shrink the window if it is not completely in the domain */

  if (wlj < 0)
    wlj = 0;
  if (wli < 0)
    wli = 0;

  if (wrj > m)
    wrj = m;
  if (wri > n)
    wri = n;

  /* ensure that the starting cell (i.e. the one in the left bottom corner)
     is _black_; to achive that we enlarge the window if needed */

  if ((wli + wlj) % 2)
    {
      if (wlj % 2)
	wlj--;
      else
	wli--;
    }

  wm = window->wm = wrj - wlj;	/* number of proper cells in y direction */
  wn = window->wn = wri - wli;	/* number of proper cells in x direction */

  if (wm <= 0 || wn <= 0)
    return 0;			/* this stops the program if
				   there is nothing to update,
				   i.e. if window parameters are incorrect */


  sh = 10 * (wn + 2);

  ntri = (((wn + 3) * (wm + 3) + 1) / 2) * 10;	/* window size for allocation;
						   (((wn + 2) * (wm + 2) + 1) / 2) * 10  
						   would be sufficient, but we give
						   more space to avoid some tests for
						   'get_location_of_triangle_SpC1d3D2' at the boundary */

  if (ntri > window->ntri)
    {


      window->ntri = ntri;

      window->wcoefs0 = (double *) realloc (window->wcoefs0,
					    ntri * sizeof (double));

      if (window->wcoefs0 == NULL)
	{
	  fprintf (stderr, "error: memory allocation failure [spline]\n");
	  exit (-1);
	}

      memset (window->wcoefs0, 0, window->ntri * sizeof (double));


      window->wcoefs1 = (double *) realloc (window->wcoefs1,
					    ntri * sizeof (double));

      if (window->wcoefs1 == NULL)
	{
	  fprintf (stderr, "error: memory allocation failure [spline]\n");
	  exit (-1);
	}


      memset (window->wcoefs1, 0, window->ntri * sizeof (double));


      window->wcoefs2 = (double *) realloc (window->wcoefs2,
					    ntri * sizeof (double));

      if (window->wcoefs2 == NULL)
	{
	  fprintf (stderr, "error: memory allocation failure [spline]\n");
	  exit (-1);
	}

      memset (window->wcoefs2, 0, window->ntri * sizeof (double));

      window->wcoefs3 = (double *) realloc (window->wcoefs3,
					    ntri * sizeof (double));

      if (window->wcoefs3 == NULL)
	{
	  fprintf (stderr, "error: memory allocation failure [spline]\n");
	  exit (-1);
	}

      memset (window->wcoefs3, 0, window->ntri * sizeof (double));

      window->wcoefs4 = (double *) realloc (window->wcoefs4,
					    ntri * sizeof (double));

      if (window->wcoefs4 == NULL)
	{
	  fprintf (stderr, "error: memory allocation failure [spline]\n");
	  exit (-1);
	}

      memset (window->wcoefs4, 0, window->ntri * sizeof (double));

      window->wcoefs5 = (double *) realloc (window->wcoefs5,
					    ntri * sizeof (double));

      if (window->wcoefs5 == NULL)
	{
	  fprintf (stderr, "error: memory allocation failure [spline]\n");
	  exit (-1);
	}

      memset (window->wcoefs5, 0, window->ntri * sizeof (double));

      window->wcoefs6 = (double *) realloc (window->wcoefs6,
					    ntri * sizeof (double));

      if (window->wcoefs6 == NULL)
	{
	  fprintf (stderr, "error: memory allocation failure [spline]\n");
	  exit (-1);
	}

      memset (window->wcoefs6, 0, window->ntri * sizeof (double));

      window->wcoefs7 = (double *) realloc (window->wcoefs7,
					    ntri * sizeof (double));

      if (window->wcoefs7 == NULL)
	{
	  fprintf (stderr, "error: memory allocation failure [spline]\n");
	  exit (-1);
	}

      memset (window->wcoefs7, 0, window->ntri * sizeof (double));


    }

  /* starting left x and y endpoints */

  llx_fixed = (wli - 1) * hx;
  lly = (wlj - 1) * hy;

  element->triangle.x3 = llx_fixed + 0.5 * hx;
  element->triangle.y3 = lly + 0.5 * hy;


  /* initialize indb (ind of black triangles)
     and indw  (ind of white triangles) */

  indb = indw = 0;


  /* loop over all cells where local approximations are needed 
     (i.e. proper cells plus one strip) */

  for (j = -1; j <= wm; j++)
    {
      llx = llx_fixed;
      element->triangle.x3 = llx_fixed + 0.5 * hx;

      for (i = -1; i <= wn; i++)
	{

	  /* i,j and k (see below) are currently only useful for multilevel stuff */

	  element->i = wli + i;
	  element->j = wlj + j;




	  /* in each step we compute the local approximations on
	     the four triangles of one quadrilateral (either black or white
	     depending on whether i+j is even or not) */

      /** fill in wcoefs0 or wcoefs4 **/

	  element->k = 0;

	  element->triangle.x1 = llx;
	  element->triangle.y1 = lly;
	  element->triangle.x2 = llx;
	  element->triangle.y2 = lly + hy;

	  find_tri_center (&element->triangle);



	  if (abs (i + j) % 2)
	    {
	      element->coefs = window->wcoefs4 + indw;
	      converter->call_local_method (element, converter->body,
					    local_method, data);
	    }
	  else
	    {
	      element->coefs = window->wcoefs0 + indb;
	      converter->call_local_method (element, converter->body,
					    local_method, data);
	    }

      /** fill in wcoefs1 or wcoefs5 **/

	  element->k = 1;

	  element->triangle.x1 = llx;
	  element->triangle.y1 = lly + hy;
	  element->triangle.x2 = llx + hx;
	  element->triangle.y2 = lly + hy;

	  find_tri_center (&element->triangle);





	  if (abs (i + j) % 2)
	    {
	      element->coefs = window->wcoefs5 + indw;
	      converter->call_local_method (element, converter->body,
					    local_method, data);
	    }
	  else
	    {
	      element->coefs = window->wcoefs1 + indb;
	      converter->call_local_method (element, converter->body,
					    local_method, data);
	    }



      /** fill in wcoefs2 or wcoefs6 **/

	  element->k = 2;


	  element->triangle.x1 = llx + hx;
	  element->triangle.y1 = lly + hy;
	  element->triangle.x2 = llx + hx;
	  element->triangle.y2 = lly;

	  find_tri_center (&element->triangle);





	  if (abs (i + j) % 2)
	    {
	      element->coefs = window->wcoefs6 + indw;
	      converter->call_local_method (element, converter->body,
					    local_method, data);
	    }
	  else
	    {
	      element->coefs = window->wcoefs2 + indb;
	      converter->call_local_method (element, converter->body,
					    local_method, data);
	    }



      /** fill in wcoefs3 or wcoefs7 **/


	  element->k = 3;


	  element->triangle.x1 = llx + hx;
	  element->triangle.y1 = lly;
	  element->triangle.x2 = llx;
	  element->triangle.y2 = lly;

	  find_tri_center (&element->triangle);







	  if (abs (i + j) % 2)
	    {
	      element->coefs = window->wcoefs7 + indw;
	      converter->call_local_method (element, converter->body,
					    local_method, data);
	    }
	  else
	    {
	      element->coefs = window->wcoefs3 + indb;
	      converter->call_local_method (element, converter->body,
					    local_method, data);
	    }



      /** increment various indices (they are only related to how
      the coefs are positioned in wcoefs* arrays **/

	  if (abs (i + j) % 2)
	    indw += 10;
	  else
	    indb += 10;

	  llx += hx;


	  /* x3 and y3 are the same for all four triangles (coordinates of the cross vertex) */

	  element->triangle.x3 += hx;
	}

      lly += hy;
      element->triangle.y3 += hy;

    }






  /*** compute and store the coefficients of the averaged spline 
       coming from the current window ***/


  /* reinitialize the starting left  y endpoint of the cell */

  lly = (wlj - 1) * hy;



  /* reinitialize indb */

  indb = 0;

  /* loop over all cells where update of grey triangles may be needed 
     (i.e. black proper cells plus black cells of one strip -- the latter
     are needed at the boundary of the domain) */

  for (j = -1; j <= wm; j++)
    {

      /* avoid y strips if we are not at the boundary */

      if (j == -1 && wlj > 0)
	{

	  lly += hy;
	  continue;

	}

      if (j == wm && wrj < m)
	{

	  lly += hy;
	  continue;

	}

      /* reinitialize llx */

      llx = llx_fixed;

      for (i = -1; i <= wn; i++)
	{

	  /* avoid white cells */

	  if (abs (i + j) % 2)
	    {

	      llx += hx;
	      continue;

	    }

	  /* avoid x strips if we are not at the boundary */

	  if (i == -1 && wli > 0)
	    {

	      indb += 10;
	      llx += hx;
	      continue;

	    }

	  if (i == wn && wri < n)
	    {

	      indb += 10;
	      llx += hx;
	      continue;

	    }

	  /* determine where to store the computed coefs */

	  ind = get_location_of_triangle_SpC1d3D2 (wli + i, wlj + j, n);


	  /* determine the location of various window cells involved */
	  /* sometimes at the boundary 'get_location_of_triangle_SpC1d3D2' might be
	     negative, but we just do not need g3, etc. in that case */


	  ind0 = get_location_of_triangle_SpC1d3D2 (i, j, wn);
	  ind1 = get_location_of_triangle_SpC1d3D2 (i - 1, j - 1, wn);
	  if (ind1 < 0)
	    ind1 = 0;
	  ind2 = get_location_of_triangle_SpC1d3D2 (i - 1, j + 1, wn);
	  if (ind2 < 0)
	    ind2 = 0;
	  ind3 = get_location_of_triangle_SpC1d3D2 (i - 1, j, wn);
	  if (ind3 < 0)
	    ind3 = 0;
	  ind4 = get_location_of_triangle_SpC1d3D2 (i, j + 1, wn);
	  ind5 = get_location_of_triangle_SpC1d3D2 (i, j - 1, wn);
	  if (ind5 < 0)
	    ind5 = 0;
	  ind6 = get_location_of_triangle_SpC1d3D2 (i + 1, j, wn);


	  /* coefficients coming from wcoefs0 */


	  memcpy (spline->coefs + ind, window->wcoefs0 + ind0,
		  10 * sizeof (double));




	  /* coefficients coming from wcoefs1 */

	  g0 = window->wcoefs1 + ind0;
	  g3 = window->wcoefs1 + ind1;




	  add_loc_extension (spline->coefs + ind, 3, g0, g1, g2, g3);

	  /* coefficients coming from wcoefs2 */

	  g0 = window->wcoefs2 + ind0;
	  g1 = window->wcoefs2 + ind1;
	  g3 = window->wcoefs2 + ind2;




	  add_loc_extension (spline->coefs + ind, 2, g0, g1, g2, g3);


	  /* coefficients coming from wcoefs3 */

	  g0 = window->wcoefs3 + ind0;
	  g1 = window->wcoefs3 + ind2;




	  add_loc_extension (spline->coefs + ind, 1, g0, g1, g2, g3);


	  /* coefficients coming from wcoefs4 */

	  g0 = window->wcoefs4 + ind3;
	  g1 = window->wcoefs4 + ind4;
	  g2 = window->wcoefs4 + ind6;
	  g3 = window->wcoefs4 + ind5;



	  add_loc_extension (spline->coefs + ind, 4, g0, g1, g2, g3);


	  /* coefficients coming from wcoefs5 */

	  g3 = window->wcoefs5 + ind3;
	  g0 = window->wcoefs5 + ind4;
	  g1 = window->wcoefs5 + ind6;
	  g2 = window->wcoefs5 + ind5;


	  add_loc_extension (spline->coefs + ind, 7, g0, g1, g2, g3);


	  /* coefficients coming from wcoefs6 */

	  g2 = window->wcoefs6 + ind3;
	  g3 = window->wcoefs6 + ind4;
	  g0 = window->wcoefs6 + ind6;
	  g1 = window->wcoefs6 + ind5;



	  add_loc_extension (spline->coefs + ind, 6, g0, g1, g2, g3);



	  /* coefficients coming from wcoefs7 */

	  g1 = window->wcoefs7 + ind3;
	  g2 = window->wcoefs7 + ind4;
	  g3 = window->wcoefs7 + ind6;
	  g0 = window->wcoefs7 + ind5;

	  add_loc_extension (spline->coefs + ind, 5, g0, g1, g2, g3);



	  /* average of all 8 versions */

	  for (k = 0; k < 10; k++)
	    (spline->coefs)[ind + k] /= 8.0;

	  nUpdated++;

	  /* increment */

	  indb += 10;

	  llx += hx;
	}

      lly += hy;

    }




  return nUpdated;

}







void
compute_SpC1d3D2 (void *data_void, void *spline_void,
		  TSFIT_LOCAL_METHOD * local_method,
		  TSFIT_CONVERTER * converter)
{
  TSFIT_DATA *data = (TSFIT_DATA *) data_void;
  SpC1d3D2 *spline = (SpC1d3D2 *) spline_void;
  int i, j;
  double hx = spline->hx;
  /* = (data->xmax - data->xmin) / data->scaling_factor / (double)spline->n; */
  double hy = spline->hy;
  /* = (data->ymax - data->ymin) / data->scaling_factor / (double)spline->m; */
  double lly = -hy;
  double llx;
  /* double radius = hx * lscontr->init_rad_factor; */
  double *start;
  TRIEL *element = spline->locale;


  /* initialize the spline  structure */


  /* init_SpC1d3D2 (spline); */


  /* since we have a uniform triangulation, diameters of all triangles
     are the same, and we take hx as a good approxiamation 
     -- instead of calling find_tri_diam */

  element->triangle.diam = spline->hx;


  if (!spline->av)
    {

      start = spline->coefs;

      element->k = 0;


      for (j = -1; j <= spline->m; j++)
	{
	  llx = -hx;
	  for (i = -1; i <= spline->n; i++)
	    {

	      /* to avoid white squares: continue if 
	         i+j is odd. Do not increment 'start'! */

	      if (abs (i + j) % 2)
		{
		  llx += hx;
		  continue;
		}

	      /* no computation for the two corner triangles that are not needed 
	         for the spline; this requres several comparisons for each i,j
	         which actually might be too expensive to do in order 
	         to just avoid two triangles */

	      if (i == -1 && j == -1)
		{
		  llx += hx;
		  start += 10;
		  continue;
		}

	      if (spline->m % 2 && i == -1 && j == spline->m)
		{
		  llx += hx;
		  start += 10;
		  continue;
		}

	      element->i = i;
	      element->j = j;


	      /* vertices of the triangle */

	      element->triangle.x1 = llx;
	      element->triangle.y1 = lly;
	      element->triangle.x2 = llx;
	      element->triangle.y2 = lly + hy;
	      element->triangle.x3 = llx + 0.5 * hx;
	      element->triangle.y3 = lly + 0.5 * hy;

	      find_tri_center (&element->triangle);

	      element->coefs = start;

	      /* compute the local approximation and
	         fill in the coefs of the spline */

	      converter->call_local_method (element, converter->body,
					    local_method, data);


	      /* increment */

	      start += 10;

	      llx += hx;

	    }

	  lly += hy;
	}

    }
  else
    {				/* averaged spline */


      int nUpdated = 0;
      int ws = spline->ws;
      int wxnum = spline->n / ws + 1;
      int wynum = spline->m / ws + 1;



      for (i = 0; i < wxnum; i++)
	for (j = 0; j < wynum; j++)
	  {
	    nUpdated =
	      update_window (i * ws, (i + 1) * ws, j * ws, (j + 1) * ws, data,
			     spline, local_method, converter);


	  }

    }

}

static void
locate_point_D2 (double x, double y, int n, int m, double hx, double hy,
		 int *i, int *j, int *ind)
/* compute the indices i,j,ind of the triangle in the Delta^2 partition 
   where (x,y) lies; n,m,hx,hy are the parameters of the Delta^2 partition;
   the starting point of the partition is (0,0), which is achieved by
   "scaling" */
{
  int ii, jj;
  double xa, ya;

  /* auxiliary variables */

  xa = x / hx;
  ya = y / hy;

  /* compute i */

  ii = (int) xa;
  if (ii < 0)
    ii = 0;
  if (ii >= n)
    ii = n - 1;
  *i = ii;

  /* compute j */

  jj = (int) ya;
  if (jj < 0)
    jj = 0;
  if (jj >= m)
    jj = m - 1;
  *j = jj;

  /* compute ind */

  xa -= (double) ii;
  ya -= (double) jj;

  if (xa - ya < 0.0)
    if (ya + xa < 1.0)
      *ind = 0;
    else
      *ind = 1;
  else if (ya + xa < 1.0)
    *ind = 3;
  else
    *ind = 2;

}


double
eval_SpC1d3D2 (double x, double y, void *spline_void)
/* evaluates the _scaled_ spline at _one_ point (x,y) in [0,1]^2 */
{
  SpC1d3D2 *spline = (SpC1d3D2 *) spline_void;
  int i, j, ind;
  double rho, sigma, tau;
  BBTRI *bbtri = spline->bbtri;
  double hx = spline->hx, hy = spline->hy;


  /* determine the indices (i,j,ind) of the triangle where (x,y) lies */

  locate_point_D2 (x, y, spline->n, spline->m, hx, hy, &i, &j, &ind);


  /* determine the vertices of the triangle */

  switch (ind)
    {
    case 0:
      bbtri->triangle->x2 = bbtri->triangle->x1 = hx * (double) i;
      bbtri->triangle->y1 = hy * (double) j;
      bbtri->triangle->y2 = hy * ((double) j + 1.0);
      break;
    case 1:
      bbtri->triangle->x2 = hx * ((double) i + 1.0);
      bbtri->triangle->y2 = bbtri->triangle->y1 = hy * ((double) j + 1.0);
      bbtri->triangle->x1 = hx * (double) i;
      break;
    case 2:
      bbtri->triangle->x2 = bbtri->triangle->x1 = hx * ((double) i + 1.0);
      bbtri->triangle->y1 = hy * ((double) j + 1.0);
      bbtri->triangle->y2 = hy * (double) j;
      break;
    case 3:
      bbtri->triangle->x1 = hx * ((double) i + 1.0);
      bbtri->triangle->x2 = hx * (double) i;
      bbtri->triangle->y2 = bbtri->triangle->y1 = hy * (double) j;
      break;
    default:
      fprintf (stderr,
	       "error: unrecognized index 'ind = %i'! [eval_SpC1d3D2]\n",
	       ind);
      exit (-1);

    }

  bbtri->triangle->x3 = hx * ((double) i + 0.5);
  bbtri->triangle->y3 = hy * ((double) j + 0.5);

  /* compute the BB coefficients in this triangle */


  compute_bbcoefs_SpC1d3D2 (bbtri->coefs, i, j, ind, spline);

  /* compute the barycentric coordinates rho, sigma, tau
     of (x,y) w.r.t. the triangle */

  tri_desc2bary (x, y, &rho, &sigma, &tau, bbtri->triangle);


  /* call the deCasteljau algorithm to evaluate */

  return bbtri_deCast (rho, sigma, tau, bbtri);

}

void
store_bbcoefs_SpC1d3D2 (SpC1d3D2 * spline, char *filename)
/* stores the BB coefficients of _all_ triangles inside the domain
(not only grey!) on the disk in a file 'filename' */
{
  FILE *fd;
  int i, j, ind, k;
  double coefs[10];

  fd = fopen (filename, "w");

  if (fd == NULL)
    {
      fprintf (stderr, "error: file opening failure \'%s\' [store_bbcoefs_SpC1d3D2]\n", filename);
      exit (-1);
    }

  fprintf (fd, "%i %i\n", spline->n, spline->m);

  for (j = 0; j < spline->m; j++)
    for (i = 0; i < spline->n; i++)
      for (ind = 0; ind < 4; ind++)
	{

	  compute_bbcoefs_SpC1d3D2 (coefs, i, j, ind, spline);

	  for (k = 0; k < 10; k++)
	    fprintf (fd, "%f ", coefs[k]);

	  fprintf (fd, "\n");

	}


  fclose (fd);

}

void
init_fvsbasis_SpC1d3D2 (SpC1d3D2 * spline)
{
  int i;
  FVSBASIS *fvsbasis;

  fvsbasis = (FVSBASIS *) malloc (sizeof (FVSBASIS));

  if (fvsbasis == NULL)
    {
      fprintf (stderr, "error: memory allocation failure [fvsbasis]\n");
      exit (-1);
    }

  spline->fvsbasis = fvsbasis;

  fvsbasis->n = spline->n;
  fvsbasis->m = spline->m;


  /* allocate memory for the function values 'f' at the vertices of the
     quadrangulation */

  fvsbasis->f = (double **) calloc (fvsbasis->n + 3, sizeof (double *));

  if (fvsbasis->f == NULL)
    {
      fprintf (stderr, "error: memory allocation failure [fvsbasis->f]\n");
      exit (-1);
    }

  for (i = 0; i < fvsbasis->n + 3; i++)
    {
      fvsbasis->f[i] = (double *) calloc (fvsbasis->m + 3, sizeof (double));

      if (fvsbasis->f[i] == NULL)
	{
	  fprintf (stderr, "error: memory allocation failure [fvsbasis->f]\n");
	  exit (-1);
	}
    }

  /* allocate memory for the x-derivative 'fx' at the vertices of the
     quadrangulation */

  fvsbasis->fx = (double **) calloc (fvsbasis->n + 3, sizeof (double *));

  if (fvsbasis->fx == NULL)
    {
      fprintf (stderr, "error: memory allocation failure [fvsbasis->fx]\n");
      exit (-1);
    }

  for (i = 0; i < fvsbasis->n + 3; i++)
    {
      fvsbasis->fx[i] = (double *) calloc (fvsbasis->m + 3, sizeof (double));

      if (fvsbasis->fx[i] == NULL)
	{
	  fprintf (stderr, "error: memory allocation failure [fvsbasis->fx]\n");
	  exit (-1);
	}
    }


  /* allocate memory for the y-derivative 'fy' at the vertices of the
     quadrangulation */

  fvsbasis->fy = (double **) calloc (fvsbasis->n + 3, sizeof (double *));

  if (fvsbasis->fy == NULL)
    {
      fprintf (stderr, "error: memory allocation failure [fvsbasis->fy]\n");
      exit (-1);
    }

  for (i = 0; i < fvsbasis->n + 3; i++)
    {
      fvsbasis->fy[i] = (double *) calloc (fvsbasis->m + 3, sizeof (double));

      if (fvsbasis->fy[i] == NULL)
	{
	  fprintf (stderr, "error: memory allocation failure [fvsbasis->fy]\n");
	  exit (-1);
	}
    }


  /* allocate memory for the normal x-derivative 'fnx' at the middle points
     of the y-direction edges of the quadrangulation */

  fvsbasis->fnx = (double **) calloc (fvsbasis->n + 3, sizeof (double *));

  if (fvsbasis->fnx == NULL)
    {
      fprintf (stderr, "error: memory allocation failure [fvsbasis->fnx]\n");
      exit (-1);
    }

  for (i = 0; i < fvsbasis->n + 3; i++)
    {
      fvsbasis->fnx[i] = (double *) calloc (fvsbasis->m + 2, sizeof (double));

      if (fvsbasis->fnx[i] == NULL)
	{
	  fprintf (stderr, "error: memory allocation failure [fvsbasis->fnx]\n");
	  exit (-1);
	}
    }



  /* allocate memory for the normal y-derivative 'fny' at the middle points
     of the x-direction edges of the quadrangulation */

  fvsbasis->fny = (double **) calloc (fvsbasis->n + 2, sizeof (double *));

  if (fvsbasis->fny == NULL)
    {
      fprintf (stderr, "error: memory allocation failure [fvsbasis->fny]\n");
      exit (-1);
    }

  for (i = 0; i < fvsbasis->n + 2; i++)
    {
      fvsbasis->fny[i] = (double *) calloc (fvsbasis->m + 3, sizeof (double));

      if (fvsbasis->fny[i] == NULL)
	{
	  fprintf (stderr, "error: memory allocation failure [fvsbasis->fny]\n");
	  exit (-1);
	}
    }

  spline->fvs_state = 1;


}




void
free_fvsbasis_SpC1d3D2 (SpC1d3D2 * spline)
{
  int i;



  for (i = 0; i < spline->fvsbasis->n + 2; i++)
    free (spline->fvsbasis->fny[i]);

  free (spline->fvsbasis->fny);


  for (i = 0; i < spline->fvsbasis->n + 3; i++)
    free (spline->fvsbasis->fnx[i]);

  free (spline->fvsbasis->fnx);


  for (i = 0; i < spline->fvsbasis->n + 3; i++)
    free (spline->fvsbasis->fy[i]);

  free (spline->fvsbasis->fy);


  for (i = 0; i < spline->fvsbasis->n + 3; i++)
    free (spline->fvsbasis->fx[i]);

  free (spline->fvsbasis->fx);


  for (i = 0; i < spline->fvsbasis->n + 3; i++)
    free (spline->fvsbasis->f[i]);

  free (spline->fvsbasis->f);

  free (spline->fvsbasis);


  spline->fvs_state = 0;

}



void
transform_to_fvs_SpC1d3D2 (SpC1d3D2 * spline)
{

  int i, j, n1, m1;
  double loc_coefs[10];


  if (spline->fvs_state != 1)
    {
      fprintf (stderr, "error: fvs_state != 1 [transform_to_fvs_SpC1d3D2]\n");
      exit (-1);
    }




  n1 = spline->n + 2;
  m1 = spline->m + 2;


  for (j = 1; j < m1; j++)
    {
      for (i = 1; i < n1; i++)
	{
	  compute_bbcoefs_SpC1d3D2 (loc_coefs, i - 1, j - 1, 3, spline);

	  spline->fvsbasis->f[i][j] = loc_coefs[3];

	  spline->fvsbasis->fx[i][j] = 3.0 * (loc_coefs[2] - loc_coefs[3]);

	  if (i <= n1)
	    {

	      spline->fvsbasis->fny[i][j] =
		1.5 * (loc_coefs[4] + loc_coefs[6]) + 3.0 * loc_coefs[5] -
		2.25 * (loc_coefs[1] + loc_coefs[2]) - 0.75 * (loc_coefs[0] +
							       loc_coefs[3]);


	    }

	  compute_bbcoefs_SpC1d3D2 (loc_coefs, i - 1, j - 1, 0, spline);

	  spline->fvsbasis->fy[i][j] = 3.0 * (loc_coefs[1] - loc_coefs[0]);

	  if (j <= m1)
	    {

	      spline->fvsbasis->fnx[i][j] =
		1.5 * (loc_coefs[4] + loc_coefs[6]) + 3.0 * loc_coefs[5] -
		2.25 * (loc_coefs[1] + loc_coefs[2]) - 0.75 * (loc_coefs[0] +
							       loc_coefs[3]);



	    }

	}
    }



  spline->fvs_state = 2;

}


void
transform_from_fvs_SpC1d3D2 (SpC1d3D2 * spline)
{
  int i, j, i1, j1, mm, nn;
  double v00, v10, v01, v11;
  double *start;
  FVSBASIS *fvsbasis;

  if (spline->fvs_state != 3)
    {
      fprintf (stderr,
	       "error: fvs_state != 3 [transform_from_fvs_SpC1d3D2]\n");
      exit (-1);
    }

  start = spline->coefs;
  mm = spline->m + 2;
  nn = spline->n + 2;
  fvsbasis = spline->fvsbasis;

  for (j = 0, j1 = 1; j < mm; j++, j1++)
    for (i = 0, i1 = 1; i < nn; i++, i1++)
      {
	/** avoid white squares **/

	if (abs (i + j) % 2)
	  continue;

	/** compute 'coefs' of the spline on current black triangle **/

	/* influence of the four function values at the vertices of the black square */

	v00 = fvsbasis->f[i][j];
	v10 = fvsbasis->f[i1][j];
	v01 = fvsbasis->f[i][j1];
	v11 = fvsbasis->f[i1][j1];

	*(start + 4) = *(start + 1) = *start = v00;
	*(start + 6) = *(start + 3) = *(start + 2) = v01;
	*(start + 5) = 0.5 * (v00 + v01);
	*(start + 7) = 0.5 * (v00 + 0.5 * (v01 + v10));
	*(start + 8) = 0.5 * (v01 + 0.5 * (v00 + v11));
	*(start + 9) = 0.25 * (v00 + v10 + v01 + v11);


	/* influence of the four x-derivative values at the vertices of the black square */

	v00 = fvsbasis->fx[i][j];
	v10 = fvsbasis->fx[i1][j];
	v01 = fvsbasis->fx[i][j1];
	v11 = fvsbasis->fx[i1][j1];

	*(start + 4) += v00 / 6.0;
	*(start + 5) -= (v00 + v01) / 12.0;
	*(start + 6) += v01 / 6.0;
	*(start + 7) += (v00 - v01) / 24.0 - v10 / 12.0;
	*(start + 8) += (v01 - v00) / 24.0 - v11 / 12.0;
	*(start + 9) += (v00 + v01 - v10 - v11) / 48.0;


	/* influence of the four y-derivative values at the vertices of the black square */

	v00 = fvsbasis->fy[i][j];
	v10 = fvsbasis->fy[i1][j];
	v01 = fvsbasis->fy[i][j1];
	v11 = fvsbasis->fy[i1][j1];

	*(start + 1) += v00 / 3.0;
	*(start + 2) -= v01 / 3.0;
	*(start + 4) += v00 / 6.0;
	*(start + 5) += (v00 - v01) / 6.0;
	*(start + 6) -= v01 / 6.0;
	*(start + 7) += (v00 - v10) / 24.0 - v01 / 12.0;
	*(start + 8) += (v11 - v01) / 24.0 + v00 / 12.0;
	*(start + 9) += (v00 + v10 - v01 - v11) / 48.0;

	/* influence of the two x-derivative values at the y-edges of the black square */

	v00 = fvsbasis->fnx[i][j];
	v10 = fvsbasis->fnx[i1][j];

	*(start + 5) += v00 / 3.0;
	*(start + 7) += v00 / 6.0;
	*(start + 8) += v00 / 6.0;
	*(start + 9) += (v00 - v10) / 12.0;


	/* influence of the two y-derivative values at the x-edges of the black square */

	v00 = fvsbasis->fny[i][j];
	v01 = fvsbasis->fny[i][j1];

	*(start + 7) += v00 / 6.0;
	*(start + 8) -= v01 / 6.0;
	*(start + 9) += (v00 - v01) / 12.0;


	/* increment */

	start += 10;

      }


  spline->fvs_state = 2;

}

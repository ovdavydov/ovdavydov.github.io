
/* data management */
#include "datamng.h"

/* first stage ("local") method */
#include "lmethod.h"

/* conversion */
#include "convert.h"

/* second stage ("global") method */
#include "gmethod.h"

/* interface to third party linear algebra software */
#include "linalg.h"

/* Bernstein-Bezier techniques */
#include "bezier.h"

/* local search */
#include "locsearch.h"

/* local polynomial approximation */
#include "locpoly.h"

/* rbf local approximation */ 
#include "locrbf.h"

/* splines used in the second stage */
#include "SpC1d3D2.h" 
#include "SpC2d6D2.h" 






		      






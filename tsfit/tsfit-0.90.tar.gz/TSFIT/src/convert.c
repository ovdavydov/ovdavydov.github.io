/* Converting the output of a first stage method to the form
suitable for the use by a second stage method.
 
  Author: Oleg Davydov
	  University of Strathclyde
	  Department of Mathematics
          26 Richmond Street
	  Glasgow G1 1XH
	  Scotland, UK
	  e-mail: oleg.davydov@strath.ac.uk


  Copyright (C) 2005 Oleg Davydov

This file is part of TSFIT.

This package is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This package is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this package; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <values.h>


#include "datamng.h"
#include "lmethod.h"
#include "convert.h"
#include "gmethod.h"

#include "locsearch.h"
#include "bezier.h"
#include "linalg.h"
#include "locpoly.h"
#include "locrbf.h"


/* #define PRINT_CONVERTER_PARAMETERS */


/******************************************************************************/
/***                      degree raising converter                          ***/
/******************************************************************************/

static void
init_degree_raising_converter (void *ccontr_void)
{
}

static void
free_degree_raising_converter (void *ccontr_void)
{
}

/* degree raising converter just converts TRIEL to TRIEL of possibly
higher degree; its "body" is neither initialized nor used */

static void
degree_raising_converter (void *locale, void *ccontr_void,
			  TSFIT_LOCAL_METHOD * local_method, void *data)
{
  TRIEL *global_element = (TRIEL *) locale;
  TRIEL *local_element = (TRIEL *) local_method->locale;

  /* copy the global element to the local element;
     in particular global_element->coefs and global_element->degree
     are copied, which is not always needed */

  /* local_element->triangle = global_element->triangle; */
  *local_element = *global_element;

  /* compute local approximation */

  local_method->compute (data, local_method->body);

  /* raise the degree from local_element->degree to global_element->degree */

  bbtri_raise_degree (local_element->degree, local_element->coefs,
		global_element->degree, global_element->coefs);
}



/******************************************************************************/
/***                    TRIEVAL to TRIEL converter                          ***/
/******************************************************************************/

/* control structure */

typedef struct
{
  int output_degree;		/* degree of the TRIEL polynomial */
  int eval_par;			/* the "degree" for evaluations at BB points */
  int number_eval_points;	/* = (eval_par + 2) * (eval_par + 1) / 2 */
  double *eval_values;		/* array of the size number_eval_points */
  double eval_step;		/* = 1.0 / eval_par */
  SVDMATR *convMatr;		/* conversion matrices */
} CTTCONTROL;



static void
init_trieval_to_triel_converter (void *ccontr_void)
{
  CTTCONTROL *cttcontr = (CTTCONTROL *) ccontr_void;

  int output_dim =
    (cttcontr->output_degree + 1) * (cttcontr->output_degree + 2) / 2;
  int number_eval_points = cttcontr->number_eval_points =
    (cttcontr->eval_par + 2) * (cttcontr->eval_par + 1) / 2;

  int i, j, m;
  double b1, b2, b3;
  int eval_par = cttcontr->eval_par;
  double eval_step = cttcontr->eval_step = 1.0 / eval_par;

  double **Aconv;
  TRINOM trinom;		/* trinomial coefficients: needed for the evaluation
				   of basis functions */

  /* allocate eval_values */

  cttcontr->eval_values =
    (double *) malloc (number_eval_points * sizeof (double));

  if (cttcontr->eval_values == NULL)
    {
      fprintf (stderr,
	       "error: not enough memory! [init_trieval_to_triel_converter]\n");
      exit (-1);
    }


  /* initialize conversion matrices */

  cttcontr->convMatr = init_svdmatr (number_eval_points, output_dim);
  cttcontr->convMatr->type = 'S';

  cttcontr->convMatr->m = number_eval_points;
  cttcontr->convMatr->n = output_dim;

  Aconv = cttcontr->convMatr->A;


  /** build conversion matrices **/


  /* 1) fill in the collocation matrix for number_eval_points uniformly distributed 
     points in the triangle */

  init_trinom (&trinom, cttcontr->output_degree);

  m = 0;
  b1 = b2 = 0.0;
  b3 = 1.0;

  for (i = 0; i <= eval_par; i++)
    {


      for (j = 0; j <= eval_par - i; j++)
	{

	  eval_BB_basis_functions (cttcontr->output_degree, b1, b2, b3,
				   Aconv[m], &trinom);


	  m++;

	  b2 += eval_step;
	  b3 -= eval_step;
	}

      b1 += eval_step;
      b2 = 0.0;
      b3 = 1.0 - b1;

    }

  free_trinom (&trinom);


  /* 2) compute the singular value decomposition  */

  compute_svd (cttcontr->convMatr);

#ifdef PRINT_CONVERTER_PARAMETERS

  /** find and print the min singular value of Aconv **/
  {
    double svconvmin = MAXDOUBLE;
    double *svconv = cttcontr->convMatr->sv;

    for (j = 0; j < output_dim; j++)
      {
	if (svconv[j] < svconvmin)
	  svconvmin = svconv[j];
      }

    fprintf (stderr, "\nmin singular value of the conversion matrix = %f\n",
	     svconvmin);
  }
#endif

}

static void
free_trieval_to_triel_converter (void *ccontr_void)
{
  CTTCONTROL *cttcontr = (CTTCONTROL *) ccontr_void;

  free_svdmatr (cttcontr->convMatr);
  free (cttcontr->convMatr);
  free (cttcontr->eval_values);
}


static void
trieval_to_triel_converter (void *locale, void *ccontr_void,
			    TSFIT_LOCAL_METHOD * local_method, void *data)
{
  TRIEL *element = (TRIEL *) locale;
  CTTCONTROL *cttcontr = (CTTCONTROL *) ccontr_void;
  TRIEVAL *eval_locale = (TRIEVAL *) local_method->locale;

  int i, j, m;
  double b1, b2, b3;
  int eval_par = cttcontr->eval_par;
  double eval_step = cttcontr->eval_step;
  double *eval_values = cttcontr->eval_values;

  /* pass the triangle from element to eval_locale */

  eval_locale->triangle = &element->triangle;


  /* do local computation */

  local_method->compute (data, local_method->body);
  /* REMOVE the third parameter of this function!!! */


  /* use the function eval_locale->eval to evaluate the local
     approximation in the triangle */

  m = 0;
  b1 = b2 = 0.0;
  b3 = 1.0;

  for (i = 0; i <= eval_par; i++)
    {

      for (j = 0; j <= eval_par - i; j++)
	{

	  eval_values[m] = eval_locale->eval (b1, b2, b3, local_method->body);

	  m++;

	  b2 += eval_step;
	  b3 -= eval_step;
	}

      b1 += eval_step;
      b2 = 0.0;
      b3 = 1.0 - b1;

    }


  /* compute BB coefs element->coefs by least squares */

  LS_using_svd (cttcontr->convMatr, eval_values, element->coefs);

}

/******************************************************************************/
/***                           set converter                                ***/
/******************************************************************************/

void
set_tsfit_converter (TSFIT_CONVERTER * converter,
		     TSFIT_LOCAL_METHOD * local_method,
		     void *global_method_void)
/* the last argument is void by a pure technical reason: convert.h
is loaded before gmethod.h by gmethod.c and tsfit.h */
{
  TSFIT_GLOBAL_METHOD *global_method =
    (TSFIT_GLOBAL_METHOD *) global_method_void;

  if (!strcmp (local_method->locale_type, "TRIEL") &&
      !strcmp (global_method->locale_type, "TRIEL"))
    {
      strcpy (converter->type, "degree_raising");
      converter->body = NULL;
      converter->init = &init_degree_raising_converter;
      converter->free = &free_degree_raising_converter;
      converter->call_local_method = &degree_raising_converter;



    }
  else if (!strcmp (local_method->locale_type, "TRIEVAL") &&
	   !strcmp (global_method->locale_type, "TRIEL"))
    {
      CTTCONTROL *cttcontr;
      TRIEL *element = (TRIEL *) global_method->locale;

      strcpy (converter->type, "trieval_to_triel");

      converter->body = calloc (1, sizeof (CTTCONTROL));
      if (converter->body == NULL)
	{
	  fprintf (stderr,
		   "\nerror: not enough memory! [set_tsfit_converter]\n");
	  exit (-1);
	}
	
      cttcontr = (CTTCONTROL *) converter->body;
	
      converter->init = &init_trieval_to_triel_converter;
      converter->free = &free_trieval_to_triel_converter;
      converter->call_local_method = &trieval_to_triel_converter;


      /* set the parameters */

      cttcontr->output_degree = element->degree;

      cttcontr->eval_par = 2 * cttcontr->output_degree;

#ifdef PRINT_CONVERTER_PARAMETERS
      fprintf (stderr, "\nNumber of evaluation points: ");
      fprintf (stderr, " %i on the edge (totally %i points)\n\n",
	       cttcontr->eval_par,
	       (cttcontr->eval_par + 2) * (cttcontr->eval_par + 1) / 2);
#endif

    }
  else
    {
      fprintf (stderr,
	       "\nerror: Cannot find a valid converter! [set_tsfit_converter]\n");
      exit (-1);
    }

}

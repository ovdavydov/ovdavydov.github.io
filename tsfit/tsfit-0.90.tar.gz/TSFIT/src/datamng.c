/* Data management and preprocessing according to the the grid 
method as described e.g. in 
 J. L. Bentley and J. H. Friedman, Data structures for range searching,
 ACM Computing Surveys, 11 (1079), 397-409.
 
  Author: Oleg Davydov
	  University of Strathclyde
	  Department of Mathematics
          26 Richmond Street
	  Glasgow G1 1XH
	  Scotland, UK
	  e-mail: oleg.davydov@strath.ac.uk


  Copyright (C) 2005 Oleg Davydov

This file is part of TSFIT.

This package is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This package is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this package; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <values.h>



#include "datamng.h"



/* scaling/unscaling of x,y,z  w.r.t. 'data' */

double
scale_x (double x, TSFIT_DATA * data)
{
  x -= data->xmin;
  return x /= data->scaling_factor;
}

double
unscale_x (double x, TSFIT_DATA * data)
{
  x *= data->scaling_factor;
  return x += data->xmin;
}

double
scale_y (double y, TSFIT_DATA * data)
{
  y -= data->ymin;
  return y /= data->scaling_factor;
}

double
unscale_y (double y, TSFIT_DATA * data)
{
  y *= data->scaling_factor;
  return y += data->ymin;
}

double
scale_z (double z, TSFIT_DATA * data)
{
  z -= data->zmin;
  return z /= data->scaling_factor;
}

double
unscale_z (double z, TSFIT_DATA * data)
{
  z *= data->scaling_factor;
  return z += data->zmin;
}



/* 'init_data_grid' assumes that preprocessing by 'init_tsfit_data'
have been performed, i.e. data->number, data->x, data->y
and data->z have been linked to the original 
(NOT scaled!!!) x,y,z coordinates of the data, data->number is the correct
number of data points, and the bounding box data->xmin, etc., and 
data->scaling_factor have been computed. 
It allocates the fileds for the grid, scales x,y,z s.t. (x,y)\in [0,1]^2 
and computes 'data->cell_number' and 'data->cell_index'. */

void
init_data_grid (DATAGRID * data)
{

  int i, j, k, m, mm, num;
  int n;
  int number = data->number;
  double *xx = data->x;
  double *yy = data->y;
  double *zz = data->z;
  double xmin = data->xmin;
  double ymin = data->ymin;
  double zmin = data->zmin;
  double scaling_factor = data->scaling_factor;
  int *cell_number;
  int **cell_index;


  /* scale x, y, z */
  
  for (n = 0; n < number; n++)
    {

      xx[n] -= xmin;
      xx[n] /= scaling_factor;

      yy[n] -= ymin;
      yy[n] /= scaling_factor;

      zz[n] -= zmin;
      zz[n] /= scaling_factor;

    }


  /* set the size of the  grid */

  m = data->grid_size = (int) sqrt (data->number / 20.0);

  if (m < 1)
    m = data->grid_size = 1;

  /* allocate and initialize the grid */

  mm = m * m;

  cell_number = data->cell_number = (int *) calloc (mm, sizeof (int));

  if (data->cell_number == NULL)
    {
      fprintf (stderr, "error: memory allocation failure [init_data_grid]\n");
      exit (-1);
    }

  cell_index = data->cell_index = (int **) calloc (mm, sizeof (int*));

  if (data->cell_index == NULL)
    {
      fprintf (stderr, "error: memory allocation failure [init_data_grid]\n");
      exit (-1);
    }


  /* sort the data into the grid */

  for (n = 0; n < number; n++)
    {

      /* determine the cell of the grid where the current data point lies */

      find_data_cell (data, xx[n], yy[n], &i, &j);

      k = j * m + i;


      num = cell_number[k];

      if (num % 10 == 0)	/* dynamic allocation of memory to cell_index[k] */
	{

	  cell_index[k] =
	    (int *) realloc (cell_index[k], (num + 10) * sizeof (int));

	  if (cell_index[k] == NULL)
	    {
	      fprintf (stderr, "error: memory allocation failure [init_data_grid]\n");
	      exit (-1);
	    }

	}
      cell_index[k][num] = n;
      cell_number[k]++;
    }



}


/* free_data_grid undoes allocations done by init_data_grid; therefore
it DOES NOT FREE data->x, data->y and  data->z, but leaves them SCALED */

void
free_data_grid (DATAGRID * data)
{
  int  i, m, mm;

  m = data->grid_size;
  mm = m * m;

  for (i = 0; i < mm; i++)
    {
      free (data->cell_index[i]);
    }

  free (data->cell_index);
  free (data->cell_number);

}


/* This function assigns x,y,z to the TSFIT_DATA structure, computes  
the bounding box and scaling factor, but does not scale the date. */

void 
init_tsfit_data (TSFIT_DATA * data, int num, double *xx, double *yy, double *zz)
{
  double x, y, z, xmin, xmax, ymin, ymax, zmin, zmax;
  int n;

  /* assign data->number and link data->x, data->y, data->z */
  
  data->number = num;
  data->x = xx;
  data->y = yy;
  data->z = zz;
  
  /* compute the bounding box */

  xmin = ymin = zmin = MAXDOUBLE;
  xmax = ymax = zmax = -MAXDOUBLE;

  for (n = 0; n < num; n++)
    {
      x = xx[n];
      y = yy[n];
      z = zz[n];
      if (x > xmax)
	xmax = x;
      if (y > ymax)
	ymax = y;
      if (x < xmin)
	xmin = x;
      if (y < ymin)
	ymin = y;
      if (z > zmax)
	zmax = z;
      if (z < zmin)
	zmin = z;
    }

  data->xmin = xmin;
  data->xmax = xmax;
  data->ymin = ymin;
  data->ymax = ymax;
  data->zmin = zmin;
  data->zmax = zmax;


  /* compute the scaling factor */

  if (xmax - xmin >= ymax - ymin)
    data->scaling_factor = xmax - xmin;
  else
    data->scaling_factor = ymax - ymin;
  
  /* initialize the data grid*/ 
   
  init_data_grid (data); 

  fprintf (stderr, "\n\nData sorting completed\n\n");
}


/* free_tsfit_data is identical to free_data_grid, but requires TSFIT_DATA */

void
free_tsfit_data (TSFIT_DATA * data)
{
  free_data_grid (data);
}



 /* find the coordinates i,j of the data cell where (x,y) lies,
    such that j * data->grid_size  + i is its index into data->grid */


void
find_data_cell (DATAGRID * data, double x, double y, int *i, int *j)
{
  int n = data->grid_size;

  if (x < 0.0)
    *i = 0;
  else if (x < 1.0)
    *i = (int) (x * n);
  else
    *i = n - 1;

  if (y < 0.0)
    *j = 0;
  else if (y < 1.0)
    *j = (int) (y * n);
  else
    *j = n - 1;

}

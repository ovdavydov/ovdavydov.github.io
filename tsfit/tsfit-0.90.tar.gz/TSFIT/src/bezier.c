/* Routines for triangle Bezier patches: de Casteljau algorithm, 
degree raising, etc. as described e.g. in 
 G. Farin, Curves and Surfaces for CAGD: a practical guide, 5th edition,
 Morgan Kaufmann Publishers Inc., San Francisco, CA, USA, 2001.
 
  Author: Oleg Davydov
	  University of Strathclyde
	  Department of Mathematics
          26 Richmond Street
	  Glasgow G1 1XH
	  Scotland, UK
	  e-mail: oleg.davydov@strath.ac.uk


  Copyright (C) 2005 Oleg Davydov

This file is part of TSFIT.

This package is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This package is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this package; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "bezier.h"


#ifndef max
#define max(a,b) ( (a) > (b) ? (a) : (b) )
#endif



/* compute the center of the triangle */

void
find_tri_center (TRIANGLE * triangle)
{
  triangle->xc = (triangle->x1 + triangle->x2 + triangle->x3) / 3.0;
  triangle->yc = (triangle->y1 + triangle->y2 + triangle->y3) / 3.0;
}

/* compute the diameter of the triangle */

void
find_tri_diam (TRIANGLE * triangle)
{
  double hx, hy, d;

  hx = triangle->x1 - triangle->x2;
  hy = triangle->y1 - triangle->y2;
  d = hx * hx + hy * hy;

  hx = triangle->x3 - triangle->x2;
  hy = triangle->y3 - triangle->y2;
  d = max (d, hx * hx + hy * hy);

  hx = triangle->x3 - triangle->x1;
  hy = triangle->y3 - triangle->y1;
  d = max (d, hx * hx + hy * hy);

  triangle->diam = sqrt (d);
}



/* baseTri->coefs is not allocated here  */

BBTRI *
init_baseTri (int max_degree, double *coefs)
{
  BBTRI *baseTri = (BBTRI *) malloc (sizeof (BBTRI));


  if (baseTri == NULL)
    {
      fprintf (stderr, "error: not enough memory! [baseTri]\n");
      exit (-1);
    }

  baseTri->degree = baseTri->max_degree = max_degree;
  baseTri->dim = baseTri->max_dim = (max_degree + 1) * (max_degree + 2) / 2;

  /* Basis triangle gets the coefficients from a computational routine 
     and therefore 'coefs' needs not be allocated; WARNING: actual
     allocated length of 'coefs' may be greater than 'max_dim' */

  baseTri->coefs = coefs;

  baseTri->c = (double *) malloc (baseTri->max_dim * sizeof (double));


  return baseTri;
}


/* since baseTri->coefs are not allocated by init_baseTri,
they are not freed here */
void
free_baseTri (BBTRI * baseTri)
{

  free (baseTri->c);

}

/* convert the Descartes coordinates of a point into 
its barycentric coordinates w.r.t. a Bezier triangle */

void
tri_desc2bary (double x, double y,
	   double *b1, double *b2, double *b3, TRIANGLE * tri)
{
  double x1, y1, x2, y2, x3, y3, tmp;

  x1 = tri->x1;
  y1 = tri->y1;
  x2 = tri->x2;
  y2 = tri->y2;
  x3 = tri->x3;
  y3 = tri->y3;

  tmp = x2 * y3 - y2 * x3;
  *b1 = ((y2 - y3) * x - (x2 - x3) * y + tmp) /
    ((y2 - y3) * x1 - (x2 - x3) * y1 + tmp);

  tmp = x1 * y3 - y1 * x3;
  *b2 = ((y1 - y3) * x - (x1 - x3) * y + tmp) /
    ((y1 - y3) * x2 - (x1 - x3) * y2 + tmp);

  tmp = x1 * y2 - y1 * x2;
  *b3 = ((y1 - y2) * x - (x1 - x2) * y + tmp) /
    ((y1 - y2) * x3 - (x1 - x2) * y3 + tmp);

}

/* convert the barycentric coordinates of a point  w.r.t. a Bezier triangle
into its Descartes coordinates */

void
tri_bary2desc (double b1, double b2, double b3,
	   double *x, double *y, TRIANGLE * tri)
{


  *x = b1 * tri->x1 + b2 * tri->x2 + b3 * tri->x3;
  *y = b1 * tri->y1 + b2 * tri->y2 + b3 * tri->y3;

}


/* de Casteljau algorithm for the evaluation  of
a polynomial of some degree at the point (r,s,t) in barycentric coordinates */
/*
 * Ordering of BB domain points 
 *   
 *   1--->2
 *    -->
 *    ->
 *    3
 */

double
bbtri_deCast (double b1, double b2, double b3, BBTRI * bbtri)
{
  double *coefs = bbtri->coefs;
  double *a, *aa;
  int d = bbtri->degree;
  int i, j;
  double *c = bbtri->c;
  double *cc, *ccc;

  /* if bbtri->degree == 0, then the loops below are empty, and *c is arbitrary.
     Therefore we return the value of the only coefficient of bbtri in this case */

  if (d++ == 0)
    return *coefs;

  /* the first step of de Casteljau algorithm, where we write the resulting
     coeeficients into the auxiliary array c, in opposite order */

  a = coefs + bbtri->dim - 1;

  for (i = 1, cc = c, aa = a - 1; i < d; i++, aa--)
    for (j = 0; j < i; j++, cc++, a--)
      {
	*cc = *a * b3 + *aa * b2;
	*cc += *(--aa) * b1;
      }

  /* the other steps */

  for (d--; d > 1; d--)
    for (i = 1, cc = c, ccc = cc + 1; i < d; i++, ccc++)
      for (j = 0; j < i; j++, cc++)
	{
	  *cc *= b3;
	  *cc += *ccc * b2;
	  *cc += *(++ccc) * b1;
	}
  return *c;
}



/* degree raising; degree_out cannot be smaller than degree_in.
If they are equal, the function only copies coefs_in into coefs_out 
if needed */
/*
 * Ordering of BB domain points 
 *   
 *   1--->2
 *    -->
 *    ->
 *    3
 */



void
bbtri_raise_degree (int degree_in, double *coefs_in,
	      int degree_out, double *coefs_out)
{
  double *coef = coefs_out;
  int cc, cl, cu;		/* raising coefficients coming from "center", "left" and "up" */
  double *coefl, *coefu, *coefc, *coef_old;
  int dd = degree_in + 1;
  int diff = degree_out - degree_in;

  if (degree_in == degree_out)
    {
      if (coefs_out != coefs_in)
	memcpy (coefs_out, coefs_in,
		(degree_in + 1) * (degree_in + 2) / 2 * sizeof (double));
      return;
    }


  coefc = coefu = coefl = coefs_in;

  /** first step: raise degree by one and write the resulting BB coefs into 
  the "upper left corner" of array coefs_out **/

  *coef = *coefs_in;		/* first corner */

  for (cc = degree_in, cl = 1; cc > 0; cl++, cc--)	/* first row without corners */
    *(++coef) = (cl * *(coefl++) + cc * *(++coefc)) / dd;

  *(++coef) = *coefl;		/* second corner */

  for (cu = 1; cu <= degree_in; cu++)	/* remaining rows except the last corner */
    {
      coef += diff;
      cc = dd - cu;

      *coef = (cc * *(++coefc) + cu * *(coefu++)) / dd;	/* first in the row */

      for (cc--, cl = 1, coefl++; cc > 0; cl++, cc--)
	*(++coef) =
	  (cl * *(coefl++) + cc * *(++coefc) + cu * *(coefu++)) / dd;

      *(++coef) = (cl * *coefl + cu * *(coefu++)) / dd;	/* last in the row */

    }

  coef += diff;
  *coef = *coefu;		/* third corner */


  /** remaining steps; now we in each step overwrite the coefs of the previous 
  degree and go through the array coefs_out in reverse order **/

  coef_old = coef;


  for (diff--; diff > 0; diff--)
    {
      coefu = coefl = coef_old;
      coef_old = coef = coef_old + diff + 1;


      *coef = *coefu;		/* last corner */

      for (cu = dd++; cu > 0; cu--)	/* other rows except the first one */
	{
	  coef -= diff;
	  coefu -= diff;

	  cl = dd - cu;

	  *(coef--) = (cl * *(coefl--) + cu * *(--coefu)) / dd;	/* last in the row */

	  for (cl--, cc = 1; cl > 0; cl--, cc++, coef--)
	    *coef = (cl * *(coefl--) + cc * *coef + cu * *(--coefu)) / dd;

	  *coef = (cc * *coef + cu * *(--coefu)) / dd;	/* first in the row */

	  coefl -= diff;
	}

      coef -= diff;



      *(coef--) = *(coefl--);	/* second corner */

      for (cl = dd - 1, cc = 1; cl > 0; cl--, cc++, coef--)	/* first row without corners */
	*coef = (cl * *(coefl--) + cc * *coef) / dd;

      /* first corner does not change */

    }

}


/* The following function evaluates the BB basis functions at a point 
(b1,b2,b3) in barycentric  coordinates. The number in the function name
is the polynomial degree. The ordering of the basis functions is as in the 
following diagram. (It is the same as for BBTRI, see bezier.h.) */
/*
 * Ordering of BB basis functions 
 *   
 *   1--->2
 *    -->
 *    ->
 *    3
 */
/* "values" must point to the start of an array where the values will be
stored */

void
eval_BB_basis_functions (int degree, double b1, double b2, double b3,
			 double *values, TRINOM * trinom)
{
  int i, d, dd, j;
  double **row;
  double *vv = values + 1;
  double *cc = trinom->coefs[degree] + 1;


  if (degree == 0)
    {
      *values = 1.0;
      return;
    }

  if (degree == 1)
    {
      *values = b1;
      *(++values) = b2;
      *(++values) = b3;
      return;
    }

  /* the rest only for degree at least 2 */

  d = degree + 1;

  row = (double **) malloc (d * sizeof (double *));

  if (row == NULL)
    {
      fprintf (stderr,
	       "error: not enough memory! [eval_BB_basis_functions]\n");
      exit (-1);
    }



  /* find starting pointers of rows of the BB triangle */


  for (i = 0, dd = d, row[0] = values; dd > 1; i++, dd--)
    row[i + 1] = row[i] + dd;


  /* write the powers of b2 and b3 in the first row and first column, respectively */


  for (i = 1, values[1] = b2; i < degree; i++)
    values[i + 1] = values[i] * b2;


  for (i = 1, *row[1] = b3; i < degree; i++)
    *row[i + 1] = *row[i] * b3;


  /* fill in the (interior of) the last diagonal */

  for (i = 1, dd = degree - 1; i < degree; i++, dd--)
    *(row[i] + dd) = *row[i] * values[dd];


  /* loop over all remaining diagonals; meanwhile values[0]
     reaches its correct value, too */

  for (j = degree - 1, values[0] = b1; j > 0; j--, values[0] *= b1)
    {
      /* finalize the endpoints of the current diagonal */
      *row[j] *= values[0];
      values[j] *= values[0];

      /* fill in the interior of the current diagonal */
      for (i = 1, dd = j - 1; i < j; i++, dd--)
	*(row[i] + dd) = *row[i] * values[dd] * values[0];

    }


  /* multiply by trinomial coefficients */

  for (j = 1; j < degree; j++)
    *(vv++) *= *(cc++);

  for (i = degree; i > 1; i--)
    for (j = 0; j < i; j++)
      *(++vv) *= *(++cc);




  free (row);


}

void
init_trinom (TRINOM * trinom, int max_degree)
{
  int i, j, k;
  double **bcoefs;
  double *c;

  trinom->max_degree = max_degree;

  /* allocate coefs */

  trinom->coefs = (double **) malloc ((max_degree + 1) * sizeof (double *));

  if (trinom->coefs == NULL)
    {
      fprintf (stderr, "error: not enough memory! [init_trinom]\n");
      exit (-1);
    }

  for (i = 0; i <= max_degree; i++)
    {
      trinom->coefs[i] =
	(double *) malloc ((i + 1) * (i + 2) / 2 * sizeof (double));

      if (trinom->coefs[i] == NULL)
	{
	  fprintf (stderr, "error: not enough memory! [init_trinom]\n");
	  exit (-1);
	}

    }

  /* allocate an auxiliary array for binomial coefficients */

  bcoefs = (double **) malloc ((max_degree + 1) * sizeof (double *));

  if (bcoefs == NULL)
    {
      fprintf (stderr, "error: not enough memory! [init_trinom]\n");
      exit (-1);
    }

  for (i = 0; i <= max_degree; i++)
    {
      bcoefs[i] = (double *) malloc ((i + 1) * sizeof (double));

      if (bcoefs[i] == NULL)
	{
	  fprintf (stderr, "error: not enough memory! [init_trinom]\n");
	  exit (-1);
	}

    }

  /* compute the binomial coefficients (Pascal triangle) */

  bcoefs[0][0] = 1.0;

  for (i = 1; i <= max_degree; i++)
    bcoefs[i][0] = bcoefs[i][i] = 1.0;

  for (i = 2; i <= max_degree; i++)
    for (j = 1; j < i; j++)
      bcoefs[i][j] = bcoefs[i - 1][j - 1] + bcoefs[i - 1][j];


  /* compute the trinomial coefficients ("Pascal pyramid") */

  for (i = 0; i <= max_degree; i++)
    for (j = i, c = trinom->coefs[i]; j >= 0; j--)
      for (k = 0; k <= j; k++, c++)
	*c = bcoefs[i][j] * bcoefs[j][k];


  /* free the memory used by binomial coefficients */

  for (i = 0; i <= max_degree; i++)
    free (bcoefs[i]);

  free (bcoefs);

}

void
free_trinom (TRINOM * trinom)
{
  int i;

  for (i = 0; i <= trinom->max_degree; i++)
    free (trinom->coefs[i]);

  free (trinom->coefs);
}

/* fill in the polynomial collocation matrix A */

void
fill_BBbasis_matr (double **A,
		   int degree, TRIANGLE * triangle,
		   int num, double *x, double *y, TRINOM * trinom)
{
  double b1, b2, b3;
  int i;



  if (degree == 0)
    {
      for (i = 0; i < num; i++)
	A[i][0] = 1.0;
      return;
    }

  if (degree == 1)
    {
      for (i = 0; i < num; i++)
	tri_desc2bary (x[i], y[i], A[i], A[i] + 1, A[i] + 2, triangle);
      return;
    }


  /* the rest for degree at least 2 only */

  for (i = 0; i < num; i++)
    {

      tri_desc2bary (x[i], y[i], &b1, &b2, &b3, triangle);

      eval_BB_basis_functions (degree, b1, b2, b3, A[i], trinom);

    }


}

/* Local RBF approximation as described in

 O. Davydov, R. Morandi and A. Sestini, Local hybrid approximation for 
 scattered data fitting with bivariate splines, submitted for publication.
 
 O. Davydov, A. Sestini and R. Morandi, Local RBF approximation for
 scattered data fitting with bivarite splines, in Proceedings of IDoMAT 2004, 
 to appear.
 
  Author: Oleg Davydov
	  University of Strathclyde
	  Department of Mathematics
          26 Richmond Street
	  Glasgow G1 1XH
	  Scotland, UK
	  e-mail: oleg.davydov@strath.ac.uk


  Copyright (C) 2005 Oleg Davydov

This file is part of TSFIT.

This package is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This package is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this package; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */


#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <values.h>


#include "datamng.h"

#include "locsearch.h"
#include "bezier.h"
#include "linalg.h"
#include "locpoly.h"
#include "locrbf.h"



#ifndef EPS0
#define EPS0 1.110223025e-16
#endif

#ifndef EPS
#ifdef EPS0
#define EPS 100*EPS0
#endif
#endif


#ifndef min
#define min(a,b) ( (a) < (b) ? (a) : (b) )
#endif

#ifndef max
#define max(a,b) ( (a) > (b) ? (a) : (b) )
#endif

#ifndef HYBRID_ONLY
#define USE_LAPACK_LSE
#endif

/* #define PRINT_LOCAL_INFO */

/* #define CHECK_NUM_STABILITY */





static double eval_hybrid (double rho, double sigma, double tau, void *lcontr_void);
static double eval_rbf (double rho, double sigma, double tau, void *lcontr_void);



/* multiquadric sqrt{1+r^2}
   with center at (0,0) and scaling parameter
   'delta' */

double
rbf_MQ (double rx, double ry, double delta)
{
  return sqrt (delta * delta + rx * rx + ry * ry);

}

/* multiquadric {1+r^2}^{1.5/2}
   with center at (0,0) and scaling parameter
   'delta' */

double
rbf_MQ1_5 (double rx, double ry, double delta)
{

  double x = sqrt (delta * delta + rx * rx + ry * ry);

  double sqx = sqrt (x);

  return x * sqx;
}

/* multiquadric {1+r^2} log {1+r^2}
   with center at (0,0) and scaling parameter
   'delta' */

double
rbf_MQ2 (double rx, double ry, double delta)
{

  static double eps = 10000.0 / MAXDOUBLE;
  double x = delta * delta + rx * rx + ry * ry;


  if (x < eps)
    return 0.0;
  else
    return x * log (x);
}

/* multiquadric {1+r^2}^{3/2}
   with center at (0,0) and scaling parameter
   'delta' */

double
rbf_MQ3 (double rx, double ry, double delta)
{

  double x = delta * delta + rx * rx + ry * ry;


  return x * sqrt (x);
}




/* inverse multiquadric 1/sqrt{1+r^2}
   with center at (0,0) and scaling parameter
   'delta' */

double
rbf_IMQ (double rx, double ry, double delta)
{
  static double eps = 10000.0 / MAXDOUBLE;
  double x = delta * delta + rx * rx + ry * ry;

  if (x < eps)
    x = eps;

  return 1.0 / sqrt (x);
}

/* inverse multiquadric 1/{1+r^2}
   with center at (0,0) and scaling parameter
   'delta' */

double
rbf_IMQ2 (double rx, double ry, double delta)
{
  static double eps = 10000.0 / MAXDOUBLE;
  double x = delta * delta + rx * rx + ry * ry;

  if (x < eps)
    x = eps;

  return 1.0 / x;
}

/* inverse multiquadric 1/{1+r^2}^{3/2}
   with center at (0,0) and scaling parameter
   'delta' */

double
rbf_IMQ3 (double rx, double ry, double delta)
{
  static double eps = 10000.0 / MAXDOUBLE;
  double x = delta * delta + rx * rx + ry * ry;

  if (x < eps)
    x = eps;


  return 1.0 / (x * sqrt (x));
}

/* inverse multiquadric 1/{1+r^2}^{0.5/2}
   with center at (0,0) and scaling parameter
   'delta' */

double
rbf_IMQ0_5 (double rx, double ry, double delta)
{
  static double eps = 10000.0 / MAXDOUBLE;
  double x = delta * delta + rx * rx + ry * ry;

  if (x < eps)
    x = eps;

  return 1.0 / sqrt (sqrt (x));
}


/* thin plate spline r^2 log r
   with center at (0,0) and scaling parameter
   'delta': f(rx/delta,ry/delta) */

double
rbf_TPS (double rx, double ry, double delta)
{
  double rr = rx * rx + ry * ry;
  rr /= (delta * delta);

  if (rr < EPS0 / 100.0)
    return 0.0;
  else
    return rr * log (rr);
}

/* thin plate spline r^4 log r
   with center at (0,0) and scaling parameter
   'delta': f(rx/delta,ry/delta) */

double
rbf_TPS4 (double rx, double ry, double delta)
{
  double rr = rx * rx + ry * ry;
  rr /= (delta * delta);

  if (rr < EPS0 / 100.0)
    return 0.0;
  else
    return rr * rr * log (rr);
}

/* thin plate spline r^6 log r
   with center at (0,0) and scaling parameter
   'delta': f(rx/delta,ry/delta) */

double
rbf_TPS6 (double rx, double ry, double delta)
{
  double rrrr, rr = rx * rx + ry * ry;
  rr /= (delta * delta);
  rrrr = rr * rr;

  if (rr < EPS0 / 100.0)
    return 0.0;
  else
    return rrrr * rr * log (rr);
}

/* polyharmonic spline r^1.5 (cond. pos. definite of order 1)
   with center at (0,0) and scaling parameter
   'delta': f(rx/delta,ry/delta) */

double
rbf_polyharmonic1_5 (double rx, double ry, double delta)
{
  double r, rr = rx * rx + ry * ry;
  rr /= (delta * delta);
  r = sqrt (rr);

  return r * sqrt (r);
}

/* polyharmonic spline r^1.75 (cond. pos. definite of order 1)
   with center at (0,0) and scaling parameter
   'delta': f(rx/delta,ry/delta) */

double
rbf_polyharmonic1_75 (double rx, double ry, double delta)
{
  double r, sr, rr = rx * rx + ry * ry;
  rr /= (delta * delta);
  r = sqrt (rr);
  sr = sqrt (r);

  return r * sr * sqrt (sr);
}


/* polyharmonic spline r^3 (cond. pos. definite of order 2)
   with center at (0,0) and scaling parameter
   'delta': f(rx/delta,ry/delta) */

double
rbf_polyharmonic3 (double rx, double ry, double delta)
{
  double rr = rx * rx + ry * ry;
  rr /= (delta * delta);

  return rr * sqrt (rr);
}

/* polyharmonic spline r^5 (cond. pos. definite of order 3)
   with center at (0,0) and scaling parameter
   'delta': f(rx/delta,ry/delta) */

double
rbf_polyharmonic5 (double rx, double ry, double delta)
{
  double rrrr, rr = rx * rx + ry * ry;
  rr /= (delta * delta);
  rrrr = rr * rr;

  return rrrr * sqrt (rr);
}

/* polyharmonic spline r^7 (cond. pos. definite of order 3)
   with center at (0,0) and scaling parameter
   'delta': f(rx/delta,ry/delta) */

double
rbf_polyharmonic7 (double rx, double ry, double delta)
{
  double rrrr, rr = rx * rx + ry * ry;
  rr /= (delta * delta);
  rrrr = rr * rr;

  return rrrr * rr * sqrt (rr);
}

/* polyharmonic spline r^9 (cond. pos. definite of order 5)
   with center at (0,0) and scaling parameter
   'delta': f(rx/delta,ry/delta) */

double
rbf_polyharmonic9 (double rx, double ry, double delta)
{
  double rrrr, rr = rx * rx + ry * ry;
  rr /= (delta * delta);
  rrrr = rr * rr;

  return rrrr * rrrr * sqrt (rr);
}


/* Gausssian exp(-r^2)
   with center at (0,0) and scaling parameter
   'delta': f(rx/delta,ry/delta) */

double
rbf_Gauss (double rx, double ry, double delta)
{
  double rr = rx * rx + ry * ry;
  rr /= (delta * delta);

  return exp (-rr);
}





/* Wendland C^2 function (1-r)_+^4(4r+1)
   with center at (0,0) and scaling parameter
   'delta': f(rx/delta,ry/delta) */

double
rbf_Wendland31 (double rx, double ry, double delta)
{
  double r = sqrt (rx * rx + ry * ry);
  double rr;

  if (r < delta)
    {
      r /= delta;
      rr = (1 - r);
      rr = rr * rr;
      rr = rr * rr;
      return rr * (4.0 * r + 1.0);
    }
  else
    return 0.0;
}


/* Wendland C^4 function (1-r)_+^6(35r^2+18r+3)
   with center at (0,0) and scaling parameter
   'delta': f(rx/delta,ry/delta) */

double
rbf_Wendland32 (double rx, double ry, double delta)
{
  double r = sqrt (rx * rx + ry * ry);
  double rr;

  if (r < delta)
    {
      r /= delta;
      rr = (1 - r);
      rr = rr * rr;
      rr = rr * rr * rr;
      return rr * (35.0 * r * r + 18.0 * r + 3.0);
    }
  else
    return 0.0;
}

/* Wendland C^6 function (1-r)_+^8(32r^3+25r^2+8r+1)
   with center at (0,0) and scaling parameter
   'delta': f(rx/delta,ry/delta) */

double
rbf_Wendland33 (double rx, double ry, double delta)
{
  double r = sqrt (rx * rx + ry * ry);
  double rr;

  if (r < delta)
    {
      r /= delta;
      rr = (1 - r);
      rr = rr * rr;
      rr = rr * rr;
      rr = rr * rr;
      return rr * (32.0 * r * r * r + 25.0 * r * r + 8.0 * r + 1.0);
    }
  else
    return 0.0;
}


/* Buhmann C^3 function 112/45 r^{9/2} + 16/3 r^{7/2} - 7 r^4 -14/15 r^2 + 1/9
   with center at (0,0) and scaling parameter
   'delta': f(rx/delta,ry/delta) */

double
rbf_BuhmannC3 (double rx, double ry, double delta)
{
  double rr = (rx * rx + ry * ry) / (delta * delta);
  double r = sqrt (rr);
  double sr;


  if (r < delta)
    {

      sr = sqrt (r);
      return 2.48888888888889 * rr * rr * sr + 5.33333333333333 * rr * r * sr
	- 7.0 * rr * rr - 0.93333333333333 * rr + 0.11111111111111;

    }
  else
    return 0.0;
}







/* extend the collocation matrix A 
   by adding a column of evaluations of the RBF basis 
   function with a knot located at (x,y)
   WARNING: 'A' and 'locPoints' must be 
   appropriately allocated in advance */

static void
extend_hybrid_matr (double knotx, double knoty, double delta,
		    double (*basis_function) (double rx, double ry, double delta),
		    int dim, double **A, int num, LOCALDATA * locPoints)
{
  int i;

  for (i = 0; i < num; i++)
    A[i][dim] =
      basis_function ((locPoints->x)[i] - knotx, (locPoints->y)[i] - knoty,
		      delta);



}



/* evaluate the hybrid function at (x,y); */

static double
eval_hybrid_funct (double x, double y, BBTRI * baseTri,
		   double delta, double (*basis_function) (double rx, double ry, double delta),
		   int knotnum, double *knotx, double *knoty, double *coefs)
{
  int poly_dim = baseTri->dim;
  double f, rho, sigma, tau;
  int i = poly_dim;
  int k;

  /* Pointer 'baseTri->coefs' is set equal to 'locMatr->coefs'
     in 'init_poly_loc_appr'; Therefore we do not need 'coefs' to evaluate
     the polynomial part */

  /* compute the barycentric coordinates of the current point */

  tri_desc2bary (x, y, &rho, &sigma, &tau, baseTri->triangle);

  /* evaluate the polynomial part of the hybrid function */

  f = bbtri_deCast (rho, sigma, tau, baseTri);

  /* add the evaluations of the RBF terms */

  for (k = 0; k < knotnum; k++)
    {

      f += coefs[i] * basis_function (x - knotx[k], y - knoty[k], delta);
      i++;
    }

  return f;
}


/* evaluate the hybrid function at the point with barycentric coordinates
b1, b2, b3 w.r.t. current triangle */

static double
eval_rbf_sum (double b1, double b2, double b3, BBTRI * baseTri,
	      double delta, double (*basis_function) (double rx, double ry, double delta),
	      int knotnum, double *knotx, double *knoty, double *coefs)
{
  double x, y, f;
  int i = baseTri->dim;
  int k;

  /* evaluate the polynomial part of the sum */

  f = bbtri_deCast (b1, b2, b3, baseTri);

  /* compute the Descartes coordinates of the current point */

 tri_bary2desc (b1, b2, b3, &x, &y, baseTri->triangle);

  /* add the evaluations of the RBF terms */

  for (k = 0; k < knotnum; k++)
    {

      f += coefs[i] * basis_function (x - knotx[k], y - knoty[k], delta);
      i++;
    }

  return f;

}

static double
eval_hybrid (double rho, double sigma, double tau, void *lcontr_void)
{
  LHACONTROL *lhacontrol = (LHACONTROL *) lcontr_void;

  return eval_rbf_sum (rho, sigma, tau, lhacontrol->lacontr->baseTri,
		       lhacontrol->delta, lhacontrol->basis_function,
		       lhacontrol->knotnum, lhacontrol->knotx,
		       lhacontrol->knoty, lhacontrol->lacontr->coefs);

}

static double
eval_rbf (double rho, double sigma, double tau, void *lcontr_void)
{
  LRBFACONTROL *lrbfacontrol = (LRBFACONTROL *) lcontr_void;

#ifdef USE_LAPACK_LSE


  return eval_rbf_sum (rho, sigma, tau, lrbfacontrol->lse->baseTri,
		       lrbfacontrol->delta, lrbfacontrol->basis_function,
		       lrbfacontrol->locKnots->number,
		       lrbfacontrol->locKnots->x, lrbfacontrol->locKnots->y,
		       lrbfacontrol->lse->coefs);

#else

  return eval_rbf_sum (rho, sigma, tau, lrbfacontrol->lacontr->baseTri,
		       lrbfacontrol->delta, lrbfacontrol->basis_function,
		       lrbfacontrol->locKnots->number,
		       lrbfacontrol->locKnots->x, lrbfacontrol->locKnots->y,
		       lrbfacontrol->coefs);
#endif

}


void
init_hybrid_loc_appr (void *lhacontr_void)
{
  LHACONTROL *lhacontr = (LHACONTROL *) lhacontr_void;
  LACONTROL *lacontr = lhacontr->lacontr;
  LSCONTROL *lscontr = lhacontr->lscontr;
  int i, max_knotnum;

  lacontr->lscontr = lscontr;

  lacontr->max_loc_dim = lhacontr->max_loc_dim;	/* to allow the use of the same
						   matrices also with hybrid basis 
						   functions */

  init_poly_loc_appr (lacontr);

  lacontr->locMatr->type = 'S';	/* to ensure that the matrix is not overwritten
				   when SVD is computed */

  lhacontr->max_delta = 0.0;
  lhacontr->min_delta = MAXDOUBLE;


  lhacontr->locale->eval = &eval_hybrid;

  max_knotnum = lhacontr->max_knotnum = lhacontr->max_loc_dim
    - (lacontr->starting_degree + 1) * (lacontr->starting_degree + 2) / 2;

  lhacontr->knotidx = (int *) malloc (lhacontr->max_knotnum * sizeof (int));

  if (lhacontr->knotidx == NULL)
    {
      fprintf (stderr, "error: memory allocation failure [lhacontr]\n");
      exit (-1);
    }

  lhacontr->knotx =
    (double *) malloc (lhacontr->max_knotnum * sizeof (double));

  if (lhacontr->knotx == NULL)
    {
      fprintf (stderr, "error: memory allocation failure [lhacontr]\n");
      exit (-1);
    }

  lhacontr->knoty =
    (double *) malloc (lhacontr->max_knotnum * sizeof (double));

  if (lhacontr->knoty == NULL)
    {
      fprintf (stderr, "error: memory allocation failure [lhacontr]\n");
      exit (-1);
    }

  lhacontr->knotnum_stat = (int *) malloc ((max_knotnum + 1) * sizeof (int));

  if (lhacontr->knotnum_stat == NULL)
    {
      fprintf (stderr, "error: memory allocation failure [lhacontr]\n");
      exit (-1);
    }

  for (i = 0; i <= max_knotnum; i++)
    (lhacontr->knotnum_stat)[i] = 0;





  /* initialize max_cond */

  lhacontr->max_cond = -MAXDOUBLE;


}


void
free_hybrid_loc_appr (void *lhacontr_void)
{
  LHACONTROL *lhacontr = (LHACONTROL *) lhacontr_void;




  free (lhacontr->knotnum_stat);

  free (lhacontr->knotidx);
  free (lhacontr->knotx);
  free (lhacontr->knoty);

  free_poly_loc_appr (lhacontr->lacontr);

}



/* hybrid polynomial/RBF method;
 num: the number of local data points, 
 xx,yy,zz: the coordinates of the points (scaled to [0,1]^2!!!),
 Rx,Ry,Sx,Sy,Tx,Ty: the vertices of the triangle, 
 a: pointer to the array of Bezier coefficients of the polynomial fit
    to the RBF approximation; 
    COMMENT: if 'compute_poly_loc_appr' is called before 'compute_hybrid_loc_appr',
    'a' contains the BB coefs of the spr local polynomial in the beginning */

void
compute_hybrid_loc_appr (void *data_void, void *lcontr_void)
{
  TSFIT_DATA *data = (TSFIT_DATA *) data_void;
  LHACONTROL *lhacontr = (LHACONTROL *) lcontr_void;
  LACONTROL *lacontr = lhacontr->lacontr;
  LOCALDATA *locPoints = lhacontr->lscontr->locPoints;

  TRIANGLE *triangle = lhacontr->locale->triangle;

  double *xx = locPoints->x;
  double *yy = locPoints->y;
  double *zz = locPoints->z;

  BBTRI *baseTri = lacontr->baseTri;

  int i, j;

  int knotnum = 0;


  int num;

  int use_rbf = 1;

  SVDMATR *locMatr = lacontr->locMatr;

  double **A = locMatr->A;
  double *sv = locMatr->sv;
  double *coefs = lacontr->coefs;
  int max_loc_dim = lacontr->max_loc_dim;	/* set when calling
						   'init_poly_loc_appr' */
  int poly_degree = lacontr->starting_degree;
  int poly_dim = (poly_degree + 1) * (poly_degree + 2) / 2;
  double svmin = lhacontr->min_sing_value;


  double delta;			/* scaling parameter for the RBF */
  double max_dist = 0;

  double d, diffx, diffy;
  double dmin = MAXDOUBLE;
  double dmax = -MAXDOUBLE;
  int k = 0;
  int dim = poly_dim;		/* total number of basis functions, polynomial
				   and non-polynomial, initialized as poly_dim */


  int *knotidx = lhacontr->knotidx;
  double *knotx = lhacontr->knotx;
  double *knoty = lhacontr->knoty;







#ifdef PRINT_LOCAL_INFO

  static int NUM = 0;

  double xi, xj, yi, yj, dx, dy;

  int pure_poly_dim;

#endif



  /* choose points for local approximation */


  choose_loc_points (data, lhacontr->lscontr, triangle->xc, triangle->yc,
		     triangle->diam);


  num = locPoints->number;






  /*  compute the scaling parameter 'delta' 
     (we first compute the maximum distance between points
     and then multiply with a coefficient) */


  for (i = 0; i < num; i++)
    {
      for (j = 0; j < num; j++)
	{
	  diffx = xx[i] - xx[j];
	  diffy = yy[i] - yy[j];

	  d = diffx * diffx + diffy * diffy;

	  if (d > max_dist)
	    {
	      max_dist = d;
	    }
	}
    }

  max_dist = sqrt (max_dist);

  delta = lhacontr->delta_coef * max_dist;



  /* initialize baseTri */

  baseTri->triangle = triangle;
  baseTri->degree = poly_degree;
  baseTri->dim = poly_dim;


  /* fill in the polynomial part of A  */

  fill_BBbasis_matr (A, poly_degree, baseTri->triangle, locPoints->number,
		     locPoints->x, locPoints->y, lacontr->trinom);

  if (num < poly_dim + 3)
    {

      use_rbf = 0;
      knotnum = 0;
      goto proceed;

    }



  /**** look first for three RBF knots closest to the vertices ****/


  /* find the knot closest to (x1,y1) and extend the collocation matrix */

  for (i = 0; i < num; i++)
    {

      diffx = xx[i] - triangle->x1;
      diffy = yy[i] - triangle->y1;

      d = diffx * diffx + diffy * diffy;

      if (d < dmin)
	{
	  dmin = d;
	  k = i;
	}

    }

  extend_hybrid_matr (xx[k], yy[k], delta, lhacontr->basis_function, dim, A,
		      num, locPoints);
  knotidx[knotnum] = k;
  knotx[knotnum] = xx[k];
  knoty[knotnum] = yy[k];
  dim++;
  knotnum++;

  /* find the knot closest to (x2,y2) and different from the first knot,
     and extend the collocation matrix */

  dmin = MAXDOUBLE;

  for (i = 0; i < num; i++)
    {

      if (i == knotidx[0])
	continue;

      diffx = xx[i] - triangle->x2;
      diffy = yy[i] - triangle->y2;

      d = diffx * diffx + diffy * diffy;

      if (d < dmin)
	{
	  dmin = d;
	  k = i;
	}

    }

  extend_hybrid_matr (xx[k], yy[k], delta, lhacontr->basis_function, dim, A,
		      num, locPoints);
  knotidx[knotnum] = k;
  knotx[knotnum] = xx[k];
  knoty[knotnum] = yy[k];
  dim++;
  knotnum++;

  /* find the knot closest to (x3,y3) and different from  both 
     previous knots, and extend the collocation matrix */

  dmin = MAXDOUBLE;

  for (i = 0; i < num; i++)
    {

      if (i == knotidx[0] || i == knotidx[1])
	continue;

      diffx = xx[i] - triangle->x3;
      diffy = yy[i] - triangle->y3;

      d = diffx * diffx + diffy * diffy;

      if (d < dmin)
	{
	  dmin = d;
	  k = i;
	}

    }

  extend_hybrid_matr (xx[k], yy[k], delta, lhacontr->basis_function, dim, A,
		      num, locPoints);
  knotidx[knotnum] = k;
  knotx[knotnum] = xx[k];
  knoty[knotnum] = yy[k];
  dim++;
  knotnum++;


  /* compute svd for the collocation matrix for the hybrid space 
     with 3 knots, and decide if we compute RBF */


  locMatr->m = num;
  locMatr->n = dim;

  compute_svd (locMatr);


  for (i = 0; i < dim; i++)
    if (sv[i] < svmin)
      {

	use_rbf = 0;
	knotnum = 0;
	goto proceed;

      }

  /* Compute the coefficients of the solution */


  LS_using_svd (locMatr, locPoints->z, coefs);



 /**** succesively add knots with maximum error ****/


  while (dim < num && dim < max_loc_dim)
    {
      int oldknot;

      /* find the index of the new data point with maximal error
         and fill in the matrix.

         NO CHECK OF SEPARATION DISTANCE, since:
         1. The maximal error is hardly near to a knot
         2. If something is wrong with the matrix, then min sing value
         will sort it out

         If needed, it might be a good idea to assure good separation distances by
         thinning the prospective knots in advance. */

      dmax = -MAXDOUBLE;

      for (i = 0; i < num; i++)
	{
          oldknot = 0;
	  
	  for (j = 0; j < knotnum; j++)
	    {
	      if (i == knotidx[j])
	        {
		  oldknot = 1;
		  break;
		}
	    }
	  if (oldknot) continue;

	  d = fabs (zz[i]
		    - eval_hybrid_funct (xx[i], yy[i], baseTri,
					 delta, lhacontr->basis_function,
					 knotnum, knotx, knoty, coefs));

	  if (d > dmax)
	    {
	      dmax = d;
	      k = i;		/* k is always assigned at least once since num > knotnum */
	    }

	}

      extend_hybrid_matr (xx[k], yy[k], delta, lhacontr->basis_function, dim,
			  A, num, locPoints);
      knotidx[knotnum] = k;
      knotx[knotnum] = xx[k];
      knoty[knotnum] = yy[k];
      dim++;
      knotnum++;

      /* compute svd for the collocation matrix for the current hybrid space, 
         and decide if the last knot is allright */

      locMatr->m = num;
      locMatr->n = dim;

      compute_svd (locMatr);



      for (i = 0; i < dim; i++)
	if (sv[i] < svmin)
	  {			/* if the knot is not allright, we remove it
				   and stop looking for further knots */
	    knotnum--;
	    dim--;
	    use_rbf = 1;
	    goto proceed;
	  }

#ifdef CHECK_NUM_STABILITY

      {
	double sv_max = -MAXDOUBLE;
	double sv_min = MAXDOUBLE;

	for (i = 0; i < knotnum; i++)
	  {
	    sv_max = max (sv_max, sv[i]);
	    sv_min = min (sv_min, sv[i]);
	  }

	lhacontr->max_cond = max (lhacontr->max_cond, sv_max / sv_min);


      }


#endif



      /* Compute the coefficients of the solution */

      LS_using_svd (locMatr, locPoints->z, coefs);


    }




proceed:





  if (!use_rbf)
    {
      /* this works because compute_poly_loc_appr adapts degree and fills 
         in the local SVDMATR structures of lacontr
         correctly for subsequent evaluation by converter. */

      lacontr->locale->triangle = *triangle;
      compute_poly_loc_appr (data, lacontr);
    }


  /* store the parameters of the current approximation */

  lhacontr->delta = delta;
  lhacontr->knotnum = knotnum;


  /* update the info */

  if (use_rbf)
    {

      lhacontr->max_delta = max (delta, lhacontr->max_delta);
      lhacontr->min_delta = min (delta, lhacontr->min_delta);
      (lhacontr->knotnum_stat)[knotnum]++;

    }
  else
    (lhacontr->knotnum_stat)[0]++;


#ifdef PRINT_LOCAL_INFO


  fprintf (stderr,
	   "\n*********************************************************************\n\n");
  fprintf (stderr, "\nTriangle:     x        y\n");
  fprintf (stderr, "          %f %f\n          %f %f\n          %f %f\n",
	   triangle->x1, triangle->y1,
	   triangle->x2, triangle->y2, triangle->x3, triangle->y3);



  /* info about local points */

  fprintf (stderr, "\n\nThe number of local points: %i\n", num);
  fprintf (stderr, "Center of the triangle: (%f,%f), disk diameter: %f\n",
	   triangle->xc, triangle->yc, lscontr->diam);
  fprintf (stderr, "Maximal distance between points: %f\n", max_dist);
  fprintf (stderr, "\n Local points:\n");
  fprintf (stderr, "     x        y        z\n");
  for (i = 0; i < num; i++)
    fprintf (stderr, "%f %f %f\n", xx[i], yy[i], zz[i]);



  if (!use_rbf)
    {

      fprintf (stderr, "\nDO NOT USE RBF\n");
      fprintf (stderr, "\n Polynomial degree: %i\n",
	       lacontr->baseTri->degree);

      pure_poly_dim =
	(lacontr->baseTri->degree + 1) * (lacontr->baseTri->degree + 2) / 2;

      fprintf (stderr, " BB coefficients of the polynomial approximation:");
      for (i = 0; i < pure_poly_dim; i++)
	{
	  if (i % 5 == 0)
	    fprintf (stderr, "\n");
	  fprintf (stderr, "%f ", (lacontr->baseTri)->coefs[i]);
	}
      fprintf (stderr, "\n");


    }
  else
    {

      /* compute the separation distance 'dmin' of the knots */

      dmin = MAXDOUBLE;
      for (i = 0; i < knotnum; i++)
	{
	  xi = (locPoints->x)[knotidx[i]];
	  yi = (locPoints->y)[knotidx[i]];
	  for (j = 0; j < knotnum; j++)
	    {
	      if (i == j)
		continue;
	      xj = (locPoints->x)[knotidx[j]];
	      yj = (locPoints->y)[knotidx[j]];
	      dx = xi - xj;
	      dy = yi - yj;
	      d = dx * dx + dy * dy;
	      if (d < dmin)
		dmin = d;
	    }
	}
      dmin = sqrt (dmin);







      fprintf (stderr,
	       "\n\nAnother hybrid local approximation computed (no.%i)",
	       ++NUM);



      /* details about RBF knots */

      fprintf (stderr, "\n\nThe number of RBF knots: %i\n", knotnum);
      fprintf (stderr,
	       "Separation distance %f, delta: %f, ratio of both: %f\n", dmin,
	       delta, dmin / delta);
      fprintf (stderr, "Actually used hybrid min_sing_value: %f\n",
	       1.0 / svmin);
      fprintf (stderr, "\n RBF knots:\n");
      fprintf (stderr, "     x        y\n");
      for (i = 0; i < knotnum; i++)
	fprintf (stderr, "%f %f\n", knotx[i], knoty[i]);


      /* info about the hybrid approximation */

      fprintf (stderr, "\n\nCoefficients of the hybrid function\n");
      fprintf (stderr, " (a) BB coefficients of the polynomial part:");
      for (i = 0; i < poly_dim; i++)
	{
	  if (i % 5 == 0)
	    fprintf (stderr, "\n");
	  fprintf (stderr, "%f ", coefs[i]);
	}
      fprintf (stderr, "\n");
      fprintf (stderr, " (b) coefficients of the RBF part:");
      for (i = poly_dim; i < dim; i++)
	{
	  if ((i - poly_dim) % 5 == 0)
	    fprintf (stderr, "\n");
	  fprintf (stderr, "%f ", coefs[i]);
	}
      fprintf (stderr, "\n");




    }

  fprintf (stderr,
	   "\n\n*********************************************************************\n");

#endif


}


#ifndef HYBRID_ONLY


void
init_rbf_loc_appr (void *lrbfacontr_void)
{
  LRBFACONTROL *lrbfacontr = (LRBFACONTROL *) lrbfacontr_void;
  LACONTROL *lacontr = lrbfacontr->lacontr;
  LSCONTROL *lscontr = lrbfacontr->lscontr;
  LOCALDATA *locKnots;
  int i, max_knotnum;
  int max_loc_dim = lrbfacontr->max_loc_dim;
  int max_poly_dim =
    (lacontr->starting_degree + 1) * (lacontr->starting_degree + 2) / 2;
  int max_number;

  /* initialize local polynomial controls, which also initializes
     local search */

  lacontr->lscontr = lscontr;

  lacontr->max_loc_dim = lrbfacontr->max_loc_dim + 28;

  init_poly_loc_appr (lacontr);

  lrbfacontr->locale->eval = &eval_rbf;

  /* initialize arrays for thinning */

  max_number = (lscontr->locPoints)->max_number;

  lrbfacontr->squared_distance =
    (double **) malloc (max_number * sizeof (double *));

  if (lrbfacontr->squared_distance == NULL)
    {
      fprintf (stderr, "error: memory allocation failure [init_rbf_loc_appr]\n");
      exit (-1);
    }

  for (i = 0; i < max_number; i++)
    {

      (lrbfacontr->squared_distance)[i] =
	(double *) malloc (max_number * sizeof (double));

      if ((lrbfacontr->squared_distance)[i] == NULL)
	{
	  fprintf (stderr, "error: memory allocation failure [init_rbf_loc_appr]\n");
	  exit (-1);
	}

    }


  lrbfacontr->bad_dist = (int **) malloc (max_number * sizeof (int *));

  if (lrbfacontr->bad_dist == NULL)
    {
      fprintf (stderr, "error: memory allocation failure [init_rbf_loc_appr]\n");
      exit (-1);
    }

  for (i = 0; i < max_number; i++)
    {

      (lrbfacontr->bad_dist)[i] = (int *) malloc (max_number * sizeof (int));

      if ((lrbfacontr->bad_dist)[i] == NULL)
	{
	  fprintf (stderr, "error: memory allocation failure [init_rbf_loc_appr]\n");
	  exit (-1);
	}

    }

  lrbfacontr->bad_point_index = (int *) malloc (max_number * sizeof (int));

  if (lrbfacontr->bad_point_index == NULL)
    {
      fprintf (stderr, "error: memory allocation failure [init_rbf_loc_appr]\n");
      exit (-1);
    }

  lrbfacontr->permute = (int *) malloc (max_number * sizeof (int));

  if (lrbfacontr->permute == NULL)
    {
      fprintf (stderr, "error: memory allocation failure [init_rbf_loc_appr]\n");
      exit (-1);
    }



  /* allocate memory for local RBF knots */

  locKnots = lrbfacontr->locKnots = (LOCALDATA *) malloc (sizeof (LOCALDATA));

  if (locKnots == NULL)
    {
      fprintf (stderr, "error: memory allocation failure [lrbfacontr: locKnots]\n");
      exit (-1);
    }

  locKnots->max_number = max_loc_dim;

  locKnots->x = (double *) malloc (max_loc_dim * sizeof (double));

  if (locKnots->x == NULL)
    {
      fprintf (stderr,
	       "error: memory allocation failure [lrbfacontr: locKnots->x]\n");
      exit (-1);
    }

  locKnots->y = (double *) malloc (max_loc_dim * sizeof (double));

  if (locKnots->y == NULL)
    {
      fprintf (stderr,
	       "error: memory allocation failure [lrbfacontr: locKnots->y]\n");
      exit (-1);
    }

  /* locKnots->z not needed since we only do computations with
     the collocation matrix!!!
     HOWEVER, we do allocate it to be able to send locKnots
     to compute_poly_loc_appr */

  locKnots->z = (double *) malloc (max_loc_dim * sizeof (double));

  if (locKnots->z == NULL)
    {
      fprintf (stderr,
	       "error: memory allocation failure [lrbfacontr: locKnots->z]\n");
      exit (-1);
    }





  /* initialize statistics */

  lrbfacontr->max_delta = 0;
  lrbfacontr->min_delta = MAXDOUBLE;

  max_knotnum = lrbfacontr->max_knotnum = lrbfacontr->max_loc_dim;

  lrbfacontr->knotnum_stat =
    (int *) malloc ((max_knotnum + 1) * sizeof (int));

  if (lrbfacontr->knotnum_stat == NULL)
    {
      fprintf (stderr,
	       "error: memory allocation failure [lrbfacontr->knotnum_stat]\n");
      exit (-1);
    }

  for (i = 0; i <= max_knotnum; i++)
    (lrbfacontr->knotnum_stat)[i] = 0;

  lrbfacontr->coefs =
    (double *) malloc ((max_loc_dim + max_poly_dim) * sizeof (double));

  if (lrbfacontr->coefs == NULL)
    {
      fprintf (stderr, "error: memory allocation failure [lrbfacontr: coefs]\n");
      exit (-1);
    }


  /* initialize max_cond */

  lrbfacontr->max_cond = -MAXDOUBLE;


#ifdef USE_LAPACK_LSE

  /* allocate LSE structure */

  lrbfacontr->lse = (LSE *) malloc (sizeof (LSE));

  if (lrbfacontr->lse == NULL)
    {
      fprintf (stderr, "error: memory allocation failure [lrbfacontr->lse]\n");
      exit (-1);
    }

  (lrbfacontr->lse)->A =
    (double **) malloc ((lscontr->locPoints)->max_number * sizeof (double *));

  if ((lrbfacontr->lse)->A == NULL)
    {
      fprintf (stderr, "error: memory allocation failure [lrbfacontr: lse->A]\n");
      exit (-1);
    }

  for (i = 0; i < (lscontr->locPoints)->max_number; i++)
    {

      ((lrbfacontr->lse)->A)[i] =
	(double *) malloc ((max_loc_dim + max_poly_dim) * sizeof (double));

      if (((lrbfacontr->lse)->A)[i] == NULL)
	{
	  fprintf (stderr,
		   "error: memory allocation failure [lrbfacontr: lse->A[i]]\n");
	  exit (-1);
	}

    }


  (lrbfacontr->lse)->B =
    (double **) malloc ((max_loc_dim + max_poly_dim) * sizeof (double *));

  if ((lrbfacontr->lse)->B == NULL)
    {
      fprintf (stderr, "error: memory allocation failure [lrbfacontr: lse->B]\n");
      exit (-1);
    }

  for (i = 0; i < max_loc_dim + max_poly_dim; i++)
    {

      ((lrbfacontr->lse)->B)[i] =
	(double *) malloc (max_poly_dim * sizeof (double));

      if (((lrbfacontr->lse)->B)[i] == NULL)
	{
	  fprintf (stderr,
		   "error: memory allocation failure [lrbfacontr: lse->B[i]]\n");
	  exit (-1);
	}

    }


  (lrbfacontr->lse)->coefs = lrbfacontr->coefs;

  (lrbfacontr->lse)->d = (double *) malloc (max_poly_dim * sizeof (double));

  if ((lrbfacontr->lse)->d == NULL)
    {
      fprintf (stderr, "error: memory allocation failure [lrbfacontr: lse->d]\n");
      exit (-1);
    }

  for (i = 0; i < max_poly_dim; i++)
    ((lrbfacontr->lse)->d)[i] = 0.0;

  (lrbfacontr->lse)->baseTri =
    init_baseTri (lacontr->starting_degree, (lrbfacontr->lse)->coefs);

  /* (lrbfacontr->lse)->baseTri->max_dim = max_loc_dim + max_poly_dim; */

  fprintf (stderr, "\n\nUsing LSE from LAPACK\n\n");

#else /* not USE_LAPACK_LSE */

  /* switch to computing the full SVD for the polynomial collocation matrix since we
     need it in this case */

  lacontr->locMatr->type = 'A';

  fprintf (stderr, "\n\nUsing LSE with SVD null space\n\n");

#endif /* not USE_LAPACK_LSE */




}


void
free_rbf_loc_appr (void *lrbfacontr_void)
{
  LRBFACONTROL *lrbfacontr = (LRBFACONTROL *) lrbfacontr_void;
  int i;

  int max_number = ((lrbfacontr->lscontr)->locPoints)->max_number;
  int max_loc_dim = lrbfacontr->max_loc_dim;
  LACONTROL *lacontr = lrbfacontr->lacontr;
  int max_poly_dim =
    (lacontr->starting_degree + 1) * (lacontr->starting_degree + 2) / 2;



#ifdef USE_LAPACK_LSE

  free_baseTri ((lrbfacontr->lse)->baseTri);
  free ((lrbfacontr->lse)->baseTri);

  free ((lrbfacontr->lse)->d);


  for (i = 0; i < max_loc_dim + max_poly_dim; i++)
    free (((lrbfacontr->lse)->B)[i]);

  free ((lrbfacontr->lse)->B);

  for (i = 0; i < max_number; i++)
    free (((lrbfacontr->lse)->A)[i]);

  free ((lrbfacontr->lse)->A);

  free (lrbfacontr->lse);


#else /* not USE_LAPACK_LSE */

#endif /* not USE_LAPACK_LSE */


  free (lrbfacontr->coefs);

  free (lrbfacontr->knotnum_stat);

  free ((lrbfacontr->locKnots)->x);
  free ((lrbfacontr->locKnots)->y);
  free ((lrbfacontr->locKnots)->z);

  free (lrbfacontr->locKnots);

  free (lrbfacontr->permute);

  free (lrbfacontr->bad_point_index);

  for (i = 0; i < max_number; i++)
    free ((lrbfacontr->bad_dist)[i]);

  free (lrbfacontr->bad_dist);

  for (i = 0; i < max_number; i++)
    free ((lrbfacontr->squared_distance)[i]);

  free (lrbfacontr->squared_distance);

  free_poly_loc_appr (lrbfacontr->lacontr);

}




/* using local least squares RBF approximations instead of polynomials;
 num: the number of local data points, 
 xx,yy,zz: the coordinates of the points (scaled to [0,1]^2!!!),
 Rx,Ry,Sx,Sy,Tx,Ty: the vertices of the triangle, 
 a: pointer to the array of Bezier coefficients of the polynomial fit
    to the RBF approximation; 
    COMMENT: if 'compute_poly_loc_appr' is called before 'compute_hybrid_loc_appr',
    'a' contains the BB coefs of the spr local polynomial in the beginning */

void
compute_rbf_loc_appr (void *data_void, void *lcontr_void)
{
  TSFIT_DATA *data = (TSFIT_DATA *) data_void;
  LRBFACONTROL *lrbfacontr = (LRBFACONTROL *) lcontr_void;

  LACONTROL *lacontr = lrbfacontr->lacontr;
  LSCONTROL *lscontr = lrbfacontr->lscontr;
  LOCALDATA *locPoints = lscontr->locPoints;
  LOCALDATA *locKnots = lrbfacontr->locKnots;
  TRIANGLE *triangle = lrbfacontr->locale->triangle;
  BBTRI *baseTri = lacontr->baseTri;


#ifdef USE_LAPACK_LSE
  LSE *lse = lrbfacontr->lse;
#endif

  double *xx = locPoints->x;
  double *yy = locPoints->y;

  int max_knotnum = lrbfacontr->max_loc_dim;

  int i, j;

  int num;			/* the number of local points */

  int knotnum;			/* the number of RBF knots */


  int poly_degree;		/* = baseTri->degree as it will be set by 'adapt_poly_degree' */
  int poly_dim;			/* = baseTri->dim as it will be set by 'adapt_poly_degree' */


#ifndef USE_LAPACK_LSE
  int rest_dim;			/* = knotnum - poly_dim after knotnum is known */
#endif

  double delta;			/* scaling parameter for the RBF */
  double max_dist = 0.0;
  double d, diffx, diffy;

  int dim;			/* total number of basis functions, polynomial
				   and non-polynomial */

  /* variables for thinning */

  double separ_tol, squared_separ_dist_of_points = MAXDOUBLE;
  double **squared_distance = lrbfacontr->squared_distance;
  int **bad_dist = lrbfacontr->bad_dist;
  int *bad_point_index = lrbfacontr->bad_point_index;
  int *permute = lrbfacontr->permute;
  int max_bad;			/* current maximal 'bad_point_index' */
  double dxx, dyy, dmin_tmp, imin_tmp = 0;
  int tmp_int, tt, nrem;
  int thin = 0;			/* thinning flag */






  /* link baseTri->triangle */

  baseTri->triangle = triangle;


  /* choose points for local approximation */

  choose_loc_points (data, lrbfacontr->lscontr, triangle->xc, triangle->yc,
		     triangle->diam);

  knotnum = num = locPoints->number;	/* initially all points as potential knots */


  /*  compute the scaling parameter 'delta' 
     (we first compute the maximum distance between points
     and then multiply with the coefficient 'lrbfacontr->delta_coef') */


  for (i = 0; i < num; i++)
    {
      for (j = 0; j < num; j++)
	{
	  diffx = xx[i] - xx[j];
	  diffy = yy[i] - yy[j];

	  d = diffx * diffx + diffy * diffy;

	  if (d > max_dist)
	    {
	      max_dist = d;
	    }
	}
    }

  max_dist = sqrt (max_dist);

  delta = lrbfacontr->delta_coef * max_dist;



#ifdef PRINT_LOCAL_INFO

  fprintf (stderr,
	   "\n*********************************************************************\n\n");
  fprintf (stderr, "\nTriangle:     x        y\n");
  fprintf (stderr, "          %f %f\n          %f %f\n          %f %f\n",
	   triangle->x1, triangle->y1,
	   triangle->x2, triangle->y2, triangle->x3, triangle->y3);



  /* info about local points */

  fprintf (stderr, "\n\nThe number of local points: %i\n", num);
  fprintf (stderr, "Center of the triangle: (%f,%f), disk diameter: %f\n",
	   triangle->xc, triangle->yc, lscontr->diam);
  fprintf (stderr, "Maximal distance between points: %f\n", max_dist);
  fprintf (stderr, "\n Local points:\n");
  fprintf (stderr, "     x        y        z\n");
  for (i = 0; i < num; i++)
    fprintf (stderr, "%f %f %f\n", xx[i], yy[i], zz[i]);


#endif


  /* set the (squared) separation tolerance;
     changed delta to max_dist since various RBFs like different deltas while separ_tol is
     solely responsible for the choice of local knots. On the other hand, if we come later to
     _adaptive_ choice of delta for local data, then  'separ_tol = delta / lrbfacontr->separ_par' 
     will seem more reasonable!! */

  /* separ_tol = delta / lrbfacontr->separ_par; */

  separ_tol = max_dist / lrbfacontr->separ_par;
  separ_tol = separ_tol * separ_tol;


  /* compute the squared distances between pairs of local points 'squared_distance',
     find the pairs with bad distances between them 'bad_dist',
     for each point, compute the number of the too close neighbors 'bad_point_index[i]'
     and compute the squared separation distance 'squared_separ_dist_of_points' */


  for (i = 0; i < num; i++)
    {
      bad_dist[i][i] = 0;
      squared_distance[i][i] = 0.0;
      bad_point_index[i] = 0;
    }


  for (i = 1; i < num; i++)
    for (j = 0; j < i; j++)
      {

	dxx = xx[i] - xx[j];
	dyy = yy[i] - yy[j];

	d = squared_distance[i][j]
	  = squared_distance[j][i] = dxx * dxx + dyy * dyy;

	if (d < separ_tol)
	  {
	    bad_dist[i][j] = bad_dist[j][i] = 1;
	    bad_point_index[i]++;
	    bad_point_index[j]++;
	  }
	else
	  bad_dist[i][j] = bad_dist[j][i] = 0;

	if (d < squared_separ_dist_of_points)
	  squared_separ_dist_of_points = d;
      }


#ifdef PRINT_LOCAL_INFO
  fprintf (stderr,
	   "\nSeparation distance of local points: %f vs %f allowed\n",
	   sqrt (squared_separ_dist_of_points), sqrt (separ_tol));
#endif


  /* THINNING */




  /*   1) first step: succesively remove points with the highest 
     'bad_point_index[i]' to ensure that the separation distance is OK, 
     according to our parameter 'lrbfacontr->separ_par' */



  if (squared_separ_dist_of_points < separ_tol)
    {
      /* otherwise all points will be candidate RBF knots
         since the separation distance  is OK */

      thin = 1;


      /* initial sorting (by insertion) of the local points: create 'permute',
         by ordering the points w.r.t. 'bad_point_index'  */

      permute[0] = 0;

      for (i = 1; i < num; i++)
	{


	  tmp_int = bad_point_index[i];

	  for (j = i - 1; (j >= 0 && tmp_int < bad_point_index[permute[j]]);
	       j--)
	    {
	      permute[j + 1] = permute[j];
	    }

	  permute[j + 1] = i;

	}



      /*  maximal 'bad_point_index' */

      max_bad = bad_point_index[permute[knotnum - 1]];

      while (max_bad > 0)
	{


	  /* remove at most 'max_bad' points for which 
	     (bad_point_index == max_bad);
	     after this loop 'nrem' is the number of removed points */

	  for (nrem = 0;
	       nrem < max_bad
	       && bad_point_index[permute[knotnum - 1]] == max_bad; nrem++)
	    knotnum--;

	  /* update 'bad_point_index' for the remaining candidates */

	  for (i = 0; i < knotnum; i++)
	    for (j = knotnum; j < knotnum + nrem; j++)
	      if (bad_dist[permute[i]][permute[j]])
		bad_point_index[permute[i]]--;


	  /* update (re-sort) 'permute' for the remaining candidates */


	  for (i = 1; i < knotnum; i++)
	    {


	      tt = permute[i];
	      tmp_int = bad_point_index[tt];

	      for (j = i - 1; j >= 0 && tmp_int < bad_point_index[permute[j]];
		   j--)
		{
		  permute[j + 1] = permute[j];
		}

	      permute[j + 1] = tt;

	    }



	  /* update 'max_bad' for the remaining candidates */

	  max_bad = bad_point_index[permute[knotnum - 1]];

	}


#ifdef PRINT_LOCAL_INFO
      if (knotnum > max_knotnum)
	{
	  fprintf (stderr,
		   "\nNumber of candidate knots after the first step of thinning");
	  fprintf (stderr,
		   "\n(enforcing separation distance): %i vs. %i allowed\n",
		   knotnum, lrbfacontr->max_loc_dim);
	  fprintf (stderr, "\n Candidate knots:\n");
	  fprintf (stderr, "     x        y\n");
	  for (i = 0; i < knotnum; i++)
	    fprintf (stderr, "%f %f\n", xx[permute[i]], yy[permute[i]]);
	  fprintf (stderr, "\nSECOND STEP OF THINNIG IS NEEDED\n");
	}
      else
	fprintf (stderr, "\nONLY FIRST STEP OF THINNIG IS NEEDED\n");
#endif

    }
  else if (knotnum > max_knotnum)
    {				/* initialize 'permute' if the second step 
				   is needed without the first step */
      thin = 1;
      for (i = 0; i < knotnum; i++)
	permute[i] = i;
    }



  /* 2) second step:  if there remain too many knots, reduce their
     number, again trying to decrease the separation distance. (Compare Floater/Iske.)
     Actually we should expect to avoid this step in almost all cases if 
     the separation distance parameter 'separ_par' is not too high */

  while (knotnum > max_knotnum)
    {

      /* find separation distance and the index of a knot where
         it is attained */

      dmin_tmp = MAXDOUBLE;

      for (i = 0; i < knotnum; i++)
	for (j = 0; j < i; j++)
	  {

	    d = squared_distance[permute[i]][permute[j]];

	    if (d < dmin_tmp)
	      {
		dmin_tmp = d;
		imin_tmp = i;
	      }
	  }

      /* remove this knot */

      knotnum--;

      for (i = imin_tmp; i < knotnum; i++)
	permute[i] = permute[i + 1];

    }



  /* store the selected knots in 'locKnots' */

  locKnots->number = knotnum;

  if (thin)
    for (i = 0; i < knotnum; i++)
      {
	(locKnots->x)[i] = xx[permute[i]];
	(locKnots->y)[i] = yy[permute[i]];
      }
  else
    for (i = 0; i < knotnum; i++)
      {
	(locKnots->x)[i] = xx[i];
	(locKnots->y)[i] = yy[i];
      }

#ifdef PRINT_LOCAL_INFO
  if (thin)
    {
      fprintf (stderr,
	       "\nFinal number of knots after thinning: %i vs. %i allowed\n",
	       knotnum, lrbfacontr->max_loc_dim);
      fprintf (stderr, "\n Knots:\n");
      fprintf (stderr, "     x        y\n");
      for (i = 0; i < knotnum; i++)
	fprintf (stderr, "%f %f\n", (locKnots->x)[i], (locKnots->y)[i]);
    }
  else
    {
      fprintf (stderr,
	       "\nNO THINNING NEEDED: All local points become RBF knots: ");
      fprintf (stderr, "%i vs. %i allowed\n", knotnum,
	       lrbfacontr->max_loc_dim);
    }
#endif

  /* if the flag 'interp_only' is on, we throw away all other local points and do
     interpolation on knots */

  if (lrbfacontr->interp_only)
    {
      if (thin)
	for (i = 0; i < knotnum; i++)
	  (locKnots->z)[i] = (locPoints->z)[permute[i]];
      else
	for (i = 0; i < knotnum; i++)
	  (locKnots->z)[i] = (locPoints->z)[i];
      locPoints = locKnots;
      num = knotnum;
    }



  /* polynomials-on-the-knots computations */

  adapt_poly_degree (locKnots, lacontr);

  poly_degree = baseTri->degree;
  dim = poly_dim = baseTri->dim;	/* both set by the above call of 'adapt_poly_degree' */



  /* polynomial degree statistics */

  (lacontr->degree_stat)[baseTri->degree]++;

#ifdef PRINT_LOCAL_INFO
  fprintf (stderr,
	   "\nPolynomial degree adapted to the knots:\n poly_degree=%i, poly_dim=%i\n",
	   poly_degree, poly_dim);
#endif



#ifdef USE_LAPACK_LSE


  /*** solve the linear equality-constrained least squares problem (LSE)
       using the routine DGGLSE of LAPACK ***/

  /* initialize the vertices, degree and dim of lse->baseTri
     (Actually we can use the current baseTri instead, can't we?
     No,  since the pointer baseTri->coefs' is set equal 
     to 'lacontr->coefs' in 'init_poly_loc_appr'. -- Should this be fixed?) */


  lse->baseTri->triangle = triangle;
  lse->baseTri->degree = poly_degree;
  lse->baseTri->dim = poly_dim;

  /* fill in the matrix 'lse->A' */

  fill_BBbasis_matr (lse->A, poly_degree, lse->baseTri->triangle,
		     locPoints->number, locPoints->x, locPoints->y,
		     lacontr->trinom);

  for (i = 0; i < knotnum; i++)
    extend_hybrid_matr ((locKnots->x)[i], (locKnots->y)[i], delta,
			lrbfacontr->basis_function, dim++, lse->A, num,
			locPoints);



  /* fill in the matrix 'lse->B' (we use the same 'lse->baseTri' as for 'A') */


  fill_BBbasis_matr ((lse->B) + poly_dim, poly_degree, lse->baseTri->triangle,
		     locKnots->number, locKnots->x, locKnots->y,
		     lacontr->trinom);

  for (i = 0; i < poly_dim; i++)
    for (j = 0; j < poly_dim; j++)
      (lse->B)[i][j] = 0.0;



  /* call the solver for the linear equality-constrained 
     least squares problem (LSE) */

  LSE_solver (lse->coefs, num, knotnum + poly_dim, poly_dim,
	      lse->A, lse->B, locPoints->z, lse->d);

#else /* not USE_LAPACK_LSE */

  /** We solve the linear equality-constrained least squares problem (LSE)
           min_x ||Ax-c|| subject to  P_K^T x_K = 0,
	   where x = [x_P x_K]^T, 
	   x_P and x_K being polynomial and RBF coefficients, respectively,
	   A = [P_Xi C_{K,Xi}],  
	   P_Xi and P_K are the polynomial collocation matrices at
               all local points Xi and knots K, respectively, 
           C_{K,Xi} is the RBF collocation matrix
  by the null space method using singular value decomposition **/


  /* In case poly_degree == 0 we must compute the SVD of the polynomials-on-knots matrix P_K
     since this is not done by the above 'adapt_poly_degree' call */

  if (poly_degree == 0)
    {

      fill_BBbasis_matr (lacontr->locMatr->A, 0, lacontr->baseTri->triangle,
			 locKnots->number, locKnots->x, locKnots->y,
			 lacontr->trinom);

      lacontr->locMatr->m = knotnum;
      lacontr->locMatr->n = 1;

      compute_svd (lacontr->locMatr);
    }




  /* fill in the polynomials-on-locPoints part P_Xi of the matrix A.
     It would be difficult to extend the polynomials-on-knots matrix
     because of thinning.
     It 'interp_only' is on, then locPoints and locKnots are the same 
     -- also in z-values -- see above */

  if (!lrbfacontr->interp_only)
    fill_BBbasis_matr (lacontr->locMatr->A, poly_degree,
		       lacontr->baseTri->triangle, locPoints->number,
		       locPoints->x, locPoints->y, lacontr->trinom);


  /* fill in the RBF part C_{K,Xi} of the matrix */

  for (i = 0; i < knotnum; i++)
    extend_hybrid_matr ((locKnots->x)[i], (locKnots->y)[i], delta,
			lrbfacontr->basis_function, dim++,
			lacontr->locMatr->A, num, locPoints);

  /* multiply C_{K,Xi} with U_2 (a part of the U-matrix of the SVD of P_K) still stored in 
     lacontr->locMatr->ut (in transposed form, see LAPACK-based 'compute_svd' in 
     "linalg.c"), and overwrite the corresponding part of lacontr->locMatr->a */

  rest_dim = knotnum - poly_dim;

  {
    double c[num * rest_dim];
    double *start = c;



    /* matrix multiplication */

    m_times_mt (num, rest_dim, knotnum,
		lacontr->locMatr->a + poly_dim, lacontr->locMatr->max_n,
		lacontr->locMatr->Ut[poly_dim], lacontr->locMatr->max_m,
		c, rest_dim);



    for (i = 0; i < num; i++, start += rest_dim)
      memcpy (lacontr->locMatr->A[i] + poly_dim, start,
	      rest_dim * sizeof (double));


  }

  /* compute SVD of [P_Xi C_{K,Xi}*Q_2] */

  lacontr->locMatr->n = knotnum;	/* correct the dimensions of the matrix */
  lacontr->locMatr->m = num;

  lacontr->locMatr->type = 'O';	/* to keep lacontr->locMatr->ut unchanged 
				   since we will need it again below! */


  compute_svd (lacontr->locMatr);

#ifdef CHECK_NUM_STABILITY

  {
    double sv_max = -MAXDOUBLE;
    double sv_min = MAXDOUBLE;

    for (i = 0; i < knotnum; i++)
      {
	sv_max = max (sv_max, lacontr->locMatr->sv[i]);
	sv_min = min (sv_min, lacontr->locMatr->sv[i]);

	/* to avoid overflow since we do not control min. sing. value */
	sv_min = max (sv_min, 1e-50);

      }

    lrbfacontr->max_cond = max (lrbfacontr->max_cond, sv_max / sv_min);


  }


#endif


  /* solve unconstrained least squares using SVD,
     and transform its solution to the solution of the original problem */


  LS_using_svd (lacontr->locMatr, locPoints->z, lacontr->coefs);
  /* we store the y-coefficients in lacontr->coefs,
     which allows to use later lacontr->baseTri for the
     evaluation! -- Should we fix this, i.e. make 
     the evaluation of the polynomial more flexible? */





  /* first poly_dim coefs are the same */

  memcpy (lrbfacontr->coefs, lacontr->coefs, poly_dim * sizeof (double));

  /* the rest of the vector y_coefs is multiplied by the matrix U_2 from the left to
     obtain the rest of x */


  mt_times_v (rest_dim, knotnum,
	      lacontr->locMatr->Ut[poly_dim], lacontr->locMatr->max_m,
	      lacontr->coefs + poly_dim, lrbfacontr->coefs + poly_dim);





  /* back to 'A' since it is needed for the next SVD of the polynomial matrix */

  lacontr->locMatr->type = 'A';

#endif /* not USE_LAPACK_LSE */




  /* store the parameters of the current approximation */

  lrbfacontr->delta = delta;


  /* update the info */

  lrbfacontr->max_delta = max (delta, lrbfacontr->max_delta);
  lrbfacontr->min_delta = min (delta, lrbfacontr->min_delta);
  (lrbfacontr->knotnum_stat)[knotnum]++;





/* fprintf(stderr,"\n4444\n"); */

#ifdef PRINT_LOCAL_INFO

  /* info about the rbf approximation */

  fprintf (stderr, "\n\nCoefficients of the rbf function\n");
  fprintf (stderr, " (a) BB coefficients of the polynomial part:");
  for (i = 0; i < poly_dim; i++)
    {
      if (i % 5 == 0)
	fprintf (stderr, "\n");
      /* fprintf (stderr, "%f ", (lse->coefs)[i]); */
      fprintf (stderr, "%f ", (lrbfacontr->coefs)[i]);
    }
  fprintf (stderr, "\n");
  fprintf (stderr, " (b) coefficients of the RBF part:");
  for (i = poly_dim; i < dim; i++)
    {
      if ((i - poly_dim) % 5 == 0)
	fprintf (stderr, "\n");
      /* fprintf (stderr, "%f ", (lse->coefs)[i]); */
      fprintf (stderr, "%f ", (lrbfacontr->coefs)[i]);
    }
  fprintf (stderr, "\n");

  fprintf (stderr,
	   "\n\n*********************************************************************\n");


#endif


}

#endif /* not HYBRID_ONLY */

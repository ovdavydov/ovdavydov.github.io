#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "tsfit.h"

int
main ()
{
  TSFIT_DATA data;
  TSFIT_LOCAL_METHOD local_method;
  TSFIT_GLOBAL_METHOD global_method;

  FILE *fp;
  int num, n;
  double *px, *py, *pz, *xx, *yy, *zz;
  double comp_cputime;
  int cl;

  fprintf (stderr, "\n\nTests with Franke's function f1 evaluated at 100 points ds3.\n\n");

  fprintf (stderr, "\n\nTSFIT Example 4: local hybrid approximation using various RBFs and 5x5 C2 spline\n");
  fprintf (stderr, "\nLocal hybrid method described in ");
  fprintf (stderr, "\nDavydov, Morandi & Sestini,  Local hybrid approximation for scattered \
         \ndata fitting with bivariate splines, preprint, August 2004.");
  fprintf (stderr, "\n(See numerical results in Section 5.1.)");
  fprintf (stderr, "\nC2 spline method described in ");
  fprintf (stderr, "\nDavydov & Zeilfelder, Scattered data fitting by direct extension\
        \nof local polynomials to bivariate splines, Advances in Comp. Math. 21 (2004), 223-271.");

  /*** read the data ***/


  /* open the file containing data points */

  fp = fopen ("f1_ds3", "r");

  if (fp == NULL)
    {
      fprintf (stderr, "error: file opening failure\n");
      exit (-1);
    }

  /* read the number of data points from the first line of the data file fp */

  fscanf (fp, "%d", &num);

  /* allocate memory for x, y, z arrays */


  if ((px = xx =
       (double *) malloc (num * sizeof (double))) == NULL)
    {
      fprintf (stderr, "error: memory allocation failure [x]\n");
      exit (-1);
    }
  if ((py = yy =
       (double *) malloc (num * sizeof (double))) == NULL)
    {
      fprintf (stderr, "error: memory allocation failure [y]\n");
      exit (-1);
    }
  if ((pz = zz =
       (double *) malloc (num * sizeof (double))) == NULL)
    {
      fprintf (stderr, "error: memory allocation failure [z]\n");
      exit (-1);
    }


  /* fill in the x, y, z arrays */


  for (n = 0; n < num; n++)
    fscanf (fp, "%lf %lf %lf", px++, py++, pz++);

  fclose (fp);

  /*** set up the data management structure ***/
  
  init_tsfit_data (&data, num, xx, yy, zz);


  fprintf (stderr, "\n\n(a) multiquadric\n\n");

  /*** determine the local method ***/


  /** choose the type of the local method **/ 

  set_local_method_type (&local_method, "Hybrid");
  

  /** set parameters of the local method **/

  /* local search parameters */
  
  set_min_points (&local_method, 16);
  set_max_points (&local_method, 100);

  /* local hybrid approximation parameters */
 
  set_radial_basis_function (&local_method, 0, &rbf_MQ);
  set_scaling_coef (&local_method, 0.4);
  set_min_sing_value_hybrid (&local_method, 1.0 / 100000.0);


  /*** determine the global method ***/


  /** choose the type of the global method **/

  set_global_method_type (&global_method, "SpC2d6D2");
  
  /** set parameters of the global method **/
  
  set_D2mesh (&global_method, &data, 5, 5);
  
  

  /*** compute the spline ***/

  cl = clock();    /* reset clock */ 

  tsfit_compute (&data, &global_method, &local_method);
  
  comp_cputime = (double) (clock()-cl) / CLOCKS_PER_SEC;

  fprintf(stderr, "\n\nCOMPUTATION CPUTIME: %1.2e sec\n\n",comp_cputime);


  /*** Evaluation  ***/

  evaluate_grid (0.0, 1.0, 100, 0.0, 1.0, 100, "output4a.txt", &data, &global_method);



  fprintf (stderr, "\n\n(b) inverse multiquadric\n\n");

  /*** determine the local method ***/


  /** reset the local method **/ 

  reset_local_method_type (&local_method, "Hybrid");
  

  /** set parameters of the local method **/

  /* local searching parameters */
  
  set_min_points (&local_method, 16);
  set_max_points (&local_method, 100);

 
  /* local hybrid approximation parameters */
 
  set_radial_basis_function (&local_method, 0, &rbf_IMQ);
  set_scaling_coef (&local_method, 0.5);
  set_min_sing_value_hybrid (&local_method, 1.0 / 10000.0);



  /*** determine the global method ***/

  /** reset the global method **/

  reset_global_method_type (&global_method, "SpC2d6D2");
  
  /** set parameters of the global method **/
  
  set_D2mesh (&global_method, &data, 5, 5);

  /*** compute the spline ***/

  cl = clock();    /* reset clock */ 

  tsfit_compute (&data, &global_method, &local_method);
  
  comp_cputime = (double) (clock()-cl) / CLOCKS_PER_SEC;

  fprintf(stderr, "\n\nCOMPUTATION CPUTIME: %1.2e sec\n\n",comp_cputime);


  /*** Evaluation  ***/

  evaluate_grid (0.0, 1.0, 100, 0.0, 1.0, 100, "output4b.txt", &data, &global_method);



  fprintf (stderr, "\n\n(c) Gaussian\n\n");

  /*** determine the local method ***/


  /** reset the local method **/ 

  reset_local_method_type (&local_method, "Hybrid");
  

  /** set parameters of the local method **/

  /* local searching parameters */
  
  set_min_points (&local_method, 16);
  set_max_points (&local_method, 100);

 
  /* local hybrid approximation parameters */
 
  set_radial_basis_function (&local_method, 0, &rbf_Gauss);
  set_scaling_coef (&local_method, 0.4);
  set_min_sing_value_hybrid (&local_method, 1.0 / 10000.0);



  /*** determine the global method ***/

  /** reset the global method **/

  reset_global_method_type (&global_method, "SpC2d6D2");
  
  /** set parameters of the global method **/
  
  set_D2mesh (&global_method, &data, 5, 5);

  /*** compute the spline ***/

  cl = clock();    /* reset clock */ 

  tsfit_compute (&data, &global_method, &local_method);
  
  comp_cputime = (double) (clock()-cl) / CLOCKS_PER_SEC;

  fprintf(stderr, "\n\nCOMPUTATION CPUTIME: %1.2e sec\n\n",comp_cputime);


  /*** Evaluation  ***/

  evaluate_grid (0.0, 1.0, 100, 0.0, 1.0, 100, "output4c.txt", &data, &global_method);




  fprintf (stderr, "\n\n(d) thin plate spline\n\n");

  /*** determine the local method ***/


  /** reset the local method **/ 

  reset_local_method_type (&local_method, "Hybrid");
  

  /** set parameters of the local method **/

  /* local searching parameters */
  
  set_min_points (&local_method, 16);
  set_max_points (&local_method, 100);

 
  /* local hybrid approximation parameters */
 
  set_radial_basis_function (&local_method, 1, &rbf_TPS);
  set_scaling_coef (&local_method, 2.0);
  set_min_sing_value_hybrid (&local_method, 1.0 / 100000.0);
  set_min_sing_value_poly (&local_method, 0.001); /* nominal value -- since
                                                          no pure polynomial
							  approximations appear */



  /*** determine the global method ***/

  /** reset the global method **/

  reset_global_method_type (&global_method, "SpC2d6D2");
  
  /** set parameters of the global method **/
  
  set_D2mesh (&global_method, &data, 5, 5);

  /*** compute the spline ***/

  cl = clock();    /* reset clock */ 

  tsfit_compute (&data, &global_method, &local_method);
  
  comp_cputime = (double) (clock()-cl) / CLOCKS_PER_SEC;

  fprintf(stderr, "\n\nCOMPUTATION CPUTIME: %1.2e sec\n\n",comp_cputime);


  /*** Evaluation  ***/

  evaluate_grid (0.0, 1.0, 100, 0.0, 1.0, 100, "output4d.txt", &data, &global_method);



  fprintf (stderr, "\n\n(e) Wendland C2 function\n\n");

  /*** determine the local method ***/


  /** reset the local method **/ 

  reset_local_method_type (&local_method, "Hybrid");
  

  /** set parameters of the local method **/

  /* local searching parameters */
  
  set_min_points (&local_method, 16);
  set_max_points (&local_method, 100);

 
  /* local hybrid approximation parameters */
 
  set_radial_basis_function (&local_method, 0, &rbf_Wendland31);
  set_scaling_coef (&local_method, 2.0);
  set_min_sing_value_hybrid (&local_method, 1.0 / 10000.0);



  /*** determine the global method ***/

  /** reset the global method **/

  reset_global_method_type (&global_method, "SpC2d6D2");
  
  /** set parameters of the global method **/
  
  set_D2mesh (&global_method, &data, 5, 5);

  /*** compute the spline ***/

  cl = clock();    /* reset clock */ 

  tsfit_compute (&data, &global_method, &local_method);
  
  comp_cputime = (double) (clock()-cl) / CLOCKS_PER_SEC;

  fprintf(stderr, "\n\nCOMPUTATION CPUTIME: %1.2e sec\n\n",comp_cputime);


  /*** Evaluation  ***/

  evaluate_grid (0.0, 1.0, 100, 0.0, 1.0, 100, "output4e.txt", &data, &global_method);



  /*** Release the memory ***/

  reset_global_method_type (&global_method, NULL);

  reset_local_method_type (&local_method, NULL);

  free_tsfit_data (&data);
  
  free (xx);
  free (yy);
  free (zz);
  

  return 0;
}
